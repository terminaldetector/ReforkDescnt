#!/usr/bin/env python3
"""Freeze one ordinary 9-case TestServer run; --prepare never starts a JVM.

Production is the accepted 5acde891 component overlay on unchanged canonical baseline classes.
Only the faf732ca GameTest source is compiled. No Gradle/Loom/remap task is invoked.
"""
from pathlib import Path
import datetime,hashlib,json,os,re,shutil,signal,subprocess,sys,time,xml.etree.ElementTree as ET,zipfile

ROOT=Path('/workspace/ungravity-v5/ragdoll-angular-20261118')
CANONICAL=Path('/workspace/ungravity-v5/ufo-body-physics')
RUN=ROOT/'work/u13-ragdoll-game-faf732c-launch-v2-20261118'
SOURCE='faf732ca11ffbbf295c286fefd74845d393cc939'
PRODUCTION='5acde8915ee940b8d2c8086511810f112bbe21bf'
ARCHIVE=ROOT/'docs/v8/RAGDOLL_ANGULAR_5ACDE891_FIRST_EVIDENCE_2026-11-18.zip'
ARCHIVE_SHA='1e9fa880be9b09d5357fa6148c3a5c96400a0e630857712c4cc6d3bb5a2747e4'
CAPTURE=Path('/workspace/ungravity-v5/control-core-20261118/work/b2-assembly-game-0bb280a-package-first19-20261118/actual-runtime-inputs.json')
JAVA=Path('/workspace/jdk21-complete')
GT_SOURCE=ROOT/'src/gametest/java/com/terminaldetector/drmd/RagdollGameTests.java'
MAIN=RUN/'overlay-main'
GT=RUN/'overlay-gametest'
RESOURCES=RUN/'gametest-resources'
RUNTIME=RUN/'runtime'
PROD_PREFIXES=[
 'com/terminaldetector/drmd/physics/ragdoll/RagdollRig',
 'com/terminaldetector/drmd/physics/ragdoll/RagdollAngularLimit',
 'com/terminaldetector/drmd/physics/ragdoll/RagdollSimulation',
 'com/terminaldetector/drmd/entity/model/FlightWreckRig',
 'com/terminaldetector/drmd/entity/RagdollEntity']
MARKERS=['U13_CODEC_LIMITED_REAL_TICKS','U13_CODEC_LEGACY_REAL_TICKS','U13_CODEC_OPAQUE_REAL_TICKS']

def sha(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def write(path,value):
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('x') as stream:json.dump(value,stream,indent=2);stream.write('\n')
def files(path):return sorted(p for p in path.rglob('*') if p.is_file()) if path.is_dir() else [path]
def snapshot(paths):
    result={}
    for path in paths:
        assert path.exists(),str(path)
        for child in files(path):result[str(child)]=dict(path=str(child),size=child.stat().st_size,sha256=sha(child))
    return list(result.values())
def verify(rows):
    for row in rows:
        path=Path(row['path']);assert path.is_file() and sha(path)==row['sha256'],str(path)
def source_guard():
    head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
    subprocess.run(['git','diff','--exit-code',SOURCE,'--','src/main','src/test','src/gametest'],cwd=ROOT,check=True,stdout=subprocess.PIPE)
    subprocess.run(['git','diff','--exit-code',PRODUCTION,'--','src/main','src/test'],cwd=ROOT,check=True,stdout=subprocess.PIPE)
    return head

def prepare():
    assert not RUN.exists(),'Never overwrite an earlier proposal or first attempt'
    assert sha(ARCHIVE)==ARCHIVE_SHA,'component evidence archive changed'
    head=source_guard()
    RUN.mkdir(parents=True)
    for path in [MAIN,GT,RESOURCES,RUNTIME]:path.mkdir()
    with zipfile.ZipFile(ARCHIVE) as archive:
        component=json.loads(archive.read('verification/attempt-01/dependencies.json'))
        outputs=json.loads(archive.read('verification/attempt-01/outputs.json'))
        assert component['source_sha']==PRODUCTION
        selected=[]
        for row in outputs:
            relative=row['path'].split('/classes/',1)[1]
            if not any(relative==prefix+'.class' or relative.startswith(prefix+'$') for prefix in PROD_PREFIXES):continue
            data=archive.read('verification/attempt-01/classes/'+relative)
            assert hashlib.sha256(data).hexdigest()==row['sha256']
            target=MAIN/relative;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data);selected.append(relative)
        assert len(selected)==14,selected
        # The old selected unit sources and all production sources remain byte-identical.
        for row in component['changed_sources']:
            path=Path(row['path'])
            if '/src/main/' in str(path) or '/src/test/' in str(path):assert sha(path)==row['sha256'],str(path)
    verify(component['reused_inputs'])
    captured=json.loads(CAPTURE.read_text())
    jars=[];jar_receipts=[]
    for row in captured['classpath']:
        if row['kind']=='directory':continue # replace all B2 project outputs; never load another worker's classes
        assert row['kind']=='file' and row['path'].endswith('.jar'),row['path']
        path=Path(row['path']);actual=sha(path)
        jar_receipts.append(dict(path=str(path),actual_sha256=actual,captured_sha256=row['sha256'],match=actual==row['sha256']))
        assert actual==row['sha256'],'runtime JAR changed from the qualified B2 capture: '+str(path)
        jars.append(path)
    assert len(jars)==103 and captured['mainClass']=='net.fabricmc.devlaunchinjector.Main'
    # Only drmd_gametest registration is replaced. Production drmd metadata/resources are reused.
    manifest=dict(schemaVersion=1,id='drmd_gametest',version='1.0.0',name='U13 ordinary ragdoll component gate',environment='*',
                  entrypoints={'fabric-gametest':['com.terminaldetector.drmd.RagdollGameTests']},
                  depends={'drmd':'*','fabric-gametest-api-v1':'*'})
    write(RESOURCES/'fabric.mod.json',manifest)
    main_manifest=json.loads((CANONICAL/'build/resources/main/fabric.mod.json').read_text())
    assert 'com.terminaldetector.drmd.DescentMod' in main_manifest['entrypoints']['main']
    # EMPTY_STRUCTURE is supplied by the named Fabric GameTest API JAR. No old GT resource
    # directory/manifest, other suite's mixins, unit outputs or other worker outputs is on the CP.
    base_main=CANONICAL/'build/classes/java/main';base_gt=CANONICAL/'build/classes/java/gametest';base_res=CANONICAL/'build/resources/main'
    runtime_cp=[GT,base_gt,RESOURCES,MAIN,base_main,base_res]+jars
    main_group=[MAIN,base_main,base_res];test_group=[GT,base_gt,RESOURCES]
    compile_cp=[MAIN]+[Path(p) for p in component['classpath_entries'][3]]
    assert all(path.exists() for path in compile_cp)
    assert compile_cp[-1]==base_gt
    remap=CANONICAL/'.gradle/loom-cache/remapClasspath.txt'
    log4j=CANONICAL/'.gradle/loom-cache/log4j.xml'
    remap_inputs=[Path(p) for p in remap.read_text().split(os.pathsep) if p]
    assert all(p.is_file() and p.suffix=='.jar' for p in remap_inputs)
    config='commonProperties\n'
    for key,value in [
        ('fabric.development','true'),('fabric.remapClasspathFile',str(remap)),('log4j.configurationFile',str(log4j)),
        ('log4j2.formatMsgNoLookups','true'),('fabric.classPathGroups','::'.join(':'.join(str(p) for p in group) for group in [main_group,test_group]))]:
        config+='\t'+key+'='+value+'\n'
    (RUN/'launch.cfg').write_text(config)
    (RUNTIME/'eula.txt').write_text('eula=true\n')
    (RUNTIME/'server.properties').write_text('level-name=world\nonline-mode=false\nenable-rcon=false\n')
    text=GT_SOURCE.read_text()
    expected=sorted(('RagdollGameTests.'+name).lower() for name in re.findall(r'@GameTest\([^)]*\)\s+public void (\w+)\(',text))
    assert len(expected)==len(set(expected))==9
    new_methods=text[text.index('\t@GameTest('):text.index('\t@GameTest(templateName = EMPTY_STRUCTURE, batchId = "ragdoll-field-default")')]
    assert '.tick(' not in new_methods and '.step(' not in new_methods,'new codecs must use ordinary world callbacks'
    named=[]
    for jar in jars:
        with zipfile.ZipFile(jar) as archive:
            name='net/minecraft/entity/Entity.class'
            if name in archive.namelist():
                data=archive.read(name);assert b'net/minecraft/entity/Entity' in data and data[:4]==b'\xca\xfe\xba\xbe'
                named.append(dict(jar=str(jar),jar_sha256=sha(jar),entry_sha256=hashlib.sha256(data).hexdigest()))
    assert len(named)==1 and named[0]['entry_sha256']=='b08c8053b5936e6fc70a17d9d103878cb439922e37a268d40418fc754a7eab0c'
    compile_command=[str(JAVA/'bin/javac'),'--release','21','-proc:none','-implicit:none','-sourcepath','',
                     '-cp',os.pathsep.join(str(p) for p in compile_cp),'-d',str(GT),str(GT_SOURCE)]
    runtime_command=[str(JAVA/'bin/java'),'-Xmx768m','-Dfile.encoding=UTF-8','-Duser.country','-Duser.language=en','-Duser.variant',
                     '-Dfabric.dli.config='+str(RUN/'launch.cfg'),'-Dfabric.dli.env=server','-Dfabric-api.gametest',
                     '-Dfabric-api.gametest.report-file=reports/gametest-results.xml',
                     '-Dfabric.dli.main=net.fabricmc.loader.impl.launch.knot.KnotServer',
                     '-cp',os.pathsep.join(str(p) for p in runtime_cp),'net.fabricmc.devlaunchinjector.Main','nogui']
    immutable=snapshot([ARCHIVE,CAPTURE,GT_SOURCE,MAIN,RESOURCES,RUN/'launch.cfg',remap,log4j,
                        JAVA/'bin/java',JAVA/'bin/javac',JAVA/'lib/server/libjvm.so',
                        base_main,base_gt,base_res]+jars+compile_cp+remap_inputs)
    write(RUN/'proposal.json',dict(source=SOURCE,production_source=PRODUCTION,metadata_head_at_prepare=head,
        runner_sha256=sha(Path(__file__)),component_archive_sha256=ARCHIVE_SHA,captured_runtime=dict(path=str(CAPTURE),sha256=sha(CAPTURE)),
        component_reused_inputs_unchanged=len(component['reused_inputs']),runtime_jars=jar_receipts,named_entity=named,
        overlay_classes=selected,main_mod_manifest_sha256=sha(base_res/'fabric.mod.json'),test_manifest=manifest,
        main_mod_group=[str(p) for p in main_group],test_mod_group=[str(p) for p in test_group],
        runtime_cp=[str(p) for p in runtime_cp],compile_cp=[str(p) for p in compile_cp],
        compile_command=compile_command,runtime_command=runtime_command,cwd=str(RUNTIME),expected_cases=expected,markers=MARKERS,
        immutable_inputs=immutable,startup_configuration_inputs=snapshot([RUNTIME/'eula.txt',RUNTIME/'server.properties']),compile_timeout_seconds=120,game_timeout_seconds=420,terminate_grace_seconds=10,
        world=str(RUNTIME/'world'),xml=str(RUNTIME/'reports/gametest-results.xml'),
        native_run=False,gradle_run=False,main_compilation=False,unit_run=False,prepared_at_utc=now()))
    print(json.dumps(dict(event='PREPARED_NO_JAVA',source=SOURCE,runner_sha256=sha(Path(__file__)),
                         proposal_sha256=sha(RUN/'proposal.json'),immutable_files=len(immutable),runtime_cp_entries=len(runtime_cp),
                         main_overlay_classes=len(selected),expected_cases=9)),flush=True)

def child(command,kind,timeout):
    log=RUN/(kind+'-first.log')
    write(RUN/(kind+'-start.json'),dict(command=command,cwd=str(RUNTIME),started_at_utc=now(),started_unix_ns=time.time_ns(),timeout_seconds=timeout))
    timed_out=False;killed=False
    with log.open('xb') as stream:
        process=subprocess.Popen(command,cwd=RUNTIME,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
        print(json.dumps(dict(event='JAVA_STARTED',kind=kind,pid=process.pid)),flush=True)
        try:code=process.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            timed_out=True;os.killpg(process.pid,signal.SIGTERM)
            try:code=process.wait(timeout=10)
            except subprocess.TimeoutExpired:killed=True;os.killpg(process.pid,signal.SIGKILL);code=process.wait()
    write(RUN/(kind+'-exit.json'),dict(pid=process.pid,actual_child_exit=code,timed_out=timed_out,forced_kill=killed,closed_at_utc=now()))
    print(json.dumps(dict(event='JAVA_CLOSED',kind=kind,actual_child_exit=code,timed_out=timed_out,forced_kill=killed)),flush=True)
    return code,timed_out,killed

def run():
    assert os.environ.get('U13_RAGDOLL_JAVA_LEASE')=='granted','Explicit root Java lease required'
    proposal=json.loads((RUN/'proposal.json').read_text())
    assert sha(Path(__file__))==proposal['runner_sha256'],'frozen runner changed'
    source_guard();verify(proposal['immutable_inputs']);verify(proposal['startup_configuration_inputs'])
    assert shutil.disk_usage(ROOT).free>=160*1024*1024,'160 MiB first-game guard; do not lower'
    assert not (RUN/'compile-start.json').exists() and not (RUN/'game-start.json').exists(),'preserve the first attempt; no retry'
    assert not any(GT.iterdir()),'new test output directory must be empty'
    assert not (RUNTIME/'world').exists() and not Path(proposal['xml']).exists(),'fresh world and XML required'
    code,timed,killed=child(proposal['compile_command'],'compile',proposal['compile_timeout_seconds'])
    if code or timed or killed:raise SystemExit(code or 1)
    output=snapshot([GT])
    assert sorted(str(Path(row['path']).relative_to(GT)) for row in output)==[
        'com/terminaldetector/drmd/RagdollGameTests$CodecClock.class','com/terminaldetector/drmd/RagdollGameTests.class']
    write(RUN/'fresh-gametest-classes.json',output)
    verify(proposal['immutable_inputs']);verify(proposal['startup_configuration_inputs']);source_guard()
    started_ns=time.time_ns();code,timed,killed=child(proposal['runtime_command'],'game',proposal['game_timeout_seconds'])
    # No additional child may start after this point. All postchecks are Python/file reads only.
    verify(output);verify(proposal['immutable_inputs']);source_guard()
    path=Path(proposal['xml']);cases=[];failures=errors=skips=0;fresh=False
    if path.is_file():
        root=ET.parse(path).getroot();cases=[node.attrib['name'] for node in root.findall('.//testcase')]
        failures=len(root.findall('.//failure'));errors=len(root.findall('.//error'));skips=len(root.findall('.//skipped'));fresh=path.stat().st_mtime_ns>=started_ns
        shutil.copy2(path,RUN/'first-game-results.xml')
    log=(RUN/'game-first.log').read_text(errors='replace');markers={marker:log.count(marker) for marker in MARKERS}
    passed=code==0 and not timed and not killed and fresh and sorted(cases)==proposal['expected_cases'] and failures==errors==skips==0 and all(count==1 for count in markers.values())
    write(RUN/'first-game-outcome.json',dict(source=SOURCE,production_source=PRODUCTION,actual_child_exit=code,timed_out=timed,forced_kill=killed,
        cases=cases,case_count=len(cases),failures=failures,errors=errors,skips=skips,fresh_xml=fresh,markers=markers,
        immutable_inputs_unchanged=True,fresh_classes_unchanged=True,startup_configuration_after=snapshot([Path(row['path']) for row in proposal['startup_configuration_inputs']]),verified_first9=passed,main_compilation=False,gradle_run=False,
        native_run=False,cold_restart=False,completed_at_utc=now()))
    print(json.dumps(dict(event='POSTCHECK',verified_first9=passed,cases=len(cases),failures=failures,errors=errors,skips=skips,markers=markers)),flush=True)
    raise SystemExit(0 if passed else code or 1)

if __name__=='__main__':
    if sys.argv[1:]==['--prepare']:prepare()
    elif sys.argv[1:]==['--run-with-root-java-lease']:run()
    else:raise SystemExit('Use --prepare (no JVM) or --run-with-root-java-lease after explicit root grant')
