# U14 batched observer — implemented source/CPU contract, no Java run

This subject implements only the reviewed diagnostic adapter. Production physics,
solver/damping, floor, initial impulses,32real deaths, ordinary ages1..1000 and.02/20
endpoint criterion remain unchanged. The original failed recorder/source checkpoint,
first overflow/crash receipts and133MBraw SHA`cf48aed0fa3f6506396198a11430194203a9f0b133184ec12c7e8d36cdae75cc`
remain preserved. No retry or new Java process has run for this subject.

## Independent old653 inputs

Canonical source/build outputs may advance independently. This diagnostic must use only
the verified read-only copies under `work/u14-private653-inputs-20261118`:1,108main
class/refmap files,608main resources and154GameTest helper classes,8,625,216bytes total.
[The full source/hash receipt](U14_PRIVATE653_NAMED_INPUTS_2026-11-18.json) is
`8f8c13d2c402c260180baf71ec66f39a99cb08c840b9a7beca0a69239fa36279`.
Every set/file matched the already qualified653proposal before and after copying.
Files are0444/directories0555; no JAR/bootstrap/JDK cache was copied. The two small old
DLI text inputs were also pinned read-only; their referenced JARs still require exact
hash verification. No future canonical class/resource/config may silently replace them.

Python inspection of these private classfiles verifies the same11target methods and
private lifetime field. [The API receipt](U14_BATCH_PRIVATE653_API_2026-11-18.json) is
API metadata evidence only, not compilation or runtime qualification of the new source.

## Actual Java byte adapter and contract

`RagdollTrajectoryOutput` uses only JDK IO/collections/zip. Its queue contains copied
JSONL bytes, UUID strings and scalar counts/times; no World/Entity/Part/callback reference.
Complete gzip members preserve original row order, original numeric strings and schema.
Flush bounds are256rows,8rows of one UUID,8world ticks inclusive and8MiBlogical bytes.
Each row remains<=256KiB. A fixed8MiB+64KiB staging array receives gzip directly;
queued rows are not concatenated or cloned into another full batch, and staging writes
to the unbuffered file without `toByteArray`. The compressed batch length is checked
before append against the unchanged127MiBtrace cap. Scalar queue+encoded staging use
about16.1MiB maximum, plus the current<=256KiB row and small deflater/scalar state.

Counters distinguish offered/observed, persisted, buffered and discarded rows/logical
bytes. Failed unaccepted current rows are counted in discarded output. Reaching the
byte cap never appends the oversized member and never retries. A process crash can
lose only the current<=256row/<=8MiBlogical batch or leave that one compressed member
incomplete. The reader validates its full CRC before crediting any of its rows. No
power-loss durability guarantee is inferred from this process-tail bound.

The actual `RagdollTrajectoryOutputContract.verify()` runs once **before floor/chunks/
drone creation and enrollment**, and is a required precondition of recorder begin.
It exercises original-order/numeric-byte roundtrip, scalar-byte ownership,256row/
8UUID-row/8tick/8MiB flush bounds, lowered synthetic byte budgets for expected row/
staging/trace failure, bounded metadata writes, recorder IO failure and propagation of
an unexpected RuntimeException. These are real authored Java-adapter tests, not a
physics executor. **They are uncompiled/unrun until the new explicit Java lease.**
Failure before this contract passes cannot be reported as a32body game pass.

## Enrollment and expected-failure handoff

Immediately after the real deaths and registered age/lifetime0enrollment, persist
`ragdoll-trajectory-admission.json`: exact admission counts, UUIDs, original perpart
mass/extents/pose/v/L and world clock. Final metadata binds its SHA. This write occurs
before any enrolled physics tick; it no longer depends on normal completion.

The unchanged1MiBmetadata budget is shared by at most512KiBadmission and512KiBfinal
summary. Reasons and violation lists are bounded. On expected recorder cap/IO failure,
the writer returns a first immutable failure code, stops recording and clears its
bounded pending queue. The recorder closes the completed prefix and writes the
NONPASSsummary while it still owns the actual state, then returns normally to the
unchanged production entity tick. The next ordinary fixture callback observes the
failure, performs owned cleanup and fails the GameTest. No entity tick is cancelled,
executed manually or replaced. Normal completion additionally checks final metadata
success before calling `context.complete()`.

Only the recorder's own expected IO/budget failures follow this route. The byte adapter
does not catch RuntimeException or Throwable; arbitrary physics/getter/runtime failures
propagate and retain their original crash path. The metadata guarantee concerns the
cap path with a writable filesystem; actual filesystem failures are bounded best-effort
receipts/logs and cannot be called a successful diagnostic.

## Exactly nine additional wrench scalars

The same three required mixins and11existing engine targets remain; no engine API,
world read, load/ticket or classpath dependency is added. Fix origin at the rig COM at
tick entry, computed relative to its first part to avoid large-coordinate cancellation.
The existing hooks accumulate only these three vectors per actor/worldtick:

1. `contact_wrench_L`: `sum(deltaL_spin + (partCOM_at_contact-origin) cross deltaP)`.
2. `gravity_wrench_L`: `sum((partCOM_before_substep-origin) cross (m*g*substep_dt))`.
3. `position_projection_dL`: `sum(deltaPosition cross (m*v))` from explicit position
   setters, including existing terrain/joint projection, distinct from contact impulse.

The part-step callback passes its existing scalar dt. Perpart endpoint p/v/L already
reconstructs total rig angular momentum about that same origin. The CPU report keeps
state delta, contact, gravity, position projection, actual.998/.994damping contribution
and remaining residual separate. It does **not** assert conservation or suppress old
clamps/fallback residuals. Added runtime data is exactly9doubles; the conservative
JSON allowance remains about325bytes/row/10.4MBlogical for32,000rows. Output cap is not
raised, and compression/CP work is not relabelled hardware/MSPT evidence.

## Required ordinary outcome and CPU checks

The future ordinary run still requires one fresh XML case, zero fail/error/skip,
32,000normal identity ticks and simulation calls,640,000D6part steps,4,096,000joint and
5,760,000terrain calls, age/lifetime0→1000 and unchanged frozen inputs/classes. All17
expected fixture/adapter class outputs must be fresh and manifest-bound. Compile only
the seven diagnostic Java files; no Gradle/main compilation or broad tests.

CPU controls verify complete-member decoding/bounds, no credited rows from an incomplete
tail, eight-UUID-row rejection, missing/nonfinite wrench rejection, independent orbital
projection/damping arithmetic and the Java source handoff boundary. The prior six
support/packing controls remain. These do not substitute for compiling/running Java.

The perpart-independent-flat predicate is explicitly rejected. Reports retain actual
endpoint20motion and conservative rig-level contact/load/pose opportunity, not a sleep
certificate. Zero eligible intervals is honest; no velocity/pose setter or threshold
tuning can manufacture rest. Full-server MSPT/FPS/draw/cube counts remain null with
reasons. A new source/helper/proposal tuple, fresh world and explicit lease are required
before any corrected ordinary run. Native/cold, optimization and production sleep
remain open.
