# U14 bounded batch observer — review-ready tuple, no Java run

New source is `24fc339c30b3965c5a5058199b102d9e2c64560f`. It implements the reviewed
lossless byte adapter, real Java memory contract, before-tick admission receipt,
expected-output failure handoff and exactly nine wrench scalars. Only test/CPU/docs
files change. The [source adapter contract](U14_BATCH_SOURCE_ADAPTER_CONTRACT_2026-11-18.md)
defines the limits and still-unrun acceptance. Main653, normal84entry manifest,
solver/damping, floor,32real deaths/normal age1000 and.02/20endpoint criterion remain
unchanged. First overflow/rawcf48 and successful early baseline/archive93dcd remain.

The Java source is **uncompiled/unrun**. The actual byte-adapter memory contract is
authored, not credited as passing by Python tests. There is no new world/XML/trace.

## Exact frozen tuple

| Input |SHA-256 |
| --- | --- |
|[Launcher](../../scripts/v8/run_ragdoll_batched_trajectory.py) |`e191cf5e77ef024a0bd0a30d33ed8c7c6bc1cc69bb67f96157f56f5a6413513f` |
|[Ordered proposal/all immutable inputs](U14_BATCH_PREPARED_LAUNCH_2026-11-18.json) |`fd7c5419e4eec218da618b69591e792c53f6d1d570b0ff883eee82224db17996` |
|Private653named classes/resources receipt |`8f8c13d2c402c260180baf71ec66f39a99cb08c840b9a7beca0a69239fa36279` |

All**2,078immutable files** and initial configuration match. That includes the exact
private653main classes/resources and helpers, selected JARs, JDK executable/libjvm,
source/helpers/validators, opt-in manifest/mixins and preserved old raw as a hash-only
sentinel. The old trace is not input to the new physics or new-record decoder.

Compilation has113ordered entries: the qualified compiler's112entries, replacing
only its canonical output directories with private byte-identical653copies, then the
private154GameTest helpers. It compiles only seven explicit Java files, empty sourcepath,
`--release21 -proc:none -implicit:none`,120-second timeout. Exactly17owned class names
(including helper/contract nested types) are checked before runtime. No JUnit/dependency
coordinate, Gradle/Loom/main compilation or broad suite is added.

Runtime has108entries, in order: fresh17diagnostic/adapter classes; private653GameTest
helpers; own two staged resources; private653main classes; private653main resources;
the exact103qualified ordinary JAR coordinates. The helper refuses any canonical
`build` output on either selected classpath. Canonical source/named outputs can advance
without silently changing this653component subject.

Main mod group is `[private main classes,private main resources]`; test group is
`[fresh classes,private GameTest helpers,own resources]`. One opt-in GameTest entrypoint
and the same3required mixins load. Private verified old remapClasspath/log4j text inputs
are used, with every referenced JAR hashed. Named Minecraft remainsb564f660/Entityb08c8053;
whole mappings.jar4ce5e826 and tiny-entry0656f261 hashes are distinct checked artifacts.
Old root998/502and433/c7receipts are provenance, not new execution results.

## Byte protocol, failure and actual ordinary gate

Queue only scalar JSONL bytes/UUID/times:<=256rows,8rows/UUID,8world ticks,8MiBlogical;
row<=256KiB; compressed staging<=8MiB+64KiB; trace<=127MiB. Original row order and
numeric strings survive. No queued World/Entity/Part/callback reference or extra world
load. Enrollment initial states persist before ticks. Admission/final metadata share
1MiB (<=512KiBeach). Counters separate observed/offered/persisted/buffered/discarded.

Expected recorder cap/IO failure writes a bounded first summary and returns to the
real entity tick; the next normal test callback fails and cleans its own fixture.
Arbitrary RuntimeException/physics failures propagate. The actual JDK-only adapter
contract runs before any cohort creation, tests the real byte/metadata code in memory
and emits `U14_OUTPUT_ADAPTER_CONTRACT_PASS`. It is not a fake physics executor.

The ordinary diagnostic still needs32,000actual identity/solver ticks,640,000part steps,
4,096,000joint and5,760,000terrain calls through age/lifetime1000. Fresh XML must contain
exactly the intended one case, zero fail/error/skip; adapter and actual-cohort completion
markers must each occur once. Both metadata files, all32000CRC-verified rows, clocks,
exact work, finite inertia/energy and unchanged frozen inputs/classes are checked.

Three vectors add exactly9scalars: fixed-origin contact angular impulse, gravity angular
impulse and position-projection orbital change. Decoder reports state delta/contact/
gravity/projection/actual damping/residual separately, with no conservation/sleep
assertion. Perpart-independent-flat support is rejected; actual endpoint motion and
rig-level support opportunity remain observations, not optimization or wake proof.

## CPU checks and later command

Six new CPU controls pass for CRC-before-credit/tail/batch bounds, missing wrench,
projection/damping arithmetic and authored Java handoff boundaries. The prior six
packing/support controls pass. The new bounded reader also decoded the entire unchanged
first-failure prefix:29,878complete members/rows,374,296,832logical bytes. The
[CPU receipt](U14_BATCH_CPU_SOURCE_CONTROLS_2026-11-18.json) records actual commands/exits.
No Python result is attributed to executing the new Java adapter.

After root reviews this tuple and grants a separate exclusive Java lease, proposed
one first attempt:

```sh
U14_RAGDOLL_BATCH_JAVA_LEASE=granted python3 scripts/v8/run_ragdoll_batched_trajectory.py --run-with-root-java-lease
```

Run from `/workspace/ungravity-v5/ragdoll-rest-baseline-20261118`. Fresh own namespace:
`work/u14-batched-24fc339-first-20261118`. Compilation120s; ordinary server600s;768MiBheap;
unchanged256MiBfree-disk guard; ten-second termination grace. Preserve first child
start/log/actual exit and all partial evidence, return the slot at last child closure,
then only Python/file analysis. No automatic retry, cap raise, source physics tweak,
native/cold/performance or sleep claim follows from preparation.
