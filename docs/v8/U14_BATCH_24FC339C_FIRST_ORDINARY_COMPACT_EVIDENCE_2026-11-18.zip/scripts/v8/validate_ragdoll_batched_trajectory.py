#!/usr/bin/env python3
"""Bounded CRC-before-credit reader and observational wrench accounting. No simulation/Java."""
from collections import Counter,deque
from pathlib import Path
import hashlib,importlib.util,json,math,sys,zlib

ROOT=Path(__file__).resolve().parents[2]
def load(name):
    spec=importlib.util.spec_from_file_location(name,Path(__file__).with_name(name+'.py'));module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module
V=load('validate_ragdoll_trajectory');A=load('analyze_ragdoll_partial_support')
ROW_CAP=256*1024;LOGICAL_CAP=8*1024*1024;ENCODED_CAP=LOGICAL_CAP+64*1024
WRENCH_KEYS=('contact_wrench_L','gravity_wrench_L','position_projection_dL')
def add(a,b):return [x+y for x,y in zip(a,b)]
def scale(a,k):return [x*k for x in a]
def cross(a,b):return [a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]]
def centre(parts):
    origin=parts[0]['p'];mass=0.;weighted=[0.,0.,0.]
    for p in parts:
        m=V.PARTS[p['id']][0];mass+=m;weighted=add(weighted,scale(V.sub(p['p'],origin),m))
    return add(origin,scale(weighted,1/mass))
def angular(parts,origin,inverse_damping=False):
    total=[0.,0.,0.]
    for p in parts:
        m=V.PARTS[p['id']][0];linear=scale(p['v'],m/(.998 if inverse_damping else 1));spin=scale(p['L'],1/(.994 if inverse_damping else 1))
        total=add(total,add(spin,cross(V.sub(p['p'],origin),linear)))
    return total
def wrench_accounting(previous,row):
    for key in WRENCH_KEYS:assert len(row[key])==3 and all(math.isfinite(v) for v in row[key]),'missing/nonfinite exact wrench'
    origin=centre(previous);before=angular(previous,origin);after=angular(row['parts'],origin);pre_damping=angular(row['parts'],origin,True)
    damping=V.sub(after,pre_damping);change=V.sub(after,before)
    residual=V.sub(V.sub(V.sub(V.sub(change,row['contact_wrench_L']),row['gravity_wrench_L']),row['position_projection_dL']),damping)
    return dict(state_delta=change,contact=row['contact_wrench_L'],gravity=row['gravity_wrench_L'],projection_orbital=row['position_projection_dL'],damping=damping,residual=residual,residual_norm=V.norm(residual))

def records(path,observed=None):
    """Credit a whole member only after its CRC passes; no incomplete crash-tail rows escape."""
    pending=b'';previous_world=None
    with Path(path).open('rb') as stream:
        while True:
            if not pending:pending=stream.read(65536)
            if not pending:return
            decoder=zlib.decompressobj(31);logical=bytearray();encoded=0
            while not decoder.eof:
                if not pending:
                    pending=stream.read(65536)
                    if not pending:raise EOFError('incomplete final gzip member; its rows are not credited')
                before=len(pending);piece=decoder.decompress(pending,LOGICAL_CAP+1-len(logical))
                consumed=before-len(decoder.unused_data if decoder.eof else decoder.unconsumed_tail)
                encoded+=consumed;pending=decoder.unused_data if decoder.eof else decoder.unconsumed_tail
                logical.extend(piece)
                assert len(logical)<=LOGICAL_CAP and encoded<=ENCODED_CAP,'gzip batch budget'
            assert logical and logical[-1]==10,'complete JSONL member must end in newline'
            lines=logical.splitlines(keepends=True);assert 1<=len(lines)<=256
            batch=[];identities=Counter()
            for line in lines:
                assert len(line)<=ROW_CAP;row=json.loads(line);identities[row['uuid']]+=1;assert identities[row['uuid']]<=8
                if previous_world is not None:assert row['world_tick']>=previous_world,'original world order lost'
                previous_world=row['world_tick'];batch.append((row,len(line)))
            assert max(row['world_tick'] for row,_ in batch)-min(row['world_tick'] for row,_ in batch)<=7
            if observed is not None:
                observed['members']=observed.get('members',0)+1
                for key,value in [('max_batch_rows',len(batch)),('max_batch_logical_bytes',len(logical)),('max_encoded_bytes',encoded),('max_rows_per_uuid',max(identities.values())),
                    ('max_world_tick_span',max(row['world_tick'] for row,_ in batch)-min(row['world_tick'] for row,_ in batch))]:observed[key]=max(observed.get(key,0),value)
            yield from batch

def check_metadata(summary,admission,trace_bytes,summary_bytes,admission_bytes,admission_sha):
    V.reject_summary(summary,trace_bytes,summary_bytes)
    assert summary['schema']=='ungravity.ragdoll.trajectory.v2' and summary['adapter_contract_passed'] and not summary['output_failed'] and summary['output_failure'] is None
    assert summary_bytes<=512*1024 and admission_bytes<=512*1024 and summary_bytes+admission_bytes<=1024*1024
    assert summary['trace_file_bytes']==trace_bytes and summary['rows_observed']==32000 and summary['admission_sha256']==admission_sha
    assert admission['schema']=='ungravity.ragdoll.trajectory.admission.v2' and admission['status']=='enrolled_before_ticks' and admission['adapter_contract_passed']
    assert admission['observer_only'] and not admission['sleep_implemented'] and admission['admission']==summary['admission']
    stats=summary['output'];assert stats['closed'] and stats['failure'] is None
    assert stats['offered_rows']==stats['persisted_rows']==32000 and stats['buffered_rows']==stats['discarded_rows']==0
    assert stats['committed_bytes']==trace_bytes and stats['persisted_logical_bytes']==summary['logical_json_bytes']
    assert stats['max_batch_rows']<=256 and stats['max_batch_logical_bytes']<=LOGICAL_CAP and stats['max_encoded_bytes']<=ENCODED_CAP
    assert stats['max_rows_per_uuid']<=8 and stats['max_world_tick_span']<=7
    assert stats['trace_cap_bytes']==127*1024*1024 and stats['row_cap_bytes']==ROW_CAP and stats['logical_cap_bytes']==LOGICAL_CAP and stats['encoded_cap_bytes']==ENCODED_CAP

def rig_reasons(row,rig):
    reasons=[]
    if rig['endpoint_corner']>V.SPEED:reasons.append('endpoint_corner_speed')
    if rig['K']>.00136:reasons.append('endpoint_rig_energy')
    if rig['joint_error']>V.JOINT:reasons.append('joint_error')
    if rig['support_robust_margin'] is None or rig['support_robust_margin']<V.MARGIN:reasons.append('rig_contact_support_span')
    if not rig['all_positive_contact_normals_up'] or rig['contact_point_plane_error'] is None or rig['contact_point_plane_error']>V.TRAVEL:reasons.append('contact_normal_or_plane')
    if rig['unknown']:reasons.append('unknown_support')
    if rig['near_player']:reasons.append('near_player64')
    if rig['bodies']:reasons.append('near_body64')
    if V.norm(V.sub(row['gravity'],[0.,-9.81,0.]))>1e-9:reasons.append('nondefault_gravity')
    imbalance=V.norm(add(rig['J'],scale(row['gravity'],A.MASS*.05)))/A.MASS
    if imbalance>V.SPEED:reasons.append('unbalanced_external_impulse')
    return reasons

def validate(directory):
    directory=Path(directory);trace=directory/'ragdoll-trajectory.jsonl.gz';sp=directory/'ragdoll-trajectory-summary.json';ep=directory/'ragdoll-trajectory-admission.json'
    s=json.loads(sp.read_text());enrollment=json.loads(ep.read_text());admission_sha=hashlib.sha256(ep.read_bytes()).hexdigest()
    check_metadata(s,enrollment,trace.stat().st_size,sp.stat().st_size,ep.stat().st_size,admission_sha)
    actors=s['actors'];initial={a['uuid']:a for a in enrollment['actors']}
    assert len(actors)==len(initial)==32 and len({a['uuid'] for a in actors})==32
    audit={}
    for actor in actors:
        e=initial[actor['uuid']];assert e['start_age']==e['end_age']==e['start_life']==e['end_life']==e['ticks']==0
        assert actor['ticks']==actor['end_age']==actor['end_life']==1000 and actor['start_age']==actor['start_life']==0
        assert actor['last_world_tick']-actor['first_world_tick']==999 and enrollment['world_tick']<=actor['first_world_tick']<=enrollment['world_tick']+1
        assert e['rig_version']==actor['rig_version']==1 and e['hull_kind'] is actor['hull_kind'] is None
        assert [p['id'] for p in e['initial_parts']]==list(V.PARTS)
        audit[actor['uuid']]=dict(meta=actor,initial=e['initial_parts'],previous=e['initial_parts'],age=0,life=0,world_tick=None,rows=0,
            history=deque(maxlen=20),late=deque(maxlen=40),motion_streak=0,motion_max=0,first_motion20=None,rig_streak=0,rig_max=0,first_rig20=None,
            reasons=Counter(),angular_residual_max=0.,max_positive_contact_dK=0.)
    rows=logical=0;batch_observed={}
    for row,size in records(trace,batch_observed):
        logical+=size;rows+=1;uid=row['uuid'];assert uid in audit;actor=audit[uid];V.check_clock(actor,row)
        assert row['simulation_calls']==1 and row['joint_solves']==128 and row['inside_checks']==180 and row['inside_unknown']==0
        assert len(row['joint_errors'])==4 and all(math.isfinite(x) and x>=0 for x in row['joint_errors'])
        assert [p['id'] for p in row['parts']]==list(V.PARTS) and len(row['gravity'])==3 and all(math.isfinite(x) for x in row['gravity'])
        bounds=[V.check_part(p,initial) for p,initial in zip(row['parts'],actor['initial'])];rig=A.rig(row);account=wrench_accounting(actor['previous'],row)
        before=[V.corner_points(p['p'],p['q'],V.PARTS[p['id']][1]) for p in actor['previous']]
        entry=dict(row=row,before=before,previous=actor['previous'],rig=rig,angular=account);actor['history'].append(entry);actor['late'].append(entry)
        actor['motion_streak']=actor['motion_streak']+1 if max(bounds)<=V.SPEED else 0;actor['motion_max']=max(actor['motion_max'],actor['motion_streak'])
        if actor['motion_streak']>=20 and actor['first_motion20'] is None:actor['first_motion20']=[row['age']-19,row['age']]
        reasons=rig_reasons(row,rig);actor['reasons'].update(reasons);actor['rig_streak']=actor['rig_streak']+1 if not reasons else 0;actor['rig_max']=max(actor['rig_max'],actor['rig_streak'])
        if actor['rig_streak']>=20 and actor['first_rig20'] is None:
            history=list(actor['history']);excursion=V.endpoint_excursion(history)
            if excursion<=V.TRAVEL:
                actor['first_rig20']=dict(ages=[row['age']-19,row['age']],world_ticks=[history[0]['row']['world_tick'],row['world_tick']],endpoint_corner_excursion_m=excursion,
                    angular_residual_max=max(e['angular']['residual_norm'] for e in history),angular_balance_is_reported_not_asserted=True)
        actor['angular_residual_max']=max(actor['angular_residual_max'],account['residual_norm']);actor['max_positive_contact_dK']=max(actor['max_positive_contact_dK'],max(p['max_positive_contact_dK'] for p in row['parts']))
        actor.update(previous=row['parts'],age=row['age'],life=row['life'],world_tick=row['world_tick'],rows=actor['rows']+1)
    assert rows==32000 and logical==s['logical_json_bytes']
    assert all(s['output'][key]==value for key,value in batch_observed.items()),'recorded batch bounds/counts must match actual decoded members'
    results=[]
    for uid,a in audit.items():
        assert a['rows']==a['age']==a['life']==1000 and a['world_tick']==a['meta']['last_world_tick']
        late=list(a['late']);results.append(dict(uuid=uid,rows=1000,max_endpoint_motion_streak=a['motion_max'],first_endpoint_motion20=a['first_motion20'],
            first_rig_support_endpoint20=a['first_rig20'],max_rig_support_local_streak=a['rig_max'],rejections=dict(a['reasons']),
            angular_residual_max=a['angular_residual_max'],max_positive_contact_dK=a['max_positive_contact_dK'],last40_parts=V.late_metrics(late),
            last40_wrench_sum={key:[sum(e['angular'][key][i] for e in late) for i in range(3)] for key in ['state_delta','contact','gravity','projection_orbital','damping','residual']}))
    return dict(status='PASS_COMPLETE_OBSERVER_DIAGNOSTIC',actors=32,part_identities=160,rows=32000,through_age=1000,actual_solver_calls=32000,actual_part_steps=640000,
        actual_joint_solves=4096000,actual_terrain_calls=5760000,trace_bytes=trace.stat().st_size,metadata_bytes=sp.stat().st_size+ep.stat().st_size,logical_json_bytes=logical,
        endpoint_motion20_actors=sum(a['first_endpoint_motion20'] is not None for a in results),rig_support_endpoint20_evidence_actors=sum(a['first_rig_support_endpoint20'] is not None for a in results),
        observed_batches=batch_observed,
        independent_flat_part_predicate_rejected=True,wrench_scalars_per_row=9,angular_balance_reported_without_conservation_assertion=True,
        thresholds=dict(endpoint_corner_speed=V.SPEED,quiet_ticks=20,endpoint_excursion=V.TRAVEL,rig_K=.00136,joint_error=V.JOINT,rig_support_margin=V.MARGIN),
        per_actor=results,sleep_implemented=False,optimization_pass=False,performance_claim=False,native_run=False,cold_run=False)

if __name__=='__main__':
    if len(sys.argv)!=3:raise SystemExit('Provide actual runtime directory and fresh result JSON; no Java')
    result=validate(sys.argv[1])
    with Path(sys.argv[2]).open('x') as stream:json.dump(result,stream,indent=2);stream.write('\n')
    print(json.dumps({key:value for key,value in result.items() if key!='per_actor'}))
