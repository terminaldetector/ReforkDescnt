#!/usr/bin/env python3
"""Validate real recorded clocks/work and derive identity-specific motion/rest evidence in Python."""
from collections import Counter,deque
from pathlib import Path
import gzip,json,math,sys

SPEED=.02;QUIET=20;TRAVEL=.001;SPECIFIC_ENERGY=.0002;JOINT=.001;MARGIN=.005
PARTS={'core':(4.,[.22,.22,.22]),'north':(.7,[.07,.07,.18]),'south':(.7,[.07,.07,.18]),'east':(.7,[.18,.07,.07]),'west':(.7,[.18,.07,.07])}
def norm(v):return math.sqrt(sum(x*x for x in v))
def sub(a,b):return [x-y for x,y in zip(a,b)]
def dot(a,b):return sum(x*y for x,y in zip(a,b))
def rotate(q,v):
    x,y,z,w=q;t=[2*(y*v[2]-z*v[1]),2*(z*v[0]-x*v[2]),2*(x*v[1]-y*v[0])]
    return [v[0]+w*t[0]+y*t[2]-z*t[1],v[1]+w*t[1]+z*t[0]-x*t[2],v[2]+w*t[2]+x*t[1]-y*t[0]]
def corner_points(p,q,half):
    return [[a+b for a,b in zip(p,rotate(q,[half[j]*(1 if i&(1<<j) else -1) for j in range(3)]))] for i in range(8)]
def expected_omega(q,L,mass,half):
    local=rotate([-q[0],-q[1],-q[2],q[3]],L)
    inertia=[mass/3*(sum(x*x for x in half)-half[i]**2) for i in range(3)]
    return rotate(q,[local[i]/inertia[i] for i in range(3)])
def check_clock(previous,row):
    assert row['age']==previous['age']+1 and row['life']==previous['life']+1,'nonconsecutive physical age/life'
    if previous['world_tick'] is not None:assert row['world_tick']==previous['world_tick']+1,'nonconsecutive ordinary world tick'
def reject_summary(s,trace_bytes,summary_bytes):
    assert s['status']=='complete' and s['observer_only'] and not s['sleep_implemented'] and s['diagnostic_only']
    assert not s['output_overflow'] and not s['violations'],'overflow/violating diagnostic is NONPASS'
    assert s['actors_requested']==32 and s['parts_requested']==160 and s['end_age']==1000 and s['rows']==32000
    assert trace_bytes==s['trace_bytes']<=127*1024*1024 and summary_bytes<=1024*1024
    assert trace_bytes+summary_bytes<=128*1024*1024
    a=s['admission'];assert all(a[k]==32 for k in ['actual_live_spawns','death_attempts','actual_dead_drones','actual_corpses'])
    assert a['actual_parts']==160 and a['death_window_world_ticks']==0
    assert s['mspt'] is s['fps'] is s['draw_calls'] is s['cubes_loaded'] is None
def check_part(part,initial):
    name=part['id'];mass,half=PARTS[name];assert initial['mass']==mass and initial['half']==half
    for key,width in [('p',3),('q',4),('v',3),('L',3),('w',3),('contact_dP',3),('contact_dL',3),('normal_weighted',3)]:
        assert len(part[key])==width and all(math.isfinite(v) for v in part[key]),'missing/nonfinite '+key
    assert abs(norm(part['q'])-1)<1e-7,'unnormalized quaternion'
    expected=expected_omega(part['q'],part['L'],mass,half)
    assert norm(sub(expected,part['w']))<=1e-8*max(1,norm(expected)),'omega/world-inertia mismatch'
    energy=.5*mass*dot(part['v'],part['v'])+.5*dot(part['L'],part['w'])
    assert math.isfinite(energy) and energy>=-1e-10 and abs(energy-part['K'])<=1e-8*max(1,abs(energy)),'energy mismatch'
    bound=norm(part['v'])+norm(half)*norm(part['w'])
    assert math.isfinite(part['corner_peak']+part['K_peak']+part['corner_chord_path']+part['corner_sweep_bound'])
    assert part['corner_peak']+1e-9>=bound and part['K_peak']+1e-9>=energy
    assert part['corner_sweep_bound']+1e-8>=part['corner_chord_path']>=0
    assert part['steps']==4 and part['integration_events']==4 and part['terrain_calls']==36
    assert part['pose_events']==part['integration_events']+part['position_events']+part['rotation_events']
    assert 0<=part['positive_contacts']<=part['contact_calls'] and part['terrain_changes']<=36
    points=corner_points(part['p'],part['q'],half)
    assert len(part['corner_min'])==len(part['corner_max'])==8
    for p,lower,upper in zip(points,part['corner_min'],part['corner_max']):
        assert all(math.isfinite(x) for x in lower+upper)
        assert all(low-1e-8<=x<=high+1e-8 for x,low,high in zip(p,lower,upper)),'corner envelope lost final pose'
    return bound
def local_reasons(row):
    reasons=[]
    if row['player_near64']:reasons.append('near_player64')
    if row['body_candidates64']!=0:reasons.append('body_candidate64')
    if norm(sub(row['gravity'],[0.,-9.81,0.]))>1e-9:reasons.append('nondefault_gravity')
    if max(row['joint_errors'])>JOINT:reasons.append('joint_error')
    for part in row['parts']:
        name=part['id'];mass,_=PARTS[name];support=part['support']
        if norm(part['v'])+norm(PARTS[name][1])*norm(part['w'])>SPEED:reasons.append(name+':endpoint_corner_speed')
        if part['K']>SPECIFIC_ENERGY*mass:reasons.append(name+':endpoint_kinetic_energy')
        if not support['hard_obsidian'] or support['unknown_reads']:reasons.append(name+':unsupported_or_unknown')
        if support['gap_min']< -TRAVEL or support['gap_max']>TRAVEL or support['face_spread']>TRAVEL:reasons.append(name+':support_gap_or_tilt')
        if support['com_margin'] is None or support['com_margin']<MARGIN:reasons.append(name+':support_margin')
        if part['positive_contacts']==0 or part['min_contact_up'] is None or part['min_contact_up']<1-1e-9:reasons.append(name+':no_up_contact')
    return reasons
def mutation_reasons(row):
    reasons=[]
    for p in row['parts']:
        if p['corner_peak']>SPEED:reasons.append(p['id']+':intermediate_peak_corner_speed')
        if p['corner_sweep_bound']>TRAVEL:reasons.append(p['id']+':mutation_sweep')
        if p['K_peak']>SPECIFIC_ENERGY*PARTS[p['id']][0]:reasons.append(p['id']+':intermediate_kinetic_energy')
    return reasons
def interval_excursion(history):
    if len(history)!=QUIET:return None
    worst=0
    for i in range(5):
        initial=history[0]['before'][i]
        for entry in history:
            p=entry['row']['parts'][i]
            for origin,lower,upper in zip(initial,p['corner_min'],p['corner_max']):
                worst=max(worst,norm([max(abs(lo-x),abs(hi-x)) for x,lo,hi in zip(origin,lower,upper)]))
    return worst
def fingerprint(row):return [(p['support']['face'],p['support']['plane_y'],p['support']['cells']) for p in row['parts']]
def endpoint_excursion(history):
    if len(history)!=QUIET:return None
    worst=0
    for i,name in enumerate(PARTS):
        initial=history[0]['before'][i]
        for entry in history:
            part=entry['row']['parts'][i]
            for first,last in zip(initial,corner_points(part['p'],part['q'],PARTS[name][1])):worst=max(worst,norm(sub(last,first)))
    return worst
def rotation_increment(previous,current):
    # Shortest world-space relative rotation; cap12rad/s and real tick sampling avoid >pi alias.
    x,y,z,w=current;a,b,c,d=[-previous[0],-previous[1],-previous[2],previous[3]]
    q=[w*a+x*d+y*c-z*b,w*b-x*c+y*d+z*a,w*c+x*b-y*a+z*d,w*d-x*a-y*b-z*c]
    if q[3]<0:q=[-v for v in q]
    length=norm(q[:3]);angle=2*math.atan2(length,q[3]);return angle,[v*angle/length for v in q[:3]] if length>1e-12 else [0.,0.,0.]
def late_metrics(entries):
    result=[]
    for i in range(5):
        first=entries[0]['previous'][i];last=entries[-1]['row']['parts'][i];linear_path=angle_arc=0.;rotvec=[0.,0.,0.]
        low=list(first['p']);high=list(first['p'])
        for e in entries:
            p=e['row']['parts'][i];prev=e['previous'][i];linear_path+=norm(sub(p['p'],prev['p']))
            angle,vector=rotation_increment(prev['q'],p['q']);angle_arc+=angle;rotvec=[a+b for a,b in zip(rotvec,vector)]
            low=[min(a,b) for a,b in zip(low,p['p'])];high=[max(a,b) for a,b in zip(high,p['p'])]
        result.append(dict(id=last['id'],net_translation_m=sub(last['p'],first['p']),centre_endpoint_path_m=linear_path,centre_range_m=sub(high,low),rotation_arc_rad=angle_arc,
            rotation_vector_sum_world_rad=rotvec,observed_mutation_corner_chord_path_m=sum(e['row']['parts'][i]['corner_chord_path'] for e in entries),
            observed_mutation_corner_sweep_bound_m=sum(e['row']['parts'][i]['corner_sweep_bound'] for e in entries),contact_dK=sum(e['row']['parts'][i]['contact_dK'] for e in entries),
            contact_dP=[sum(e['row']['parts'][i]['contact_dP'][j] for e in entries) for j in range(3)],positive_contacts=sum(e['row']['parts'][i]['positive_contacts'] for e in entries)))
    return result
def validate(directory):
    directory=Path(directory);summary_path=directory/'ragdoll-trajectory-summary.json';trace=directory/'ragdoll-trajectory.jsonl.gz'
    summary=json.loads(summary_path.read_text());reject_summary(summary,trace.stat().st_size,summary_path.stat().st_size)
    actors=summary['actors'];assert len(actors)==32 and len({a['uuid'] for a in actors})==32
    audit={}
    for actor in actors:
        assert actor['ticks']==actor['end_age']==actor['end_life']==1000 and actor['start_age']==actor['start_life']==0
        assert actor['last_world_tick']-actor['first_world_tick']==999 and actor['rig_version']==1 and actor['hull_kind'] is None
        assert [p['id'] for p in actor['initial_parts']]==list(PARTS)
        audit[actor['uuid']]=dict(meta=actor,age=0,life=0,world_tick=None,previous=actor['initial_parts'],motion_streak=0,motion_max=0,static_streak=0,static_max=0,
            first_motion20=None,first_static20=None,first_strict_mutation20=None,reasons=Counter(),mutation_rejections=Counter(),history=deque(maxlen=20),late=deque(maxlen=40),contact_max_positive_dK=0.)
    rows=logical=0;counts=Counter()
    with gzip.open(trace,'rb') as stream:
        for line in stream:
            assert len(line)<=256*1024,'oversized record';logical+=len(line);row=json.loads(line);identity=row['uuid'];assert identity in audit,'unowned actor row'
            actor=audit[identity];check_clock(actor,row)
            assert row['simulation_calls']==1 and row['joint_solves']==128 and row['inside_checks']==180 and row['inside_unknown']==0
            assert len(row['joint_errors'])==4 and all(math.isfinite(v) and v>=0 for v in row['joint_errors'])
            assert [p['id'] for p in row['parts']]==list(PARTS) and len(row['gravity'])==3 and all(math.isfinite(v) for v in row['gravity'])
            bounds=[check_part(p,initial) for p,initial in zip(row['parts'],actor['meta']['initial_parts'])]
            before=[corner_points(p['p'],p['q'],PARTS[p['id']][1]) for p in actor['previous']]
            strict=mutation_reasons(row);actor['mutation_rejections'].update(strict)
            entry=dict(row=row,before=before,previous=actor['previous'],strict_reasons=strict);actor['history'].append(entry);actor['late'].append(entry)
            actor['motion_streak']=actor['motion_streak']+1 if max(bounds)<=SPEED else 0;actor['motion_max']=max(actor['motion_max'],actor['motion_streak'])
            if actor['motion_streak']>=QUIET and actor['first_motion20'] is None:actor['first_motion20']=[row['age']-19,row['age']]
            reasons=local_reasons(row);actor['reasons'].update(reasons)
            actor['static_streak']=actor['static_streak']+1 if not reasons else 0;actor['static_max']=max(actor['static_max'],actor['static_streak'])
            if actor['static_streak']>=QUIET:
                window=list(actor['history']);excursion=endpoint_excursion(window)
                if excursion<=TRAVEL and all(fingerprint(e['row'])==fingerprint(window[0]['row']) for e in window):
                    if actor['first_static20'] is None:actor['first_static20']=dict(ages=[row['age']-19,row['age']],world_ticks=[window[0]['row']['world_tick'],row['world_tick']],corner_excursion_upper_m=excursion)
                    if not any(e['strict_reasons'] for e in window) and interval_excursion(window)<=TRAVEL and actor['first_strict_mutation20'] is None:
                        actor['first_strict_mutation20']=dict(ages=[row['age']-19,row['age']],world_ticks=[window[0]['row']['world_tick'],row['world_tick']],mutation_corner_excursion_upper_m=interval_excursion(window))
                else:actor['reasons'].update(['twenty_tick_excursion_or_support_change'])
            actor['contact_max_positive_dK']=max(actor['contact_max_positive_dK'],max(p['max_positive_contact_dK'] for p in row['parts']))
            actor.update(age=row['age'],life=row['life'],world_tick=row['world_tick'],previous=row['parts']);counts[identity]+=1;rows+=1
    assert rows==32000 and logical==summary['logical_json_bytes'] and all(v==1000 for v in counts.values()) and len(counts)==32
    result=[]
    for identity,actor in audit.items():
        assert actor['age']==actor['life']==1000 and actor['world_tick']==actor['meta']['last_world_tick']
        result.append(dict(uuid=identity,rows=counts[identity],max_endpoint_motion_streak=actor['motion_max'],first_endpoint_motion20=actor['first_motion20'],
            max_static_local_streak=actor['static_max'],first_static_supported20=actor['first_static20'],rejections=dict(actor['reasons']),max_positive_contact_dK=actor['contact_max_positive_dK'],
            first_strict_mutation20=actor['first_strict_mutation20'],intermediate_mutation_rejections=dict(actor['mutation_rejections']),
            last40=late_metrics(list(actor['late']))))
    return dict(status='PASS_COMPLETE_OBSERVER_DIAGNOSTIC',actors=32,part_identities=160,rows=rows,actual_solver_calls=32000,actual_part_steps=640000,actual_joint_solves=4096000,
        actual_terrain_calls=5760000,through_age=1000,trace_bytes=trace.stat().st_size,logical_json_bytes=logical,
        endpoint_motion20_actors=sum(a['first_endpoint_motion20'] is not None for a in result),static_supported20_actors=sum(a['first_static_supported20'] is not None for a in result),
        strict_mutation20_actors=sum(a['first_strict_mutation20'] is not None for a in result),
        thresholds=dict(corner_speed_mps=SPEED,quiet_ticks=QUIET,per_tick_corner_sweep_m=TRAVEL,specific_energy_m2_s2=SPECIFIC_ENERGY,joint_error_m=JOINT,support_margin_m=MARGIN,twenty_tick_excursion_m=TRAVEL),
        per_actor=result,sleep_implemented=False,optimization_pass=False,performance_claim=False,native_run=False,cold_run=False)

if __name__=='__main__':
    if len(sys.argv)!=3:raise SystemExit('Provide actual runtime directory and fresh result JSON; no Java invoked')
    result=validate(sys.argv[1])
    with Path(sys.argv[2]).open('x') as stream:json.dump(result,stream,indent=2);stream.write('\n')
    print(json.dumps({k:v for k,v in result.items() if k!='per_actor'}))
