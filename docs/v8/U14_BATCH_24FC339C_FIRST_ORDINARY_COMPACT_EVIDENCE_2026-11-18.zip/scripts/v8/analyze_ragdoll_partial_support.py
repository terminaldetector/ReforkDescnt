#!/usr/bin/env python3
"""CPU-only rig-level support/motion bounds from the retained first overflow prefix."""
from collections import defaultdict,deque
from pathlib import Path
import gzip,hashlib,importlib.util,json,math,statistics,sys

ROOT=Path(__file__).resolve().parents[2]
RUN=ROOT/'work/u14-trajectory-d9760f0-first-20261118'
RAW=RUN/'runtime/ragdoll-trajectory.jsonl.gz'
SHA='cf48aed0fa3f6506396198a11430194203a9f0b133184ec12c7e8d36cdae75cc'
SPEC=importlib.util.spec_from_file_location('trajectory_math',ROOT/'scripts/v8/validate_ragdoll_trajectory.py')
V=importlib.util.module_from_spec(SPEC);SPEC.loader.exec_module(V)
MASS=6.8;DT=.05;DAMPING=.998
def vecsum(vectors):return [sum(values) for values in zip(*vectors)]
def scale(v,k):return [x*k for x in v]
def stats(values):
    values=list(values)
    return None if not values else dict(min=min(values),median=statistics.median(values),max=max(values),mean=statistics.mean(values))
def cross(a,b,c):return(b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])
def hull(points):
    points=sorted(set(tuple(p) for p in points))
    if len(points)<3:return points
    lower=[]
    for p in points:
        while len(lower)>1 and cross(lower[-2],lower[-1],p)<=0:lower.pop()
        lower.append(p)
    upper=[]
    for p in reversed(points):
        while len(upper)>1 and cross(upper[-2],upper[-1],p)<=0:upper.pop()
        upper.append(p)
    return lower[:-1]+upper[:-1]
def margin(polygon):
    if len(polygon)<3:return None
    return min(cross(a,polygon[(i+1)%len(polygon)],[0,0])/math.dist(a,polygon[(i+1)%len(polygon)]) for i,a in enumerate(polygon))
def rig(row):
    parts=row['parts'];origin=parts[0]['p']
    local=vecsum(scale(V.sub(p['p'],origin),V.PARTS[p['id']][0]) for p in parts)
    centre=[a+b/MASS for a,b in zip(origin,local)]
    momentum=vecsum(scale(p['v'],V.PARTS[p['id']][0]) for p in parts)
    contact=vecsum(p['contact_dP'] for p in parts)
    sites=[];radii=[];weights=[];planes=[];unsupported=[]
    for p in parts:
        if p['positive_contacts']==0:unsupported.append(p['id']);continue
        lower=p['contact_point_min'];upper=p['contact_point_max']
        assert lower is not None and upper is not None
        site=[(lower[0]+upper[0])/2-centre[0],(lower[2]+upper[2])/2-centre[2]]
        radius=math.hypot((upper[0]-lower[0])/2,(upper[2]-lower[2])/2)
        sites.append(site);radii.append(radius);weights.append(p['normal_weighted'][1])
        planes.extend([lower[1]-p['support']['plane_y'],upper[1]-p['support']['plane_y']])
    centre_margin=margin(hull(sites));robust=None if centre_margin is None else centre_margin-max(radii)
    normal_weight=sum(weights);cop=None;cop_uncertainty=None
    if normal_weight>0:
        cop=[sum(w*s[i] for w,s in zip(weights,sites))/normal_weight for i in range(2)]
        cop_uncertainty=sum(w*r for w,r in zip(weights,radii))/normal_weight
    return dict(centre=centre,P=momentum,J=contact,K=sum(p['K'] for p in parts),peak_K_sum=sum(p['K_peak'] for p in parts),
        endpoint_corner=max(V.norm(p['v'])+V.norm(V.PARTS[p['id']][1])*V.norm(p['w']) for p in parts),
        sampled_peak_corner=max(p['corner_peak'] for p in parts),joint_error=max(row['joint_errors']),
        support_parts=5-len(unsupported),parts_without_positive_contact=unsupported,normal_impulse=sum(p['normal_impulse'] for p in parts),
        contact_point_plane_error=max(map(abs,planes)) if planes else None,all_positive_contact_normals_up=all(p['min_contact_up'] is None or p['min_contact_up']>=1-1e-9 for p in parts),
        support_centre_hull_margin=centre_margin,support_robust_margin=robust,cop_relative_to_com=cop,cop_uncertainty=cop_uncertainty,
        contact_dK=sum(p['contact_dK'] for p in parts),max_positive_contact_dK=max(p['max_positive_contact_dK'] for p in parts),
        max_part_mutation_chord=sum(p['corner_chord_path'] for p in parts)/5,
        max_part_mutation_sweep=max(p['corner_sweep_bound'] for p in parts),
        total_part_mutation_sweep=sum(p['corner_sweep_bound'] for p in parts),
        unknown=sum(p['support']['unknown_reads'] for p in parts),near_player=row['player_near64'],bodies=row['body_candidates64'])
def window(entries):
    first=entries[0]['previous'];last=entries[-1]['row'];states=[e['rig'] for e in entries]
    first_rig=rig(first);first_centre=first_rig['centre'];centre_excursion=max(V.norm(V.sub(s['centre'],first_centre)) for s in states)
    history=[dict(row=e['row'],before=[V.corner_points(p['p'],p['q'],V.PARTS[p['id']][1]) for p in e['previous']['parts']]) for e in entries]
    endpoint_excursion=V.endpoint_excursion(history) if len(entries)==20 else None
    mutation_excursion=V.interval_excursion(history) if len(entries)==20 else None
    metrics=[]
    for e in entries:
        s=e['rig'];prev=rig(e['previous']);gravity=e['row']['gravity']
        residual=V.sub(V.sub(V.sub(scale(s['P'],1/DAMPING),prev['P']),scale(gravity,MASS*DT)),s['J'])
        # Relative potential is safe for the recorded constant gravity, not a variable field integral.
        dU=-MASS*V.dot(gravity,V.sub(s['centre'],prev['centre']))
        dE=s['K']-prev['K']+dU
        metrics.append(dict(momentum_residual=V.norm(residual),energy_change=dE,
            energy_after_contact_delta=dE-s['contact_dK'],support_ratio=s['J'][1]/(-MASS*gravity[1]*DT),
            unbalanced_external_impulse_per_mass=V.norm(vecsum([s['J'],scale(gravity,MASS*DT)]))/MASS))
    before=[e['previous']['parts'] for e in entries]
    late=V.late_metrics([dict(row=e['row'],previous=p) for e,p in zip(entries,before)])
    return dict(ages=[entries[0]['row']['age'],last['age']],world_ticks=[entries[0]['row']['world_tick'],last['world_tick']],
        rig_com_net_m=V.sub(states[-1]['centre'],first_centre),rig_com_excursion_m=centre_excursion,
        endpoint_corner_excursion_m=endpoint_excursion,mutation_corner_envelope_excursion_upper_m=mutation_excursion,
        endpoint_corner_bound=stats(s['endpoint_corner'] for s in states),sampled_intermediate_corner_bound=stats(s['sampled_peak_corner'] for s in states),
        end_kinetic_energy=stats(s['K'] for s in states),sum_of_part_peak_energies=stats(s['peak_K_sum'] for s in states),
        max_joint_error=stats(s['joint_error'] for s in states),supporting_parts=stats(s['support_parts'] for s in states),
        parts_ever_without_positive_contact=sorted(set(p for s in states for p in s['parts_without_positive_contact'])),
        positive_up_normals_all_ticks=all(s['all_positive_contact_normals_up'] for s in states),
        support_normal_impulse=stats(s['normal_impulse'] for s in states),support_to_default_weight_impulse_ratio=stats(m['support_ratio'] for m in metrics),
        momentum_balance_residual=stats(m['momentum_residual'] for m in metrics),
        unbalanced_external_impulse_per_mass_mps=stats(m['unbalanced_external_impulse_per_mass'] for m in metrics),
        robust_support_hull_margin=stats(s['support_robust_margin'] for s in states if s['support_robust_margin'] is not None),
        rows_with_robust_contact_hull_containing_com=sum(s['support_robust_margin'] is not None and s['support_robust_margin']>=0 for s in states),
        contact_point_plane_error=stats(s['contact_point_plane_error'] for s in states if s['contact_point_plane_error'] is not None),
        contact_dK=stats(s['contact_dK'] for s in states),max_positive_contact_dK=max(s['max_positive_contact_dK'] for s in states),
        net_K_plus_U_change=sum(m['energy_change'] for m in metrics),sum_contact_dK=sum(s['contact_dK'] for s in states),
        other_K_plus_U_change=sum(m['energy_after_contact_delta'] for m in metrics),
        max_per_part_mutation_sweep=stats(s['max_part_mutation_sweep'] for s in states),
        unknown_support_rows=sum(s['unknown']>0 for s in states),near_player_rows=sum(s['near_player'] for s in states),near_body_rows=sum(s['bodies']>0 for s in states),
        per_part=late)
def analyze():
    with RAW.open('rb') as stream:assert hashlib.file_digest(stream,'sha256').hexdigest()==SHA
    actors={};rows=0
    with gzip.open(RAW,'rt') as stream:
        for line in stream:
            row=json.loads(line);uid=row['uuid'];rows+=1
            if uid not in actors:
                actors[uid]=dict(previous=None,history=deque(maxlen=20),late=deque(maxlen=40),early=[],motion_streak=0,motion_max=0,first_motion20=None,first_rig_support20=None,endpoint_pose_rejections=0)
            a=actors[uid];s=rig(row)
            a['motion_streak']=a['motion_streak']+1 if s['endpoint_corner']<=.02 else 0;a['motion_max']=max(a['motion_max'],a['motion_streak'])
            if a['previous'] is not None:
                V.check_clock(a['previous'],row)
                entry=dict(row=row,previous=a['previous'],rig=s);a['history'].append(entry);a['late'].append(entry)
                if 128<=row['age']<=167:a['early'].append(entry)
                if a['motion_streak']>=20 and len(a['history'])==20:
                    candidate=window(list(a['history']))
                    if a['first_motion20'] is None:a['first_motion20']=candidate
                    # Rig-level evidence label only; original per-part-flat predicate is intentionally absent.
                    geometry=(candidate['rows_with_robust_contact_hull_containing_com']==20 and candidate['robust_support_hull_margin']['min']>=.005 and candidate['positive_up_normals_all_ticks'] and
                        candidate['unknown_support_rows']==candidate['near_player_rows']==candidate['near_body_rows']==0)
                    endpoint=(candidate['end_kinetic_energy']['max']<=.00136 and candidate['max_joint_error']['max']<=.001 and candidate['endpoint_corner_excursion_m']<=.001
                        and candidate['unbalanced_external_impulse_per_mass_mps']['max']<=.02)
                    if geometry and endpoint and a['first_rig_support20'] is None:a['first_rig_support20']=candidate
                    if not endpoint:a['endpoint_pose_rejections']+=1
            a['previous']=row
            if rows%5000==0:print(json.dumps(dict(event='CPU_RIG_SUPPORT',rows=rows)),flush=True)
    result=[]
    for uid,a in actors.items():
        result.append(dict(uuid=uid,last_age=a['previous']['age'],max_endpoint_motion_streak=a['motion_max'],first_endpoint_motion20=a['first_motion20'],
            first_rig_support_endpoint20=a['first_rig_support20'],endpoint_pose_rejection_windows=a['endpoint_pose_rejections'],
            early40=None if len(a['early'])!=40 else window(a['early']),last40=window(list(a['late']))))
    with RAW.open('rb') as stream:assert hashlib.file_digest(stream,'sha256').hexdigest()==SHA
    return dict(schema='ungravity.u14.partial-rig-support-analysis.v1',raw_sha256=SHA,status='PARTIAL_DIAGNOSTIC_ANALYSIS_NOT_A_GATE_PASS',raw_rows=rows,actors=len(actors),
        through_age1000=False,first_endpoint_motion20_actors=sum(a['first_endpoint_motion20'] is not None for a in result),
        rig_support_endpoint20_evidence_actors=sum(a['first_rig_support_endpoint20'] is not None for a in result),
        energy_units='game mass-unit m2/s2; not calibrated joules',momentum_units='game mass-unit m/s',
        support_bound='Contact bbox-centre convex hull, eroded by the largest bbox half-diagonal. Positive margin remains inside the hull of any one actual contact point selected from each bbox; this is geometric load opportunity, not full joint/contact equilibrium proof.',
        linear_balance='P_end/.998 - P_previous - M*g*.05 - sum(contact_dP); residual includes existing velocity clamps/fallback resets or unobserved mechanisms, not asserted zero by construction.',
        angular_balance_limitation='Per-part spin contact_dL lacks correlation of contact_dP with evolving COM positions, and positional projection moves orbital momentum. No exact system angular-momentum balance inferred.',
        energy_limitation='Delta(K+U) and summed contact_dK are measured separately. Their remainder combines integration, joint impulses, contact positional projection, damping and possible resets; it is not assigned to one mechanism.',
        no_independent_flat_part_certificate=True,no_sleep_implementation=True,no_optimization_pass=True,no_performance_native_or_cold_claim=True,per_actor=result)

if __name__=='__main__':
    if len(sys.argv)!=2:raise SystemExit('Provide a fresh result JSON path; no Java, raw copy or mutation')
    result=analyze()
    with Path(sys.argv[1]).open('x') as stream:json.dump(result,stream,indent=2);stream.write('\n')
    print(json.dumps({k:v for k,v in result.items() if k!='per_actor'},indent=2))
