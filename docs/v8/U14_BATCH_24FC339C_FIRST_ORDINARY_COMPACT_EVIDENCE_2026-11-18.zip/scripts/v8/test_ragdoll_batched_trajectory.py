"""CPU contracts for bounded decoding, wrench bookkeeping and the authored Java adapter boundary."""
import copy,gzip,importlib.util,json,math,tempfile,unittest
from pathlib import Path
SPEC=importlib.util.spec_from_file_location('batched',Path(__file__).with_name('validate_ragdoll_batched_trajectory.py'))
B=importlib.util.module_from_spec(SPEC);SPEC.loader.exec_module(B)
def row(t):return (json.dumps(dict(uuid='actual-id',world_tick=t,exact_number=1.2345678901234567))+'\n').encode()
def parts():return [dict(id=name,p=[0.,0.,0.],q=[0.,0.,0.,1.],v=[0.,0.,0.],L=[0.,0.,0.]) for name in B.V.PARTS]

class BatchedTrajectoryCPUContracts(unittest.TestCase):
    def with_trace(self,data,action):
        with tempfile.TemporaryDirectory() as directory:
            path=Path(directory)/'synthetic.gz';path.write_bytes(data);return action(path)
    def test_complete_members_preserve_all_rows_and_independent_batch_bounds(self):
        data=gzip.compress(b''.join(row(t) for t in range(8)),mtime=0)+gzip.compress(b''.join(row(t) for t in range(8,16)),mtime=0)
        observed={};rows=self.with_trace(data,lambda p:list(B.records(p,observed)))
        self.assertEqual(list(range(16)),[r['world_tick'] for r,_ in rows]);self.assertEqual(2,observed['members']);self.assertEqual(8,observed['max_rows_per_uuid']);self.assertEqual(7,observed['max_world_tick_span'])
        self.assertEqual(max(len(gzip.compress(b''.join(row(t) for t in range(8)),mtime=0)),len(gzip.compress(b''.join(row(t) for t in range(8,16)),mtime=0))),observed['max_encoded_bytes'])
    def test_incomplete_last_member_never_credits_its_rows(self):
        data=gzip.compress(b''.join(row(t) for t in range(8)),mtime=0)+gzip.compress(b''.join(row(t) for t in range(8,16)),mtime=0)[:-2]
        def action(path):
            accepted=[]
            with self.assertRaises(EOFError):
                for item,_ in B.records(path):accepted.append(item['world_tick'])
            self.assertEqual(list(range(8)),accepted)
        self.with_trace(data,action)
    def test_more_than_eight_rows_per_uuid_in_one_member_is_rejected(self):
        data=gzip.compress(b''.join(row(t) for t in range(9)),mtime=0)
        with self.assertRaises(AssertionError):self.with_trace(data,lambda p:list(B.records(p)))
    def test_missing_or_nonfinite_wrench_cannot_be_called_equilibrium_evidence(self):
        previous=parts();current=dict(parts=copy.deepcopy(previous),contact_wrench_L=[0.,0.,0.],gravity_wrench_L=[0.,0.,0.],position_projection_dL=[0.,0.,0.])
        self.assertEqual(0.,B.wrench_accounting(previous,current)['residual_norm'])
        current['contact_wrench_L'][0]=math.nan
        with self.assertRaises(AssertionError):B.wrench_accounting(previous,current)
        del current['contact_wrench_L']
        with self.assertRaises(KeyError):B.wrench_accounting(previous,current)
    def test_projection_orbital_and_existing_damping_remain_separate(self):
        previous=parts();previous[0].update(v=[1.,0.,0.],L=[0.,0.,2.]);after=copy.deepcopy(previous);after[0].update(p=[0.,1.,0.],v=[.998,0.,0.],L=[0.,0.,1.988])
        account=B.wrench_accounting(previous,dict(parts=after,contact_wrench_L=[0.,0.,0.],gravity_wrench_L=[0.,0.,0.],position_projection_dL=[0.,0.,-4.]))
        self.assertEqual([0.,0.,-4.],account['projection_orbital']);self.assertAlmostEqual(-.004,account['damping'][2],places=12);self.assertLess(account['residual_norm'],1e-12)
    def test_actual_java_adapter_source_is_scalar_only_and_ordinary_callback_owns_failure(self):
        root=B.ROOT/'src/gametest/java/com/terminaldetector/drmd';output=(root/'diag/ragdoll/RagdollTrajectoryOutput.java').read_text();contract=(root/'diag/ragdoll/RagdollTrajectoryOutputContract.java').read_text();recorder=(root/'diag/ragdoll/RagdollTrajectoryRecorder.java').read_text();fixture=(root/'RagdollTrajectoryGameTests.java').read_text()
        self.assertNotIn('net.minecraft',output);self.assertNotIn('com.terminaldetector.drmd.entity',output);self.assertNotIn('catch(RuntimeException',output);self.assertIn('catch(IOException',output)
        self.assertIn('LOGICAL_CAP=8*1024*1024',output);self.assertIn('IDENTITY_ROWS_CAP=8,TICK_SPAN_CAP=7',output);self.assertIn('127L*1024*1024',output)
        self.assertLess(fixture.index('RagdollTrajectoryOutputContract.verify()'),fixture.index('ModEntities.DRONE.create'))
        self.assertIn('RagdollTrajectoryOutput.metadata(metadata,summary,0)',contract);self.assertIn('unexpected.failure()==null',contract)
        emitter=recorder[recorder.index('private static void emit('):recorder.index('public static void assertComplete(')]
        self.assertNotIn('throw ',emitter);self.assertIn('finish("failed_output",outputFailure)',emitter);self.assertIn('RagdollTrajectoryRecorder.outputFailure()==null',fixture)
        for name in B.WRENCH_KEYS:self.assertEqual(1,recorder.count('"'+name+'"'))

if __name__=='__main__':unittest.main()
