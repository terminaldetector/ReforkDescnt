#!/usr/bin/env python3
"""Prepare one observer-only32 identity trajectory TestServer attempt. No JVM in --prepare."""
from pathlib import Path
import datetime,hashlib,importlib.util,json,os,shutil,signal,subprocess,sys,time,xml.etree.ElementTree as ET,zipfile

ROOT=Path('/workspace/ungravity-v5/ragdoll-rest-baseline-20261118')
CANONICAL=Path('/workspace/ungravity-v5/ufo-body-physics')
BASE='65370f7266cea705ebf2f9e86217031370fa2a3d'
SOURCE='24fc339c30b3965c5a5058199b102d9e2c64560f'
RUN=ROOT/'work/u14-batched-24fc339-first-20261118'
QUALIFIED=Path('/workspace/ungravity-v5/control-core-20261118/work/generic-core-observer-build-375f42d-first-20261118')
COMPILER=QUALIFIED/'compileCubiccheckJava-actual-inputs.json'
FROZEN=QUALIFIED/'qualified-root-inputs-frozen.json'
OWNER=QUALIFIED/'actual-remapped-owner-audit.json'
RUNTIME_LAYOUT=Path('/workspace/ungravity-v5/control-core-20261118/work/b2-assembly-game-0bb280a-package-first19-20261118/actual-runtime-inputs.json')
FULL=CANONICAL/'work/multi-agent/integrated-65370f7'
JAVA=Path('/workspace/jdk21-complete')
OUT=RUN/'classes'
RES=RUN/'resources'
CWD=RUN/'runtime'
VALIDATOR=ROOT/'scripts/v8/validate_ragdoll_batched_trajectory.py'
VALIDATION_SPEC=importlib.util.spec_from_file_location('u14_trajectory_validation',VALIDATOR)
VALIDATION=importlib.util.module_from_spec(VALIDATION_SPEC);VALIDATION_SPEC.loader.exec_module(VALIDATION)
PRIVATE=ROOT/'work/u14-private653-inputs-20261118'
PRIVATE_RECEIPT=PRIVATE/'receipt.json'
PRIVATE_CONFIG=PRIVATE/'launch-inputs/receipt.json'
OLD_RAW=ROOT/'work/u14-trajectory-d9760f0-first-20261118/runtime/ragdoll-trajectory.jsonl.gz'


def sha(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def write(path,value):
    with path.open('x') as stream:json.dump(value,stream,indent=2);stream.write('\n')
def files(path):return sorted(p for p in path.rglob('*') if p.is_file()) if path.is_dir() else [path]
def snapshot(paths):
    rows={}
    for path in paths:
        assert path.exists(),str(path)
        for child in files(path):rows[str(child)]=dict(path=str(child),bytes=child.stat().st_size,sha256=sha(child))
    return list(rows.values())
def verify(rows):
    for row in rows:
        path=Path(row['path']);assert path.is_file() and sha(path)==row['sha256'],str(path)
def source_guard():
    subprocess.run(['git','diff','--exit-code',SOURCE,'--','src','docs/v8/U14_BATCH_SOURCE_ADAPTER_CONTRACT_2026-11-18.md'],cwd=ROOT,check=True,stdout=subprocess.PIPE)
    subprocess.run(['git','diff','--exit-code',BASE,'--','src/main','build.gradle','src/gametest/resources/fabric.mod.json'],cwd=ROOT,check=True,stdout=subprocess.PIPE)
    subprocess.run(['git','diff','--exit-code',SOURCE,'--','scripts/v8/validate_ragdoll_batched_trajectory.py','scripts/v8/validate_ragdoll_trajectory.py','scripts/v8/analyze_ragdoll_partial_support.py'],cwd=ROOT,check=True,stdout=subprocess.PIPE)
    assert sha(ROOT/'docs/v8/U14_BASELINE_794976C7_FIRST_ORDINARY_EVIDENCE_2026-11-18.zip')=='93dcd591c1bb03b5df8411475de50f67b2f0c2983508980b0eb17bba4ac4f63b'
    assert sha(OLD_RAW)=='cf48aed0fa3f6506396198a11430194203a9f0b133184ec12c7e8d36cdae75cc'
    return subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()

def prepare():
    assert not RUN.exists(),'retain first proposal/attempt; do not overwrite'
    head=source_guard();RUN.mkdir(parents=True)
    for path in [OUT,RES,CWD]:path.mkdir()
    frozen=json.loads(FROZEN.read_text());assert frozen['source']==BASE
    assert sha(PRIVATE_RECEIPT)=='8f8c13d2c402c260180baf71ec66f39a99cb08c840b9a7beca0a69239fa36279'
    bound=json.loads(PRIVATE_RECEIPT.read_text());assert bound['source']==BASE
    by_kind={item['kind']:item for item in bound['sets']};roots=[];directory_map={}
    for kind in ['main-classes','main-resources','gametest-classes']:
        item=by_kind[kind];path=Path(item['private_root']);directory_map[Path(item['original_root'])]=path
        actual={p.relative_to(path).as_posix():dict(bytes=p.stat().st_size,sha256=sha(p)) for p in files(path)}
        expected={row['path']:dict(bytes=row['bytes'],sha256=row['sha256']) for row in item['files']}
        assert actual==expected,'private653 '+kind+' changed'
        if kind!='gametest-classes':roots.append(path)
    assert [by_kind[k]['count'] for k in ['main-classes','main-resources','gametest-classes']]==[1108,608,154]
    for frozen_name,kind in [('mainClasses','main-classes'),('mainResources','main-resources')]:
        assert frozen['roots'][frozen_name]['files']==by_kind[kind]['files']
    counts=json.loads((FULL/'counts.json').read_text());assert counts==dict(unit=dict(tests=998,failures=0,errors=0,skipped=0),game=dict(tests=502,failures=0,errors=0,skipped=0))
    artifacts=json.loads((FULL/'frozen-artifacts.json').read_text());assert artifacts['source']==BASE
    for row in artifacts['artifacts']:assert sha(CANONICAL/row['path'])==row['sha256'],row['path']
    compiler=json.loads(COMPILER.read_text());compile_cp=[];by_name={};compile_checks=[]
    for row in compiler['classpath']:
        path=Path(row['path'])
        if row['kind']=='directory':
            assert path in directory_map;path=directory_map[path];assert path in roots
        else:
            assert row['kind']=='file' and path.suffix=='.jar' and sha(path)==row['sha256'],str(path)
            assert path.name not in by_name;by_name[path.name]=row
            compile_checks.append(dict(path=str(path),actual_sha256=sha(path),captured_sha256=row['sha256']))
        compile_cp.append(path)
    assert len(compile_cp)==112
    layout=json.loads(RUNTIME_LAYOUT.read_text());runtime_jars=[];selection=[]
    for row in layout['classpath']:
        if row['kind']=='directory':continue
        assert row['kind']=='file' and row['path'].endswith('.jar')
        old=Path(row['path']);selected=by_name.get(old.name,row);path=Path(selected['path'])
        assert selected['sha256']==row['sha256'],'changed runtime coordinate bytes need separate review: '+old.name
        assert sha(path)==selected['sha256'],str(path)
        runtime_jars.append(path);selection.append(dict(runtime_coordinate=old.name,basis_capture=str(RUNTIME_LAYOUT),basis_path=str(old),basis_sha256=row['sha256'],
            actual_path=str(path),actual_sha256=sha(path),qualified_compiler_path=old.name in by_name,bytes_equal_to_qualified_layout=True))
    assert len(runtime_jars)==103 and sum(row['qualified_compiler_path'] for row in selection)==90
    owner=json.loads(OWNER.read_text());assert owner['outcome']=='PASS' and owner['production_source']==BASE
    mapping=next(path for path in runtime_jars if path.name=='mappings.jar')
    with zipfile.ZipFile(mapping) as archive:mapping_entry_sha256=hashlib.sha256(archive.read('mappings/mappings.tiny')).hexdigest()
    assert mapping_entry_sha256==owner['mappings_sha256']
    named=next(path for path in runtime_jars if path.name.startswith('minecraft-merged-20af7074aa'))
    assert sha(named)==owner['actual_named_MC']['sha256']
    with zipfile.ZipFile(named) as archive:
        entity=archive.read('net/minecraft/entity/Entity.class');assert entity[:4]==b'\xca\xfe\xba\xbe' and b'net/minecraft/entity/Entity' in entity
    base_gt=PRIVATE/'gametest-classes';assert base_gt.is_dir()
    assert (base_gt/'com/terminaldetector/drmd/AiFixtureChunks.class').is_file()
    assert not (base_gt/'com/terminaldetector/drmd/RagdollTrajectoryGameTests.class').exists()
    compile_cp.append(base_gt)
    manifest_source=ROOT/'src/gametest/resources/fixtures/ragdoll-trajectory.fabric.mod.json'
    mixin_source=ROOT/'src/gametest/resources/drmd.ragdoll_trajectory.mixins.json'
    manifest=json.loads(manifest_source.read_text());assert manifest['entrypoints']=={'fabric-gametest':['com.terminaldetector.drmd.RagdollTrajectoryGameTests']}
    assert 'main' not in manifest['entrypoints'] and manifest['mixins']==['drmd.ragdoll_trajectory.mixins.json']
    shutil.copyfile(manifest_source,RES/'fabric.mod.json');shutil.copyfile(mixin_source,RES/mixin_source.name)
    group_main=roots;group_test=[OUT,base_gt,RES]
    runtime_cp=[OUT,base_gt,RES]+roots+runtime_jars;assert len(runtime_cp)==108
    assert not any(str(path).startswith(str(CANONICAL/'build')) for path in runtime_cp+compile_cp),'future canonical output must not be borrowed'
    config_receipt=json.loads(PRIVATE_CONFIG.read_text())
    for row in config_receipt['files']:assert sha(Path(row['private']))==row['sha256']
    remap=PRIVATE/'launch-inputs/remapClasspath.txt';log4j=PRIVATE/'launch-inputs/log4j.xml'
    remap_jars=[Path(p) for p in remap.read_text().split(os.pathsep) if p]
    assert all(p.is_file() and p.suffix=='.jar' for p in remap_jars)
    config='commonProperties\n'
    for key,value in [('fabric.development','true'),('fabric.remapClasspathFile',str(remap)),('log4j.configurationFile',str(log4j)),('log4j2.formatMsgNoLookups','true'),
                      ('fabric.classPathGroups','::'.join(':'.join(str(path) for path in group) for group in [group_main,group_test]))]:config+='\t'+key+'='+value+'\n'
    (RUN/'launch.cfg').write_text(config)
    (CWD/'eula.txt').write_text('eula=true\n');(CWD/'server.properties').write_text('level-name=world\nonline-mode=false\nenable-rcon=false\n')
    sources=[ROOT/'src/gametest/java/com/terminaldetector/drmd/RagdollTrajectoryGameTests.java']+sorted((ROOT/'src/gametest/java/com/terminaldetector/drmd/diag/ragdoll').rglob('*.java'))
    assert len(sources)==7
    compile_command=[str(JAVA/'bin/javac'),'--release','21','-proc:none','-implicit:none','-sourcepath','','-cp',os.pathsep.join(str(path) for path in compile_cp),'-d',str(OUT)]+[str(path) for path in sources]
    game_command=[str(JAVA/'bin/java'),'-Xmx768m','-Dfile.encoding=UTF-8','-Duser.country','-Duser.language=en','-Duser.variant',
        '-Dfabric.dli.config='+str(RUN/'launch.cfg'),'-Dfabric.dli.env=server','-Dfabric.dli.main=net.fabricmc.loader.impl.launch.knot.KnotServer',
        '-Dfabric-api.gametest','-Dfabric-api.gametest.report-file=reports/gametest-results.xml','-Ddrmd.gate.ragdollTrajectory=true',
        '-cp',os.pathsep.join(str(path) for path in runtime_cp),'net.fabricmc.devlaunchinjector.Main','nogui']
    immutable=snapshot([COMPILER,FROZEN,OWNER,RUNTIME_LAYOUT,FULL/'counts.json',FULL/'frozen-artifacts.json',
        ROOT/'docs/v8/U14_BATCH_SOURCE_ADAPTER_CONTRACT_2026-11-18.md',Path(__file__),VALIDATOR,ROOT/'scripts/v8/validate_ragdoll_trajectory.py',ROOT/'scripts/v8/analyze_ragdoll_partial_support.py',PRIVATE_RECEIPT,PRIVATE_CONFIG,OLD_RAW,ROOT/'docs/v8/U14_BATCH_PRIVATE653_API_2026-11-18.json',ROOT/'docs/v8/U14_BASELINE_794976C7_FIRST_ORDINARY_EVIDENCE_2026-11-18.zip',manifest_source,mixin_source,RES,RUN/'launch.cfg',
        JAVA/'bin/java',JAVA/'bin/javac',JAVA/'lib/server/libjvm.so',remap,log4j]+roots+[base_gt]+sources+compile_cp+runtime_jars+remap_jars)
    write(RUN/'proposal.json',dict(source=SOURCE,base=BASE,metadata_head_at_prepare=head,runner_sha256=sha(Path(__file__)),
        qualified_root_counts={name:item['count'] for name,item in frozen['roots'].items()},full_gate_counts=counts,private653_receipt_sha256=sha(PRIVATE_RECEIPT),actual_selected_output_roots=[str(p) for p in roots+[base_gt]],borrowed_future_canonical_outputs=False,
        scalar_batch_limits=dict(rows=256,rows_per_uuid=8,inclusive_world_ticks=8,logical_bytes=8*1024*1024,encoded_bytes=8*1024*1024+64*1024),wrench_scalars=9,java_adapter_contract_before_cohort=True,
        compile_capture=str(COMPILER),compile_checks=compile_checks,runtime_selection=selection,actual_named_mc=dict(path=str(named),sha256=sha(named),entity_sha256=hashlib.sha256(entity).hexdigest()),
        mappings_jar_sha256=sha(mapping),mappings_tiny_entry_sha256=mapping_entry_sha256,main_mod_group=[str(path) for path in group_main],test_mod_group=[str(path) for path in group_test],test_manifest=manifest,
        compile_cp=[str(path) for path in compile_cp],runtime_cp=[str(path) for path in runtime_cp],compile_command=compile_command,game_command=game_command,
        startup_configuration=snapshot([CWD/'eula.txt',CWD/'server.properties']),immutable=immutable,compile_timeout=120,game_timeout=600,terminate_grace=10,
        expected_case='ragdolltrajectorygametests.thirtytworealdeathidentitiesreceiveonethousandunchangedphysicalticks',expected_actors=32,end_age=1000,expected_rows=32000,output_cap_bytes=128*1024*1024,main_compilation=False,sleep_implemented=False,
        prepared_at_utc=now()))
    print(json.dumps(dict(event='PREPARED_NO_JAVA',source=SOURCE,runner_sha256=sha(Path(__file__)),proposal_sha256=sha(RUN/'proposal.json'),
        immutable_files=len(immutable),runtime_cp_entries=len(runtime_cp),compile_cp_entries=len(compile_cp),actors=32,end_age=1000)),flush=True)

def child(command,name,timeout):
    write(RUN/(name+'-start.json'),dict(command=command,cwd=str(CWD),started_at_utc=now(),started_unix_ns=time.time_ns(),timeout=timeout))
    timed=killed=False
    with (RUN/(name+'-first.log')).open('xb') as log:
        process=subprocess.Popen(command,cwd=CWD,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
        print(json.dumps(dict(event='JAVA_STARTED',kind=name,pid=process.pid)),flush=True)
        try:code=process.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            timed=True;os.killpg(process.pid,signal.SIGTERM)
            try:code=process.wait(timeout=10)
            except subprocess.TimeoutExpired:killed=True;os.killpg(process.pid,signal.SIGKILL);code=process.wait()
    write(RUN/(name+'-exit.json'),dict(pid=process.pid,actual_child_exit=code,timed_out=timed,forced_kill=killed,closed_at_utc=now()))
    print(json.dumps(dict(event='JAVA_CLOSED',kind=name,actual_child_exit=code,timed_out=timed,forced_kill=killed)),flush=True)
    return code,timed,killed

def run():
    assert os.environ.get('U14_RAGDOLL_BATCH_JAVA_LEASE')=='granted','explicit root Java lease required'
    p=json.loads((RUN/'proposal.json').read_text());assert p['runner_sha256']==sha(Path(__file__))
    source_guard();verify(p['immutable']);verify(p['startup_configuration'])
    assert shutil.disk_usage(ROOT).free>=256*1024*1024,'256MiB trajectory disk guard; do not lower'
    assert not any(OUT.iterdir()) and not (RUN/'compile-start.json').exists() and not (RUN/'game-start.json').exists(),'no retry of first attempt'
    assert not (CWD/'world').exists() and not (CWD/'reports/gametest-results.xml').exists()
    assert not list(CWD.glob('ragdoll-trajectory*'))
    code,timed,killed=child(p['compile_command'],'compile',p['compile_timeout'])
    if code or timed or killed:raise SystemExit(code or 1)
    outputs=snapshot([OUT]);assert len(outputs)==17 and all(row['path'].endswith('.class') for row in outputs)
    expected_names=['RagdollTrajectoryGameTests','diag/ragdoll/RagdollTrajectoryRecorder','diag/ragdoll/RagdollTrajectoryRecorder$Run','diag/ragdoll/RagdollTrajectoryRecorder$Actor','diag/ragdoll/RagdollTrajectoryRecorder$Owner','diag/ragdoll/RagdollTrajectoryRecorder$PartFrame','diag/ragdoll/RagdollTrajectoryRecorder$Frame','diag/ragdoll/RagdollTrajectoryOutput','diag/ragdoll/RagdollTrajectoryOutput$Failure','diag/ragdoll/RagdollTrajectoryOutput$Staging','diag/ragdoll/RagdollTrajectoryOutput$StagingLimit','diag/ragdoll/RagdollTrajectoryOutputContract','diag/ragdoll/RagdollTrajectoryOutputContract$IoFailureSink','diag/ragdoll/RagdollTrajectoryOutputContract$RuntimeFailureSink','diag/ragdoll/mixin/RagdollTrajectoryEntityProbe','diag/ragdoll/mixin/RagdollTrajectorySimulationProbe','diag/ragdoll/mixin/RagdollTrajectoryPartProbe']
    assert {Path(row['path']).relative_to(OUT).as_posix() for row in outputs}=={'com/terminaldetector/drmd/'+name+'.class' for name in expected_names}
    write(RUN/'fresh-fixture-outputs.json',outputs)
    verify(p['immutable']);verify(p['startup_configuration']);source_guard()
    start=time.time_ns();code,timed,killed=child(p['game_command'],'game',p['game_timeout'])
    # No further child process may start; postchecks below are Python/file reads only.
    verify(outputs);verify(p['immutable']);source_guard()
    xml=CWD/'reports/gametest-results.xml';cases=[];failures=errors=skips=0;fresh=False
    if xml.is_file():
        tree=ET.parse(xml).getroot();cases=[node.attrib['name'] for node in tree.findall('.//testcase')]
        failures=len(tree.findall('.//failure'));errors=len(tree.findall('.//error'));skips=len(tree.findall('.//skipped'));fresh=xml.stat().st_mtime_ns>=start
        shutil.copy2(xml,RUN/'first-game-results.xml')
    observation=None;observation_error=None
    try:
        observation=VALIDATION.validate(CWD)
        write(RUN/'trajectory-analysis-first.json',observation)
    except (AssertionError,KeyError,ValueError,TypeError,OSError,EOFError) as failure:observation_error=repr(failure)
    log_text=(RUN/'game-first.log').read_text(errors='replace');adapter_markers=log_text.count('U14_OUTPUT_ADAPTER_CONTRACT_PASS');cohort_markers=log_text.count('U14_TRAJECTORY_REAL_TICKS')
    passed=code==0 and not timed and not killed and fresh and cases==[p['expected_case']] and failures==errors==skips==0 and observation is not None and adapter_markers==cohort_markers==1
    brief=None if observation is None else {key:value for key,value in observation.items() if key!='per_actor'}
    write(RUN/'first-trajectory-outcome.json',dict(source=SOURCE,base=BASE,actual_child_exit=code,timed_out=timed,forced_kill=killed,cases=cases,
        failures=failures,errors=errors,skips=skips,fresh_xml=fresh,adapter_contract_markers=adapter_markers,cohort_completion_markers=cohort_markers,diagnostic=brief,observation_error=observation_error,
        immutable_inputs_unchanged=True,fixture_outputs_unchanged=True,startup_after=snapshot([Path(row['path']) for row in p['startup_configuration']]),
        verified_first_diagnostic=passed,sleep_implemented=False,main_compilation=False,gradle_run=False,native_run=False,closed_at_utc=now()))
    print(json.dumps(dict(event='POSTCHECK',verified_first_diagnostic=passed,diagnostic=brief,observation_error=observation_error)),flush=True)
    raise SystemExit(0 if passed else code or 1)

if __name__=='__main__':
    if sys.argv[1:]==['--prepare']:prepare()
    elif sys.argv[1:]==['--run-with-root-java-lease']:run()
    else:raise SystemExit('Use --prepare (no JVM), or --run-with-root-java-lease only after explicit root grant')
