from pathlib import Path
import datetime,fcntl,gzip,hashlib,importlib.util,json,os,shutil,zipfile,zlib

root=Path('/workspace/ungravity-v5/ragdoll-rest-baseline-20261118')
run=root/'work/u14-batched-24fc339-first-20261118';world=run/'runtime/world';raw=run/'runtime/ragdoll-trajectory.jsonl.gz'
def sha(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
spec=importlib.util.spec_from_file_location('sealed_batch',root/'scripts/v8/run_ragdoll_batched_trajectory.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
p=json.loads((run/'proposal.json').read_text());m.source_guard();m.verify(p['immutable']);m.verify(json.loads((run/'fresh-fixture-outputs.json').read_text()))
for phase in ['compile','game']:
    receipt=json.loads((run/(phase+'-exit.json')).read_text());assert receipt['actual_child_exit']==0 and not receipt['timed_out'] and not receipt['forced_kill'];assert not Path('/proc/'+str(receipt['pid'])).exists()
assert world.is_dir() and not world.is_symlink() and world.resolve()==world.absolute()
start=json.loads((run/'game-start.json').read_text())['started_unix_ns'];files=sorted(f for f in world.rglob('*') if f.is_file())
assert len(files)==39 and all(not f.is_symlink() and f.stat().st_nlink==1 and f.stat().st_ctime_ns>=start for f in files)
assert not any(f.suffix.lower() in ['.jar','.log','.png','.java','.py'] for f in files)
assert sha(raw)=='19843b616d5ba027847a025d0f51168e9e7a1588fad13ee24718df8847460f8e'
logical=hashlib.sha256();logical_count=0
with gzip.open(raw,'rb') as stream:
    while block:=stream.read(1024*1024):logical.update(block);logical_count+=len(block)
assert logical_count==405433030
snapshot=[dict(path=f.relative_to(root).as_posix(),bytes=f.stat().st_size,sha256=sha(f),device=f.stat().st_dev,inode=f.stat().st_ino,ctime_ns=f.stat().st_ctime_ns,mtime_ns=f.stat().st_mtime_ns,nlink=f.stat().st_nlink) for f in files]
checks=[]
for f in files:
    data=f.read_bytes()
    if data[:2]==b'\x1f\x8b':checks.append(dict(path=str(f.relative_to(world)),kind='gzip-full-CRC',decoded_bytes=len(gzip.decompress(data))))
    if f.suffix=='.mca':
        if not data:
            checks.append(dict(path=str(f.relative_to(world)),kind='valid-empty-region',bytes=0));continue
        assert len(data)>=8192 and len(data)%4096==0;chunks=[];used={0,1}
        for i in range(1024):
            location=int.from_bytes(data[i*4:i*4+4],'big');sector=location>>8;allocated=location&255
            if not location:continue
            assert sector>=2 and allocated>0 and (sector+allocated)*4096<=len(data)
            sectors=set(range(sector,sector+allocated));assert not used.intersection(sectors);used.update(sectors)
            at=sector*4096;length=int.from_bytes(data[at:at+4],'big');kind=data[at+4];assert 1<=length<=allocated*4096-4 and not kind&128
            payload=data[at+5:at+4+length]
            if kind==1:decoded=gzip.decompress(payload)
            elif kind==2:decoded=zlib.decompress(payload)
            elif kind==3:decoded=payload
            else:raise AssertionError(('unknown region compression',kind,str(f)))
            chunks.append(dict(slot=i,compression=kind,decoded_bytes=len(decoded)))
        checks.append(dict(path=str(f.relative_to(world)),kind='all-anvil-sectors-and-compressed-chunks',chunks=chunks))
def external_fds():
    found=[];denied=0
    for proc in Path('/proc').iterdir():
        if not proc.name.isdigit():continue
        try:entries=list((proc/'fd').iterdir())
        except (FileNotFoundError,ProcessLookupError):continue
        except PermissionError:denied+=1;continue
        for fd in entries:
            try:target=fd.resolve(strict=False)
            except (FileNotFoundError,PermissionError,OSError):continue
            if target.is_relative_to(world) and int(proc.name)!=os.getpid():found.append(dict(pid=int(proc.name),fd=fd.name,path=str(target)))
    return found,denied
with (world/'session.lock').open('r+b') as session:
    fcntl.lockf(session,fcntl.LOCK_EX|fcntl.LOCK_NB);fcntl.flock(session,fcntl.LOCK_EX|fcntl.LOCK_NB)
    foreign,denied=external_fds();assert not foreign;st=os.fstat(session.fileno());locks=[]
    for line in Path('/proc/locks').read_text().splitlines():
        values=line.split()
        if len(values)<6 or ':' not in values[5]:continue
        try:major,minor,inode=values[5].split(':')
        except ValueError:continue
        if int(major,16)==os.major(st.st_dev) and int(minor,16)==os.minor(st.st_dev) and int(inode)==st.st_ino:locks.append(line)
    assert len(locks)==2 and all(int(line.split()[4])==os.getpid() for line in locks),locks
    check=dict(world_snapshot=snapshot,world_files=39,world_bytes=sum(f.stat().st_size for f in files),world_allocated_bytes=sum(f.stat().st_blocks*512 for f in files),fresh_inode_ctime_after_game_start=True,compression_checks=checks,
        session_locks=dict(fcntl_and_flock_exclusive=True,proc_locks=locks,foreign_fds=foreign,proc_fd_permission_denials=denied),raw=dict(path=raw.relative_to(root).as_posix(),bytes=raw.stat().st_size,sha256=sha(raw),full_gzip_crc_verified=True,logical_bytes=logical_count,logical_sha256=logical.hexdigest()),
        expected_old_raw_sha256='cf48aed0fa3f6506396198a11430194203a9f0b133184ec12c7e8d36cdae75cc',raw_will_not_be_deleted=True,future_seed_needed=False,reason='Completed disposable observer fixture discarded owned actors; root authorized only its closed world reclaim, not traces',java_run=False)
    with (run/'world-prearchive-checks.json').open('x') as out:json.dump(check,out,indent=2);out.write('\n')
    paths=[f for f in run.rglob('*') if f.is_file() and f!=raw]
    paths+=[root/'src/gametest/java/com/terminaldetector/drmd/RagdollTrajectoryGameTests.java']+list((root/'src/gametest/java/com/terminaldetector/drmd/diag/ragdoll').rglob('*.java'))
    paths+=[root/'src/gametest/resources/drmd.ragdoll_trajectory.mixins.json',root/'src/gametest/resources/fixtures/ragdoll-trajectory.fabric.mod.json']
    paths+=[root/'scripts/v8'/name for name in ['run_ragdoll_batched_trajectory.py','validate_ragdoll_batched_trajectory.py','validate_ragdoll_trajectory.py','analyze_ragdoll_partial_support.py','test_ragdoll_batched_trajectory.py']]
    paths+=[root/'docs/v8'/name for name in ['U14_BATCH_SOURCE_ADAPTER_CONTRACT_2026-11-18.md','U14_BATCH_CPU_SOURCE_CONTROLS_2026-11-18.json','U14_BATCH_PREPARED_LAUNCH_2026-11-18.md','U14_BATCH_PRIVATE653_API_2026-11-18.json','U14_PRIVATE653_NAMED_INPUTS_2026-11-18.json']]
    paths+=[root/'work/u14-private653-inputs-20261118/launch-inputs'/name for name in ['receipt.json','remapClasspath.txt','log4j.xml']]
    members={f.relative_to(root).as_posix():f.read_bytes() for f in sorted(set(paths))}
    manifest=dict(source=m.SOURCE,metadata='e281b1840300c8b8cd82f561c0d7dcbb4332f472',status='PASS_COMPLETE_OBSERVER_DIAGNOSTIC',external_raw=check['raw'],raw_included=False,files=[dict(path=n,bytes=len(d),sha256=hashlib.sha256(d).hexdigest()) for n,d in members.items()])
    archive=root/'docs/v8/U14_BATCH_24FC339C_FIRST_ORDINARY_COMPACT_EVIDENCE_2026-11-18.zip'
    with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as zipped:
        for name,data in members.items():zipped.writestr(name,data)
        zipped.writestr('ARCHIVE_MANIFEST.json',json.dumps(manifest,indent=2)+'\n')
    with zipfile.ZipFile(archive) as zipped:
        assert zipped.testzip() is None and len(zipped.namelist())==len(members)+1
        for name,data in members.items():assert zipped.read(name)==data
        for row in snapshot:assert hashlib.sha256(zipped.read(row['path'])).hexdigest()==row['sha256']
    for row in snapshot:
        f=root/row['path'];current=f.stat();assert (current.st_dev,current.st_ino,current.st_ctime_ns,current.st_size)==(row['device'],row['inode'],row['ctime_ns'],row['bytes']) and sha(f)==row['sha256']
    assert not external_fds()[0];before_free=shutil.disk_usage(root).free
    shutil.rmtree(world);assert not world.exists();after_free=shutil.disk_usage(root).free
    receipt=dict(deleted_only=str(world),world_files=39,world_bytes=check['world_bytes'],world_allocated_bytes=check['world_allocated_bytes'],world_archive_all_sha_bytes_crc_verified=True,world_compression_validated=True,exclusive_locks_held_through_delete=True,fresh_inodes_reverified=True,future_seed_needed=False,
        archive=dict(path=archive.relative_to(root).as_posix(),bytes=archive.stat().st_size,sha256=sha(archive),members=len(members)+1,contains_full_world=True,contains_raw_trace=False),free_before=before_free,free_after=after_free,new_raw_unchanged_sha256=sha(raw),old_raw_unchanged_sha256=sha(m.OLD_RAW),java_run=False,completed_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
    with (run/'world-reclaim-receipt.json').open('x') as out:json.dump(receipt,out,indent=2);out.write('\n')
    print(json.dumps(receipt,indent=2))
