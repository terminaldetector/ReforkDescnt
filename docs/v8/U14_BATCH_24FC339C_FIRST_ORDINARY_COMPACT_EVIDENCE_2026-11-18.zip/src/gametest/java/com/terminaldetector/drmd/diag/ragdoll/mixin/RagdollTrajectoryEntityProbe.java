package com.terminaldetector.drmd.diag.ragdoll.mixin;

import com.terminaldetector.drmd.client.portal.PortalTransform.Vec3;
import com.terminaldetector.drmd.diag.ragdoll.RagdollTrajectoryRecorder;
import com.terminaldetector.drmd.entity.RagdollEntity;
import com.terminaldetector.drmd.physics.ragdoll.RagdollSimulation;
import net.minecraft.util.math.Box;
import org.spongepowered.asm.mixin.*;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.*;

@Mixin(value=RagdollEntity.class,remap=false)
public abstract class RagdollTrajectoryEntityProbe {
    @Shadow private int lifeTicks;
    @Inject(method="tick",at=@At("HEAD"),require=1,remap=false)
    private void trajectoryEnter(CallbackInfo ci){RagdollTrajectoryRecorder.enter((RagdollEntity)(Object)this,lifeTicks);}
    @Inject(method="tick",at=@At("RETURN"),require=1,remap=false)
    private void trajectoryLeave(CallbackInfo ci){RagdollTrajectoryRecorder.leave((RagdollEntity)(Object)this,lifeTicks);}
    @Inject(method="resolveTerrain",at=@At("HEAD"),require=1,remap=false)
    private void trajectoryTerrainEnter(RagdollSimulation.Part part,Vec3 fallback,CallbackInfo ci){RagdollTrajectoryRecorder.terrainEnter(part);}
    @Inject(method="resolveTerrain",at=@At("RETURN"),require=1,remap=false)
    private void trajectoryTerrainLeave(RagdollSimulation.Part part,Vec3 fallback,CallbackInfo ci){RagdollTrajectoryRecorder.terrainLeave(part);}
    @Inject(method="insideLoadedWorld",at=@At("RETURN"),require=1,remap=false)
    private void trajectoryAvailability(Box bounds,CallbackInfoReturnable<Boolean> ci){RagdollTrajectoryRecorder.available(ci.getReturnValue());}
}
