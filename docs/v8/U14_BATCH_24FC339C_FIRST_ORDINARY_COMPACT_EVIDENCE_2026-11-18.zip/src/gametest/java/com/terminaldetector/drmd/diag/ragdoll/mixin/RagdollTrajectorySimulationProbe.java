package com.terminaldetector.drmd.diag.ragdoll.mixin;

import com.terminaldetector.drmd.client.portal.PortalTransform.Vec3;
import com.terminaldetector.drmd.diag.ragdoll.RagdollTrajectoryRecorder;
import com.terminaldetector.drmd.physics.ragdoll.*;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value=RagdollSimulation.class,remap=false)
public abstract class RagdollTrajectorySimulationProbe {
    @Inject(method="step(DLcom/terminaldetector/drmd/client/portal/PortalTransform$Vec3;IILcom/terminaldetector/drmd/physics/ragdoll/RagdollSimulation$CollisionResolver;)V",at=@At("HEAD"),require=1,remap=false)
    private void trajectoryStep(double seconds,Vec3 gravity,int substeps,int iterations,RagdollSimulation.CollisionResolver contacts,CallbackInfo ci){
        RagdollTrajectoryRecorder.simulation((RagdollSimulation)(Object)this,seconds,gravity,substeps,iterations,contacts!=null);
    }
    @Inject(method="solve",at=@At("HEAD"),require=1,remap=false)
    private void trajectoryJoint(RagdollRig.Joint joint,double dt,CallbackInfo ci){RagdollTrajectoryRecorder.joint((RagdollSimulation)(Object)this);}
}
