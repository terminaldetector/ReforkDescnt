package com.terminaldetector.drmd.diag.ragdoll.mixin;

import com.terminaldetector.drmd.client.portal.PortalTransform.*;
import com.terminaldetector.drmd.d6.D6PhysicsBody;
import com.terminaldetector.drmd.diag.ragdoll.RagdollTrajectoryRecorder;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.*;

@Mixin(value=D6PhysicsBody.class,remap=false)
public abstract class RagdollTrajectoryPartProbe {
    @Inject(method="step",at=@At("HEAD"),require=1,remap=false)
    private void trajectoryStep(double seconds,CallbackInfo ci){RagdollTrajectoryRecorder.step((D6PhysicsBody)(Object)this,seconds);}
    @Inject(method="step",at=@At("RETURN"),require=1,remap=false)
    private void trajectoryAfterStep(double seconds,CallbackInfo ci){RagdollTrajectoryRecorder.state((D6PhysicsBody)(Object)this);}
    @Inject(method="applyImpulse",at=@At("RETURN"),require=1,remap=false)
    private void trajectoryImpulse(Vec3 impulse,Vec3 offset,CallbackInfo ci){RagdollTrajectoryRecorder.state((D6PhysicsBody)(Object)this);}
    @Inject(method="integrateSolvedPose",at=@At("HEAD"),require=1,remap=false)
    private void trajectoryIntegrateEnter(double seconds,CallbackInfo ci){RagdollTrajectoryRecorder.poseEnter((D6PhysicsBody)(Object)this);}
    @Inject(method="integrateSolvedPose",at=@At("RETURN"),require=1,remap=false)
    private void trajectoryIntegrateLeave(double seconds,CallbackInfo ci){RagdollTrajectoryRecorder.poseLeave((D6PhysicsBody)(Object)this,0);}
    @Inject(method="withPosition",at=@At("HEAD"),require=1,remap=false)
    private void trajectoryPositionEnter(Vec3 position,CallbackInfoReturnable<D6PhysicsBody> ci){RagdollTrajectoryRecorder.poseEnter((D6PhysicsBody)(Object)this);}
    @Inject(method="withPosition",at=@At("RETURN"),require=1,remap=false)
    private void trajectoryPositionLeave(Vec3 position,CallbackInfoReturnable<D6PhysicsBody> ci){RagdollTrajectoryRecorder.poseLeave((D6PhysicsBody)(Object)this,1);}
    @Inject(method="withRotation",at=@At("HEAD"),require=1,remap=false)
    private void trajectoryRotationEnter(Quat rotation,CallbackInfoReturnable<D6PhysicsBody> ci){RagdollTrajectoryRecorder.poseEnter((D6PhysicsBody)(Object)this);}
    @Inject(method="withRotation",at=@At("RETURN"),require=1,remap=false)
    private void trajectoryRotationLeave(Quat rotation,CallbackInfoReturnable<D6PhysicsBody> ci){RagdollTrajectoryRecorder.poseLeave((D6PhysicsBody)(Object)this,2);}
    @Inject(method="contactImpulse",at=@At("HEAD"),require=1,remap=false)
    private void trajectoryContactEnter(Vec3 offset,Vec3 normal,double friction,CallbackInfoReturnable<Double> ci){RagdollTrajectoryRecorder.contactEnter((D6PhysicsBody)(Object)this,offset);}
    @Inject(method="contactImpulse",at=@At("RETURN"),require=1,remap=false)
    private void trajectoryContactLeave(Vec3 offset,Vec3 normal,double friction,CallbackInfoReturnable<Double> ci){RagdollTrajectoryRecorder.contactLeave((D6PhysicsBody)(Object)this,normal,ci.getReturnValue());}
}
