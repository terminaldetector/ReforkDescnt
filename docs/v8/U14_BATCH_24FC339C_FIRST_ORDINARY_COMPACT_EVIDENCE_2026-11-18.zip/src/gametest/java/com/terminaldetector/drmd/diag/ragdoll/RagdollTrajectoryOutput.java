package com.terminaldetector.drmd.diag.ragdoll;

import java.io.*;
import java.util.*;
import java.util.zip.GZIPOutputStream;

/** Test-only JDK byte adapter. Queue entries are scalar JSONL bytes and UUID strings, never game objects. */
final class RagdollTrajectoryOutput {
    static final long TRACE_CAP=127L*1024*1024,METADATA_CAP=1024*1024;
    static final int ROW_CAP=256*1024,LOGICAL_CAP=8*1024*1024,ENCODED_CAP=LOGICAL_CAP+64*1024,ROWS_CAP=256,IDENTITY_ROWS_CAP=8,TICK_SPAN_CAP=7;
    record Failure(String code,String detail){}
    private static final class StagingLimit extends IOException {StagingLimit(){super("encoded staging exceeds fixed bound");}}
    private static final class Staging extends OutputStream {
        private final byte[] bytes;private int size;
        Staging(int cap){bytes=new byte[cap];}
        void reset(){size=0;}
        int size(){return size;}
        @Override public void write(int value)throws IOException{if(size==bytes.length)throw new StagingLimit();bytes[size++]=(byte)value;}
        @Override public void write(byte[] source,int offset,int length)throws IOException{
            Objects.checkFromIndexSize(offset,length,source.length);if(length>bytes.length-size)throw new StagingLimit();System.arraycopy(source,offset,bytes,size,length);size+=length;
        }
        void writeTo(OutputStream sink)throws IOException{sink.write(bytes,0,size);}
    }
    private final OutputStream sink;private final long traceCap;private final Staging staging;
    private final List<byte[]> pending=new ArrayList<>();private final Map<String,Integer> identityRows=new HashMap<>();
    private int logicalPending;private long firstTick=Long.MIN_VALUE,lastTick=Long.MIN_VALUE;
    private long offeredRows,offeredLogical,persistedRows,persistedLogical,discardedRows,discardedLogical,committedBytes,members;
    private int maxRows,maxLogical,maxEncoded,maxIdentityRows,maxTickSpan;private Failure failure;private boolean closed;

    RagdollTrajectoryOutput(OutputStream sink){this(sink,TRACE_CAP,ENCODED_CAP);}
    /** Contract tests may lower byte budgets; callers can never raise production limits. */
    RagdollTrajectoryOutput(OutputStream sink,long traceCap,int encodedCap){
        if(traceCap<0||traceCap>TRACE_CAP||encodedCap<1||encodedCap>ENCODED_CAP)throw new IllegalArgumentException("fixed output upper bounds");
        this.sink=Objects.requireNonNull(sink);this.traceCap=traceCap;staging=new Staging(encodedCap);
    }
    boolean append(String identity,long worldTick,byte[] line){
        Objects.requireNonNull(identity);Objects.requireNonNull(line);
        if(identity.isEmpty()||identity.length()>64)throw new IllegalArgumentException("bounded scalar identity required");
        if(failure!=null)return false;if(closed)throw new IllegalStateException("closed output");
        if(firstTick!=Long.MIN_VALUE&&worldTick<lastTick)throw new IllegalArgumentException("packing world clock moved backwards");
        offeredRows++;offeredLogical+=line.length;
        if(line.length>ROW_CAP)return fail("ROW_LIMIT","logical row exceeds256KiB");
        if(!pending.isEmpty()&&(pending.size()==ROWS_CAP||logicalPending+line.length>LOGICAL_CAP||identityRows.getOrDefault(identity,0)==IDENTITY_ROWS_CAP||worldTick-firstTick>TICK_SPAN_CAP))
            if(!flush())return false;
        if(pending.isEmpty())firstTick=worldTick;
        lastTick=worldTick;pending.add(line.clone());logicalPending+=line.length;
        int count=identityRows.merge(identity,1,Integer::sum);
        maxRows=Math.max(maxRows,pending.size());maxLogical=Math.max(maxLogical,logicalPending);maxIdentityRows=Math.max(maxIdentityRows,count);maxTickSpan=Math.max(maxTickSpan,(int)(worldTick-firstTick));
        return pending.size()!=ROWS_CAP||flush();
    }
    boolean flush(){
        if(failure!=null)return false;if(closed)throw new IllegalStateException("closed output");if(pending.isEmpty())return true;
        staging.reset();
        try(var gzip=new GZIPOutputStream(staging,8192)){for(var row:pending)gzip.write(row);}
        catch(StagingLimit limit){return fail("ENCODED_STAGING_LIMIT",limit.getMessage());}
        catch(IOException io){return fail("ENCODING_IO",io.toString());}
        maxEncoded=Math.max(maxEncoded,staging.size());
        if(staging.size()>traceCap-committedBytes)return fail("TRACE_LIMIT","complete gzip batch exceeds remaining127MiB trace budget");
        try{staging.writeTo(sink);}catch(IOException io){return fail("TRACE_WRITE_IO",io.toString());}
        committedBytes+=staging.size();persistedRows+=pending.size();persistedLogical+=logicalPending;members++;
        pending.clear();identityRows.clear();logicalPending=0;firstTick=lastTick=Long.MIN_VALUE;return true;
    }
    private boolean fail(String code,String detail){
        if(failure==null)failure=new Failure(code,detail==null?"":detail.substring(0,Math.min(detail.length(),1024)));
        discardedRows=offeredRows-persistedRows;discardedLogical=offeredLogical-persistedLogical;
        pending.clear();identityRows.clear();logicalPending=0;firstTick=lastTick=Long.MIN_VALUE;return false;
    }
    boolean finish(){
        if(closed)return failure==null;
        if(failure==null)flush();
        try{sink.close();}catch(IOException io){fail("TRACE_CLOSE_IO",io.toString());}closed=true;return failure==null;
    }
    Failure failure(){return failure;}
    long rows(){return persistedRows;}
    long bytes(){return committedBytes;}
    long logicalBytes(){return persistedLogical;}
    static boolean metadataFits(byte[] data,long alreadyWritten){return data.length<=METADATA_CAP/2&&alreadyWritten>=0&&data.length<=METADATA_CAP-alreadyWritten;}
    static Failure metadata(OutputStream sink,byte[] data,long alreadyWritten){
        if(!metadataFits(data,alreadyWritten))return new Failure("METADATA_LIMIT","metadata reserve would be exceeded");
        try{sink.write(data);return null;}catch(IOException io){return new Failure("METADATA_IO",io.toString().substring(0,Math.min(io.toString().length(),1024)));}
    }
    Map<String,Object> stats(){
        var result=new LinkedHashMap<String,Object>();
        result.put("offered_rows",offeredRows);result.put("offered_logical_bytes",offeredLogical);result.put("persisted_rows",persistedRows);result.put("persisted_logical_bytes",persistedLogical);
        result.put("buffered_rows",pending.size());result.put("buffered_logical_bytes",logicalPending);result.put("discarded_rows",discardedRows);result.put("discarded_logical_bytes",discardedLogical);
        result.put("committed_bytes",committedBytes);result.put("members",members);result.put("max_batch_rows",maxRows);result.put("max_batch_logical_bytes",maxLogical);result.put("max_encoded_bytes",maxEncoded);
        result.put("max_rows_per_uuid",maxIdentityRows);result.put("max_world_tick_span",maxTickSpan);result.put("closed",closed);result.put("failure",failure);
        result.put("trace_cap_bytes",traceCap);result.put("row_cap_bytes",ROW_CAP);result.put("logical_cap_bytes",LOGICAL_CAP);result.put("encoded_cap_bytes",staging.bytes.length);
        return result;
    }
}
