package com.terminaldetector.drmd;

import com.terminaldetector.drmd.diag.ragdoll.RagdollTrajectoryRecorder;
import com.terminaldetector.drmd.diag.ragdoll.RagdollTrajectoryOutputContract;
import com.terminaldetector.drmd.entity.*;
import com.terminaldetector.drmd.physics.PhysicsProfileState;
import net.fabricmc.fabric.api.gametest.v1.FabricGameTest;
import net.minecraft.block.Blocks;
import net.minecraft.entity.Entity;
import net.minecraft.test.*;
import net.minecraft.util.math.*;
import java.util.*;

/** Separate opt-in diagnostic; the successful32/128 baseline is never extended or rewritten. */
public final class RagdollTrajectoryGameTests implements FabricGameTest {
    @GameTest(templateName=EMPTY_STRUCTURE,batchId="u14-trajectory32-age1000",tickLimit=1250)
    public void thirtyTwoRealDeathIdentitiesReceiveOneThousandUnchangedPhysicalTicks(TestContext c){
        c.assertTrue(RagdollTrajectoryRecorder.ENABLED,"explicit trajectory observer flag required");
        c.assertTrue(PhysicsProfileState.expanded(c.getWorld()),"unchanged expanded profile required");
        RagdollTrajectoryOutputContract.verify();
        var floor=c.getAbsolutePos(new BlockPos(1000,80,1000));
        var chunks=new AiFixtureChunks(c.getWorld(),floor.add(22,0,1),2);
        var area=new Box(Vec3d.of(floor.add(-6,0,-6)),Vec3d.of(floor.add(52,12,10)));
        var drones=new ArrayList<DroneEntity>();var corpses=new ArrayList<RagdollEntity>();
        boolean[] closed={false};int[] stage={0},callbacks={0},admission={0};long[] deathTick={Long.MIN_VALUE};
        Runnable cleanup=()->{
            if(closed[0])return;closed[0]=true;
            drones.forEach(Entity::discard);corpses.forEach(Entity::discard);
            c.getWorld().getEntitiesByClass(RagdollEntity.class,area,Entity::isAlive).forEach(Entity::discard);chunks.close();
        };
        try{
            c.assertTrue(c.getWorld().getEntitiesByClass(RagdollEntity.class,area,Entity::isAlive).isEmpty(),"fresh owned volume has no old corpse");
            for(var p:BlockPos.iterate(floor.add(-5,0,-5),floor.add(50,0,8)))c.getWorld().setBlockState(p,Blocks.OBSIDIAN.getDefaultState(),2);
            for(var p:BlockPos.iterate(floor.add(-5,1,-5),floor.add(50,10,8)))c.getWorld().setBlockState(p,Blocks.AIR.getDefaultState(),2);
            for(int i=0;i<32;i++){
                var drone=ModEntities.DRONE.create(c.getWorld());c.assertTrue(drone!=null,"existing ordinary drone factory");
                drone.setPosition(Vec3d.ofBottomCenter(floor.add((i%16)*3,3,(i/16)*3)));drone.setAiDisabled(true);drone.setHealth(1);drones.add(drone);
            }
            RagdollTrajectoryRecorder.begin(c.getWorld(),floor);
        }catch(RuntimeException|Error failure){try{RagdollTrajectoryRecorder.finish("failed_init",failure.toString());}finally{cleanup.run();}throw failure;}
        c.runAtEveryTick(()->{
            if(closed[0])return;
            try{
                c.assertTrue(RagdollTrajectoryRecorder.outputFailure()==null,"trajectory observer NONPASS: "+RagdollTrajectoryRecorder.outputFailure());
                // The existing short helper resets once; this long ordinary test keeps its world active.
                c.getWorld().resetIdleTimeout();
                c.assertTrue(++callbacks[0]<1180,"bounded continuous ordinary trajectory timed out; stage="+stage[0]);
                if(stage[0]==0){
                    c.assertTrue(++admission[0]<=80,"original entity-ticking admission bound: "+chunks.readiness(drones.stream().map(Entity::getBlockPos).toArray(BlockPos[]::new)));
                    if(!chunks.entityTicking(drones.stream().map(Entity::getBlockPos).toArray(BlockPos[]::new)))return;
                    int count=0;
                    for(var drone:drones){if(!c.getWorld().spawnEntity(drone)){RagdollTrajectoryRecorder.admission("actual_live_spawns",count);throw new IllegalStateException("ordinary spawn refused at"+count);}count++;}
                    RagdollTrajectoryRecorder.admission("actual_live_spawns",count);stage[0]=1;return;
                }
                if(stage[0]==1){
                    c.assertTrue(++admission[0]<=100,"live actors did not receive ordinary ticks");
                    if(drones.stream().anyMatch(d->d.age<3))return;
                    c.assertTrue(drones.stream().allMatch(d->c.getWorld().getEntity(d.getUuid())==d),"actual registered live identities before lethal damage");
                    deathTick[0]=c.getWorld().getTime();int attempts=0;
                    for(var drone:drones){drone.damage(drone.getDamageSources().generic(),1000);attempts++;}
                    RagdollTrajectoryRecorder.admission("death_attempts",attempts);
                    RagdollTrajectoryRecorder.admission("actual_dead_drones",drones.stream().filter(d->!d.isAlive()).count());
                    RagdollTrajectoryRecorder.admission("death_world_tick",deathTick[0]);
                    RagdollTrajectoryRecorder.admission("death_window_world_ticks",c.getWorld().getTime()-deathTick[0]);
                    corpses.addAll(c.getWorld().getEntitiesByClass(RagdollEntity.class,area,Entity::isAlive));corpses.sort(Comparator.comparingInt(Entity::getId));
                    RagdollTrajectoryRecorder.admission("actual_corpses",corpses.size());
                    RagdollTrajectoryRecorder.admission("actual_parts",corpses.stream().mapToInt(b->b.simulation().parts().size()).sum());
                    if(corpses.size()!=32){
                        RagdollTrajectoryRecorder.admission("refusal_reason",null);
                        RagdollTrajectoryRecorder.admission("refusal_reason_null","death event exposes no structured corpse refusal cause");
                    }
                    c.assertTrue(attempts==32&&drones.stream().noneMatch(Entity::isAlive)&&corpses.size()==32&&c.getWorld().getTime()==deathTick[0],"all32 real deaths in one tick, original budgets unchanged");
                    for(var body:corpses)c.assertTrue(body.rigVersion()==1&&body.flightHullKind()==null&&body.simulation().parts().size()==5&&body.simulation().centreVelocity().length()>.01,"existing scout family and actual death impulse");
                    RagdollTrajectoryRecorder.enroll(corpses);stage[0]=2;return;
                }
                if(corpses.stream().anyMatch(b->b.age<1000))return;
                for(var body:corpses)c.assertTrue(body.isAlive()&&c.getWorld().getEntity(body.getUuid())==body&&chunks.entityTicking(body.getBlockPos()),"same real corpse identity is alive/entity-ticking through age1000");
                c.assertTrue(c.getWorld().getTime()-deathTick[0]>=999,"ordinary world clock covers continuous thousand-tick trajectory");
                RagdollTrajectoryRecorder.assertComplete();RagdollTrajectoryRecorder.finish("complete","32 real deaths, continuous normal age1..1000, no sleep");
                c.assertTrue(RagdollTrajectoryRecorder.outputFailure()==null,"trajectory final metadata NONPASS: "+RagdollTrajectoryRecorder.outputFailure());
                DescentMod.LOGGER.info("U14_TRAJECTORY_REAL_TICKS actors=32 parts=160 age=1000 deathTick={} closedWorldTick={} manualTicks=false sleep=false",deathTick[0],c.getWorld().getTime());
                cleanup.run();c.complete();
            }catch(RuntimeException|Error failure){
                try{RagdollTrajectoryRecorder.finish("failed",failure.toString());}finally{cleanup.run();}throw failure;
            }
        });
    }
}
