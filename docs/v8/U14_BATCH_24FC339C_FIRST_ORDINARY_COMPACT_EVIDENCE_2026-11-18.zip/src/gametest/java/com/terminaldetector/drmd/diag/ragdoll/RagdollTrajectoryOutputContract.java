package com.terminaldetector.drmd.diag.ragdoll;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.zip.GZIPInputStream;

/** Actual Java byte-adapter checks. Runs once before any diagnostic cohort enrollment, not a fake physics executor. */
public final class RagdollTrajectoryOutputContract {
    private static boolean passed;
    private RagdollTrajectoryOutputContract(){}
    private static final class IoFailureSink extends OutputStream {
        @Override public void write(int value)throws IOException{throw new IOException("contract-output-io");}
        @Override public void write(byte[] bytes,int offset,int length)throws IOException{throw new IOException("contract-output-io");}
    }
    private static final class RuntimeFailureSink extends OutputStream {
        final RuntimeException sentinel=new IllegalStateException("contract-unexpected-runtime");
        @Override public void write(int value){throw sentinel;}
        @Override public void write(byte[] bytes,int offset,int length){throw sentinel;}
    }
    private static void require(boolean condition,String message){if(!condition)throw new IllegalStateException("trajectory output contract: "+message);}
    private static byte[] row(String id,int tick){return("{\"uuid\":\""+id+"\",\"tick\":"+tick+",\"number\":1.2345678901234567,\"signed_zero\":-0.0}\n").getBytes(StandardCharsets.UTF_8);}
    public static boolean passed(){return passed;}
    public static void verify(){
        if(passed)throw new IllegalStateException("adapter contract must execute exactly once per diagnostic process");
        try{
            var target=new ByteArrayOutputStream();var expected=new ByteArrayOutputStream();var output=new RagdollTrajectoryOutput(target,RagdollTrajectoryOutput.TRACE_CAP,64*1024);
            for(int tick=0;tick<8;tick++)for(int id=0;id<32;id++){byte[] raw=row("actor"+id,tick);expected.write(raw);require(output.append("actor"+id,tick,raw),"original ordered batch accepted");}
            require(output.rows()==256&&output.finish(),"256rows committed without tail");
            try(var decoded=new GZIPInputStream(new ByteArrayInputStream(target.toByteArray()))){require(Arrays.equals(expected.toByteArray(),decoded.readAllBytes()),"lossless original order/numeric strings");}
            require(((Number)output.stats().get("max_batch_rows")).intValue()==256&&((Number)output.stats().get("max_rows_per_uuid")).intValue()==8,"row/identity bound");

            var copied=new ByteArrayOutputStream();var ownership=new RagdollTrajectoryOutput(copied,RagdollTrajectoryOutput.TRACE_CAP,64*1024);byte[] mutable=row("one",0);byte[] original=mutable.clone();
            require(ownership.append("one",0,mutable),"scalar byte ownership");Arrays.fill(mutable,(byte)'x');require(ownership.finish(),"owned row flush");
            try(var decoded=new GZIPInputStream(new ByteArrayInputStream(copied.toByteArray()))){require(Arrays.equals(original,decoded.readAllBytes()),"caller cannot mutate queued bytes");}

            var times=new RagdollTrajectoryOutput(new ByteArrayOutputStream(),RagdollTrajectoryOutput.TRACE_CAP,64*1024);
            for(int tick=0;tick<9;tick++)require(times.append("same",tick,row("same",tick)),"eight ticks per UUID");
            require(times.finish()&&((Number)times.stats().get("max_rows_per_uuid")).intValue()==8&&((Number)times.stats().get("max_world_tick_span")).intValue()==7,"eight-row/time span flush");

            var untouched=new ByteArrayOutputStream();var limit=new RagdollTrajectoryOutput(untouched,1,64*1024);
            require(limit.append("one",0,row("one",0)),"offered row buffered");
            require(!limit.flush()&&limit.failure()!=null&&limit.failure().code().equals("TRACE_LIMIT"),"expected cap returns failure without entity exception");
            var failure=limit.failure();require(!limit.append("one",1,row("one",1))&&limit.failure()==failure,"first failure immutable/no retry");
            require(!limit.finish()&&untouched.size()==0&&limit.rows()==0&&((Number)limit.stats().get("discarded_rows")).intValue()==1,"no oversized member appended/true discarded count");
            require(limit.failure().detail().getBytes(StandardCharsets.UTF_8).length<2048,"bounded failure summary signal");
            byte[] summary="{\"status\":\"NONPASS_OUTPUT_LIMIT\",\"rows_discarded\":1}".getBytes(StandardCharsets.UTF_8);var metadata=new ByteArrayOutputStream();
            require(RagdollTrajectoryOutput.metadata(metadata,summary,0)==null&&Arrays.equals(summary,metadata.toByteArray()),"same actual adapter persists expected-overflow summary");
            require(RagdollTrajectoryOutput.metadata(new ByteArrayOutputStream(),new byte[512*1024+1],0).code().equals("METADATA_LIMIT"),"bounded metadata reserve");
            var staging=new RagdollTrajectoryOutput(new ByteArrayOutputStream(),RagdollTrajectoryOutput.TRACE_CAP,1);
            require(staging.append("one",0,row("one",0))&&!staging.flush()&&staging.failure().code().equals("ENCODED_STAGING_LIMIT")&&!staging.finish(),"encoded staging budget returns NONPASS");
            var oversized=new RagdollTrajectoryOutput(new ByteArrayOutputStream(),RagdollTrajectoryOutput.TRACE_CAP,64*1024);
            require(!oversized.append("one",0,new byte[RagdollTrajectoryOutput.ROW_CAP+1])&&oversized.failure().code().equals("ROW_LIMIT")&&!oversized.finish(),"oversized scalar row fails before copying");
            var logical=new RagdollTrajectoryOutput(new ByteArrayOutputStream(),RagdollTrajectoryOutput.TRACE_CAP,64*1024);byte[] fullRow=new byte[RagdollTrajectoryOutput.ROW_CAP];
            for(int id=0;id<33;id++)require(logical.append("scalar"+id,0,fullRow),"logical buffer flush");
            require(logical.finish()&&((Number)logical.stats().get("max_batch_logical_bytes")).intValue()==8*1024*1024,"fixed8MiB scalar queue");

            var io=new RagdollTrajectoryOutput(new IoFailureSink(),RagdollTrajectoryOutput.TRACE_CAP,64*1024);
            require(io.append("one",0,row("one",0))&&!io.flush()&&io.failure().code().equals("TRACE_WRITE_IO")&&!io.finish(),"only expected recorder IO becomes NONPASS");
            var unexpectedSink=new RuntimeFailureSink();var unexpected=new RagdollTrajectoryOutput(unexpectedSink,RagdollTrajectoryOutput.TRACE_CAP,64*1024);
            require(unexpected.append("one",0,row("one",0)),"runtime sentinel buffered");boolean propagated=false;
            try{unexpected.flush();}catch(RuntimeException actual){if(actual!=unexpectedSink.sentinel)throw actual;propagated=true;}
            require(propagated&&unexpected.failure()==null,"unexpected runtime exception propagates");
            passed=true;System.out.println("U14_OUTPUT_ADAPTER_CONTRACT_PASS originalOrder=true scalarOnly=true capSummarySignal=true unexpectedRuntimePropagates=true");
        }catch(IOException failure){throw new IllegalStateException("trajectory output contract IO",failure);}
    }
}
