package com.terminaldetector.drmd.diag.ragdoll;

import com.google.gson.GsonBuilder;
import com.terminaldetector.drmd.client.portal.PortalTransform.*;
import com.terminaldetector.drmd.d6.D6PhysicsBody;
import com.terminaldetector.drmd.DescentMod;
import com.terminaldetector.drmd.diag.*;
import com.terminaldetector.drmd.entity.RagdollEntity;
import com.terminaldetector.drmd.physics.ragdoll.*;
import com.terminaldetector.drmd.world.access.*;
import com.terminaldetector.drmd.world.contraption.BodySpatialIndex;
import com.terminaldetector.drmd.world.contraption.boarding.BoardingSystem;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.block.Blocks;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/** Read-only per-identity trajectories; bounded scalar batches and expected-output failures never replace physics. */
public final class RagdollTrajectoryRecorder {
    public static final boolean ENABLED=Boolean.getBoolean("drmd.gate.ragdollTrajectory");
    public static final int ACTORS=32,PARTS=160,END_AGE=1000;
    private static final long TRACE_CAP=RagdollTrajectoryOutput.TRACE_CAP,SUMMARY_CAP=RagdollTrajectoryOutput.METADATA_CAP;
    private static final int ROW_CAP=RagdollTrajectoryOutput.ROW_CAP;
    private static final com.google.gson.Gson JSON=new GsonBuilder().serializeNulls().create();
    private static final ThreadLocal<Frame> CURRENT=new ThreadLocal<>();
    private static final Map<UUID,Actor> OWNERS=new LinkedHashMap<>();
    private static final IdentityHashMap<D6PhysicsBody,Owner> BODIES=new IdentityHashMap<>();
    private static Run run;private static boolean stoppingRegistered;private static String outputFailure;
    private RagdollTrajectoryRecorder(){}
    private static final class Run {
        final ServerWorld world;final BlockPos floor;final RagdollTrajectoryOutput output;final long started;
        final Map<String,Object> admission=new LinkedHashMap<>();final List<String> violations=new ArrayList<>();
        long metadataBytes,observedRows;String admissionSha;boolean admissionWritten;
        Run(ServerWorld world,BlockPos floor)throws IOException{
            this.world=world;this.floor=floor.toImmutable();started=world.getTime();
            output=new RagdollTrajectoryOutput(Files.newOutputStream(path("ragdoll-trajectory.jsonl.gz"),StandardOpenOption.CREATE_NEW,StandardOpenOption.WRITE));
        }
    }
    private static final class Actor {
        final RagdollEntity entity;final int startAge,startLife;final List<Map<String,Object>> initial=new ArrayList<>();
        int lastAge,lastLife;long firstWorld=Long.MIN_VALUE,lastWorld=Long.MIN_VALUE,ticks;
        Actor(RagdollEntity e){
            entity=e;startAge=lastAge=e.age;var tag=new NbtCompound();e.writeNbt(tag);startLife=lastLife=tag.getInt("life");
            for(var p:e.simulation().parts()){var b=p.body();initial.add(obj("id",p.segment().id(),"mass",b.mass(),"half",v(p.segment().halfExtents()),"p",v(b.position()),"q",q(b.rotation()),"v",v(b.linearVelocity()),"L",v(b.angularMomentum())));}
        }
    }
    private record Owner(Actor actor,int part){}
    private static final class PartFrame {
        final RagdollSimulation.Part part;final Vec3[] before,min,max;
        Vec3[] mutationBefore;Vec3 mutationPosition;Quat mutationRotation;int mutationDepth;boolean contactActive;
        Vec3 contactP,contactL,contactPosition,contactPoint,pointMin,pointMax;
        Vec3 deltaP=zero(),deltaL=zero(),normalSum=zero();
        long steps,poseEvents,integrationEvents,positionEvents,rotationEvents,contactCalls,positiveContacts,terrainCalls,terrainChanges;
        double cornerPath,cornerSweep,maxCorner,maxEnergy,normalImpulse,contactEnergyBefore,contactEnergyDelta,maxPositiveContactEnergy,minUp=Double.POSITIVE_INFINITY;
        PartFrame(RagdollSimulation.Part part){this.part=part;before=corners(part);min=before.clone();max=before.clone();sample(this);}
    }
    private static final class Frame {
        final Actor actor;final long worldTick,started;final int lifeBefore;final List<PartFrame> parts=new ArrayList<>();
        long simulations,joints,insideChecks,insideUnknown;double seconds;int substeps,iterations;Vec3 gravity;
        RagdollSimulation.Part terrainPart;Vec3 terrainBefore;
        final Vec3 origin;Vec3 contactWrench=zero(),gravityWrench=zero(),projectionOrbit=zero();
        Frame(Actor actor,int life){this.actor=actor;lifeBefore=life;worldTick=run.world.getTime();started=DiagServerTick.begin();origin=relativeCentre(actor.entity.simulation().parts());for(var p:actor.entity.simulation().parts())parts.add(new PartFrame(p));}
    }
    private static Path path(String name){return FabricLoader.getInstance().getGameDir().resolve(name);}
    private static Vec3 zero(){return new Vec3(0,0,0);}
    private static List<Double> v(Vec3 v){return List.of(v.x(),v.y(),v.z());}
    private static List<Double> q(Quat q){return List.of(q.x(),q.y(),q.z(),q.w());}
    private static Map<String,Object> obj(Object... pairs){var map=new LinkedHashMap<String,Object>();for(int i=0;i<pairs.length;i+=2)map.put((String)pairs[i],pairs[i+1]);return map;}
    private static String bounded(String value,int limit){return value==null?"":value.substring(0,Math.min(value.length(),limit));}
    private static void violation(String value){if(run!=null&&run.violations.size()<64)run.violations.add(bounded(value,512));}
    private static Vec3 relativeCentre(List<RagdollSimulation.Part> parts){
        Vec3 origin=parts.getFirst().body().position(),sum=zero();double mass=0;
        for(var p:parts){mass+=p.body().mass();sum=sum.plus(p.body().position().minus(origin).scaled(p.body().mass()));}
        return origin.plus(sum.scaled(1/mass));
    }
    private static Vec3[] corners(RagdollSimulation.Part part){
        var half=part.segment().halfExtents();var b=part.body();var result=new Vec3[8];
        for(int i=0;i<8;i++)result[i]=b.position().plus(b.rotation().rotate(new Vec3((i&1)==0?-half.x():half.x(),(i&2)==0?-half.y():half.y(),(i&4)==0?-half.z():half.z())));
        return result;
    }
    private static void sample(PartFrame part){
        var body=part.part.body();double speed=body.linearVelocity().length()+body.angularVelocity().length()*part.part.segment().halfExtents().length();
        double energy=.5*body.mass()*body.linearVelocity().lengthSquared()+.5*body.angularMomentum().dot(body.angularVelocity());
        if(!Double.isFinite(speed+energy)||energy< -1e-10)violation("nonfinite_or_negative_energy");
        part.maxCorner=Math.max(part.maxCorner,speed);part.maxEnergy=Math.max(part.maxEnergy,energy);
    }
    private static double kinetic(D6PhysicsBody body){return .5*body.mass()*body.linearVelocity().lengthSquared()+.5*body.angularMomentum().dot(body.angularVelocity());}
    private static PartFrame part(D6PhysicsBody body){
        var frame=CURRENT.get();if(frame==null)return null;var owner=BODIES.get(body);
        if(owner==null||owner.actor!=frame.actor){violation("part_owner_mismatch");return null;}return frame.parts.get(owner.part);
    }
    public static void begin(ServerWorld world,BlockPos floor){
        if(!ENABLED||!RagdollTrajectoryOutputContract.passed()||run!=null||!OWNERS.isEmpty()||!BODIES.isEmpty()||CURRENT.get()!=null)throw new IllegalStateException("exclusive enabled trajectory observer required");
        outputFailure=null;try{run=new Run(world,floor);}catch(IOException failure){throw new IllegalStateException(failure);}
        for(var key:List.of("actual_live_spawns","death_attempts","actual_dead_drones","actual_corpses","actual_parts"))run.admission.put(key,0);
        if(!stoppingRegistered){stoppingRegistered=true;ServerLifecycleEvents.SERVER_STOPPING.register(server->{if(run!=null&&run.world.getServer()==server)finish("partial_server_stopping","ordinary server stopped before trajectory completion");});}
        DiagTrace.record("ragdoll.trajectory","observer-only32 real deaths through age1000 begin");
    }
    public static void admission(String key,Object value){if(run!=null)run.admission.put(key,value);}
    public static void enroll(List<RagdollEntity> bodies){
        if(run==null||!OWNERS.isEmpty()||bodies.size()!=ACTORS)throw new IllegalStateException("exact32 enrollment required");
        for(var body:bodies){
            if(body.getWorld()!=run.world||run.world.getEntity(body.getUuid())!=body||body.age!=0||body.simulation().parts().size()!=5)throw new IllegalStateException("actual newborn registered five-part identity required");
            var actor=new Actor(body);if(actor.startLife!=0||OWNERS.put(body.getUuid(),actor)!=null)throw new IllegalStateException("fresh unique physical lifetime required");
            for(int i=0;i<body.simulation().parts().size();i++)if(BODIES.put(body.simulation().parts().get(i).body(),new Owner(actor,i))!=null)throw new IllegalStateException("shared physical part");
        }
        if(BODIES.size()!=PARTS)throw new IllegalStateException("exact160 parts required");
        if(writeMetadata(run,"ragdoll-trajectory-admission.json",obj("schema","ungravity.ragdoll.trajectory.admission.v2","status","enrolled_before_ticks","observer_only",true,"sleep_implemented",false,
            "adapter_contract_passed",RagdollTrajectoryOutputContract.passed(),"world_tick",run.world.getTime(),"admission",new LinkedHashMap<>(run.admission),"actors",actorData(true))))run.admissionWritten=true;
        else finish("failed_output_metadata",outputFailure);
    }
    public static void enter(RagdollEntity entity,int life){
        if(!ENABLED||run==null||outputFailure!=null)return;if(CURRENT.get()!=null){violation("nested_or_unclosed_tick");CURRENT.remove();}
        var actor=OWNERS.get(entity.getUuid());if(actor==null||entity.age>END_AGE)return;
        if(actor.entity!=entity||run.world.getEntity(entity.getUuid())!=entity||!run.world.getServer().isOnThread())throw new IllegalStateException("ordinary identity/thread mismatch");
        if(entity.age!=actor.lastAge+1||life!=actor.lastLife||actor.lastWorld!=Long.MIN_VALUE&&run.world.getTime()!=actor.lastWorld+1)violation("nonconsecutive_world_age_life");
        CURRENT.set(new Frame(actor,life));
    }
    public static void leave(RagdollEntity entity,int life){
        var frame=CURRENT.get();if(frame==null)return;CURRENT.remove();
        if(frame.actor.entity!=entity||run==null)throw new IllegalStateException("tick_return_owner");
        if(life!=frame.lifeBefore+1||frame.simulations!=1||frame.seconds!=.05||frame.substeps!=4||frame.iterations!=8||frame.joints!=128||frame.insideUnknown!=0)violation("original_budget_lifetime_or_availability");
        var parts=new ArrayList<Map<String,Object>>();
        for(var p:frame.parts){
            sample(p);if(p.steps!=4||p.terrainCalls!=36||p.mutationDepth!=0||p.contactActive||p.integrationEvents!=4)violation("part_work_or_probe_balance");
            var b=p.part.body();double energy=.5*b.mass()*b.linearVelocity().lengthSquared()+.5*b.angularMomentum().dot(b.angularVelocity());
            parts.add(obj("id",p.part.segment().id(),"p",v(b.position()),"q",q(b.rotation()),"v",v(b.linearVelocity()),"L",v(b.angularMomentum()),"w",v(b.angularVelocity()),"K",energy,
                "corner_peak",p.maxCorner,"K_peak",p.maxEnergy,"corner_chord_path",p.cornerPath,"corner_sweep_bound",p.cornerSweep,"corner_min",Arrays.stream(p.min).map(RagdollTrajectoryRecorder::v).toList(),"corner_max",Arrays.stream(p.max).map(RagdollTrajectoryRecorder::v).toList(),
                "steps",p.steps,"pose_events",p.poseEvents,"integration_events",p.integrationEvents,"position_events",p.positionEvents,"rotation_events",p.rotationEvents,
                "terrain_calls",p.terrainCalls,"terrain_changes",p.terrainChanges,"contact_calls",p.contactCalls,"positive_contacts",p.positiveContacts,"normal_impulse",p.normalImpulse,
                "contact_dP",v(p.deltaP),"contact_dL",v(p.deltaL),"normal_weighted",v(p.normalSum),"min_contact_up",p.minUp==Double.POSITIVE_INFINITY?null:p.minUp,
                "contact_point_min",p.pointMin==null?null:v(p.pointMin),"contact_point_max",p.pointMax==null?null:v(p.pointMax),"contact_dK",p.contactEnergyDelta,"max_positive_contact_dK",p.maxPositiveContactEnergy,"support",support(p)));
        }
        var errors=new ArrayList<Double>();for(int i=0;i<entity.rig().joints().size();i++)errors.add(entity.simulation().jointError(i));
        var bounds=entity.getBoundingBox();boolean playerNear=BoardingSystem.players(run.world).stream().anyMatch(player->bounds.expand(64).intersects(player.getBoundingBox()));
        int bodiesNear=BodySpatialIndex.query(run.world,bounds.expand(64)).size();
        var row=obj("uuid",entity.getUuid().toString(),"world_tick",frame.worldTick,"age",entity.age,"life",life,"gravity",frame.gravity==null?null:v(frame.gravity),
            "simulation_calls",frame.simulations,"joint_solves",frame.joints,"joint_errors",errors,"inside_checks",frame.insideChecks,"inside_unknown",frame.insideUnknown,
            "player_near64",playerNear,"body_candidates64",bodiesNear,"parts",parts,
            "contact_wrench_L",v(frame.contactWrench),"gravity_wrench_L",v(frame.gravityWrench),"position_projection_dL",v(frame.projectionOrbit));
        if(frame.actor.firstWorld==Long.MIN_VALUE)frame.actor.firstWorld=frame.worldTick;
        frame.actor.lastAge=entity.age;frame.actor.lastLife=life;frame.actor.lastWorld=frame.worldTick;frame.actor.ticks++;
        run.observedRows++;emit(row,entity.getUuid().toString(),frame.worldTick);
        DiagServerTick.charge("ragdoll.trajectory.actor_with_observer",System.nanoTime()-frame.started);
    }
    private static Map<String,Object> support(PartFrame part){
        // The owned diagnostic plane is known. No search, ticket, chunk get or unavailable->air fallback.
        Vec3[] corners=corners(part.part);int face=-1;double lowest=Double.POSITIVE_INFINITY;List<Vec3> points=List.of();
        for(int axis=0;axis<3;axis++)for(int side=0;side<2;side++){
            var set=new ArrayList<Vec3>();for(int i=0;i<8;i++)if(((i>>axis)&1)==side)set.add(corners[i]);
            double average=set.stream().mapToDouble(Vec3::y).average().orElseThrow();if(average<lowest){lowest=average;face=axis*2+side;points=set;}
        }
        double plane=run.floor.getY()+1.,minGap=Double.POSITIVE_INFINITY,maxGap=Double.NEGATIVE_INFINITY;
        var cells=new TreeMap<String,List<Object>>();boolean hard=true;int unknown=0;
        for(var p:points){
            double gap=p.y()-plane;minGap=Math.min(minGap,gap);maxGap=Math.max(maxGap,gap);
            var pos=new BlockPos(MathHelper.floor(p.x()),run.floor.getY(),MathHelper.floor(p.z()));
            var cell=WorldAccess.of(run.world).readIfLoaded(pos);boolean obsidian=cell.isPresent()&&cell.get().isOf(Blocks.OBSIDIAN);
            if(cell.isEmpty())unknown++;hard&=obsidian;
            cells.put(pos.getX()+":"+pos.getZ(),Arrays.asList(pos.getX(),pos.getZ(),cell.isEmpty()?null:net.minecraft.registry.Registries.BLOCK.getId(cell.get().getBlock()).toString()));
        }
        // A convex hull of the actual four projected corners, not their looser axis-aligned box.
        var polygon=new ArrayList<Vec3>(points);polygon.sort(Comparator.comparingDouble(Vec3::x).thenComparingDouble(Vec3::z));
        var hull=new ArrayList<Vec3>();
        for(var p:polygon){while(hull.size()>1&&cross(hull.get(hull.size()-2),hull.getLast(),p)<=0)hull.removeLast();hull.add(p);}
        int lower=hull.size();for(int i=polygon.size()-2;i>=0;i--){var p=polygon.get(i);while(hull.size()>lower&&cross(hull.get(hull.size()-2),hull.getLast(),p)<=0)hull.removeLast();hull.add(p);}if(hull.size()>1)hull.removeLast();
        double margin=Double.POSITIVE_INFINITY;var centre=part.part.body().position();
        if(hull.size()<3)margin=Double.NEGATIVE_INFINITY;
        else for(int i=0;i<hull.size();i++){var a=hull.get(i);var b=hull.get((i+1)%hull.size());margin=Math.min(margin,cross(a,b,centre)/Math.hypot(b.x()-a.x(),b.z()-a.z()));}
        return obj("face",face,"plane_y",plane,"gap_min",minGap,"gap_max",maxGap,"face_spread",maxGap-minGap,"com_margin",Double.isFinite(margin)?margin:null,
            "hard_obsidian",hard,"unknown_reads",unknown,"cells",cells.values().stream().toList());
    }
    private static double cross(Vec3 a,Vec3 b,Vec3 p){return(b.x()-a.x())*(p.z()-a.z())-(b.z()-a.z())*(p.x()-a.x());}
    public static void simulation(RagdollSimulation simulation,double seconds,Vec3 gravity,int substeps,int iterations,boolean contacts){
        var f=CURRENT.get();if(f==null)return;if(f.actor.entity.simulation()!=simulation||!contacts)violation("simulation_owner_or_contacts");
        f.simulations++;f.seconds=seconds;f.gravity=gravity;f.substeps=substeps;f.iterations=iterations;
    }
    public static void joint(RagdollSimulation simulation){var f=CURRENT.get();if(f!=null){if(f.actor.entity.simulation()!=simulation)violation("joint_owner");f.joints++;}}
    public static void step(D6PhysicsBody body,double seconds){
        var p=part(body);if(p!=null){
            p.steps++;var f=CURRENT.get();if(f.gravity==null)violation("missing_gravity_before_part_step");
            else f.gravityWrench=f.gravityWrench.plus(body.position().minus(f.origin).cross(f.gravity.scaled(body.mass()*seconds)));sample(p);
        }
    }
    public static void state(D6PhysicsBody body){var p=part(body);if(p!=null)sample(p);}
    public static void poseEnter(D6PhysicsBody body){
        var p=part(body);if(p!=null&&p.mutationDepth++==0){p.mutationBefore=corners(p.part);p.mutationPosition=body.position();p.mutationRotation=body.rotation();sample(p);}
    }
    public static void poseLeave(D6PhysicsBody body,int kind){
        var p=part(body);if(p==null)return;if(p.mutationDepth<=0){violation("unbalanced_pose_return");return;}
        if(--p.mutationDepth!=0)return;var after=corners(p.part);double distance=0;
        for(int i=0;i<8;i++){
            distance=Math.max(distance,after[i].minus(p.mutationBefore[i]).length());
            p.min[i]=new Vec3(Math.min(p.min[i].x(),after[i].x()),Math.min(p.min[i].y(),after[i].y()),Math.min(p.min[i].z(),after[i].z()));
            p.max[i]=new Vec3(Math.max(p.max[i].x(),after[i].x()),Math.max(p.max[i].y(),after[i].y()),Math.max(p.max[i].z(),after[i].z()));
        }
        var first=p.mutationRotation;var last=body.rotation();
        double dot=first.x()*last.x()+first.y()*last.y()+first.z()*last.z()+first.w()*last.w();
        double norm=Math.sqrt((first.x()*first.x()+first.y()*first.y()+first.z()*first.z()+first.w()*first.w())*(last.x()*last.x()+last.y()*last.y()+last.z()*last.z()+last.w()*last.w()));
        double angle=2*Math.acos(Math.min(1,Math.abs(dot)/norm));
        if(kind==1){var f=CURRENT.get();f.projectionOrbit=f.projectionOrbit.plus(body.position().minus(p.mutationPosition).cross(body.linearVelocity().scaled(body.mass())));}
        p.cornerPath+=distance;p.cornerSweep+=body.position().minus(p.mutationPosition).length()+p.part.segment().halfExtents().length()*angle;
        p.poseEvents++;if(kind==0)p.integrationEvents++;else if(kind==1)p.positionEvents++;else p.rotationEvents++;sample(p);
    }
    public static void contactEnter(D6PhysicsBody body,Vec3 offset){var p=part(body);if(p==null)return;if(p.contactActive)violation("nested_contact");p.contactActive=true;p.contactP=body.linearVelocity().scaled(body.mass());p.contactL=body.angularMomentum();p.contactPosition=body.position();p.contactPoint=p.contactPosition.plus(offset);p.contactEnergyBefore=kinetic(body);sample(p);}
    public static void contactLeave(D6PhysicsBody body,Vec3 normal,double magnitude){
        var p=part(body);if(p==null)return;if(!p.contactActive){violation("contact_return_without_head");return;}p.contactActive=false;p.contactCalls++;
        Vec3 deltaP=body.linearVelocity().scaled(body.mass()).minus(p.contactP),deltaL=body.angularMomentum().minus(p.contactL);
        p.deltaP=p.deltaP.plus(deltaP);p.deltaL=p.deltaL.plus(deltaL);
        var f=CURRENT.get();f.contactWrench=f.contactWrench.plus(deltaL.plus(p.contactPosition.minus(f.origin).cross(deltaP)));
        double energyDelta=kinetic(body)-p.contactEnergyBefore;p.contactEnergyDelta+=energyDelta;p.maxPositiveContactEnergy=Math.max(p.maxPositiveContactEnergy,energyDelta);
        if(magnitude>0){
            p.positiveContacts++;p.normalImpulse+=magnitude;p.normalSum=p.normalSum.plus(normal.scaled(magnitude));p.minUp=Math.min(p.minUp,normal.y());
            if(p.pointMin==null){p.pointMin=p.contactPoint;p.pointMax=p.contactPoint;}
            else{p.pointMin=new Vec3(Math.min(p.pointMin.x(),p.contactPoint.x()),Math.min(p.pointMin.y(),p.contactPoint.y()),Math.min(p.pointMin.z(),p.contactPoint.z()));p.pointMax=new Vec3(Math.max(p.pointMax.x(),p.contactPoint.x()),Math.max(p.pointMax.y(),p.contactPoint.y()),Math.max(p.pointMax.z(),p.contactPoint.z()));}
        }sample(p);
    }
    public static void terrainEnter(RagdollSimulation.Part part){var f=CURRENT.get();if(f==null)return;if(f.terrainPart!=null)violation("nested_terrain");f.terrainPart=part;f.terrainBefore=part.body().position();var p=part(part.body());if(p!=null)p.terrainCalls++;}
    public static void terrainLeave(RagdollSimulation.Part part){var f=CURRENT.get();if(f==null)return;if(f.terrainPart!=part)violation("terrain_owner");var p=part(part.body());if(p!=null&&part.body().position().minus(f.terrainBefore).lengthSquared()>1e-20)p.terrainChanges++;f.terrainPart=null;f.terrainBefore=null;}
    public static void available(boolean available){var f=CURRENT.get();if(f!=null){f.insideChecks++;if(!available)f.insideUnknown++;}}
    public static String outputFailure(){return outputFailure;}
    private static void signalOutputFailure(String code,String detail){
        if(outputFailure==null)outputFailure=bounded(code+": "+detail,2048);
    }
    private static boolean writeMetadata(Run owner,String name,Object value){
        byte[] data=JSON.toJson(value).getBytes(StandardCharsets.UTF_8);
        if(!RagdollTrajectoryOutput.metadataFits(data,owner.metadataBytes)){signalOutputFailure("METADATA_LIMIT",name);return false;}
        try(var sink=Files.newOutputStream(path(name),StandardOpenOption.CREATE_NEW,StandardOpenOption.WRITE)){
            var failure=RagdollTrajectoryOutput.metadata(sink,data,owner.metadataBytes);
            if(failure!=null){signalOutputFailure(failure.code(),failure.detail());return false;}
        }catch(IOException io){signalOutputFailure("METADATA_IO",io.toString());DescentMod.LOGGER.error("U14 trajectory metadata failure {}",name,io);return false;}
        owner.metadataBytes+=data.length;
        if(name.equals("ragdoll-trajectory-admission.json")){
            try{owner.admissionSha=HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(data));}
            catch(NoSuchAlgorithmException impossible){throw new AssertionError(impossible);}
        }
        return true;
    }
    private static List<Map<String,Object>> actorData(boolean initial){
        var result=new ArrayList<Map<String,Object>>();
        for(var actor:OWNERS.values()){
            var row=obj("uuid",actor.entity.getUuid().toString(),"ticks",actor.ticks,"start_age",actor.startAge,"end_age",actor.lastAge,"start_life",actor.startLife,"end_life",actor.lastLife,
                "first_world_tick",actor.firstWorld,"last_world_tick",actor.lastWorld,"rig_version",actor.entity.rigVersion(),"hull_kind",actor.entity.flightHullKind()==null?null:actor.entity.flightHullKind().id);
            if(initial)row.put("initial_parts",actor.initial);result.add(row);
        }
        return result;
    }
    private static void emit(Object value,String identity,long worldTick){
        byte[] raw=(JSON.toJson(value)+"\n").getBytes(StandardCharsets.UTF_8);
        if(!run.output.append(identity,worldTick,raw)){
            var failure=run.output.failure();signalOutputFailure(failure.code(),failure.detail());
            finish("failed_output",outputFailure); // Expected recorder failure returns to the unchanged production entity tick.
        }
    }
    public static void assertComplete(){
        if(run==null||outputFailure!=null||OWNERS.size()!=ACTORS||!run.admissionWritten||!run.violations.isEmpty()||run.observedRows!=ACTORS*END_AGE)throw new IllegalStateException("incomplete/violating trajectory");
        for(var actor:OWNERS.values())if(actor.ticks!=END_AGE||actor.lastAge!=END_AGE||actor.lastLife!=END_AGE)throw new IllegalStateException("missing continuous1000 real ticks");
        if(!run.output.finish()){
            var failure=run.output.failure();signalOutputFailure(failure.code(),failure.detail());finish("failed_output",outputFailure);
            throw new IllegalStateException("trajectory observer output failed in ordinary fixture callback: "+outputFailure);
        }
        if(run.output.rows()!=ACTORS*END_AGE)throw new IllegalStateException("persisted trajectory rows incomplete");
    }
    public static void finish(String status,String reason){
        if(run==null)return;Run closed=run;
        try{
            if(!closed.output.finish()){
                var failure=closed.output.failure();signalOutputFailure(failure.code(),failure.detail());status="failed_output";reason=outputFailure;
            }
            Long fileBytes=null;String fileBytesReason=null;
            try{fileBytes=Files.size(path("ragdoll-trajectory.jsonl.gz"));}catch(IOException io){fileBytesReason=bounded(io.toString(),1024);}
            var outputCause=closed.output.failure();boolean overflow=outputCause!=null&&Set.of("TRACE_LIMIT","ROW_LIMIT","ENCODED_STAGING_LIMIT").contains(outputCause.code());
            writeMetadata(closed,"ragdoll-trajectory-summary.json",obj("schema","ungravity.ragdoll.trajectory.v2","status",status,"reason",bounded(reason,2048),"observer_only",true,"sleep_implemented",false,
                "adapter_contract_passed",RagdollTrajectoryOutputContract.passed(),"actors_requested",ACTORS,"parts_requested",PARTS,"end_age",END_AGE,"rows",closed.output.rows(),"rows_observed",closed.observedRows,
                "trace_bytes",closed.output.bytes(),"trace_file_bytes",fileBytes,"trace_file_bytes_reason",fileBytesReason,"logical_json_bytes",closed.output.logicalBytes(),"output",closed.output.stats(),
                "trace_format","original-order UTF-8 JSONL, bounded complete gzip batches","trace_cap_bytes",TRACE_CAP,"metadata_cap_bytes",SUMMARY_CAP,"single_metadata_cap_bytes",SUMMARY_CAP/2,"row_cap_bytes",ROW_CAP,
                "output_overflow",overflow,"output_failed",outputFailure!=null||outputCause!=null,"output_failure",outputFailure,"admission_file","ragdoll-trajectory-admission.json","admission_sha256",closed.admissionSha,"metadata_bytes_before_summary",closed.metadataBytes,
                "admission",new LinkedHashMap<>(closed.admission),"actors",actorData(false),"violations",closed.violations,"seed",closed.world.getSeed(),"backend",CubicAvailability.backend(closed.world).name(),
                "floor",List.of(closed.floor.getX(),closed.floor.getY(),closed.floor.getZ()),"start_world_tick",closed.started,"end_world_tick",closed.world.getTime(),
                "heap_max_bytes",Runtime.getRuntime().maxMemory(),"heap_used_bytes_at_close",Runtime.getRuntime().totalMemory()-Runtime.getRuntime().freeMemory(),
                "mspt",null,"mspt_reason","Actor timer includes observer/encoding and is not complete server tick","fps",null,"fps_reason","headless TestServer","draw_calls",null,"draw_calls_reason","headless TestServer",
                "cubes_loaded",null,"cubes_loaded_reason","no authoritative loaded-cube counter attached","diagnostic_only",true));
            DiagTrace.record("ragdoll.trajectory","closed observer status="+status+" persisted="+closed.output.rows()+" observed="+closed.observedRows);
        }finally{OWNERS.clear();BODIES.clear();CURRENT.remove();run=null;}
    }
}
