import org.junit.platform.engine.discovery.DiscoverySelectors;
import org.junit.platform.launcher.core.LauncherDiscoveryRequestBuilder;
import org.junit.platform.launcher.core.LauncherFactory;
import org.junit.platform.launcher.listeners.SummaryGeneratingListener;
import java.io.PrintWriter;

public final class ScopedRagdollJUnit {
    public static void main(String[] args) {
        var request = LauncherDiscoveryRequestBuilder.request().selectors(
            DiscoverySelectors.selectClass("com.terminaldetector.drmd.physics.ragdoll.RagdollAngularLimitTest"),
            DiscoverySelectors.selectClass("com.terminaldetector.drmd.FlightWreckRigTest")).build();
        var listener = new SummaryGeneratingListener();
        var launcher = LauncherFactory.create();
        launcher.registerTestExecutionListeners(listener);
        launcher.execute(request);
        var summary = listener.getSummary();
        var writer = new PrintWriter(System.out, true);
        summary.printTo(writer);
        summary.printFailuresTo(writer);
        if (summary.getTestsFoundCount() != 17 || summary.getTestsSucceededCount() != 17
                || summary.getTestsFailedCount() != 0 || summary.getTestsSkippedCount() != 0)
            System.exit(1);
    }
}
