from pathlib import Path
import hashlib, json, struct, subprocess, sys, zipfile

PINNED_SOURCE='5acde8915ee940b8d2c8086511810f112bbe21bf'
mode=sys.argv[1:]
if mode not in [['--prepare-only'],['--root-java-lease-granted']]:
    raise SystemExit('Use --prepare-only (no JVM) or the explicitly granted root Java lease.')
prepare_only=mode==['--prepare-only']
root=Path('/workspace/ungravity-v5/ragdoll-angular-20261118')
baseline=Path('/workspace/ungravity-v5/ufo-body-physics')
historical=Path('/workspace/ungravity-v5/encounter-admission-20261118')
base_out=Path('/tmp/ungravity-ragdoll-angular-f36df65')
prefix='preflight' if prepare_only else 'attempt'
number=1
while (base_out/f'{prefix}-{number:02d}').exists():number+=1
out=base_out/f'{prefix}-{number:02d}'
out.mkdir()
print('Fresh evidence directory:',out,flush=True)
classes=out/'classes'
classes.mkdir()

def digest(p):
    h=hashlib.sha256()
    with p.open('rb') as stream:
        for data in iter(lambda:stream.read(1024*1024),b''):h.update(data)
    return h.hexdigest()

source_sha=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
assert source_sha==PINNED_SOURCE,(source_sha,PINNED_SOURCE)
subprocess.run(['git','diff','--exit-code','HEAD','--','src'],cwd=root,check=True)
source_paths=[
 historical/'work/u03-unit/first-b1c9e33-20261118/compileJava-actual-inputs.json',
 historical/'work/u03-unit/first-b1c9e33-20261118/compileTestJava-actual-inputs.json',
 historical/'work/u03-unit/optional-resources-first-b1c9e33-20261118/test-actual-inputs.json',
 historical/'work/u03-gameplay/first-8d9fe36-20261118/compileGametestJava-actual-inputs.json']
captures=[json.loads(p.read_text()) for p in source_paths]
substitutions=[]
jar_checks=[]
all_inputs={}

# Only these existing canonical output directories can replace old project outputs.
allowed_outputs={'build/classes/java/main','build/resources/main','build/classes/java/gametest'}

def record_input(p):
    if p.is_dir():
        files=sorted(f for f in p.rglob('*') if f.is_file())
    else:files=[p]
    assert files or p.is_dir(),str(p)
    for file in files:
        key=str(file)
        if key not in all_inputs:
            all_inputs[key]=dict(path=key,size=file.stat().st_size,sha256=digest(file))

def captured_cp(index):
    result=[]
    for entry in captures[index]['classpath']:
        original=Path(entry['path'])
        if entry['kind']=='missingOptionalTestResources':
            substitutions.append(dict(capture=str(source_paths[index]),old=str(original),new=None,reason='captured optional resources absent and unused'))
            continue
        if entry['kind']=='directory':
            suffix=str(original.relative_to(historical))
            if suffix=='build/classes/java/test':
                substitutions.append(dict(capture=str(source_paths[index]),old=str(original),new=None,reason='selected test classes are freshly compiled only; no old test outputs reused'))
                continue
            assert suffix in allowed_outputs,(suffix,entry['kind'])
            p=baseline/suffix
            assert p.is_dir(),p
            substitutions.append(dict(capture=str(source_paths[index]),old=str(original),new=str(p),reason='verified existing canonical directory; historical source attribution not reused'))
        else:
            assert entry['kind']=='file',entry['kind']
            p=original
            assert p.is_file(),str(p)
            assert p.suffix=='.jar',str(p)
            record_input(p)
            actual=all_inputs[str(p)]['sha256']
            jar_checks.append(dict(capture=str(source_paths[index]),path=str(p),historical_sha256=entry['sha256'],actual_sha256=actual,historical_match=actual==entry['sha256']))
            if '/org.junit.jupiter/' in str(p):assert '/5.11.3/' in str(p),str(p)
            if '/org.junit.platform/' in str(p):assert '/1.11.3/' in str(p),str(p)
        record_input(p)
        result.append(p)
    return list(dict.fromkeys(result))

compile_main,compile_tests,runtime,compile_gt=[captured_cp(i) for i in range(4)]
base_classes=baseline/'build/classes/java/main'
base_gt=baseline/'build/classes/java/gametest'
assert base_classes.is_dir() and base_gt.is_dir()
record_input(base_classes)
record_input(base_gt)
compile_main=[base_classes]+compile_main
# LauncherFactory for the small runner comes from the captured runtime, not a cache glob.
launcher_jars=[p for p in runtime if p.suffix=='.jar' and ('/org.junit.platform/' in str(p) or '/org.junit.jupiter/' in str(p))]
compile_tests=list(dict.fromkeys(compile_tests+launcher_jars))
compile_gt.append(base_gt)
cp_sets=[compile_main,compile_tests,runtime,compile_gt]

# Read classfile metadata directly in Python; no Java/javap is involved in this preflight.
named_entities=[]
for p in list(dict.fromkeys(q for cp in cp_sets for q in cp if q.suffix=='.jar')):
    with zipfile.ZipFile(p) as archive:
        name='net/minecraft/entity/Entity.class'
        if name not in archive.namelist():continue
        data=archive.read(name)
        assert data[:4]==b'\xca\xfe\xba\xbe'
        count=struct.unpack_from('>H',data,8)[0];pool={};offset=10;index=1
        while index<count:
            tag=data[offset];offset+=1
            if tag==1:
                size=struct.unpack_from('>H',data,offset)[0];offset+=2
                pool[index]=data[offset:offset+size].decode('utf-8',errors='replace');offset+=size
            elif tag in [3,4]:offset+=4
            elif tag in [5,6]:offset+=8;index+=1
            elif tag in [7,8,16,19,20]:pool[index]=struct.unpack_from('>H',data,offset)[0];offset+=2
            elif tag in [9,10,11,12,17,18]:offset+=4
            elif tag==15:offset+=3
            else:raise AssertionError(tag)
            index+=1
        this_class=struct.unpack_from('>H',data,offset+2)[0]
        self_name=pool[pool[this_class]]
        assert self_name=='net/minecraft/entity/Entity',self_name
        named_entities.append(dict(jar=str(p),jar_sha256=digest(p),entry=name,entry_sha256=hashlib.sha256(data).hexdigest(),self_name=self_name,major=struct.unpack_from('>H',data,6)[0]))
assert named_entities,'No verified named Entity class in actual CP'
main=[root/'src/main/java/com/terminaldetector/drmd'/p for p in [
 'physics/ragdoll/RagdollRig.java','physics/ragdoll/RagdollAngularLimit.java',
 'physics/ragdoll/RagdollSimulation.java','entity/model/FlightWreckRig.java','entity/RagdollEntity.java']]
tests=[root/'src/test/java/com/terminaldetector/drmd/physics/ragdoll/RagdollAngularLimitTest.java',
       root/'src/test/java/com/terminaldetector/drmd/FlightWreckRigTest.java',base_out/'ScopedRagdollJUnit.java']
gametest=root/'src/gametest/java/com/terminaldetector/drmd/RagdollGameTests.java'
java=Path('/workspace/jdk21-complete/bin')
receipt=dict(source_sha=source_sha,prepare_only=prepare_only,runner_sha256=digest(Path(__file__)),
 captures=[dict(path=str(p),sha256=digest(p)) for p in source_paths],
 substitutions=substitutions,historical_jar_checks=jar_checks,named_entities=named_entities,
 jdk_executables=[dict(path=str(p),sha256=digest(p)) for p in [java/'java',java/'javac']],
 classpath_entries=[[str(p) for p in cp] for cp in cp_sets],reused_inputs=list(all_inputs.values()),
 changed_sources=[dict(path=str(p),sha256=digest(p)) for p in main+tests+[gametest]])
(out/'dependencies.json').write_text(json.dumps(receipt,indent=2)+'\n')
stale=[x for x in jar_checks if not x['historical_match']]
(out/'historical-cache-mismatches.json').write_text(json.dumps(stale,indent=2)+'\n')
print('Historical JAR hash mismatches:',len(stale),flush=True)
for x in stale:print(json.dumps(x),flush=True)
print('Named Entity receipts:',json.dumps(named_entities),flush=True)

cp_strings=[':'.join(str(p) for p in cp) for cp in cp_sets]
flags=['--release','21','-proc:none','-implicit:none','-sourcepath','']
commands=[
 [str(java/'javac')]+flags+['-cp',cp_strings[0],'-d',str(classes)]+[str(p) for p in main],
 [str(java/'javac')]+flags+['-cp',str(classes)+':'+cp_strings[1],'-d',str(classes)]+[str(p) for p in tests],
 [str(java/'java'),'-Xmx256m','-cp',str(classes)+':'+cp_strings[2],'ScopedRagdollJUnit'],
 [str(java/'javac')]+flags+['-cp',str(classes)+':'+cp_strings[3],'-d',str(classes),str(gametest)]]
(out/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
if prepare_only:
    print('Metadata only: no Java/Gradle/native process started.',flush=True)
    raise SystemExit(0)
statuses=[]
for index,command in enumerate(commands,1):
    try:
        result=subprocess.run(command,cwd=root,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=120)
        output=result.stdout;exit_code=result.returncode
    except subprocess.TimeoutExpired as error:
        output=(error.stdout or b'').decode(errors='replace') if isinstance(error.stdout,bytes) else (error.stdout or '')
        output+='\nCHILD_TIMEOUT_120_SECONDS\n';exit_code=124
    (out/f'{index:02d}.log').write_text(output)
    print(f'phase {index}: exit={exit_code}',flush=True)
    print(output,flush=True)
    statuses.append(dict(phase=index,exit=exit_code,timeout_seconds=120))
    (out/'status.json').write_text(json.dumps(statuses,indent=2)+'\n')
    if exit_code:raise SystemExit(exit_code)
assert all(digest(Path(item['path']))==item['sha256'] for item in all_inputs.values()),'Reused dependency changed during gate'
outputs=[dict(path=str(p),size=p.stat().st_size,sha256=digest(p)) for p in sorted(classes.rglob('*.class'))]
(out/'outputs.json').write_text(json.dumps(outputs,indent=2)+'\n')
print('All reused inputs unchanged; changed output classes:',len(outputs),flush=True)
