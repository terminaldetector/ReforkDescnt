#!/usr/bin/env bash
set -euo pipefail
cd /workspace/ungravity-v5/ufo-body-physics
python3 work/ufo-body/native/verify-build-stamp.py before
JAVA_HOME=/workspace/jdk21-complete PATH=/workspace/jdk21-complete/bin:$PATH GRADLE_USER_HOME=/workspace/.gradle ./gradlew remapJar remapCubiccheckJar --no-daemon --offline > work/ufo-body/native/verified-build.log 2>&1
python3 work/ufo-body/native/verify-build-stamp.py record
