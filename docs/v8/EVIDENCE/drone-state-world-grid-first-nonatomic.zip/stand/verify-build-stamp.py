from pathlib import Path
import hashlib,json,sys,zipfile
root=Path('/workspace/ungravity-v5/ufo-body-physics'); stamp=root/'work/ufo-body/native/verified-build.json'
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def inputs():
 return {str(p.relative_to(root)):digest(p) for p in sorted([*(root/'src').rglob('*'),root/'build.gradle',root/'gradle.properties',root/'settings.gradle']) if p.is_file()}
def jars():
 paths=[root/'build/libs'/('drmd-6dof-1.1.35-ufo-dev.1'+suffix+'.jar') for suffix in ['', '-cubiccheck']]
 for p in paths:
  with zipfile.ZipFile(p) as z:assert z.testzip() is None,p
 return {str(p.relative_to(root)):digest(p) for p in paths}
if sys.argv[1]=='before':
 (stamp.with_suffix('.inputs.json')).write_text(json.dumps(inputs(),sort_keys=True))
elif sys.argv[1]=='record':
 prior=json.loads(stamp.with_suffix('.inputs.json').read_text());assert prior==inputs(),'Source changed during build'
 stamp.write_text(json.dumps(dict(inputs=prior,jars=jars(),scope='Both remapped artifacts from a successful build; bytes and sources rechecked before every native launch'),indent=2)+'\n')
else:
 saved=json.loads(stamp.read_text());assert saved['inputs']==inputs(),'Build inputs changed: rebuild before native launch';assert saved['jars']==jars(),'Artifact bytes changed: rebuild before native launch'
 print('Verified current source and both remapped artifacts')
