#!/usr/bin/env bash
set +e
cd /workspace/ungravity-v5/ps1-render
bash scripts/v8/ps1_build.sh
build_code=$?
cp work/ps1/verified-build.log work/sky-lod/fixed-first-build.log
echo "$build_code" > work/sky-lod/fixed-first-build.exit
if [ "$build_code" -ne 0 ]; then exit "$build_code"; fi
cp work/ps1/verified-build.json work/sky-lod/fixed-first-build.json
JAVA_HOME=/workspace/jdk21-complete PATH=/workspace/jdk21-complete/bin:$PATH GRADLE_USER_HOME=/workspace/.gradle ./gradlew test --tests com.terminaldetector.drmd.PresentationOptionsTest --offline --no-daemon > work/sky-lod/fixed-first-options.log 2>&1
unit_code=$?
echo "$unit_code" > work/sky-lod/fixed-first-options.exit
if [ -f build/test-results/test/TEST-com.terminaldetector.drmd.PresentationOptionsTest.xml ]; then cp build/test-results/test/TEST-com.terminaldetector.drmd.PresentationOptionsTest.xml work/sky-lod/fixed-first-options.xml; fi
if [ "$unit_code" -ne 0 ]; then exit "$unit_code"; fi
bash scripts/v8/ps1_native.sh ps1-sky-layers-fixed-sodium
native_code=$?
echo "$native_code" > work/sky-lod/fixed-first-native.exit
exit "$native_code"
