#!/usr/bin/env bash
set -euo pipefail
cd /workspace/ungravity-v5/ufo-body-physics
scenario="$1"
python3 work/ufo-body/native/verify-build-stamp.py check
test ! -e "build/cubic-client-final-${scenario}"
if [ -e build/cubic-client-automation ]; then
  mv build/cubic-client-automation "build/cubic-client-before-${scenario}"
fi
args=()
if [[ "$scenario" != *gl32* ]]; then
  args+=(--sodium /workspace/ungravity-v5/world/work/gate0/upstream/sodium-fabric-0.8.13+mc1.21.1.jar)
fi
python3 work/ufo-body/native/prepare-with-verified-library-links.py --server-runtime /workspace/ungravity-v5/world/build/cubic-seed2-gate --runtime build/cubic-client-automation --drmd build/libs/drmd-6dof-1.1.35-ufo-dev.1.jar --gate build/libs/drmd-6dof-1.1.35-ufo-dev.1-cubiccheck.jar --bcc /workspace/Refork-audit/work/master-v5/upstream/bettercubicchunks-fabric-0.1.1+mc1.21.1.jar --api /workspace/.gradle/caches/modules-2/files-2.1/net.fabricmc.fabric-api/fabric-api/0.116.15+1.21.1/d25c793833a90cc028c9a61bc4546cd578a70ce1/fabric-api-0.116.15+1.21.1.jar --java /workspace/jdk21-complete/bin/java --copy-test-world "${args[@]}" > "work/ufo-body/native/final-${scenario}-prepare.log"
python3 work/ufo-body/native/dedup-staged-libraries.py "$scenario"
python3 work/ufo-body/native/seed-verified-minecraft-remap.py
python3 - "$scenario" <<'PY'
import sys,json,pathlib,subprocess
scenario=sys.argv[1];root=pathlib.Path('build/cubic-client-automation')
p=root/'launch.json';a=json.loads(p.read_text());a.insert(1,'-Ddrmd.gate.mechanisms=true');
p.write_text(json.dumps(a,indent=2))

if 'fabulous' in scenario:
    opts=root/'options.txt'; content=opts.read_text(); import re; content=re.sub(r'(?m)^graphicsMode:.*$', 'graphicsMode:2', content) if re.search(r'(?m)^graphicsMode:',content) else content+'\ngraphicsMode:2\n';opts.write_text(content)
p=root/'inputs.json';a=json.loads(p.read_text());a['sourceSha']=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();a['scenario']=scenario;a['glOverride']='3.2/150' if 'gl32' in scenario else '3.3/330';a['uncommittedDiff']=subprocess.check_output(['git','diff','--stat'],text=True);p.write_text(json.dumps(a,indent=2))
PY
display_file="work/ufo-body/native/final-${scenario}-display.txt"
: > "$display_file"
/workspace/xvfb/usr/bin/Xvfb -displayfd 3 -screen 0 1280x1024x24 3> "$display_file" > "work/ufo-body/native/final-${scenario}-xvfb.log" 2>&1 &
display_pid=$!
trap 'kill "$display_pid" 2>/dev/null || true; wait "$display_pid" 2>/dev/null || true' EXIT
for attempt in {1..100}; do
  kill -0 "$display_pid"
  if [ -s "$display_file" ]; then break; fi
  sleep .1
done
test -s "$display_file"
read -r display_number < "$display_file"
if [[ "$scenario" == *gl32* ]]; then
 export MESA_GL_VERSION_OVERRIDE=3.2 MESA_GLSL_VERSION_OVERRIDE=150
else
 export MESA_GL_VERSION_OVERRIDE=3.3 MESA_GLSL_VERSION_OVERRIDE=330
fi
set +e
DISPLAY=:$display_number LIBGL_ALWAYS_SOFTWARE=1 timeout --kill-after=15 --foreground 360 python3 -c 'import os,json; p="/workspace/ungravity-v5/ufo-body-physics/build/cubic-client-automation"; a=json.load(open(p+"/launch.json")); os.chdir(p);os.execv(a[0],a)' < /dev/null > "work/ufo-body/native/final-${scenario}.log" 2>&1
stage_code=$?
set -e
echo "$stage_code" > "work/ufo-body/native/final-${scenario}.exit"
if [ "$stage_code" -ne 0 ]; then exit "$stage_code"; fi
test -s build/cubic-client-automation/mechanisms-ok.json
python3 - <<'CHECK'
from pathlib import Path
assert not list(Path('build/cubic-client-automation/crash-reports').glob('*.txt'))
CHECK
mv build/cubic-client-automation "build/cubic-client-final-${scenario}"
