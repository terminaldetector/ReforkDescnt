from pathlib import Path
import hashlib,json,subprocess,zipfile,xml.etree.ElementTree as E

root=Path.cwd();work=root/'work/mechanisms';scenario='player-mechanisms-input-sodium'
runtime=root/'build'/('cubic-client-final-'+scenario)
source=(work/'native-source.txt').read_text().strip();full=(work/'full-passed-source.txt').read_text().strip()
marker=json.loads((runtime/'mechanisms-ok.json').read_text())
assert marker['actualClientUseAndSneakKeys'] and marker['physicalMotorPositiveAndReverse'] and marker['detachPreservesSpin']
assert len(marker['frames'])==4 and not list((runtime/'crash-reports').glob('*.txt'))
tests=E.parse(work/'full-results.xml').getroot();cases=list(tests.iter('testcase'))
assert len(cases)==357 and not any(c.find('failure') is not None or c.find('error') is not None for c in cases)
unit=json.loads((work/'unit-summary.json').read_text());assert unit==dict(tests=756,failures=0,errors=0,skipped=0)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
game=root/'build/libs/drmd-6dof-1.1.35-ufo-dev.1.jar';observer=root/'build/libs/drmd-6dof-1.1.35-ufo-dev.1-cubiccheck.jar'
assert sha(game)==(work/'full-game.sha256').read_text().split()[0]
subprocess.run(['python3','work/ufo-body/native/verify-build-stamp.py','check'],check=True)
summary=dict(nativeSource=source,fullServerSource=full,productionSource='f04d15b',unit=unit,gameTests=dict(tests=357,failures=0),focusedCases=11,
             gameSha256=sha(game),observerSha256=sha(observer),sameGameBytesForFullAndNative=True,nativeScenario=scenario,native=marker,
             scope='Player-built generic bearings/drives and real client controls. Generic weapons, world anchoring, power economy and complete saved-world/multiplayer lifecycle remain open.',releaseAccepted=False,publication='Local only')
(work/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
(work/'source-series.patch').write_text(subprocess.check_output(['git','diff','8d35584..'+source,'--','AGENTS.md','src'],text=True))
files={}
def add(path,name=None):
 assert path.is_file() and not path.is_symlink(),path
 files[name or str(path.relative_to(root))]=path
for path in work.iterdir():
 if path.is_file() and path.suffix in {'.log','.xml','.json','.txt','.patch','.gradle','.sh','.py'}:add(path)
for path in (root/'build/test-results/test').glob('TEST-*.xml'):add(path)
for path in (runtime/'mechanism-frames').glob('*.png'):add(path)
for name in ['inputs.json','launch.json','options.txt','mechanisms-ok.json']:add(runtime/name)
for suffix in ['.log','.exit','-prepare.log','-xvfb.log']:
 path=root/'work/ufo-body/native'/('final-'+scenario+suffix)
 if path.is_file():add(path)
add(game);add(observer);add(root/'docs/v8/PLAYER_BUILT_MECHANISMS.md')
manifest={name:sha(path) for name,path in sorted(files.items())}
dest=root/'docs/v8/EVIDENCE'/('player-mechanisms-'+source[:7]+'.zip');assert not dest.exists()
with zipfile.ZipFile(dest,'x',zipfile.ZIP_DEFLATED) as z:
 for name,path in sorted(files.items()):z.write(path,name)
 z.writestr('MANIFEST.json',json.dumps(dict(source=source,fullServerSource=full,files=manifest),indent=2))
with zipfile.ZipFile(dest) as z:
 assert z.testzip() is None
 for name,digest in manifest.items():assert hashlib.sha256(z.read(name)).hexdigest()==digest
summary.update(archive=str(dest.relative_to(root)),archiveSha256=sha(dest),verifiedFiles=len(manifest),crcAndHashesVerified=True)
(work/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
