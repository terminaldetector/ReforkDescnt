from pathlib import Path
import fcntl,hashlib,json,subprocess,zipfile,shutil
import sys,contextlib
assert sys.argv[1] in ['cubic-client-final-release-actors-sodium','cubic-client-final-release-gun-sodium','cubic-client-final-release-mirror-fabulous-gl32']
root=Path('/workspace/ungravity-v5/snapshot-ci');runtime=root/'build'/sys.argv[1];world=runtime/'saves';dest=Path('work/preserved-disposable-worlds')/('snapshot-'+sys.argv[1]+'-closed-mechanisms.zip')
assert world.is_dir() and not world.is_symlink() and not dest.exists()
log=runtime/'logs/latest.log';assert 'All dimensions are saved' in log.read_text()[-5000:]
with contextlib.ExitStack() as stack:
 locks=list(world.rglob('session.lock'));assert locks
 for p in locks:
  lock=stack.enter_context(p.open('r+b'));fcntl.lockf(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 paths=sorted(p for p in world.rglob('*') if p.is_file());assert not any(p.is_symlink() for p in paths)
 manifest={str(p.relative_to(world)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
 meta={'original':str(world),'workspaceHeadAtPreservation':subprocess.check_output(['git','-C',str(root),'rev-parse','HEAD'],text=True).strip(),'scope':'Closed disposable old native snapshot-test worlds only; original logs and all evidence remain','files':manifest}
 with zipfile.ZipFile(dest,'x',zipfile.ZIP_DEFLATED) as z:
  for p in paths:z.write(p,str(p.relative_to(world)))
  z.writestr('MANIFEST.json',json.dumps(meta,indent=2));z.write(log,'original-shutdown.log')
 with zipfile.ZipFile(dest) as z:
  assert z.testzip() is None
  for n,h in manifest.items():assert hashlib.sha256(z.read(n)).hexdigest()==h
 # Recheck originals immediately before reclaiming this closed test world.
 assert manifest=={str(p.relative_to(world)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
 meta.update(archive=str(dest),sha256=hashlib.sha256(dest.read_bytes()).hexdigest(),bytesBefore=sum(p.stat().st_size for p in paths),bytesAfter=dest.stat().st_size,fullFileHashesAndCrcVerified=True)
 shutil.rmtree(world)
 Path(str(dest)+'.json').write_text(json.dumps(meta,indent=2)+'\n');print(json.dumps({k:v for k,v in meta.items() if k!='files'}))
