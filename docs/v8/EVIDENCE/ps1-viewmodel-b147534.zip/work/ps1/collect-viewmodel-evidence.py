"""Collect the unchanged-observer viewmodel negative and first exact same-camera positives."""
from pathlib import Path
import hashlib,json,math,subprocess,xml.etree.ElementTree as E,zipfile

root=Path.cwd();work=root/'work/ps1';source='b1475348a9a9a9f1d6495cd7f622ac213144969a';negative='fbe0bb7e5c62a8aef101cbaf347948c4cb0fcbe3'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
subprocess.run(['python3','scripts/v8/ps1_build_stamp.py','check'],check=True)
stamp=json.loads((work/'verified-build.json').read_text());old=json.loads((work/'viewmodel-negative-build.json').read_text());assert stamp['sourceSha']==source and old['sourceSha']==negative
observer=next(k for k in stamp['jars'] if k.endswith('-cubiccheck.jar'));assert stamp['jars'][observer]==old['jars'][observer]
assert not subprocess.check_output(['git','diff',negative,source,'--','src/cubiccheck','scripts/v8','src/test','src/gametest','build.gradle','settings.gradle','gradle.properties'])
assert subprocess.check_output(['git','diff','--name-only',negative,source,'--','src/main'],text=True).splitlines()==['src/main/java/com/terminaldetector/drmd/client/presentation/ScenePresentation.java']
unit=E.parse(work/'viewmodel-positive-five-unit.xml').getroot();assert {k:int(unit.get(k,0)) for k in ['tests','failures','errors','skipped']}==dict(tests=5,failures=0,errors=0,skipped=0)
bad=root/'build/cubic-client-failed-ps1-viewmodel-fbe0bb7';badInputs=json.loads((bad/'inputs.json').read_text());assert badInputs['sourceSha']==negative and badInputs['candidateJars']==old['jars']
assert (work/'ps1-viewmodel-negative-sodium.exit').read_text().strip()=='255'
failure=json.loads((bad/'viewmodel-failure/viewmodel-visibility.json').read_text());assert failure['nativePixels']>=100 and failure['ps1Pixels']==0 and failure['sameCamera'] and failure['sameModules'] and failure['maximumProjectedVertexDeltaPixels']==0
def stage(trace,name):return next(v for v in trace if v['stage']==name)
assert stage(failure['ps1Trace'],'gold-layer-after-1')['sequence']<stage(failure['ps1Trace'],'cockpit-after')['sequence']
assert stage(failure['ps1Trace'],'gold-layer-after-1')['goldPixels']==failure['nativePixels'] and stage(failure['ps1Trace'],'cockpit-after')['goldPixels']==0
cases=['ps1-viewmodel-fixed-sodium','ps1-viewmodel-fixed-fabulous-gl32'];runtimes=[];results={};presentation={}
sceneNames=['native-baseline','ps1-360','native-restored','debug-wireframe','ps1-180-resized','native-window-restored']
for case in cases:
    runtime=root/'build'/('cubic-client-final-'+case);runtimes.append(runtime)
    inputs=json.loads((runtime/'inputs.json').read_text());assert inputs['sourceSha']==source and inputs['candidateJars']==stamp['jars']
    assert '-Ddrmd.gate.viewmodel=true' in json.loads((runtime/'launch.json').read_text())
    assert (work/(case+'.exit')).read_text().strip()=='0' and not list((runtime/'crash-reports').glob('*.txt'))
    for rel,digest in stamp['jars'].items():assert sha(runtime/'mods'/Path(rel).name)==digest
    proof=json.loads((runtime/'viewmodel-proof/viewmodel-visibility.json').read_text());assert proof['thresholds']==failure['thresholds']
    assert proof['nativePixels']==failure['nativePixels'] and proof['ps1Pixels']>=proof['requiredPixels']==max(100,math.ceil(proof['nativePixels']*.75))
    assert proof['sameCamera'] and proof['sameModules'] and proof['maximumProjectedVertexDeltaPixels']<=1
    assert proof['nativeCamera']==proof['ps1Camera'] and proof['modules']==failure['modules']
    assert stage(proof['ps1Trace'],'cockpit-after')['sequence']<stage(proof['ps1Trace'],'gold-layer-after-1')['sequence']
    assert stage(proof['ps1Trace'],'final')['goldPixels']==proof['ps1Pixels']
    assert sum(v['stage']=='actual-white-solid-gold-flush-before' for v in proof['ps1Trace'])==1
    for group in ['nativeTrace','ps1Trace']:
        draw=stage(proof[group],'actual-white-solid-gold-flush-before');assert draw['mainFbo']==draw['drawFbo'] and draw['depthTest'] and draw['depthWrite'] and draw['depthFunction']==515
    assert len(list((runtime/'viewmodel-proof').glob('*.png')))==14
    marker=json.loads((runtime/'presentation-ok.json').read_text());assert [s['scene'] for s in marker['scenes']]==sceneNames
    for key in ['runtimeToggleWithoutReload','actualWindowResizeAndRestore','exceptionTargetsRestored','debugPostprocessExceptionRestored','blockstoreHashUnchanged','independentHybridChoiceUnchanged']:assert marker[key]
    assert len(list((runtime/'presentation-frames').glob('*.png')))==9
    for s in marker['scenes']:
        assert s['glError']==0 and s['nativeHudPixel']
        if s['profile']=='PS1_HYBRID':assert s['worldNearestGridRatio']>.97 and s['deferredOverlayPasses']>=2 and s['reflectedGoldPixels']>=30 and s['sampleEpoch']==s['frameEpoch']==s['mirrorEpoch']
        elif s['profile']=='RENDER_DEBUG':assert s['debugWorldEdges']['ratio']>=.70 and min(s['debugWorldEdges']['horizontalBins'])>=20
    sodium=any('sodium' in a['path'].lower() for a in inputs['artifacts']);assert sodium==('sodium' in case)
    if 'gl32' in case:assert inputs['glOverride']=='3.2/150' and 'graphicsMode:2' in (runtime/'options.txt').read_text()
    results[case]={k:proof[k] for k in ['epoch','nativePixels','ps1Pixels','requiredPixels','sameCamera','sameModules','maximumProjectedVertexDeltaPixels']};presentation[case]=marker
summary=dict(source=source,negativeSource=negative,jars=stamp['jars'],negativeJars=old['jars'],sameObserverBytes=True,unit=dict(source=source,tests=5,failures=0,errors=0,skipped=0),negative={k:failure[k] for k in ['nativePixels','ps1Pixels','requiredPixels','sameCamera','sameModules','maximumProjectedVertexDeltaPixels']},positive=results,presentation=presentation,
    imageScope='First negative14stagePNG; each positive14stagePNG+9normalpresentationPNG. Key weapon/cockpit/final images inspected; all captures and18normal-sequence images retained for further review.',
    scope='Stationary default laser/cockpit buffered-ordering repair and existing six-scene presentation/Debug regression. Broader weapons/recoil/YPR and full S04/S05 remain open.',fullCanonicalRegressionsClaimed=False,releaseAccepted=False,publication='Local only')
(work/'viewmodel-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
(work/'viewmodel-source-series.patch').write_text(subprocess.check_output(['git','diff','abfa3db',source,'--','src','scripts/v8'],text=True))
files={}
def add(p,name=None):
    assert p.is_file() and not p.is_symlink(),p
    files[name or str(p.relative_to(root))]=p
for p in work.iterdir():
    if p.is_file() and p.name.startswith('viewmodel-') and p.suffix in {'.json','.log','.txt','.xml','.exit','.patch'}:add(p)
add(work/'collect-viewmodel-evidence.py')
for runtime in [bad,*runtimes]:
    for name in ['inputs.json','launch.json','options.txt','presentation-ok.json']:
        p=runtime/name
        if p.exists():add(p)
    for folder in ['presentation-frames','viewmodel-failure','viewmodel-proof','crash-reports']:
        for p in (runtime/folder).glob('*'):
            if p.is_file():add(p)
for case in ['ps1-viewmodel-negative-sodium',*cases]:
    for suffix in ['.exit','-prepare.log','-display.txt','-xvfb.log']:add(work/(case+suffix))
for p in (root/'scripts/v8').glob('ps1*'):
    if p.is_file():add(p)
for p in [root/'src/main/java/com/terminaldetector/drmd/client/presentation/ScenePresentation.java',root/'src/cubiccheck/java/com/terminaldetector/drmd/gate/NativeViewmodelCheck.java',root/'src/cubiccheck/resources/drmd.cubiccheck.mixins.json',root/'docs/v8/PS1_PRESENTATION_WIP.md',root/'docs/v8/EVIDENCE/ps1-debug-7df89aa.json']:add(p)
for p in (root/'src/cubiccheck/java/com/terminaldetector/drmd/gate/mixin').glob('Viewmodel*Probe.java'):add(p)
official=Path('/workspace/ungravity-v5/ufo-body-physics/scripts/v5/prepare_cubic_client.py')
for runtime in [bad,*runtimes]:assert sha(official)==json.loads((runtime/'inputs.json').read_text())['officialStagerSha256']
add(official,'official_stager/prepare_cubic_client.py')
manifest={name:sha(p) for name,p in sorted(files.items())};dest=root/'docs/v8/EVIDENCE/ps1-viewmodel-b147534.zip';dest.parent.mkdir(parents=True,exist_ok=True);assert not dest.exists()
with zipfile.ZipFile(dest,'x',zipfile.ZIP_DEFLATED) as z:
    for name,p in sorted(files.items()):z.write(p,name)
    z.writestr('MANIFEST.json',json.dumps(dict(source=source,negativeSource=negative,files=manifest),indent=2))
with zipfile.ZipFile(dest) as z:
    assert z.testzip() is None
    for name,digest in manifest.items():assert hashlib.sha256(z.read(name)).hexdigest()==digest,name
receipt={k:summary[k] for k in ['source','negativeSource','jars','negativeJars','sameObserverBytes','unit','negative','positive','scope','fullCanonicalRegressionsClaimed','releaseAccepted']};receipt.update(archive=str(dest.relative_to(root)),archiveSha256=sha(dest),verifiedFiles=len(manifest),crcAndHashesVerified=True)
dest.with_suffix('.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
