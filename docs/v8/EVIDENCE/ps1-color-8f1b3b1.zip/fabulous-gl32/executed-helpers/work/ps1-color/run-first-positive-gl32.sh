#!/usr/bin/env bash
set +e
cd /workspace/ungravity-v5/ps1-render
bash scripts/v8/ps1_native.sh ps1-color-reference-fixed-fabulous-gl32
native_code=$?
echo "$native_code" > work/ps1-color/positive-first-gl32-native.exit
exit "$native_code"
