#!/usr/bin/env bash
set +e
cd /workspace/ungravity-v5/ps1-render
bash scripts/v8/ps1_build.sh
build_code=$?
cp work/ps1/verified-build.log work/ps1-color/positive-first-build.log
echo "$build_code" > work/ps1-color/positive-first-build.exit
if [ "$build_code" -ne 0 ]; then exit "$build_code"; fi
cp work/ps1/verified-build.json work/ps1-color/positive-first-build.json
JAVA_HOME=/workspace/jdk21-complete PATH=/workspace/jdk21-complete/bin:$PATH GRADLE_USER_HOME=/workspace/.gradle ./gradlew test --tests com.terminaldetector.drmd.PresentationOptionsTest --tests com.terminaldetector.drmd.Ps1ColorOptionsTest --offline --no-daemon > work/ps1-color/positive-first-units.log 2>&1
unit_code=$?
echo "$unit_code" > work/ps1-color/positive-first-units.exit
for name in PresentationOptionsTest Ps1ColorOptionsTest; do if [ -f "build/test-results/test/TEST-com.terminaldetector.drmd.${name}.xml" ]; then cp "build/test-results/test/TEST-com.terminaldetector.drmd.${name}.xml" "work/ps1-color/positive-first-${name}.xml"; fi; done
if [ "$unit_code" -ne 0 ]; then exit "$unit_code"; fi
python3 - <<'PY' > work/ps1-color/positive-first-observer-parity.log 2>&1
from pathlib import Path
import hashlib
p=Path('build/libs/drmd-6dof-1.1.35-ufo-dev.1-cubiccheck.jar');expected='f6712df320502a4ff6e0412e031bbebffc4d081f018da00751bc3cddc215406f';actual=hashlib.sha256(p.read_bytes()).hexdigest();assert actual==expected,(actual,expected);print('Exact observer/reference byte parity with first074 negative',actual)
PY
parity_code=$?
echo "$parity_code" > work/ps1-color/positive-first-observer-parity.exit
if [ "$parity_code" -ne 0 ]; then exit "$parity_code"; fi
bash scripts/v8/ps1_native.sh ps1-color-reference-fixed-sodium
native_code=$?
echo "$native_code" > work/ps1-color/positive-first-native.exit
exit "$native_code"
