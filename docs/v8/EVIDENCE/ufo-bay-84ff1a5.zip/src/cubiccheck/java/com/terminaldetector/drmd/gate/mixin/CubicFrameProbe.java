package com.terminaldetector.drmd.gate.mixin;
import com.terminaldetector.drmd.gate.CubicClientGate;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.RenderTickCounter;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(GameRenderer.class)
public class CubicFrameProbe {
    @Inject(method="render",at=@At("HEAD"))
    private void before(RenderTickCounter counter,boolean tick,CallbackInfo ci){com.terminaldetector.drmd.gate.NativeIslandLoadCheck.beforeFrame(counter.getTickDelta(false));com.terminaldetector.drmd.gate.NativeSharedCombatCheck.beforeFrame(counter.getTickDelta(false));com.terminaldetector.drmd.gate.NativeTypedCombatRouteCheck.beforeFrame(counter.getTickDelta(false));}
    @Inject(method="render",at=@At("RETURN"))
    private void completed(RenderTickCounter counter,boolean tick,CallbackInfo ci) {
        if(com.terminaldetector.drmd.gate.NativeIslandLoadCheck.ENABLED){com.terminaldetector.drmd.gate.NativeIslandLoadCheck.rendered();return;}
        if(com.terminaldetector.drmd.gate.NativeJointReloadCheck.READ){com.terminaldetector.drmd.gate.NativeJointReloadCheck.rendered();return;}
        if(com.terminaldetector.drmd.gate.NativeSharedCombatCheck.ENABLED){com.terminaldetector.drmd.gate.NativeSharedCombatCheck.rendered();return;}
        if(com.terminaldetector.drmd.gate.NativeTypedCombatRouteCheck.ENABLED){com.terminaldetector.drmd.gate.NativeTypedCombatRouteCheck.rendered();return;}
        if(com.terminaldetector.drmd.gate.NativeDroneWreckCheck.ENABLED){com.terminaldetector.drmd.gate.NativeDroneWreckCheck.rendered();return;}
        if(com.terminaldetector.drmd.gate.NativeFlightEnemyCheck.ENABLED){com.terminaldetector.drmd.gate.NativeFlightEnemyCheck.rendered();return;}
        if(com.terminaldetector.drmd.gate.NativeDroneRouteCheck.ENABLED){com.terminaldetector.drmd.gate.NativeDroneRouteCheck.rendered();return;}
        if(com.terminaldetector.drmd.gate.NativeDroneStateCheck.READ){com.terminaldetector.drmd.gate.NativeDroneStateCheck.rendered();return;}
        if(Boolean.getBoolean("drmd.gate.swarm")){com.terminaldetector.drmd.gate.NativeSwarmBaselineCheck.rendered();return;}
        if(com.terminaldetector.drmd.gate.NativeUfoReloadCheck.READ){com.terminaldetector.drmd.gate.NativeUfoReloadCheck.rendered();return;}
        if(Boolean.getBoolean("drmd.gate.flightBody")){com.terminaldetector.drmd.gate.NativeFlightBodyCheck.rendered();return;}
        if(Boolean.getBoolean("drmd.gate.joints")){com.terminaldetector.drmd.gate.NativeJointCheck.rendered();}else if(Boolean.getBoolean("drmd.gate.bodyIndex")){com.terminaldetector.drmd.gate.NativeBodyIndexCheck.rendered();}else if(Boolean.getBoolean("drmd.gate.bodyEdit")){com.terminaldetector.drmd.gate.NativeBodyEditCheck.rendered();}else if(Boolean.getBoolean("drmd.gate.shipGravity"))com.terminaldetector.drmd.gate.NativeShipGravityCheck.rendered();
        else if(Boolean.getBoolean("drmd.gate.boarding"))com.terminaldetector.drmd.gate.NativeBoardingCheck.rendered();
        else if(Boolean.getBoolean("drmd.gate.snapshot"))com.terminaldetector.drmd.gate.NativeSnapshotCheck.rendered();
        else if(Boolean.getBoolean("drmd.gate.contacts"))com.terminaldetector.drmd.gate.NativeBodyCollisionCheck.rendered();
        else if(Boolean.getBoolean("drmd.gate.gun"))com.terminaldetector.drmd.gate.NativePortalGunCheck.rendered();
        else if(Boolean.getBoolean("drmd.gate.actors"))com.terminaldetector.drmd.gate.NativeActorFrameCheck.rendered();
        else if(Boolean.getBoolean("drmd.gate.mirrors"))com.terminaldetector.drmd.gate.NativeMirrorCheck.rendered();
        else CubicClientGate.frameFinished();
    }
}
