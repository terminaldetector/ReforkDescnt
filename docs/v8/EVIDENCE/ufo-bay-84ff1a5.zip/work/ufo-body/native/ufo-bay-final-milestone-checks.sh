#!/usr/bin/env bash
set -euo pipefail
cd /workspace/ungravity-v5/ufo-body-physics
JAVA_HOME=/workspace/jdk21-complete PATH=/workspace/jdk21-complete/bin:$PATH GRADLE_USER_HOME=/workspace/.gradle ./gradlew processGametestResources --rerun-tasks --no-daemon --offline > work/ufo-body/ufo-bay-restore-full-resources.log 2>&1
python3 - <<'PY'
import json
from pathlib import Path
assert json.loads(Path('build/resources/gametest/fabric.mod.json').read_text())['entrypoints']==json.loads(Path('src/gametest/resources/fabric.mod.json').read_text())['entrypoints']
print('Restored every original full-suite GameTest entrypoint')
PY
bash work/ufo-body/native/build-verified.sh
cp work/ufo-body/native/verified-build.log work/ufo-body/ufo-bay-verified-build.log
bash work/ufo-body/native/run-island.sh flight-body-control-bay-gl32
bash work/ufo-body/native/run-island.sh flight-body-control-bay-sodium
python3 work/ufo-body/native/verify-build-stamp.py check
JAVA_HOME=/workspace/jdk21-complete PATH=/workspace/jdk21-complete/bin:$PATH GRADLE_USER_HOME=/workspace/.gradle ./gradlew test runGametest remapJar remapCubiccheckJar --no-daemon --offline > work/ufo-body/ufo-bay-final-regressions.log 2>&1
python3 work/ufo-body/native/verify-build-stamp.py check
python3 - <<'PY'
import json
from pathlib import Path
assert json.loads(Path('build/resources/gametest/fabric.mod.json').read_text())['entrypoints']==json.loads(Path('src/gametest/resources/fabric.mod.json').read_text())['entrypoints']
print('Full-suite GameTest entrypoints remain intact after the run')
PY
