from pathlib import Path
import hashlib,json,subprocess,zipfile,xml.etree.ElementTree as E
subprocess.run(['python3','work/ufo-body/native/verify-build-stamp.py','check'],check=True)
source=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();files=set()
def add(p):
 p=Path(p);assert p.is_file(),p;files.add(p)
stamp=json.loads(Path('work/ufo-body/native/verified-build.json').read_text())
for p,h in stamp['jars'].items():assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==h;add(p)
for p in ['src/main/java/com/terminaldetector/drmd/world/mega/SkyUfoEntity.java','src/main/java/com/terminaldetector/drmd/world/mega/UfoControlSystem.java','src/gametest/java/com/terminaldetector/drmd/PhysicalUfoGameTests.java','src/cubiccheck/java/com/terminaldetector/drmd/gate/NativeFlightBodyCheck.java','src/cubiccheck/java/com/terminaldetector/drmd/gate/CubicClientGate.java','src/cubiccheck/java/com/terminaldetector/drmd/gate/mixin/CubicFrameProbe.java','src/gametest/resources/fabric.mod.json','build/resources/gametest/fabric.mod.json','build.gradle','gradle.properties','work/ufo-body/native/verified-build.json','work/ufo-body/native/run-island.sh','work/ufo-body/native/ufo-bay-final-milestone-checks.sh','work/ufo-body/native/ufo-bay-final-milestone-checks.log','work/ufo-body/collect-ufo-bay-evidence.py','work/ufo-body/ufo-bay-focus.init.gradle','work/ufo-body/ufo-bay-focused-final.xml','build/gametest/reports/gametest-results.xml']:add(p)
for p in Path('work/ufo-body').glob('ufo-bay-*.log'):add(p)
for p in Path('work/ufo-body').glob('ufo-bay-*failure.zip'):add(p)
for p in Path('build/test-results/test').glob('TEST-*.xml'):add(p)
markers={}
for profile in ['gl32','sodium']:
 scenario='flight-body-control-bay-'+profile;r=Path('build/cubic-client-final-'+scenario)
 for suffix in ['.log','.exit','-prepare.log']:add('work/ufo-body/native/final-'+scenario+suffix)
 assert Path('work/ufo-body/native/final-'+scenario+'.exit').read_text().strip()=='0'
 info=json.loads((r/'inputs.json').read_text());assert info['sourceSha']==source and not info['uncommittedDiff']
 m=json.loads((r/'ufo-control-ok.json').read_text());assert m['bayPausedSamples']>=8 and m['bayResumed'] and m['pauseResumed'] and m['actualUfo'] and m['actualThrust'] and m['controlCore'] and not m['teleportFollow'] and m['predictionSamples']>=25 and m['maxPredictionError']<.8 and len(m['scenes'])==7
 for p in ['inputs.json','launch.json','ufo-control-ok.json']:add(r/p)
 frames=list((r/'flight-body-frames').glob('*.png'));assert len(frames)==7
 for p in frames:add(p)
 markers[profile]=m
rs=[E.parse(p).getroot() for p in Path('build/test-results/test').glob('TEST-*.xml')];u={k:sum(int(r.get(k,0)) for r in rs) for k in ['tests','failures','errors','skipped']}
cs=list(E.parse('build/gametest/reports/gametest-results.xml').iter('testcase'));g={'tests':len(cs),'failures':sum(c.find('failure') is not None for c in cs),'errors':sum(c.find('error') is not None for c in cs),'skipped':sum(c.find('skipped') is not None for c in cs)}
assert u==dict(tests=722,failures=0,errors=0,skipped=0) and g==dict(tests=292,failures=0,errors=0,skipped=0)
assert json.loads(Path('build/resources/gametest/fabric.mod.json').read_text())['entrypoints']==json.loads(Path('src/gametest/resources/fabric.mod.json').read_text())['entrypoints']
assert 'BUILD SUCCESSFUL' in Path('work/ufo-body/ufo-bay-final-regressions.log').read_text()
m={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(files)}
s=dict(source=source,productionSource=subprocess.check_output(['git','rev-parse','d63ca21'],text=True).strip(),jars=stamp['jars'],unit=u,server=g,native=markers,files=m,releaseAccepted=False,publication='Local only',scope='Captured UFO pauses autonomous hostile bay/timer and restores AI bay cycle at release; physical identity/momentum and existing independently deployed drones are preserved. Full v8/Dynamic Boarding remain open.')
p=Path('docs/v8/EVIDENCE/ufo-bay-'+source[:7]+'.zip')
with zipfile.ZipFile(p,'x',zipfile.ZIP_DEFLATED) as z:
 for f in sorted(files):z.write(f,str(f))
 z.writestr('MANIFEST.json',json.dumps(s,indent=2))
with zipfile.ZipFile(p) as z:
 assert z.testzip() is None
 for n,h in m.items():assert hashlib.sha256(z.read(n)).hexdigest()==h
s['archive']=str(p);s['archiveSha256']=hashlib.sha256(p.read_bytes()).hexdigest();Path('work/ufo-body/ufo-bay-summary.json').write_text(json.dumps(s,indent=2)+'\n')
print(json.dumps({k:v for k,v in s.items() if k!='files'},indent=2))
