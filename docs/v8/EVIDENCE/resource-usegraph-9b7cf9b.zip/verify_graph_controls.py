"""Pure graph controls with synthetic in-memory models; no game or source mutations."""
import hashlib,importlib.util,json,runpy,subprocess,tempfile
from pathlib import Path

ROOT=Path('/workspace/ungravity-v5/audit-next-20261109');OUT=ROOT/'work/resource-usegraph'
g=runpy.run_path(str(OUT/'audit_graph.py'))
assert g['result']['errors']==[] and len(g['items'])==131 and len(g['blocks'])==47
controls=[]
def case(name,model,expected_error=None,extra=None):
 g['errors'].clear()
 key='fixture:probe';g['models'][key]=model
 for k,v in (extra or {}).items():g['models'][k]=v
 g['check_model'](key,'SYNTHETIC_FIXTURE_NOT_RUNTIME')
 errors=list(g['errors'])
 if expected_error is None:assert not errors,(name,errors)
 else:assert errors and any(expected_error in r['error'] for r in errors),(name,errors)
 controls.append(dict(case=name,result='PASS',expected='valid graph' if expected_error is None else expected_error))
 for k in [key,*(extra or {})]:g['models'].pop(k)

case('actual vanilla item parent',{'parent':'minecraft:item/generated','textures':{'layer0':'minecraft:item/iron_ingot'}})
case('actual vanilla block texture variable',{'parent':'minecraft:block/cube_all','textures':{'all':'minecraft:block/stone'}})
case('synthetic missing vanilla parent',{'parent':'minecraft:item/fixture_absent_model'},'missing model minecraft:item/fixture_absent_model')
case('synthetic missing vanilla texture',{'parent':'minecraft:item/generated','textures':{'layer0':'minecraft:item/fixture_absent_texture'}},'missing texture minecraft:item/fixture_absent_texture')
case('synthetic missing custom parent',{'parent':'fixture:missing'},'missing model fixture:missing')
case('synthetic parent cycle',{'parent':'fixture:b'},'parent cycle',{'fixture:b':{'parent':'fixture:probe'}})
case('synthetic texture cycle',{'textures':{'a':'#b','b':'#a'}},'cyclic texture')
case('synthetic unbound face texture',{'elements':[{'faces':{'north':{'texture':'#absent'}}}]},'unbound/cyclic texture')
case('synthetic missing override',{'parent':'minecraft:item/generated','textures':{'layer0':'minecraft:item/iron_ingot'},'overrides':[{'predicate':{'damage':1},'model':'fixture:absent'}]},'missing model fixture:absent')
case('synthetic override cycle',{'overrides':[{'predicate':{'damage':1},'model':'fixture:probe'}]},'override cycle')
case('legitimate builtin entity marker',{'parent':'builtin/entity'})

revision=g['REV'];source=subprocess.check_output(['git','show',revision+':scripts/audit_resources.py'],cwd=ROOT)
old_path=OUT/'pinned-audit_resources.py';old_path.write_bytes(source)
spec=importlib.util.spec_from_file_location('existing_resource_scan',old_path);old=importlib.util.module_from_spec(spec);spec.loader.exec_module(old)
with tempfile.TemporaryDirectory(prefix='resource-geometry-') as temp:
 root=Path(temp)
 for path in g['paths']:
  if path.startswith('src/main/resources/assets/'):
   target=root/path;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(g['blob'](path))
 geom=old.scan(root)
 assert geom['errors']==[]
 geometry=dict(scope='Existing pinned scanner on exact exported model/image assets; dimensions/display/staticJSON only, its vanilla dependency deferral remains explicit',models=geom['models'],item_models=len(geom['items']),errors=geom['errors'],duplicate_geometry_groups=len(geom['duplicate_geometry']),vanilla_dependencies_unverified_by_old_scanner=geom['vanilla_dependencies'])
 # Existing scanner deliberately defers every Minecraft parent. Demonstrate scope,
 # not an asserted broken production resource or a false runtime PASS.
 probe=root/'src/main/resources/assets/fixture/models/item/probe.json';probe.parent.mkdir(parents=True)
 probe.write_text(json.dumps({'parent':'minecraft:item/fixture_absent_model'}))
 deferred=old.scan(root)
 assert not any('fixture_absent_model' in e for e in deferred['errors'])
 assert 'model minecraft:item/fixture_absent_model' in deferred['vanilla_dependencies']
 original_scope=dict(synthetic_missing_vanilla_parent='deferred as external by existing scanner, not checked there',runtime_or_production_defect=False,small_followup='Optional strict actual-vanilla-jar resolver plus registered blockstate roots, retaining explicit default deferral; not implemented here')

result=dict(scope='Static graph/arithmetic/bounds validation,11synthetic controls; no Java or actual item appearance verification',
 revision=revision,controls=controls,control_count=len(controls),geometry=geometry,old_scanner_scope=original_scope,
 checker_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
 resource_graph_sha256=hashlib.sha256((OUT/'registered-graph.json').read_bytes()).hexdigest())
(OUT/'graph-verification.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ['revision','scope','control_count','geometry','old_scanner_scope']},indent=2))
