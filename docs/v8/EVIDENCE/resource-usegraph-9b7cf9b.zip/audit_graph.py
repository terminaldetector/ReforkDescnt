"""Read pinned registered roots and resolve model/texture edges against real MC assets."""
import hashlib,io,json,re,subprocess,zipfile
from PIL import Image
from pathlib import Path

ROOT=Path('/workspace/ungravity-v5/audit-next-20261109')
REV='9b7cf9b0709a47c181d113923f7ac59a4b62fd3c'
MC=ROOT/'build/native-benchmark-9426/9426-capacity16-v1/cubic-client-automation/libraries/com/mojang/minecraft/1.21.1/minecraft-1.21.1-client.jar'
OUT=ROOT/'work/resource-usegraph'
PREFIX='src/main/resources/'
paths=subprocess.check_output(['git','ls-tree','-r','--name-only',REV],cwd=ROOT).decode().splitlines()
cache={}
def blob(path):
 if path not in cache:cache[path]=subprocess.check_output(['git','show',REV+':'+path],cwd=ROOT)
 return cache[path]
def sha(raw):return hashlib.sha256(raw).hexdigest()
def rid(value):return value if ':' in value else 'minecraft:'+value
models={};textures={};states={};sources={}
for path in paths:
 if not path.startswith(PREFIX+'assets/'):continue
 relative=path[len(PREFIX):];parts=relative.split('/');ns=parts[1]
 if '/models/' in path and path.endswith('.json'):
  key=ns+':'+'/'.join(parts[3:])[:-5];models[key]=json.loads(blob(path));sources['model '+key]=path
 if '/textures/' in path and path.endswith('.png'):
  key=ns+':'+'/'.join(parts[3:])[:-4];textures[key]=blob(path);sources['texture '+key]=path
 if '/blockstates/' in path and path.endswith('.json'):states[ns+':'+parts[-1][:-5]]=(path,json.loads(blob(path)))
with zipfile.ZipFile(MC) as z:
 vanilla_entries=set(z.namelist())
 vanilla_atlas=z.read('assets/minecraft/atlases/blocks.json')
 for name in z.namelist():
  if name.startswith('assets/minecraft/models/') and name.endswith('.json'):
   models['minecraft:'+name[len('assets/minecraft/models/'):-5]]=json.loads(z.read(name))
  if name.startswith('assets/minecraft/textures/') and name.endswith('.png'):
   textures['minecraft:'+name[len('assets/minecraft/textures/'):-4]]=z.read(name)

items={};blocks={}
def add(target,key,path,offset,kind):
 lines=blob(path).decode().splitlines();line=blob(path).decode()[:offset].count('\n')+1
 target.setdefault('drmd:'+key,[]).append(dict(path=path,line=line,text=lines[line-1],binding=kind))
p='src/main/java/com/terminaldetector/drmd/weapon/items/ModItems.java';text=blob(p).decode()
for m in re.finditer(r'\b(wep|register|egg)\s*\(\s*"([a-z0-9_/]+)"',text):add(items,m[2],p,m.start(),m[1]+' actual literal call')
for p,pattern in [('src/main/java/com/terminaldetector/drmd/entity/ModBlocks.java',r'\bregister\s*\(\s*"([a-z0-9_/]+)"'),
                  ('src/main/java/com/terminaldetector/drmd/entity/ModWorldBlocks.java',r'\b(registerBlock|registerBlockNoItem)\s*\(\s*"([a-z0-9_/]+)"')]:
 text=blob(p).decode()
 for m in re.finditer(pattern,text):
  key=m[1] if 'ModBlocks.java' in p else m[2]
  noitem='ModWorldBlocks.java' in p and m[1]=='registerBlockNoItem'
  add(blocks,key,p,m.start(),'registered block with'+('out' if noitem else '')+' item')
  if not noitem:add(items,key,p,m.start(),'helper registers BlockItem with same id')
 if 'ModWorldBlocks' in p:
  for m in re.finditer(r'Registry\.register\(Registries\.ITEM,\s*Identifier\.of\(DescentMod\.MOD_ID,\s*"([a-z0-9_/]+)"',text):add(items,m[1],p,m.start(),'explicit Registry ITEM literal')

organic_path='src/main/java/com/terminaldetector/drmd/world/geometry/OrganicMaterials.java'
organic=blob(organic_path).decode()
enum_list=re.search(r'new Block\[\]\{(.*?)\}',organic,re.S).group(1)
organic_sources=re.findall(r'Blocks\.([A-Z_]+)',enum_list)
assert len(organic_sources)==13
for name in organic_sources:
 key='organic_'+name.lower()
 assert 'minecraft:'+name.lower() in states or 'minecraft:'+name.lower() in models or 'minecraft:block/'+name.lower() in models
 add(blocks,key,organic_path,organic.index('Registry.register(Registries.BLOCK'),'derived organic_'+name.lower()+' from explicit vanilla source list; no BlockItem registered')

errors=[];edges=[];builtins=[];placeholders=[];root_results=[];visited_models=set()
BUILTINS={'minecraft:builtin/generated','minecraft:builtin/entity'}
def inherit(key,chain=()):
 if key in chain:raise ValueError('parent cycle '+str(chain+(key,)))
 if key in BUILTINS:
  builtins.append({'model':key,'chain':chain});return {}
 if key not in models:raise ValueError('missing model '+key)
 visited_models.add(key)
 data=models[key];result={}
 if data.get('parent'):
  parent=rid(data['parent']);edges.append(dict(kind='parent',source=key,target=parent));result=inherit(parent,chain+(key,))
 merged={**result,**data};merged['textures']={**result.get('textures',{}),**data.get('textures',{})}
 return merged
def check_model(key,root,chain=()):
 try:data=inherit(key)
 except ValueError as e:errors.append(dict(root=root,model=key,error=str(e)));return
 bindings=data.get('textures',{})
 def texture(value,seen=()):
  if not isinstance(value,str):raise ValueError('non-string texture')
  if value.startswith('#'):
   var=value[1:]
   if var in seen or var not in bindings:raise ValueError('unbound/cyclic texture '+value)
   return texture(bindings[var],seen+(var,))
  target=rid(value);edges.append(dict(kind='texture',source=key,target=target,root=root))
  if target in ('minecraft:missingno','minecraft:missing'):placeholders.append(dict(root=root,model=key,texture=target));return
  if target not in textures:raise ValueError('missing texture '+target)
  if textures[target][:8]!=b'\x89PNG\r\n\x1a\n':raise ValueError('bad PNG '+target)
 references=list(bindings.values())
 for element in data.get('elements',[]):references.extend(face.get('texture') for face in element.get('faces',{}).values())
 for value in references:
  try:texture(value)
  except ValueError as e:errors.append(dict(root=root,model=key,error=str(e)))
 for override in data.get('overrides',[]):
  target=rid(override['model']);edges.append(dict(kind='override',source=key,target=target))
  if target in chain:errors.append(dict(root=root,model=key,error='override cycle '+target))
  else:check_model(target,root,chain+(key,))
def state_models(value):
 if isinstance(value,dict):
  if 'model' in value:yield rid(value['model'])
  for child in value.values():yield from state_models(child)
 elif isinstance(value,list):
  for child in value:yield from state_models(child)

for key in sorted(items):
 model=key.split(':')[0]+':item/'+key.split(':')[1];before=len(errors);check_model(model,key)
 root_results.append(dict(kind='item',id=key,model=model,registration=items[key],errors=errors[before:]))
for key in sorted(blocks):
 before=len(errors)
 if key not in states:errors.append(dict(root=key,error='missing blockstate'))
 else:
  for model in state_models(states[key][1]):check_model(model,key)
 root_results.append(dict(kind='block',id=key,registration=blocks[key],blockstate=states.get(key,(None,None))[0],errors=errors[before:]))

programmatic=[];unclassified_asset_literals=[]
for path in paths:
 if not path.startswith('src/main/java/') or not path.endswith('.java'):continue
 # Keep Java source reads separate from the asset cache: text search is bounded inventory,
 # not execution of arbitrary dynamic Identifier construction.
 text=blob(path).decode()
 seen=set()
 patterns=[(r'Identifier\.ofVanilla\(\s*"(textures/[^"+]+\.png)"\s*\)',lambda m:'minecraft'),
           (r'Identifier\.of\(\s*("[a-z0-9_.-]+"|[\w.]+MOD_ID)\s*,\s*"(textures/[^"+]+\.png)"\s*\)',lambda m:m[1].strip('"') if m[1].startswith('"') else 'drmd')]
 for pattern,namespace in patterns:
  for m in re.finditer(pattern,text):
   ref=m[1] if 'ofVanilla' in pattern else m[2];ns=namespace(m);asset='assets/'+ns+'/'+ref
   line=text[:m.start()].count('\n')+1;seen.add(ref)
   if asset in vanilla_entries or PREFIX+asset in paths:status='present-packaged-file'
   elif asset=='assets/minecraft/textures/atlas/blocks.png':status='runtime-generated-block-atlas'
   else:status='MISSING_LITERAL_RESOURCE';errors.append(dict(root=path,line=line,error='missing direct-render texture '+ns+':'+ref))
   programmatic.append(dict(path=path,line=line,text=text.splitlines()[line-1],namespace=ns,resource=ref,status=status))
 for m in re.finditer(r'"(textures/[^"\n]*|models/[^"\n]*|[^"\n]+\.(?:obj|gltf|glb|mesh|d6m))"',text):
  if m[1] not in seen:unclassified_asset_literals.append(dict(path=path,line=text[:m.start()].count('\n')+1,value=m[1],reason='Dynamic/non-Identifier literal; requires manual call-path review, not automatically missing'))

data_consumers=[]
for path in paths:
 if not path.startswith('src/main/resources/data/drmd/') or not path.endswith('.json'):continue
 data=json.loads(blob(path))
 def walk(value,trail=()):
  if isinstance(value,dict):
   if value.get('type')=='minecraft:item' and isinstance(value.get('name'),str):yield value['name'],trail+('name',),'loot-item'
   if isinstance(value.get('item'),str):yield value['item'],trail+('item',),'item-reference'
   if '/recipe/' in path and isinstance(value.get('result'),dict):
    result=value['result'];target=result.get('id',result.get('item'))
    if isinstance(target,str):yield target,trail+('result',),'recipe-result'
   for key,child in value.items():yield from walk(child,trail+(key,))
  elif isinstance(value,list):
   for n,child in enumerate(value):yield from walk(child,trail+(n,))
 for target,trail,kind in walk(data):
  if not target.startswith('drmd:'):continue
  exists=target in items
  data_consumers.append(dict(path=path,json_path=list(trail),kind=kind,item=target,registered_in_source=exists))
  if not exists:errors.append(dict(root=path,error='data consumer references unregistered item '+target))

pngs=[]
for path in paths:
 if not path.startswith(PREFIX+'assets/drmd/') or not path.endswith('.png'):continue
 raw=blob(path)
 try:
  with Image.open(io.BytesIO(raw)) as image:shape=image.size;mode=image.mode;image.verify()
  status='decoded-and-verified'
 except Exception as error:status='invalid';errors.append(dict(root=path,error='PNG decode/integrity '+str(error)));shape=None;mode=None
 pngs.append(dict(path=path,sha256=sha(raw),bytes=len(raw),dimensions=shape,mode=mode,status=status))

shared={}
for row in root_results:
 if row['kind']!='item':continue
 data=inherit(row['model'])
 # Shared generated-icon endpoint is a semantic review candidate, not file absence.
 parent=row['model'];ancestry=set()
 while parent in models and parent not in ancestry:
  ancestry.add(parent);parent=rid(models[parent].get('parent',''))
 if parent=='minecraft:builtin/generated':
  token=json.dumps(data.get('textures',{}),sort_keys=True)
  shared.setdefault(token,[]).append(row['id'])
shared_icons=[dict(items=group,bindings=json.loads(key),classification='resolved shared icon; intent/distinctness requires review, not missing resource') for key,group in shared.items() if len(group)>1]
result=dict(scope='Static registered literal/helper root graph, real vanilla resource jar; programmatic source adapters and runtime appearance require separate review',revision=REV,
 minecraft_jar=dict(path=str(MC),sha256=sha(MC.read_bytes()),bytes=MC.stat().st_size),
 item_count=len(items),block_count=len(blocks),model_count=len(models),texture_count=len(textures),roots=root_results,
 errors=errors,builtin_parent_edges=builtins,known_placeholder_edges=placeholders,edges=edges,
 programmatic_texture_edges=programmatic,unclassified_asset_literals=unclassified_asset_literals,
 data_item_consumers=data_consumers,png_integrity=pngs,shared_generated_icons=shared_icons,
 generated_atlas_definition=dict(path='assets/minecraft/atlases/blocks.json',sha256=sha(vanilla_atlas),content=json.loads(vanilla_atlas)),
 unreferenced_model_candidates=[dict(model=key,path=sources['model '+key],status='Not reached from these registry/blockstate/override roots; not proof of unused source or deletion safety') for key in sorted(models) if key.startswith('drmd:') and key not in visited_models],
 bound_source_or_resource_files={p:sha(raw) for p,raw in cache.items()},java_run=False)
(OUT/'registered-graph.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ['revision','item_count','block_count','model_count','texture_count','errors','known_placeholder_edges']},indent=2))
