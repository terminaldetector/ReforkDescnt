"""Read cached named vanilla class metadata/call sites only; no JVM or decompiler execution."""
import hashlib,json,struct,zipfile
from pathlib import Path


def read_class(data):
    pos=0
    def read(n):
        nonlocal pos
        out=data[pos:pos+n];assert len(out)==n;pos+=n;return out
    def u1():return read(1)[0]
    def u2():return int.from_bytes(read(2),'big')
    def u4():return int.from_bytes(read(4),'big')
    assert read(4)==b'\xca\xfe\xba\xbe';minor=u2();major=u2();count=u2();cp=[None]*count;i=1
    while i<count:
        tag=u1()
        if tag==1:cp[i]=(tag,read(u2()).decode('utf-8',errors='replace'))
        elif tag in [3,4]:cp[i]=(tag,read(4))
        elif tag in [5,6]:cp[i]=(tag,read(8));i+=1
        elif tag in [7,8,16,19,20]:cp[i]=(tag,u2())
        elif tag in [9,10,11,12,17,18]:cp[i]=(tag,u2(),u2())
        elif tag==15:cp[i]=(tag,u1(),u2())
        else:raise ValueError(tag)
        i+=1
    def utf(index):return cp[index][1]
    def ref(index):
        item=cp[index]
        if item[0]==8:return {'string':utf(item[1])}
        if item[0] in [9,10,11]:
            cls=cp[item[1]][1];name,desc=cp[item[2]][1:]
            return {'owner':utf(cls),'name':utf(name),'descriptor':utf(desc)}
        return None
    access=u2();this=u2();parent=u2();interfaces=[u2() for _ in range(u2())]
    def attrs():
        return [(utf(u2()),read(u4())) for _ in range(u2())]
    for _ in range(u2()):read(6);attrs()
    methods=[]
    for _ in range(u2()):
        flags=u2();name=utf(u2());desc=utf(u2());attributes=attrs()
        code=next((a[1] for a in attributes if a[0]=='Code'),None)
        if code is not None:code=code[8:8+int.from_bytes(code[4:8],'big')]
        methods.append((name,desc,code))
    attrs();assert pos==len(data)
    return methods,ref


def instructions(code):
    i=0
    two=set([0x10,0x12,*range(0x15,0x1a),*range(0x36,0x3b),0xa9,0xbc])
    three=set([0x11,0x13,0x14,0x84,*range(0x99,0xa9),*range(0xb2,0xb9),0xbb,0xbd,0xc0,0xc1,0xc6,0xc7])
    while i<len(code):
        op=code[i];size=2 if op in two else 3 if op in three else 4 if op==0xc5 else 5 if op in [0xb9,0xba,0xc8,0xc9] else 1
        if op in [0xaa,0xab]:
            start=i+1+(4-(i+1)%4)%4
            if op==0xaa:
                low,high=struct.unpack('>ii',code[start+4:start+12]);size=start+12+4*(high-low+1)-i
            else:size=start+8+8*int.from_bytes(code[start+4:start+8],'big')-i
        elif op==0xc4:size=6 if code[i+1]==0x84 else 4
        assert size>0 and i+size<=len(code)
        yield i,op,code[i+1:i+size]
        i+=size
    assert i==len(code)


if __name__=='__main__':
    jar=Path('/workspace/ungravity-v5/ufo-body-physics/.gradle/loom-cache/minecraftMaven/net/minecraft/minecraft-merged-20af7074aa/1.21.1-net.fabricmc.yarn.1_21_1.1.21.1+build.3-v2/minecraft-merged-20af7074aa-1.21.1-net.fabricmc.yarn.1_21_1.1.21.1+build.3-v2.jar')
    wanted={'net/minecraft/world/chunk/WorldChunk':['loadBlockEntity','getBlockEntity','getPackedBlockEntityNbt','removeBlockEntity','setBlockState'],
            'net/minecraft/world/chunk/ProtoChunk':['removeBlockEntity','setBlockState'],
            'net/minecraft/world/ChunkRegion':['setBlockState'],
            'net/minecraft/world/chunk/Chunk':['addPendingBlockEntityNbt','getBlockEntityNbt']}
    result={}
    with zipfile.ZipFile(jar) as z:
        for cls,names in wanted.items():
            raw=z.read(cls+'.class');methods,ref=read_class(raw);rows=[]
            for name,desc,code in methods:
                if name not in names or code is None:continue
                calls=[]
                for at,op,operand in instructions(code):
                    if op in [0x12,0x13,*range(0xb2,0xba)]:
                        index=operand[0] if op==0x12 else int.from_bytes(operand[:2],'big');value=ref(index)
                        if value is not None:calls.append(dict(offset=at,opcode=hex(op),**value))
                rows.append(dict(method=name,descriptor=desc,call_sites_and_string_constants=calls))
            result[cls]=dict(class_sha256=hashlib.sha256(raw).hexdigest(),methods=rows)
    print(json.dumps(dict(scope='Cached vanilla named class metadata only; no runtime BCC transformation/branch execution or producer reproduction is inferred',jar=str(jar),classes=result),indent=2))
