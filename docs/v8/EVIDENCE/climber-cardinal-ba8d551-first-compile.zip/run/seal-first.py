from pathlib import Path
import subprocess,json,hashlib,zipfile
root=Path.cwd();out=root/'work/climber-cardinal-force-20261117';source='ba8d551225cd951865ef9ed8bf4365a9e473aeb7'
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==source
assert not subprocess.check_output(['git','diff','HEAD','--','src'],text=True)
assert not(root/'build/gametest/world').exists()
files={}
def add(p,name=None):
 p=Path(p);name=name or str(p.relative_to(root));assert p.is_file(),p;assert name not in files;files[name]=p
for name in subprocess.check_output(['git','diff','--name-only','952286a',source,'--','src'],text=True).splitlines():add(root/name)
for name in ['src/gametest/java/com/terminaldetector/drmd/ClimberFieldGravityGameTests.java','src/gametest/resources/fabric.mod.json','build.gradle','settings.gradle','gradle.properties']:add(root/name)
for p in out.glob('first*'):
 if p.is_file():add(p,'run/'+p.name)
for name in ['focus.init.gradle','executing-focus.init.gradle','CONTRACT.md','source-receipt.json','seal-first.py']:add(out/name,'run/'+name)
for p in out.glob('TEST-*.xml'):add(p,'run/'+p.name)
for p in (root/'build/classes/java/test/com/terminaldetector/drmd').glob('LocalSurfaceMotionTest*.class'):add(p)
for directory,patterns in [('build/classes/java/main/com/terminaldetector/drmd/world/gravity',['LocalSurfaceMotion*','LocalSurfaceGeometry*','LocalSurfaceNavigation*']),('build/classes/java/main/com/terminaldetector/drmd/mixin',['LocalSurfaceTravelMixin*','LocalSurfacePounceMixin*'])]:
 for pattern in patterns:
  for p in (root/directory).glob(pattern+'.class'):add(p)
for name in ['src/main/resources/drmd.mixins.json','build/resources/main/drmd.mixins.json','build/resources/main/fabric.mod.json']:
 if name not in files:add(root/name)
patch=subprocess.check_output(['git','diff','952286a',source,'--','src']);(out/'source-first.patch').write_bytes(patch);add(out/'source-first.patch','run/source-first.patch')
rows=[{'path':n,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}for n,p in sorted(files.items())]
archive=root/'docs/v8/EVIDENCE/climber-cardinal-ba8d551-first-compile.zip';assert not archive.exists()
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for n,p in sorted(files.items()):z.write(p,n)
 z.writestr('MANIFEST.json',json.dumps({'source':source,'worldFiles':0,'payloads':rows,'classification':'10mathPASS; compileGametestJava fixture overload FAIL; 0GT, no native/mixin/gameplay'},indent=2)+'\n')
with zipfile.ZipFile(archive)as z:
 assert z.testzip()is None
 for r in rows:assert hashlib.sha256(z.read(r['path'])).hexdigest()==r['sha256']
receipt={'source':source,'archive':str(archive.relative_to(root)),'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'bytes':archive.stat().st_size,'payloadFiles':len(rows),'worldFiles':0,'allSha256AndZipCrcVerified':True,'units':10,'unitFailures':0,'gameTestsRun':0,'installableJarGenerated':False,'classification':'fixture-only constructor mismatch before any GameTest/native/mixin execution'}
(out/'first-archive.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
