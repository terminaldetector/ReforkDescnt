"""Seal the actual 1013/513 run, first compile failure, and both same-JAR clients."""
from pathlib import Path
import hashlib, json, subprocess, tarfile, xml.etree.ElementTree as ET, zipfile

ROOT=Path('/workspace/ungravity-v5/ufo-body-physics')
SOURCE='0107bd85e028b8aa0c035206848caf63f6c78632'
BASE='65370f7266cea705ebf2f9e86217031370fa2a3d'
RUN=ROOT/'work/multi-agent/integrated-0107bd8'
OLD=ROOT/'work/multi-agent/integrated-65370f7'
ARCHIVE=ROOT/'docs/v8/EVIDENCE/integrated-0107bd8.zip'
sha=lambda b:hashlib.sha256(b).hexdigest()
assert not ARCHIVE.exists()
counts=json.loads((RUN/'counts.json').read_text())
assert counts=={k:dict(tests=n,failures=0,errors=0,skipped=0)for k,n in [('unit',1013),('game',513)]}
pair=json.loads((RUN/'native-pair-first/receipt.json').read_text())
stamp=json.loads((RUN/'verified-build.json').read_text())
assert pair['gatePassed'] and pair['source']==pair['endSource']==stamp['sourceSha']==SOURCE
assert pair['jarsUnchanged'] and pair['helpersUnchanged'] and pair['jars']==stamp['jars']
assert all(x['gatePassed'] and x['javaExit']==x['helperExit']==0 for x in pair['results'])
manifest=json.loads((RUN/'processed-full-manifest.json').read_text())['entrypoints']['fabric-gametest']
oldmanifest=json.loads((OLD/'processed-full-manifest.json').read_text())['entrypoints']['fabric-gametest']
assert len(manifest)==len(set(manifest))==87 and manifest[:84]==oldmanifest
assert not any('DiagnosticGameTests' in n for n in manifest)

def cases(data):
    return [(x.get('classname'),x.get('name'))for x in ET.fromstring(data).iter('testcase')]

def units(path):
    with tarfile.open(path)as archive:
        return [case for m in archive.getmembers()if m.isfile() and m.name.endswith('.xml')for case in cases(archive.extractfile(m).read())]

delta={}
for kind,before,after,added in [('unit',units(OLD/'unit-results.tar.gz'),units(RUN/'unit-results.tar.gz'),15),
                              ('game',cases((OLD/'full-game-results.xml').read_bytes()),cases((RUN/'full-game-results.xml').read_bytes()),11)]:
    assert len(before)==len(set(before)) and len(after)==len(set(after))
    assert set(before)<=set(after) and len(set(after)-set(before))==added
    delta[kind]={'before':len(before),'after':len(after),'removed':[],'added':sorted(set(after)-set(before))}
(RUN/'exact-test-case-delta.json').write_text(json.dumps(delta,indent=2)+'\n')

payload={}
def add(path,name=None):
    p=Path(path);assert p.is_file()and not p.is_symlink()
    n=name or p.relative_to(ROOT).as_posix();assert not n.startswith('/')and'..'not in Path(n).parts
    b=p.read_bytes();assert n not in payload or payload[n]==b;payload[n]=b

for p in sorted(RUN.rglob('*')):
    if p.is_file():add(p)
for dirname in ['integrated-f0aff15']:
    for p in sorted((ROOT/'work/multi-agent'/dirname).rglob('*')):
        if p.is_file():add(p)
for name in ['integrated-f0aff15-FIRST-COMPILE-NONPASS.json','integrated-f0aff15-preflight.json',
             'integrated-f0aff15-outer.log','integrated-f0aff15-outer.exit','integrated-0107bd8-preflight.json',
             'integrated-0107bd8-outer.log','integrated-0107bd8-outer.exit','run-integrated-full-1013.sh',
             'run-integrated-native-pair.py','preserve-current-full-world.py','collect-0107bd8.py','u07-root-import-6fa96cf.json']:
    add(ROOT/'work/multi-agent'/name)
world_receipt=ROOT/'work/ufo-body/integrated-0107bd8-preserved.json';add(world_receipt)
world=json.loads(world_receipt.read_text())
assert world['rawWorldReclaimed']and world['fullZIPCRCAndEverySHA256']
assert sha(Path(world['archive']).read_bytes())==world['archiveSHA256']
rows=[]
changed=subprocess.check_output(['git','diff','--name-only',BASE,SOURCE,'--','src/main','src/test','src/gametest','src/cubiccheck'],cwd=ROOT,text=True).splitlines()
assert len(changed)==36
for n in changed:
    b=subprocess.check_output(['git','show',SOURCE+':'+n],cwd=ROOT)
    assert(ROOT/n).read_bytes()==b;payload['source/'+n]=b
    old=subprocess.run(['git','show',BASE+':'+n],cwd=ROOT,stdout=subprocess.PIPE,stderr=subprocess.DEVNULL)
    rows.append({'path':n,'oldSHA256':sha(old.stdout)if old.returncode==0 else None,'newSHA256':sha(b)})
payload['SOURCE-DELTA.json']=(json.dumps(rows,indent=2)+'\n').encode()
for result in pair['results']:
    runtime=Path(result['runtime'])
    for n in ['inputs.json','launch.json','options.txt','logs/latest.log','actual-negative-fixture-inputs.json',
              'surface-arrival-outcome.json','presentation-ok.json','ps1-color-ok.json']:
        if(runtime/n).is_file():add(runtime/n)
    for directory in ['surface-arrival-frames','surface-arrival-packets','presentation-frames','ps1-color-reference','viewmodel-proof']:
        for p in sorted((runtime/directory).rglob('*')):
            if p.is_file():add(p)
    for rel,expected in stamp['jars'].items():assert sha((runtime/'mods'/Path(rel).name).read_bytes())==expected
header={'schema':'ungravity.current-full-and-native-evidence.v1','source':SOURCE,'base':BASE,'counts':counts,
        'entries':87,'jars':stamp['jars'],'sameJarNativePair':True,'changedSourcePaths':len(rows),
        'oldTestsRemoved':0,'addedUnits':15,'addedGames':11,'exactCaseDelta':delta,
        'externalComponentNativeNotRelabelled':True,'worldArchive':world['archive'],
        'worldArchiveSHA256':world['archiveSHA256'],'firstCompileFailureIncluded':True,
        'files':{n:{'bytes':len(b),'sha256':sha(b)}for n,b in sorted(payload.items())}}
with zipfile.ZipFile(ARCHIVE,'x',zipfile.ZIP_DEFLATED,compresslevel=6)as z:
    for n,b in sorted(payload.items()):z.writestr(n,b)
    z.writestr('MANIFEST.json',json.dumps(header,indent=2)+'\n')
with zipfile.ZipFile(ARCHIVE)as z:
    assert z.testzip()is None and set(z.namelist())==set(payload)|{'MANIFEST.json'}
    for n,e in header['files'].items():
        b=z.read(n);assert len(b)==e['bytes']and sha(b)==e['sha256']
receipt={'source':SOURCE,'archive':ARCHIVE.relative_to(ROOT).as_posix(),'bytes':ARCHIVE.stat().st_size,
         'sha256':sha(ARCHIVE.read_bytes()),'payloads':len(payload),'allCRCAndSHA256':True,
         'units':1013,'games':513,'entries':87,'sameJarClients':2,'frames':40,'sourcePaths':36,
         'actualNewUnitCases':15,'actualNewGameCases':11,'removedOldCases':0,
         'fullSpecAccepted':False,'wholePacketsAccepted':0}
(ROOT/'docs/v8/EVIDENCE/integrated-0107bd8.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
