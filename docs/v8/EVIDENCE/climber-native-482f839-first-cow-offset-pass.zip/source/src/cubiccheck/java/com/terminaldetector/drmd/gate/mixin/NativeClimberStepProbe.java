package com.terminaldetector.drmd.gate.mixin;

import com.terminaldetector.drmd.climber.ClimberStepTrace;
import net.minecraft.entity.*;
import net.minecraft.util.math.*;
import net.minecraft.util.shape.VoxelShape;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.*;
import java.util.List;

@Mixin(Entity.class)
public abstract class NativeClimberStepProbe {
    @Inject(method="move",at=@At("HEAD"))
    private void before(MovementType type,Vec3d requested,CallbackInfo ci){if(ClimberStepTrace.ENABLED)ClimberStepTrace.beginMove((Entity)(Object)this,type,requested);}
    @Inject(method="move",at=@At("RETURN"))
    private void after(MovementType type,Vec3d requested,CallbackInfo ci){if(ClimberStepTrace.ENABLED)ClimberStepTrace.endMove((Entity)(Object)this);}
    @Inject(method="adjustMovementForCollisions(Lnet/minecraft/util/math/Vec3d;)Lnet/minecraft/util/math/Vec3d;",at=@At("HEAD"))
    private void adjust(Vec3d requested,CallbackInfoReturnable<Vec3d> cir){if(ClimberStepTrace.ENABLED)ClimberStepTrace.adjustBegin((Entity)(Object)this,requested);}
    @Inject(method="adjustMovementForCollisions(Lnet/minecraft/util/math/Vec3d;)Lnet/minecraft/util/math/Vec3d;",at=@At(value="RETURN",ordinal=0))
    private void selectedStep(Vec3d requested,CallbackInfoReturnable<Vec3d> cir){if(ClimberStepTrace.ENABLED)ClimberStepTrace.adjustEnd((Entity)(Object)this,cir.getReturnValue(),true);}
    @Inject(method="adjustMovementForCollisions(Lnet/minecraft/util/math/Vec3d;)Lnet/minecraft/util/math/Vec3d;",at=@At(value="RETURN",ordinal=1))
    private void base(Vec3d requested,CallbackInfoReturnable<Vec3d> cir){if(ClimberStepTrace.ENABLED)ClimberStepTrace.adjustEnd((Entity)(Object)this,cir.getReturnValue(),false);}
    @Inject(method="adjustMovementForCollisions(Lnet/minecraft/util/math/Vec3d;Lnet/minecraft/util/math/Box;Ljava/util/List;)Lnet/minecraft/util/math/Vec3d;",at=@At("HEAD"))
    private static void candidate(Vec3d requested,Box box,List<VoxelShape> shapes,CallbackInfoReturnable<Vec3d> cir){if(ClimberStepTrace.ENABLED)ClimberStepTrace.candidateBegin(requested,box,shapes.size());}
    @Inject(method="adjustMovementForCollisions(Lnet/minecraft/util/math/Vec3d;Lnet/minecraft/util/math/Box;Ljava/util/List;)Lnet/minecraft/util/math/Vec3d;",at=@At("RETURN"))
    private static void candidateReturn(Vec3d requested,Box box,List<VoxelShape> shapes,CallbackInfoReturnable<Vec3d> cir){if(ClimberStepTrace.ENABLED)ClimberStepTrace.candidateEnd(cir.getReturnValue());}
}
