package com.terminaldetector.drmd.gate.mixin;

import com.terminaldetector.drmd.gate.NativeClimberSurfaceCheck;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.goal.PounceAtTargetGoal;
import net.minecraft.entity.mob.*;
import org.spongepowered.asm.mixin.*;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(PounceAtTargetGoal.class)
public abstract class NativeClimberPounceProbe {
    @Shadow @Final private MobEntity mob;
    @Shadow private LivingEntity target;
    @Shadow @Final private float velocity;
    @Inject(method="start",at=@At("HEAD"))
    private void before(CallbackInfo ci){if(NativeClimberSurfaceCheck.ENABLED&&mob instanceof SpiderEntity actor)NativeClimberSurfaceCheck.pounce(actor,target,velocity,true);}
    @Inject(method="start",at=@At("RETURN"))
    private void after(CallbackInfo ci){if(NativeClimberSurfaceCheck.ENABLED&&mob instanceof SpiderEntity actor)NativeClimberSurfaceCheck.pounce(actor,target,velocity,false);}
}
