package com.terminaldetector.drmd.gate;

import com.google.gson.Gson;
import com.terminaldetector.drmd.climber.*;
import com.terminaldetector.drmd.DescentPlayerData;
import com.terminaldetector.drmd.flight.FlightSystem;
import com.terminaldetector.drmd.world.access.CubicAvailability;
import com.terminaldetector.drmd.world.access.WorldAccess;
import com.terminaldetector.drmd.world.gravity.*;
import com.terminaldetector.drmd.d6.D6ChunkPos;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.ScreenshotRecorder;
import net.minecraft.entity.*;
import net.minecraft.entity.mob.SpiderEntity;
import net.minecraft.entity.passive.CowEntity;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.*;
import net.minecraft.world.*;
import org.joml.Matrix4f;
import org.joml.Vector3f;
import java.nio.file.*;
import java.security.MessageDigest;
import java.util.*;

/** Observer/stager only. The exact production JAR owns all frames, physics, native AI and movement. */
public final class NativeClimberSurfaceCheck {
    public static final boolean ENABLED=Boolean.getBoolean("drmd.gate.climberSurface");
    public static final String GAME="d4725ebb1524815dd4e6d8666bfa1b584c580b445c29eb2f163a11dc73a94306";
    private static final Gson JSON=new Gson();
    private static final Vec3d UP=new Vec3d(1,0,0);
    private static final BlockPos MIN=new BlockPos(88,2150,88),MAX=MIN.add(16,12,16),CENTRE=MIN.add(8,0,8);
    private static final Box ROOM=new Box(Vec3d.of(MIN),Vec3d.of(MAX.add(1,1,1)));
    private static final Box PLATE=new Box(MIN.getX()+1,MIN.getY()+5,CENTRE.getZ()-4,MAX.getX(),MIN.getY()+6,CENTRE.getZ()+5);
    private static final int ADMISSION=240,OBSERVE=120,MAX_AIR=40,TOTAL=600;
    private static final long WALL=120_000_000_000L;
    private enum Phase { VOLUMES,DARK,SETTLE,RUNNING,DONE,RETIRED,FAILED }
    private record View(Phase phase,long tick,List<Integer> ids,String failure){}
    private static final class Trial {
        final SpiderEntity actor;final CowEntity target;final Object navigation,control;
        final double eye;ClimberAirAcceptance.State trace;Vec3d baseline;double initialDistance;int baseAge,samples,maxPath,illegal,coarse;
        boolean nativePath,passage,crossed;
        Trial(SpiderEntity actor,CowEntity target){this.actor=actor;this.target=target;navigation=actor.getNavigation();control=actor.getMoveControl();eye=actor.getEyeHeight(EntityPose.STANDING);}
    }
    private static final List<Trial> TRIALS=new ArrayList<>(); // server owner thread only
    private static final List<Map<String,Object>> ADMISSIONS=new ArrayList<>(),OBSERVATIONS=new ArrayList<>();
    private static final ArrayDeque<Map<String,Object>> MODELS=new ArrayDeque<>(); // render thread only
    private static final Map<Integer,Integer> MODEL_COUNTS=new HashMap<>(),FINAL_COUNTS=new HashMap<>(),LAST_FRAME=new HashMap<>();
    private static volatile View view=new View(Phase.VOLUMES,0,List.of(),null);
    private static volatile UUID observer;
    private static volatile boolean retireRequested;
    private static volatile long joinedNanos;
    private static Phase phase=Phase.VOLUMES;
    private static long ticks;private static UUID field;private static boolean staged,finished;private static int frame,clientTicks;
    private static volatile String modelFailure;
    private static String observedBackend="UNOBSERVED";
    private static String observerMode="UNOBSERVED";
    private static int failureWait;
    private NativeClimberSurfaceCheck(){}
    public static void register(){
        if(!ENABLED)throw new IllegalStateException("climber observer requires its sole scenario flag");
        for(String name:System.getProperties().stringPropertyNames())
            if(name.startsWith("drmd.gate.")&&!name.equals("drmd.gate.climberSurface")&&Boolean.parseBoolean(System.getProperty(name)))
                throw new IllegalStateException("competing native scenario flag "+name);
        if(!FabricLoader.getInstance().isModLoaded("bettercubicchunks")||!FabricLoader.getInstance().isModLoaded("sodium"))
            throw new IllegalStateException("actual BCC and Sodium required");
        ServerTickEvents.END_SERVER_TICK.register(NativeClimberSurfaceCheck::serverTick);
        ClientTickEvents.END_CLIENT_TICK.register(NativeClimberSurfaceCheck::clientTick);
        WorldRenderEvents.END.register(context->rendered());
    }
    private static Path file(String name){return MinecraftClient.getInstance().runDirectory.toPath().resolve(name);}
    private static void require(boolean condition,String why){if(!condition)throw new IllegalStateException(why);}
    private static void write(String name,Object value){try{Files.writeString(file(name),JSON.toJson(value)+"\n");}catch(java.io.IOException e){throw new IllegalStateException(e);}}
    private static void publish(String failure){view=new View(phase,ticks,TRIALS.stream().map(t->t.actor.getId()).toList(),failure);}
    private static void serverTick(MinecraftServer server){
        if(observer==null||phase==Phase.RETIRED||phase==Phase.FAILED)return;
        var player=server.getPlayerManager().getPlayer(observer);if(player==null)return;
        var world=player.getServerWorld();
        try{
            require(server.isOnThread(),"OBSERVER: world owner thread");
            require(modelFailure==null,modelFailure==null?"":modelFailure);
            require(++ticks<=TOTAL&&System.nanoTime()-joinedNanos<=WALL,"WATCHDOG:600server ticks/120seconds after join");
            var backend=WorldAccess.of(world).backend();observedBackend=backend.name();
            require(backend==CubicAvailability.Backend.NATIVE_CUBIC,"ARTIFACT: actual native cubic backend");
            if(!staged){
                player.changeGameMode(GameMode.SPECTATOR);
                FlightSystem.disable(player,DescentPlayerData.get(player)); // Only the real observer player's one-time camera staging.
                player.teleport(world,MAX.getX()-2,MIN.getY()+9,CENTRE.getZ(),Set.of(),90,18);staged=true;
                observerMode=player.isSpectator()?"SPECTATOR":"OTHER";
                publish(null);return;
            }
            observerMode=player.isSpectator()?"SPECTATOR":"OTHER";
            require(player.isSpectator(),"FIXTURE_OBSERVER: spectator mode changed");
            if(phase==Phase.VOLUMES){
                boolean full=available(world,ROOM.expand(1));admission(Map.of("fixtureFull",full));
                require(ticks<ADMISSION||full,"PREFLIGHT_VOLUME: complete native fixture never FULL; movement UNOBSERVED");
                if(!full)return;
                for(var at:BlockPos.iterate(MIN,MAX)){
                    boolean shell=at.getX()==MIN.getX()||at.getX()==MAX.getX()||at.getY()==MIN.getY()||at.getY()==MAX.getY()||at.getZ()==MIN.getZ()||at.getZ()==MAX.getZ();
                    boolean plate=at.getY()==MIN.getY()+5&&at.getX()>MIN.getX()&&at.getX()<MAX.getX()&&at.getZ()>=CENTRE.getZ()-4&&at.getZ()<=CENTRE.getZ()+4;
                    world.setBlockState(at,(shell||plate?Blocks.OBSIDIAN:Blocks.AIR).getDefaultState(),2);
                }
                phase=Phase.DARK;publish(null);return;
            }
            if(phase==Phase.DARK){
                boolean full=available(world,ROOM.expand(1));boolean dark=full;var lights=new ArrayList<Map<String,Object>>();
                if(full)for(int i=0;i<2;i++)for(double y:new double[]{2.5,8.5}){
                    var at=BlockPos.ofFloored(new Vec3d(MIN.getX()+4+1.3,MIN.getY()+y,CENTRE.getZ()+(i==0?-2.5:2.5)));
                    int sky=world.getLightLevel(LightType.SKY,at),block=world.getLightLevel(LightType.BLOCK,at);dark&=sky==0&&block==0;
                    lights.add(Map.of("at",List.of(at.getX(),at.getY(),at.getZ()),"sky",sky,"block",block));
                }
                admission(Map.of("fixtureFull",full,"dark",dark,"actualLight",lights));
                require(ticks<ADMISSION||dark,"PREFLIGHT_LIGHT: native darkness missing; movement UNOBSERVED");
                if(!dark)return;spawn(world);phase=Phase.SETTLE;publish(null);return;
            }
            if(phase==Phase.SETTLE){
                boolean admitted=true;var states=new ArrayList<Map<String,Object>>();
                for(var t:TRIALS){
                    var support=ClimberAirAcceptance.support(world,t.actor,UP,t.eye);
                    boolean eligible=t.actor.isAlive()&&!t.actor.isRemoved()&&world.getEntityById(t.actor.getId())==t.actor
                        &&world.shouldTickEntity(t.actor.getBlockPos())&&t.actor.age>0&&!t.actor.isAiDisabled()&&!t.actor.hasNoGravity()
                        &&t.actor.getPose()==EntityPose.STANDING&&!t.actor.hasVehicle()&&t.actor.getNavigation()==t.navigation&&t.actor.getMoveControl()==t.control
                        &&!t.actor.isTouchingWater()&&!t.actor.isInLava()&&EntityGravitySystem.suppressesVanillaGravity(t.actor)
                        &&t.target.isAlive()&&!t.target.isRemoved()&&world.getEntityById(t.target.getId())==t.target
                        &&ActorFrames.up(t.actor).distanceTo(UP)<=1e-6&&support.valid()&&t.actor.isOnGround()&&ActorFrames.up(t.target).distanceTo(UP)<=1e-6
                        &&Math.abs(Vec3d.ofCenter(t.target.getBlockPos()).subtract(t.actor.getPos()).dotProduct(UP))<=1;
                    admitted&=eligible;var row=snapshot(t);row.put("support",support);row.put("eligible",eligible);states.add(row);
                }
                admission(Map.of("naturalSettled",admitted,"actualActors",states));
                require(ticks<ADMISSION||admitted,"PREFLIGHT_SETTLE: production frame/contact/AI admission missing; route UNOBSERVED");
                if(!admitted)return;
                for(var t:TRIALS){
                    t.baseline=t.actor.getPos();t.baseAge=t.actor.age;t.initialDistance=t.actor.getPos().distanceTo(t.target.getPos());
                    t.actor.setTarget(t.target); // The sole disclosed initial target assignment; no repeated AI command.
                    t.trace=ClimberAirAcceptance.arm(t.actor,t.target,UP,t.eye);ClimberStepTrace.arm(t.actor,PLATE);
                    ClimberAirAcceptance.emit(t.trace,t.actor,"ADMITTED",Map.of("wall",true,"barrier",true,"naturalProductionSettle",true,"seedOnce",0,
                        "actualInitialTargetDistance",t.initialDistance,"initialVelocityPreserved",ClimberAirAcceptance.vector(t.actor.getVelocity())));
                }
                phase=Phase.RUNNING;publish(null);return;
            }
            if(phase==Phase.RUNNING){
                boolean done=true;
                for(var t:TRIALS){
                    require(t.actor.isAlive()&&!t.actor.isRemoved()&&world.getEntityById(t.actor.getId())==t.actor&&world.shouldTickEntity(t.actor.getBlockPos()),"AI_OWNERSHIP: actual native actor lost");
                    require(t.actor.getTarget()==t.target&&t.actor.getNavigation()==t.navigation&&t.actor.getMoveControl()==t.control&&!t.actor.isAiDisabled()&&!t.actor.hasNoGravity(),"AI_OWNERSHIP: native identity/target/flags changed");
                    require(t.target.isAlive()&&!t.target.isRemoved()&&world.getEntityById(t.target.getId())==t.target,"AI_OWNERSHIP: actual fixture target lost");
                    if(t.samples<OBSERVE&&t.actor.age>t.trace.lastAge)observe(world,t);
                    if(t.samples<OBSERVE)done=false;
                }
                if(!done)return;
                for(var t:TRIALS){
                    require(t.nativePath&&t.maxPath>=1&&t.passage&&t.crossed&&t.trace.flightStart<0
                        &&t.actor.getY()-t.baseline.y>=1&&t.initialDistance-t.actor.getPos().distanceTo(t.target.getPos())>=1,"AI_ROUTE: native supported passage/crossing/progress incomplete");
                    require(t.trace.pounces==0||t.trace.completedArcs>0&&t.trace.resumedNativeAfterLanding,"NATIVE_AIR: no measured reacquisition/resumption");
                    ClimberStepTrace.finalEvidence(t.actor);
                }
                phase=Phase.DONE;serverReport(null);publish(null);return;
            }
            if(phase==Phase.DONE&&retireRequested){cleanup();phase=Phase.RETIRED;publish(null);}
        }catch(Throwable failure){phase=Phase.FAILED;serverReport(failure.toString());publish(failure.toString());cleanup();}
    }
    private static void spawn(ServerWorld world){
        field=UUID.randomUUID();GravityFields.put(new GravityFields.Field(field,world.getRegistryKey(),MIN.add(8,6,8),UP.negate(),32,1,FieldShape.SPHERE,"native climber natural settle"));
        EntityType<?>[] types={EntityType.SPIDER,EntityType.CAVE_SPIDER};
        for(int i=0;i<2;i++){
            var actor=(SpiderEntity)types[i].create(world);var target=EntityType.COW.create(world);require(actor!=null&&target!=null,"FIXTURE: registered native entities");
            actor.setPersistent();actor.getRandom().setSeed(0);actor.setPosition(MIN.getX()+4,MIN.getY()+2.5,CENTRE.getZ()+(i==0?-2.5:2.5));
            target.setPersistent();target.setAiDisabled(true);target.setNoGravity(true);target.setInvulnerable(true);
            target.setPosition(MIN.getX()+1.6,MIN.getY()+8.5,CENTRE.getZ()+(i==0?-2.5:2.5));
            TRIALS.add(new Trial(actor,target));require(world.spawnEntity(actor)&&world.spawnEntity(target),"FIXTURE: native world registration");
        }
    }
    private static void observe(ServerWorld world,Trial t){
        var actor=t.actor;var trace=t.trace;require(actor.age==trace.lastAge+1,"OBSERVER: missed ordinary entity tick");
        var support=ClimberAirAcceptance.support(world,actor,UP,t.eye);var box=actor.getBoundingBox();
        require(support.available()&&support.bodyClear()&&support.eyeError()<=1e-6&&support.upError()<=1e-6
            &&available(world,trace.previousBox.union(box).expand(1)),"CONTACT: FULL/body/eye/frame evidence lost");
        double step=actor.getPos().distanceTo(trace.previousPosition);trace.maximumStep=Math.max(trace.maximumStep,step);
        if(support.gap()!=null)trace.maximumGap=Math.max(trace.maximumGap,support.gap());
        require(step<=1,"COLLISION: actual per-age step exceeds1m");
        if(support.valid()){
            if(trace.flightStart>=0){require(actor.age-trace.flightStart<=MAX_AIR,"NATIVE_AIR: reacquisition exceeds40ticks");trace.maximumAirTicks=Math.max(trace.maximumAirTicks,actor.age-trace.flightStart);trace.completedArcs++;trace.flightStart=-1;trace.lastLandingAge=actor.age;}
            if(trace.lastLandingAge>=0&&actor.age>trace.lastLandingAge&&actor.getNavigation().getCurrentPath()!=null)trace.resumedNativeAfterLanding=true;
        }else{
            require(!actor.isOnGround(),"CONTACT: unsupported actor claims ground");
            if(trace.flightStart<0){require(trace.pounces>trace.consumedPounces&&actor.age-trace.lastPounceAge<=1,"CONTACT: support loss without fresh native pounce");trace.flightStart=trace.lastPounceAge;trace.consumedPounces=trace.pounces;}
            require(actor.age-trace.flightStart<=MAX_AIR,"NATIVE_AIR: unsupported beyond40ticks");
        }
        require(trace.impulseErrors==0,"NATIVE_AIR: local inherited impulse mismatch");
        var path=actor.getNavigation().getCurrentPath();if(path!=null){t.nativePath=true;t.maxPath=Math.max(t.maxPath,path.getCurrentNodeIndex());}
        var old=trace.previousBox;var expanded=PLATE.contract(1e-6).expand(Math.max(old.getLengthX(),box.getLengthX())/2,Math.max(old.getLengthY(),box.getLengthY())/2,Math.max(old.getLengthZ(),box.getLengthZ())/2);
        if(expanded.contains(old.getCenter())||expanded.contains(box.getCenter())||expanded.raycast(old.getCenter(),box.getCenter()).isPresent()){
            t.coarse++;if(!ClimberStepTrace.explainsSelectedStep(actor,old,box,PLATE))t.illegal++;
            if(t.illegal>0)ClimberStepTrace.beforeAssertion(actor,old,box,expanded,support,t.illegal);
            require(t.illegal==0,"COLLISION: unexplained whole-body plate sweep");
        }
        boolean band=box.maxY>PLATE.minY+1e-6&&box.minY<PLATE.maxY-1e-6;
        boolean passage=box.minZ>=MIN.getZ()+1-1e-6&&box.maxZ<=PLATE.minZ+1e-6||box.minZ>=PLATE.maxZ-1e-6&&box.maxZ<=MAX.getZ()+1e-6;
        t.passage|=band&&passage&&support.valid();t.crossed|=box.minY>=PLATE.maxY+1e-6;
        t.samples++;var row=snapshot(t);row.put("support",support);OBSERVATIONS.add(row);
        trace.lastAge=actor.age;trace.previousBox=box;trace.previousPosition=actor.getPos();ClimberStepTrace.observedBoundary(actor,box);
    }
    public static void pounce(SpiderEntity actor,LivingEntity target,float leap,boolean before){
        if(phase!=Phase.RUNNING||!(actor.getWorld()instanceof ServerWorld world)||!world.getServer().isOnThread())return;
        for(var t:TRIALS)if(t.actor==actor){ClimberAirAcceptance.pounce(actor,target,leap,before);return;}
    }
    private static void admission(Map<String,Object> data){
        var row=new LinkedHashMap<String,Object>();row.put("phase",phase.toString());row.put("tick",ticks);row.put("nanos",System.nanoTime());row.putAll(data);
        ADMISSIONS.add(row);if(ADMISSIONS.size()>16)ADMISSIONS.removeFirst();publish(null);
    }
    private static Map<String,Object> snapshot(Trial t){
        var actor=t.actor;var row=new LinkedHashMap<String,Object>();row.put("id",actor.getId());row.put("uuid",actor.getUuid().toString());row.put("type",actor.getType().toString());row.put("age",actor.age);
        row.put("worldTick",actor.getWorld().getTime());row.put("position",ClimberAirAcceptance.vector(actor.getPos()));row.put("velocity",ClimberAirAcceptance.vector(actor.getVelocity()));row.put("up",ClimberAirAcceptance.vector(ActorFrames.up(actor)));
        row.put("onGround",actor.isOnGround());row.put("aiDisabled",actor.isAiDisabled());row.put("noGravity",actor.hasNoGravity());row.put("samples",t.samples);row.put("nativePath",t.nativePath);row.put("maxPath",t.maxPath);
        row.put("navigationClass",actor.getNavigation().getClass().getName());row.put("navigationIdentity",System.identityHashCode(actor.getNavigation()));row.put("controlClass",actor.getMoveControl().getClass().getName());row.put("controlIdentity",System.identityHashCode(actor.getMoveControl()));row.put("productionGravityLease",EntityGravitySystem.suppressesVanillaGravity(actor));
        row.put("supportedPassage",t.passage);row.put("bodyCrossed",t.crossed);row.put("illegalSweeps",t.illegal);row.put("coarseChords",t.coarse);row.put("targetPosition",ClimberAirAcceptance.vector(t.target.getPos()));
        row.put("targetSetupFlags",Map.of("aiDisabled",t.target.isAiDisabled(),"noGravity",t.target.hasNoGravity(),"invulnerable",t.target.isInvulnerable()));
        row.put("nativeTargetBlockNormalDelta",Vec3d.ofCenter(t.target.getBlockPos()).subtract(actor.getPos()).dotProduct(UP));
        if(t.trace!=null){row.put("pounces",t.trace.pounces);row.put("closedArcs",t.trace.completedArcs);row.put("maxAirTicks",t.trace.maximumAirTicks);row.put("maximumGap",t.trace.maximumGap);row.put("maximumStep",t.trace.maximumStep);row.put("nativeAfterLanding",t.trace.resumedNativeAfterLanding);row.put("baseAge",t.baseAge);row.put("baseline",ClimberAirAcceptance.vector(t.baseline));row.put("initialTargetDistance",t.initialDistance);row.put("distanceImprovement",t.initialDistance-actor.getPos().distanceTo(t.target.getPos()));}return row;
    }
    private static boolean available(ServerWorld world,Box box){
        if(box.minY<world.getBottomY()||box.maxY>world.getTopY()||!world.getWorldBorder().contains(box))return false;
        int x0=MathHelper.floor(box.minX)>>4,x1=MathHelper.floor(box.maxX)>>4,y0=MathHelper.floor(box.minY)>>4,y1=MathHelper.floor(box.maxY)>>4,z0=MathHelper.floor(box.minZ)>>4,z1=MathHelper.floor(box.maxZ)>>4;
        if((long)(x1-x0+1)*(y1-y0+1)*(z1-z0+1)>64)return false;var access=WorldAccess.of(world);
        for(int x=x0;x<=x1;x++)for(int y=y0;y<=y1;y++)for(int z=z0;z<=z1;z++)if(!access.isVolumeAvailable(new D6ChunkPos(x,y,z)))return false;return true;
    }
    private static void serverReport(String failure){write("climber-native-server.json",Map.of("phase",phase.toString(),"tick",ticks,"failure",failure==null?"":failure,"observedBackend",observedBackend,"actualObserverMode",observerMode,"admissions",ADMISSIONS,"observations",OBSERVATIONS,"finalActors",TRIALS.stream().map(NativeClimberSurfaceCheck::snapshot).toList()));}
    private static void cleanup(){if(field!=null){GravityFields.remove(field);field=null;}for(var t:TRIALS){t.actor.discard();t.target.discard();}}
    private static void clientTick(MinecraftClient client){
        if(finished)return;
        if(client.currentScreen instanceof net.minecraft.client.gui.screen.world.BackupPromptScreen prompt)
            for(var child:prompt.children())if(child instanceof net.minecraft.client.gui.widget.ButtonWidget button&&button.getMessage().getString().equals("I know what I'm doing!"))button.onPress();
        if(observer==null){
            if(client.player==null||client.world==null||client.getServer()==null)return;
            require(client.runDirectory.getName().startsWith("climber-client-automation-"),"disposable climber runtime required");
            try{verifyRuntimeGame();}catch(Throwable failure){finishClient(client,false,"ARTIFACT: "+failure);return;}
            observer=client.player.getUuid();joinedNanos=System.nanoTime();client.setScreen(null);return;
        }
        clientTicks++;
        if(view.phase==Phase.FAILED){finishClient(client,false,view.failure);return;}
        if(System.nanoTime()-joinedNanos>WALL)modelFailure="CLIENT_WATCHDOG:120seconds after join";
        if(modelFailure!=null){if(++failureWait>30)finishClient(client,false,modelFailure+"; server acknowledgement UNOBSERVED");return;}
        if(view.phase==Phase.RETIRED)finishClient(client,true,null);
    }
    public static boolean observeModel(LivingEntity actor){return ENABLED&&!finished&&(view.phase==Phase.RUNNING||view.phase==Phase.DONE)&&view.ids.contains(actor.getId());}
    public static void model(LivingEntity actor,Matrix4f before,Matrix4f after,float yaw,float delta){
        if(!observeModel(actor))return;if(ActorFrames.up(actor).distanceTo(UP)>1e-6)return; // Await actual tracker sync, never set it.
        var expectedType=view.ids.indexOf(actor.getId())==0?EntityType.SPIDER:EntityType.CAVE_SPIDER;
        if(actor.getType()!=expectedType){modelFailure="CLIENT_SYNC: actual tracked entity type differs for "+actor.getId();return;}
        if(before==null){modelFailure="RENDER_BASIS: missing actual before matrix";return;}
        var relative=new Matrix4f(before).invert().mul(after);var up=relative.transformDirection(new Vector3f(0,1,0)).normalize();var forward=relative.transformDirection(new Vector3f(0,0,-1)).normalize();
        var expected=ActorFrameMath.toWorld(Vec3d.fromPolar(0,yaw),UP);
        boolean finite=Float.isFinite(up.x)&&Float.isFinite(up.y)&&Float.isFinite(up.z)&&Float.isFinite(forward.x)&&Float.isFinite(forward.y)&&Float.isFinite(forward.z);
        if(!finite||up.distance(new Vector3f(1,0,0))>.002||forward.distance(new Vector3f((float)expected.x,(float)expected.y,(float)expected.z))>.002
            ||actor.getEyePos().distanceTo(actor.getPos().add(UP.multiply(actor.getEyeHeight(EntityPose.STANDING))))>1e-6
            ||!actor.getBoundingBox().equals(ActorFrames.body(actor,actor.getPos(),UP))){modelFailure="RENDER_BASIS: actual model/eye/body differs for "+actor.getId();return;}
        if(LAST_FRAME.getOrDefault(actor.getId(),-1)==frame)return;LAST_FRAME.put(actor.getId(),frame);MODEL_COUNTS.merge(actor.getId(),1,Integer::sum);
        if(view.phase==Phase.DONE)FINAL_COUNTS.merge(actor.getId(),1,Integer::sum);
        var row=new LinkedHashMap<String,Object>();row.put("id",actor.getId());row.put("type",actor.getType().toString());row.put("frame",frame);row.put("serverPhase",view.phase.toString());row.put("yaw",yaw);row.put("up",List.of(up.x,up.y,up.z));row.put("forward",List.of(forward.x,forward.y,forward.z));
        float[] raw=new float[16];relative.get(raw);row.put("actualRelativeMatrix",raw);MODELS.addLast(row);while(MODELS.size()>16)MODELS.removeFirst();
    }
    private static void rendered(){
        frame++;if(finished||view.phase!=Phase.DONE||retireRequested||modelFailure!=null||view.ids.size()!=2||view.ids.stream().anyMatch(id->FINAL_COUNTS.getOrDefault(id,0)<3))return;
        var client=MinecraftClient.getInstance();
        try(var image=ScreenshotRecorder.takeScreenshot(client.getFramebuffer())){image.writeTo(file("climber-native.png"));write("climber-native-models.json",Map.of("actualRenderedFrame",frame,"counts",MODEL_COUNTS,"finalCounts",FINAL_COUNTS,"last16",List.copyOf(MODELS)));retireRequested=true;}
        catch(java.io.IOException error){modelFailure="OBSERVER_SCREENSHOT: "+error;}
    }
    private static void finishClient(MinecraftClient client,boolean pass,String failure){
        if(finished)return;finished=true;var row=new LinkedHashMap<String,Object>();row.put("status",pass?"PASS":"FAIL");row.put("gameSHA256",GAME);row.put("failure",failure);row.put("lastServerView",view);row.put("clientTicks",clientTicks);row.put("renderedFrames",frame);row.put("modelCounts",MODEL_COUNTS);row.put("finalModelCounts",FINAL_COUNTS);
        row.put("oldFourFailuresRemainOpen",true);row.put("whole3DAIAndBoardingOpen",true);row.put("naturalProductionSettle",true);write("climber-native-result.json",row);client.scheduleStop();
    }
    private static void verifyRuntimeGame()throws Exception{
        var paths=FabricLoader.getInstance().getModContainer("drmd").orElseThrow().getOrigin().getPaths();
        require(paths.size()==1&&Files.isRegularFile(paths.getFirst()),"standalone actual production JAR origin required");
        String actual;try(var input=Files.newInputStream(paths.getFirst())){var digest=MessageDigest.getInstance("SHA-256");byte[] chunk=new byte[65536];int n;while((n=input.read(chunk))>=0)digest.update(chunk,0,n);actual=HexFormat.of().formatHex(digest.digest());}
        require(GAME.equals(actual),"actual game JAR differs: "+actual);
        write("climber-native-artifacts.json",Map.of("actualGameOrigin",paths.getFirst().toString(),"actualGameSHA256",actual,"bccLoaded",FabricLoader.getInstance().isModLoaded("bettercubicchunks"),"sodiumLoaded",FabricLoader.getInstance().isModLoaded("sodium")));
    }
}
