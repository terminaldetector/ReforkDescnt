from pathlib import Path
import subprocess, json, hashlib, zipfile, fcntl, shutil

root = Path.cwd()
out = root / 'work/climber-native/first-482f839'
runtime = root / 'build/climber-client-automation-climber-309-sodium-cow-offset-first'
world = runtime / 'saves/Cubic-Gate'
source = '482f839de026789bc151b7cf58894a5085091489'
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip() == source
assert not subprocess.check_output(['git', 'diff', 'HEAD', '--'])
assert world.is_dir()
lock = open(out / 'closed-world.lock', 'a')
fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)

def no_own_java():
    for proc in Path('/proc').glob('[0-9]*'):
        try:
            if (proc / 'comm').read_text().strip() not in ['java', 'javaw']:
                continue
            if '\nState:\tZ' in (proc / 'status').read_text():
                continue
            cwd = (proc / 'cwd').resolve()
            if cwd == root or root in cwd.parents:
                raise RuntimeError('own Java still active')
        except (FileNotFoundError, ProcessLookupError, PermissionError):
            pass

no_own_java()
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
inputs = json.loads((out / 'first-inputs.json').read_text())
for name, digest in inputs['sourceInputs'].items():
    assert sha(root / name) == digest, name
assert not subprocess.check_output(['git', 'diff', '3095999', 'HEAD', '--', 'src/main', 'src/client', 'src/test', 'build.gradle', 'settings.gradle'])
summary = json.loads((out / 'first-summary.json').read_text())
assert summary['buildExit'] == summary['nativeExit'] == summary['wrapperValidationExit'] == 0
assert summary['activeJavaAtClose'] == [] and summary['sourceAndHelpersUnchanged']
classes = {str(p.relative_to(root)): sha(p) for p in sorted((root / 'build/classes').rglob('*.class')) if p.is_file()}
(out / 'first-output-classes.json').write_text(json.dumps({'source': source, 'classes': classes}, indent=2) + '\n')
files = {}

def add(p, name):
    p = Path(p)
    assert p.is_file(), p
    assert name not in files, name
    files[name] = p

for p in out.rglob('*'):
    if p.is_file() and p.name not in ['closed-world.lock', 'first-archive.json']:
        add(p, 'run/' + str(p.relative_to(out)))
names = subprocess.check_output(['git', 'diff', '--name-only', '3095999', source, '--', 'src/cubiccheck', 'scripts/v8/climber_native*'], text=True).splitlines()
for name in names:
    add(root / name, 'source/' + name)
for p in (runtime / 'mods').glob('*.jar'):
    add(p, 'runtime/mods/' + p.name)
for name in ['inputs.json', 'launch.json', 'options.txt', 'climber-native-result.json', 'climber-native-server.json', 'climber-native-artifacts.json', 'climber-native-models.json', 'climber-native.png']:
    add(runtime / name, 'runtime/' + name)
for folder in ['config', 'logs', 'crash-reports']:
    for p in (runtime / folder).rglob('*'):
        if p.is_file():
            add(p, 'runtime/' + str(p.relative_to(runtime)))
world_rows = []
for p in sorted(world.rglob('*')):
    if p.is_file():
        name = str(p.relative_to(world))
        add(p, 'world/' + name)
        world_rows.append({'path': name, 'bytes': p.stat().st_size, 'sha256': sha(p)})
(out / 'world-inventory.json').write_text(json.dumps(world_rows, indent=2) + '\n')
add(out / 'world-inventory.json', 'run/world-inventory.json')
rows = [{'path': name, 'bytes': p.stat().st_size, 'sha256': sha(p)} for name, p in sorted(files.items())]
archive = root / 'docs/v8/EVIDENCE/climber-native-482f839-first-cow-offset-pass.zip'
assert not archive.exists()
with zipfile.ZipFile(archive, 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for name, p in sorted(files.items()):
        z.write(p, name)
    z.writestr('MANIFEST.json', json.dumps({'source': source, 'payloads': rows,
        'worldFiles': len(world_rows), 'worldBytes': sum(row['bytes'] for row in world_rows),
        'classification': 'FIRST_BUILD0; actual native0/validator0 scoped static+X two-species nativeAI/contact/pounce/model-basis PASS; old4/whole3DAI/boarding OPEN',
        'immutableLibrariesAndMinecraftCache': 'full hashes/references retained in staged inputs; not duplicated or removed'}, indent=2) + '\n')
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for row in rows:
        assert hashlib.sha256(z.read(row['path'])).hexdigest() == row['sha256']
assert sorted(str(p.relative_to(world)) for p in world.rglob('*') if p.is_file()) == sorted(row['path'] for row in world_rows)
for row in world_rows:
    assert sha(world / row['path']) == row['sha256']
no_own_java()
shutil.rmtree(world)
receipt = {'source': source, 'archive': str(archive.relative_to(root)), 'sha256': sha(archive), 'bytes': archive.stat().st_size,
    'payloads': len(rows), 'worldFiles': len(world_rows), 'worldBytes': sum(row['bytes'] for row in world_rows),
    'allSHA256AndZipCRCVerified': True, 'exclusiveLock': str(out / 'closed-world.lock'), 'closedOwnWorldReclaimed': True,
    'buildExit': 0, 'nativeExit': 0, 'validatorExit': 0, 'routeSamples': 240, 'screenshotFinalModelFrames': {'30': 3, '32': 3},
    'newWorldOrCacheOrJarDependencyElsewhereRemoved': False}
(out / 'first-archive.json').write_text(json.dumps(receipt, indent=2) + '\n')
fcntl.flock(lock, fcntl.LOCK_UN)
lock.close()
print(json.dumps(receipt, indent=2))
