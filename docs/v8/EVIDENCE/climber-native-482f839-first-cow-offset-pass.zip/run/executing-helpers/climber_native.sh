#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/../.."
scenario="$1"
[[ "$scenario" =~ ^climber-[a-z0-9-]+$ ]]
runtime="build/climber-client-automation-${scenario}"
mkdir -p work/climber-native
python3 scripts/v8/climber_native_build_stamp.py check
test ! -e "$runtime"
CLIMBER_NATIVE_SCENARIO="$scenario" python3 scripts/v8/climber_native_prepare.py --server-runtime /workspace/ungravity-v5/world/build/cubic-seed2-gate --runtime "$runtime" --drmd /workspace/ungravity-v5/ufo-body-physics/work/multi-agent/integrated-3095999/artifacts/drmd-6dof-1.1.35-ufo-dev.1.jar --gate build/libs/drmd-6dof-1.1.35-ufo-dev.1-cubiccheck.jar --bcc /workspace/Refork-audit/work/master-v5/upstream/bettercubicchunks-fabric-0.1.1+mc1.21.1.jar --api /workspace/.gradle/caches/modules-2/files-2.1/net.fabricmc.fabric-api/fabric-api/0.116.15+1.21.1/d25c793833a90cc028c9a61bc4546cd578a70ce1/fabric-api-0.116.15+1.21.1.jar --java /workspace/jdk21-complete/bin/java --copy-test-world --sodium /workspace/ungravity-v5/world/work/gate0/upstream/sodium-fabric-0.8.13+mc1.21.1.jar > "work/climber-native/${scenario}-prepare.log"
display_file="work/climber-native/${scenario}-display.txt"
: > "$display_file"
/workspace/xvfb/usr/bin/Xvfb -displayfd 3 -screen 0 1280x1024x24 3> "$display_file" > "work/climber-native/${scenario}-xvfb.log" 2>&1 &
display_pid=$!
trap 'kill "$display_pid" 2>/dev/null || true; wait "$display_pid" 2>/dev/null || true' EXIT
for attempt in {1..100}; do kill -0 "$display_pid"; if [ -s "$display_file" ]; then break; fi; sleep .1; done
test -s "$display_file"
read -r display_number < "$display_file"
set +e
DISPLAY=:$display_number LIBGL_ALWAYS_SOFTWARE=1 MESA_GL_VERSION_OVERRIDE=3.3 MESA_GLSL_VERSION_OVERRIDE=330 timeout --kill-after=15 --foreground 360 python3 -c 'import os,json,sys; from pathlib import Path; p=Path(sys.argv[1]).resolve(); a=json.loads((p/"launch.json").read_text()); os.chdir(p);os.execv(a[0],a)' "$runtime" < /dev/null > "work/climber-native/${scenario}.log" 2>&1
climber_native_exit=$?
set -e
printf '%s\n' "$climber_native_exit" > "work/climber-native/${scenario}.native.exit"
if [ "$climber_native_exit" -ne 0 ]; then exit "$climber_native_exit"; fi
python3 - "$runtime" <<'PY'
from pathlib import Path
import json,sys
p=Path(sys.argv[1]);result=json.loads((p/'climber-native-result.json').read_text());server=json.loads((p/'climber-native-server.json').read_text());artifacts=json.loads((p/'climber-native-artifacts.json').read_text())
assert result['status']=='PASS'and artifacts['actualGameSHA256']=='d4725ebb1524815dd4e6d8666bfa1b584c580b445c29eb2f163a11dc73a94306'
assert server['phase']=='DONE'and server['observedBackend']=='NATIVE_CUBIC'and len(server['finalActors'])==2
assert server['actualObserverMode']=='SPECTATOR'
assert all(a['samples']==120 and a['supportedPassage']and a['bodyCrossed']and a['illegalSweeps']==0 for a in server['finalActors'])
assert len(result['finalModelCounts'])==2 and all(n>=3 for n in result['finalModelCounts'].values())
assert(p/'climber-native.png').is_file()and not list((p/'crash-reports').glob('*.txt'))
print('Native actual BCC/Sodium climber scoped PASS; old4/whole3DAI/boarding remain OPEN')
PY
