"""Adapt the existing official native stager; reuse only verified immutable libraries/MC remap cache."""
from pathlib import Path
import importlib.util,json,os,sys,zipfile

ROOT=Path(__file__).resolve().parents[2]
official=ROOT/'scripts/v5/prepare_cubic_client.py'
libraries=Path('/workspace/ungravity-v5/boarding-attachment/build/cubic-client-final-body-scale-volumes-final-gl32/libraries')
donor=Path('/workspace/ungravity-v5/ufo-body-physics/build/cubic-client-final-flight-body-current-phase-sodium')
spec=importlib.util.spec_from_file_location('official_climber_stager',official);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
original=module.verified_copy
def copy(source,target,sha1=None):
    parts=target.parts
    if 'libraries'in parts:
        prior=libraries.joinpath(*parts[parts.index('libraries')+1:])
        if prior.is_file()and module.digest(prior)==module.digest(source)and(not sha1 or module.digest(prior,'sha1')==sha1):
            target.parent.mkdir(parents=True,exist_ok=True);os.link(prior,target);return target
    return original(source,target,sha1)
module.verified_copy=copy;module.main()
runtime=Path(sys.argv[sys.argv.index('--runtime')+1]).resolve();stamp=json.loads((ROOT/'work/climber-native/verified-build.json').read_text())
manifest=json.loads((runtime/'inputs.json').read_text())
for path,digest in [(Path(stamp['game']['path']),stamp['game']['sha256']),(ROOT/stamp['observer']['path'],stamp['observer']['sha256'])]:
    staged=runtime/'mods'/path.name;assert module.digest(staged)==digest
    assert next(a['sha256']for a in manifest['artifacts']if a['path']==str(staged.relative_to(runtime)))==digest
mc='libraries/com/mojang/minecraft/1.21.1/minecraft-1.21.1-client.jar';old=json.loads((donor/'inputs.json').read_text())
assert next(a['sha256']for a in manifest['artifacts']if a['path']==mc)==next(a['sha256']for a in old['artifacts']if a['path']==mc)
assert module.digest(runtime/mc)==module.digest(donor/mc)
derived=donor/'.fabric/remappedJars/minecraft-1.21.1-0.19.5/client-intermediary.jar';target=runtime/derived.relative_to(donor)
with zipfile.ZipFile(derived)as z:assert z.testzip()is None and not any(n.startswith('com/terminaldetector/')for n in z.namelist())
target.parent.mkdir(parents=True,exist_ok=True);os.link(derived,target)
launch=runtime/'launch.json';args=json.loads(launch.read_text());assert not any(a.startswith('-Ddrmd.gate.')for a in args)
args.insert(1,'-Ddrmd.gate.climberSurface=true');launch.write_text(json.dumps(args,indent=2)+'\n')
java=Path(sys.argv[sys.argv.index('--java')+1])
manifest.update(observerSource=stamp['observerSource'],productionBase=stamp['productionBase'],game=stamp['game'],observer=stamp['observer'],scenario=os.environ['CLIMBER_NATIVE_SCENARIO'],officialStagerSHA256=module.digest(official),java={'path':str(java),'executableSHA256':module.digest(java),'releaseSHA256':module.digest(java.parent.parent/'release')},derivedMinecraftOnly={'source':str(derived),'sha256':module.digest(derived),'noGameClassesOrSaveBorrowed':True},scope='STAGED_NOT_RUN')
(runtime/'inputs.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('Staged exact309 production + observer only, actual BCC/Sodium, immutable verified MC/library caches')
