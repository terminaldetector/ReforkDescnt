#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/../.."
python3 scripts/v8/climber_native_build_stamp.py before
JAVA_HOME=/workspace/jdk21-complete PATH=/workspace/jdk21-complete/bin:$PATH GRADLE_USER_HOME=/workspace/.gradle ./gradlew remapCubiccheckJar --offline --no-daemon -I scripts/v8/climber_native_observer.init.gradle
python3 scripts/v8/climber_native_build_stamp.py record
