"""Bind observer inputs to exact309 production; never certify a stale/foreign game or a runtime pass."""
from pathlib import Path
import hashlib,json,subprocess,sys,zipfile

ROOT=Path(__file__).resolve().parents[2]
BASE='30959990c104543a78940a3baecf95ee4f73517d'
GAME=Path('/workspace/ungravity-v5/ufo-body-physics/work/multi-agent/integrated-3095999/artifacts/drmd-6dof-1.1.35-ufo-dev.1.jar')
GAME_SHA='d4725ebb1524815dd4e6d8666bfa1b584c580b445c29eb2f163a11dc73a94306'
OBSERVER=ROOT/'build/libs/drmd-6dof-1.1.35-ufo-dev.1-cubiccheck.jar'
STAMP=ROOT/'work/climber-native/verified-build.json'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def inputs():
    paths=[*(ROOT/'src/cubiccheck').rglob('*'),*(ROOT/'scripts/v8').glob('climber_native*'),*(ROOT/'gradle').rglob('*'),ROOT/'gradlew',ROOT/'scripts/v5/prepare_cubic_client.py',ROOT/'build.gradle',ROOT/'settings.gradle',ROOT/'gradle.properties']
    return {str(p.relative_to(ROOT)):sha(p)for p in sorted(paths)if p.is_file()}
def source():
    assert not subprocess.check_output(['git','status','--porcelain','--','src/cubiccheck','scripts/v8/climber_native*','scripts/v5/prepare_cubic_client.py','gradle','gradlew','build.gradle','settings.gradle','gradle.properties'],cwd=ROOT),'Freeze all observer/helper inputs before building'
    assert not subprocess.check_output(['git','diff',BASE,'HEAD','--','src/main','src/client','build.gradle','settings.gradle','gradle.properties'],cwd=ROOT),'Production must remain exact309'
    assert not subprocess.check_output(['git','diff','HEAD','--','src/main','src/client'],cwd=ROOT),'Dirty production source'
    return subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
def game():
    assert sha(GAME)==GAME_SHA,'Exact saved309 game changed or unavailable'
    with zipfile.ZipFile(GAME)as z:
        assert z.testzip()is None and 'com/terminaldetector/drmd/world/gravity/LocalSurfaceFollowDecision.class'in z.namelist()
        mix=json.loads(z.read('drmd.mixins.json'))['mixins'];assert mix.count('NativeDeferredFluidMixin')==1
    return {'path':str(GAME),'sha256':GAME_SHA}
def observer():
    with zipfile.ZipFile(OBSERVER)as z:
        assert z.testzip()is None
        m=json.loads(z.read('fabric.mod.json'));assert set(m['entrypoints'])=={'client'}
        assert m['entrypoints']['client']==['com.terminaldetector.drmd.gate.CubicClientGate']
        assert m['mixins']==['drmd.climber_native.mixins.json']
        assert 'com/terminaldetector/drmd/gate/NativeClimberSurfaceCheck.class'in z.namelist()
        assert not any(n.startswith(('com/terminaldetector/drmd/world/','com/terminaldetector/drmd/entity/','com/terminaldetector/drmd/mixin/'))or n=='com/terminaldetector/drmd/DescentMod.class'for n in z.namelist()),'Observer contains replacement production classes'
    return {'path':str(OBSERVER.relative_to(ROOT)),'sha256':sha(OBSERVER)}
STAMP.parent.mkdir(parents=True,exist_ok=True)
mode=sys.argv[1]
if mode=='before':
    STAMP.with_suffix('.inputs.json').write_text(json.dumps({'observerSource':source(),'inputs':inputs(),'productionBase':BASE,'game':game()},indent=2)+'\n')
elif mode=='record':
    saved=json.loads(STAMP.with_suffix('.inputs.json').read_text());assert saved['observerSource']==source()and saved['inputs']==inputs()and saved['game']==game(),'Inputs changed during build'
    saved['observer']=observer();saved['scope']='BUILD_ONLY_NOT_NATIVE_PASS';STAMP.write_text(json.dumps(saved,indent=2)+'\n')
elif mode=='check':
    saved=json.loads(STAMP.read_text());source()
    assert saved['inputs']==inputs()and saved['game']==game()and saved['observer']==observer(),'Rebuild changed observer inputs/artifacts'
    print('Exact309 production and frozen observer build verified',saved['observerSource'])
else:raise ValueError('before/record/check required')
