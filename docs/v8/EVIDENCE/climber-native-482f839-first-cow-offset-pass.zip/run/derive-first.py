from pathlib import Path
import json, math

out = Path(__file__).resolve().parent
server = json.loads((out / 'climber-native-server.json').read_text())
models = json.loads((out / 'climber-native-models.json').read_text())
result = json.loads((out / 'climber-native-result.json').read_text())
log = (out / 'climber-309-sodium-cow-offset-first.log').read_text()
events = []
for line in log.splitlines():
    for label in ('CLIMBER_AIR_ACCEPTANCE', 'CLIMBER_STEP_ASSESSMENT'):
        marker = label + ' '
        if marker in line:
            events.append({'label': label, 'event': json.loads(line.split(marker, 1)[1])})

actors = []
for final in server['finalActors']:
    uid = final['uuid']
    rows = [row for row in server['observations'] if row['uuid'] == uid]
    admission = [row for event in server['admissions'] for row in event.get('actualActors', []) if row['uuid'] == uid]
    air = [e['event'] for e in events if e['label'] == 'CLIMBER_AIR_ACCEPTANCE' and e['event'].get('uuid') == uid]
    pounces = [event for event in air if event['phase'] == 'NATIVE_POUNCE_AFTER']
    assert len(rows) == 120
    assert all(row['age'] == final['baseAge'] + i + 1 for i, row in enumerate(rows))
    assert all(row['support']['available'] and row['support']['bodyClear'] and row['support']['eyeError'] <= 1e-6 and row['support']['upError'] <= 1e-6 for row in rows)
    assert all(row['navigationIdentity'] == final['navigationIdentity'] and row['controlIdentity'] == final['controlIdentity'] for row in rows)
    assert all(not row['aiDisabled'] and not row['noGravity'] and row['productionGravityLease'] for row in rows)
    assert all(event['impulseErrors'] == 0 and math.dist(event['actualVelocity'], event['expectedLocalImpulse']) <= 1e-6 for event in pounces)
    supported = [row for row in rows if row['support']['hit'] and row['support'].get('gap') is not None and -1e-6 <= row['support']['gap'] <= .08 and row['support']['normal'] >= .95]
    actors.append({'final': final, 'actualAgeRange': [rows[0]['age'], rows[-1]['age']],
        'actualWorldTimeRange': [rows[0]['worldTick'], rows[-1]['worldTick']], 'consecutiveActualAges': True,
        'all120AvailableBodyClearEyeAndUpWithin1e6': True, 'nativeControllerNavigationIdentitiesStable': True,
        'nativeAIAndGravityPolicyOwnedByProduction': True, 'supportedSamples': len(supported),
        'unsupportedSamples': len(rows) - len(supported), 'unsupportedClaimsGround': sum(row['onGround'] for row in rows if row not in supported),
        'firstSupportedPassageAge': next(row['age'] for row in rows if row['supportedPassage']),
        'firstWholeBodyCrossedAge': next(row['age'] for row in rows if row['bodyCrossed']),
        'naturalAdmission': {'firstRetained': admission[0], 'lastRetained': admission[-1]},
        'actualNativePounceAfters': pounces})

basis = []
for entity_id in result['finalModelCounts']:
    rows = [row for row in models['last16'] if str(row['id']) == entity_id]
    up_error = max(math.dist(row['up'], [1, 0, 0]) for row in rows)
    # Pinned ActorFrameMath: local right maps to -worldY for localUp=+X.
    forward_error = max(math.dist(row['forward'], [0, math.sin(math.radians(row['yaw'])), math.cos(math.radians(row['yaw']))]) for row in rows)
    assert up_error <= .002 and forward_error <= .002
    basis.append({'id': int(entity_id), 'retainedMatrixRows': len(rows), 'retainedFrameRange': [rows[0]['frame'], rows[-1]['frame']],
        'upErrorMax': up_error, 'forwardErrorMax': forward_error, 'finalFramesAtScreenshot': models['finalCounts'][entity_id],
        'finalFramesAtClientClose': result['finalModelCounts'][entity_id]})

analysis = {'source': '482f839de026789bc151b7cf58894a5085091489', 'scope': 'offline derivation of sealed actual first run; no new game queries',
    'classification': 'FIRST_BUILD0; actual native0/validator0; static +X two native Spider species route/contact/native pounce and actual model-basis PASS; old4/whole3DAI/boarding OPEN',
    'serverTickAtDone': server['tick'], 'serverRetiredTick': result['lastServerView']['tick'], 'admissionTicks': [row['tick'] for row in server['admissions']],
    'actors': actors, 'events': events, 'modelBasis': basis,
    'screenshotLimit': 'Actual PNG manually inspected: extremely dark native night fixture. Matrix/tracked type/body/eye evidence passes; no broad texture/animation/visual-quality acceptance.',
    'targetLifecycle': 'Only initial target X changed92->89.6 before spawn. Production field moves actual NoAI/NoGravity Cow to89.046656 before admission. No observer postspawn target movement/velocity/pose command.',
    'unobserved': ['actual field sample/source/vector/strength DTO (declared source +Xup/strength1/radius32 separately retained)',
        'private native cube-index revision metadata', 'raw native RNG outcomes', 'oblique/moving support and multiplayer/cold reload',
        'all prior four failing cases; none rerun by this first native tuple'],
    'oldFourFailuresRemainOpen': True, 'whole3DAIAndBoardingOpen': True}
(out / 'first-analysis.json').write_text(json.dumps(analysis, indent=2) + '\n')
print(json.dumps({'actors': [{key: actor[key] for key in ('actualAgeRange', 'consecutiveActualAges', 'supportedSamples', 'unsupportedSamples', 'unsupportedClaimsGround', 'firstSupportedPassageAge', 'firstWholeBodyCrossedAge')} for actor in actors], 'modelBasis': basis, 'events': len(events)}, indent=2))
