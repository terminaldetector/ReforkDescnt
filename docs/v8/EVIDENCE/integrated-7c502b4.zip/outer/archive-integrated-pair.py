"""Preserve an exact completed full-suite and same-JAR native pair, without rebuilding."""
from pathlib import Path
import hashlib
import json
import re
import struct
import sys
import tarfile
import xml.etree.ElementTree as ET
import zipfile
import zlib

root = Path('/workspace/ungravity-v5/ufo-body-physics')
source, run, expected_units, expected_games = sys.argv[1:]
assert re.fullmatch('[0-9a-f]{40}', source)
assert re.fullmatch('[a-z0-9-]+', run)
base = root / 'work/multi-agent' / run
out = root / 'docs/v8/EVIDENCE' / (run + '.zip')
assert not out.exists()
sha = lambda data: hashlib.sha256(data).hexdigest()
stamp = json.loads((base / 'verified-build.json').read_text())
pair = json.loads((base / 'native-pair-first/receipt.json').read_text())
counts = json.loads((base / 'counts.json').read_text())
assert stamp['sourceSha'] == pair['source'] == pair['endSource'] == source
assert stamp['jars'] == pair['jars']
assert pair['gatePassed'] and pair['jarsUnchanged'] and pair['helpersUnchanged']
assert counts == {
    'unit': dict(tests=int(expected_units), failures=0, errors=0, skipped=0),
    'game': dict(tests=int(expected_games), failures=0, errors=0, skipped=0),
}
with tarfile.open(base / 'unit-results.tar.gz') as tar:
    units = [case for m in tar.getmembers() if m.name.endswith('.xml')
             for case in ET.fromstring(tar.extractfile(m).read()).iter('testcase')]
games = list(ET.parse(base / 'full-game-results.xml').getroot().iter('testcase'))
for cases, count in [(units, int(expected_units)), (games, int(expected_games))]:
    assert len(cases) == count
    assert all(all(c.find(tag) is None for tag in ('failure', 'error', 'skipped')) for c in cases)
assert (base / 'full-regressions.exit').read_text().strip() == '0'
assert (root / 'work/multi-agent' / (run + '-outer.exit')).read_text().strip() == '0'
for name, digest in stamp['jars'].items():
    assert sha((root / name).read_bytes()) == digest
    assert sha((base / 'artifacts' / Path(name).name).read_bytes()) == digest

payload = {}
def add(path, name):
    assert name not in payload, name
    payload[name] = path.read_bytes()

def validate_png(data):
    assert data[:8] == b'\x89PNG\r\n\x1a\n'
    at, compressed, dimensions = 8, bytearray(), None
    while at < len(data):
        length = struct.unpack('>I', data[at:at + 4])[0]
        kind, body = data[at + 4:at + 8], data[at + 8:at + 8 + length]
        crc = struct.unpack('>I', data[at + 8 + length:at + 12 + length])[0]
        assert zlib.crc32(kind + body) & 0xffffffff == crc
        if kind == b'IHDR':
            dimensions = struct.unpack('>II', body[:8])
        if kind == b'IDAT':
            compressed.extend(body)
        at += 12 + length
    assert at == len(data) and dimensions in ((1280, 720), (960, 540), (640, 360), (320, 180))
    assert zlib.decompress(compressed)

for path in sorted(base.rglob('*')):
    rel = path.relative_to(base)
    if path.is_file() and rel.parts[0] != 'artifacts':
        add(path, 'run/' + str(rel))
for path in sorted((root / 'work/multi-agent').glob(run + '-*')):
    if path.is_file():
        add(path, 'outer/' + path.name)
add(Path(__file__), 'outer/archive-integrated-pair.py')

for result in pair['results']:
    assert result['helperExit'] == result['javaExit'] == 0 and result['gatePassed']
    runtime = Path(result['runtime'])
    kind, scenario = result['kind'], result['scenario']
    inputs = json.loads((runtime / 'inputs.json').read_text())
    assert inputs['sourceSha'] == source and inputs['candidateJars'] == stamp['jars']
    for name, digest in stamp['jars'].items():
        assert sha((runtime / 'mods' / Path(name).name).read_bytes()) == digest
    files = ['inputs.json', 'launch.json', 'options.txt', 'usercache.json', 'logs/latest.log']
    if kind == 'arrival':
        files += ['actual-negative-fixture-inputs.json', 'surface-arrival-outcome.json']
        folders = ['surface-arrival-frames', 'surface-arrival-packets']
        # The closed native cache is part of this exact observation, not a fixture replacement.
        add(runtime / 'saves/Cubic-Gate/drmd/surface/L0/0_0.bin', kind + '/disk/L0_0_0.bin')
    else:
        files += ['presentation-ok.json', 'ps1-color-ok.json']
        folders = ['presentation-frames', 'viewmodel-proof', 'ps1-color-reference']
    for name in files:
        path = runtime / name
        if path.is_file():
            add(path, kind + '/' + name)
    for folder in folders:
        for path in sorted((runtime / folder).rglob('*')):
            if path.is_file():
                add(path, kind + '/' + str(path.relative_to(runtime)))
    launcher = root / ('work/cubic-arrival' if kind == 'arrival' else 'work/ps1')
    for suffix in ('.log', '.exit', '-prepare.log', '-xvfb.log'):
        add(launcher / (scenario + suffix), kind + '/launcher/' + scenario + suffix)

frames = [n for n in payload if n.endswith('.png')]
depth = [n for n in payload if n.endswith('.f32')]
assert len(frames) == 40 and len(depth) == 10, (len(frames), len(depth))
for name in frames:
    validate_png(payload[name])
manifest = {name: dict(bytes=len(data), sha256=sha(data)) for name, data in sorted(payload.items())}
with zipfile.ZipFile(out, 'x', zipfile.ZIP_DEFLATED) as archive:
    for name, data in sorted(payload.items()):
        archive.writestr(name, data)
    archive.writestr('SHA256-MANIFEST.json', json.dumps(manifest, indent=2) + '\n')
with zipfile.ZipFile(out) as archive:
    assert archive.testzip() is None
    for name, entry in manifest.items():
        data = archive.read(name)
        assert len(data) == entry['bytes'] and sha(data) == entry['sha256']

receipt = dict(source=source, archiveSHA256=sha(out.read_bytes()), archiveBytes=out.stat().st_size,
               payloadFiles=len(payload), pngFiles=len(frames), depthArrays=len(depth), counts=counts,
               entrypoints=len(json.loads((base / 'processed-full-manifest.json').read_text())['entrypoints']['fabric-gametest']),
               jars=stamp['jars'], nativePair=pair, releaseAccepted=False, fullSpecificationAccepted=False)
out.with_suffix('.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({k: receipt[k] for k in ('source', 'archiveSHA256', 'archiveBytes', 'payloadFiles', 'pngFiles', 'depthArrays')}))
