#!/usr/bin/env bash
set -euo pipefail
cd /workspace/ungravity-v5/ufo-body-physics
run="$1"
expected_source="$2"
expected_units="$3"
expected_games="$4"
[[ "$run" =~ ^[a-z0-9-]+$ ]]
test "$(git rev-parse HEAD)" = "$expected_source"
test -z "$(git status --porcelain --untracked-files=no)"
test ! -e "work/multi-agent/$run"
test ! -e "work/multi-agent/$run-outer.exit"
trap 'code=$?; echo "$code" > "work/multi-agent/$run-outer.exit"' EXIT
cp "$0" "work/multi-agent/$run-outer-executed.sh"
cp work/multi-agent/run-full.sh "work/multi-agent/$run-full-executed.sh"
chmod a-w "work/multi-agent/$run-outer-executed.sh" "work/multi-agent/$run-full-executed.sh"
# Bind BOTH presentation and original-world arrival launchers to this one build.
# The full runner owns its own independent before/build/record sequence for PS1.
python3 scripts/v8/cubic_arrival_build_stamp.py before
cp work/cubic-arrival/verified-build.inputs.json "work/multi-agent/$run-arrival-inputs-before.json"
bash "work/multi-agent/$run-full-executed.sh" "$run" "$expected_source" "$expected_units" "$expected_games"
python3 scripts/v8/cubic_arrival_build_stamp.py record
python3 scripts/v8/cubic_arrival_build_stamp.py check
cp work/cubic-arrival/verified-build.json "work/multi-agent/$run/arrival-verified-build.json"
python3 - "$run" <<'PY'
import json,sys
from pathlib import Path
r=Path('work/multi-agent')/sys.argv[1]
p=json.loads((r/'verified-build.json').read_text())
a=json.loads((r/'arrival-verified-build.json').read_text())
assert p['sourceSha']==a['sourceSha'] and p['jars']==a['jars']
print('Both native protocols bound to the SAME fully tested source/JARs:',p['sourceSha'])
PY
test "$(git rev-parse HEAD)" = "$expected_source"
test -z "$(git status --porcelain --untracked-files=no)"
