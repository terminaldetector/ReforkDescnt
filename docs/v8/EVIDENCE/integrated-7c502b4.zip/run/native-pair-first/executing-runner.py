#!/usr/bin/env python3
"""One fresh arrival and one presentation client, sequentially on the final tested JARs."""
import hashlib,json,os,re,shutil,subprocess,sys,time
from pathlib import Path

root=Path('/workspace/ungravity-v5/ufo-body-physics');os.chdir(root)
source,run=sys.argv[1:]
assert re.fullmatch('[0-9a-f]{40}',source) and re.fullmatch('[a-z0-9-]+',run)
head=lambda:subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert head()==source and not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'])
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
base=root/'work/multi-agent'/run;out=base/'native-pair-first';out.mkdir(exist_ok=False)
p=json.loads((base/'verified-build.json').read_text());a=json.loads((base/'arrival-verified-build.json').read_text())
assert p['sourceSha']==a['sourceSha']==source and p['jars']==a['jars']
assert all(sha(root/f)==v for f,v in p['jars'].items())
helpers=['scripts/v8/ps1_native.sh','scripts/v8/ps1_prepare.py','scripts/v8/ps1_build_stamp.py','scripts/v8/cubic_arrival_native.sh','scripts/v8/cubic_arrival_prepare.py','scripts/v8/cubic_arrival_build_stamp.py','scripts/v5/prepare_cubic_client.py']
before={f:sha(root/f) for f in helpers}
for f in helpers:
 dest=out/'helpers'/f;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(root/f,dest)
shutil.copyfile(__file__,out/'executing-runner.py')
(out/'before.json').write_text(json.dumps({'source':source,'startNs':time.time_ns(),'helperHashes':before,'jars':p['jars']},indent=2)+'\n')
results=[]
for kind,script,scenario,prefix,automation,names in [
 ('arrival','scripts/v8/cubic_arrival_native.sh',f'cubic-surface-arrival-integrated-{source[:7]}-sodium','cubic-surface-arrival','cubic-surface-arrival-automation',['inputs.json','launch.json','surface-arrival-outcome.json']),
 ('presentation','scripts/v8/ps1_native.sh',f'ps1-color-integrated-{source[:7]}-sodium','cubic-client','cubic-client-automation',['inputs.json','launch.json','presentation-ok.json','ps1-color-ok.json','viewmodel-proof/viewmodel-visibility.json'])]:
 assert head()==source and all(sha(root/f)==v for f,v in p['jars'].items()) and all(sha(root/f)==v for f,v in before.items())
 stage=out/kind;stage.mkdir()
 cmd=['bash',script,scenario];(stage/'launch.json').write_text(json.dumps({'command':cmd,'startNs':time.time_ns()})+'\n')
 print('START',kind,scenario,flush=True)
 with (stage/'helper.log').open('xb') as log:child=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
 (stage/'child.exit').write_text(str(child.returncode)+'\n')
 (stage/'early-close.json').write_text(json.dumps({'childExit':child.returncode,'endNs':time.time_ns()})+'\n')
 runtime=root/f'build/{prefix}-final-{scenario}'
 if not runtime.is_dir():runtime=root/f'build/{automation}'
 copied=[]
 for name in names:
  src=runtime/name
  if src.is_file():
   dest=stage/'observed'/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dest);copied.append(name)
 javaExit=root/('work/cubic-arrival' if kind=='arrival' else 'work/ps1')/(scenario+'.exit')
 result={'kind':kind,'scenario':scenario,'helperExit':child.returncode,'javaExit':int(javaExit.read_text()) if javaExit.is_file() else None,'runtime':str(runtime),'observed':copied,'pngCount':len(list(runtime.rglob('*.png'))),'gatePassed':child.returncode==0 and all(n in copied for n in names)}
 (stage/'receipt.json').write_text(json.dumps(result,indent=2)+'\n');results.append(result);print(json.dumps(result),flush=True)
receipt={'source':source,'endSource':head(),'jars':p['jars'],'jarsUnchanged':all(sha(root/f)==v for f,v in p['jars'].items()),'helpersUnchanged':all(sha(root/f)==v for f,v in before.items()),'results':results,'endNs':time.time_ns()}
receipt['gatePassed']=receipt['endSource']==source and receipt['jarsUnchanged'] and receipt['helpersUnchanged'] and all(r['gatePassed'] for r in results)
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');code=0 if receipt['gatePassed'] else 1
(out/'wrapper.exit').write_text(str(code)+'\n');print(json.dumps(receipt,indent=2),flush=True);sys.exit(code)
