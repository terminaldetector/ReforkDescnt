#!/usr/bin/env bash
set +e
cd /workspace/ungravity-v5/ps1-render
bash scripts/v8/ps1_build.sh
build_code=$?
cp work/ps1/verified-build.log work/sky-lod/first-build.log
echo "$build_code" > work/sky-lod/first-build.exit
if [ "$build_code" -ne 0 ]; then exit "$build_code"; fi
cp work/ps1/verified-build.json work/sky-lod/first-build.json
bash scripts/v8/ps1_native.sh ps1-sky-layers-negative-sodium
native_code=$?
echo "$native_code" > work/sky-lod/first-native.exit
exit "$native_code"
