# DRMD checkpoint report

- Source SHA: `8aeb5594d2c5bbb1616a47564fde58f36c910b5d`
- Version: `1.1.35-ufo-dev.1`
- Run: https://github.com/terminaldetector/ReforkDescnt/actions/runs/42207155405
- Target: Minecraft 1.21.1 / Fabric / Java 21

| Stage | Outcome |
|---|---|
| unit | success |
| gametest | success |
| build | success |
| rendercheck | skipped |
| shootcheck | failure |
| verify | skipped |

## Test reports

- unit: {'tests': 712, 'failures': 0, 'errors': 0, 'skipped': 0} (`build/test-results/test`); zero tests means NOT VERIFIED.
- gametest: {'tests': 280, 'failures': 0, 'errors': 0, 'skipped': 0} (`build/gametest/reports`); zero tests means NOT VERIFIED.

**NOT VERIFIED: no installable-mod artifact is certified by this run.**
See `logs/`, JUnit XML, GameTest logs and client crash reports for the first failure.

## Limits

- Historical 1.1.12 results in the supplied MHT are not results of this run.
- Manual playability smoke test: NOT RUN.
- Audit camera sweeps up to 628 m/s stress the renderer; these are not production player-speed claims.
- Swarm profiles use invulnerable controlled actors, capped client FPS and software graphics in GHA. Larger counts report actual limits, not a general 1000+ performance guarantee.
- Workshop Apply Build publishes construction/muzzles; Stats/Projectile/Flak/Guidance drafts are saved/exported, not runtime behavior overrides.
- Three hybrid samples: laser_pulse (impulse), plasma, gravy_railgun. Models tab in the existing Workshop; Creative + server operator for publishing.
- Local named presets: config/drmd/weapon-presets/*.nbt; authoritative layouts: world/data/drmd/visual/*.nbt.
- Source archives, reports and artifacts are retained by GHA for 90 days.
