from pathlib import Path
import hashlib,json,subprocess,zipfile,xml.etree.ElementTree as E,sys
subprocess.run(['python3','work/ufo-body/native/verify-build-stamp.py','check'],check=True)
source=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();files=set()
def add(p):
 p=Path(p);assert p.is_file(),p;files.add(p)
for n in subprocess.check_output(['git','diff','--name-only','7dc81c1',source],text=True).splitlines():
 if n.startswith('src/'):add(n)
for n in ['build.gradle','gradle.properties','src/gametest/resources/fabric.mod.json','build/resources/gametest/fabric.mod.json','build/gametest/reports/gametest-results.xml','work/ufo-body/native/verified-build.json','work/ufo-body/native/run-turret.sh','work/ufo-body/native/build-verified.sh','work/ufo-body/native/verify-build-stamp.py','work/ufo-body/native/prepare-with-verified-library-links.py','work/ufo-body/native/dedup-staged-libraries.py','work/ufo-body/native/seed-verified-minecraft-remap.py','scripts/v5/prepare_cubic_client.py','src/gametest/java/com/terminaldetector/drmd/AiFixtureChunks.java','work/ufo-body/turret-focused-46-passed-20261107.xml','work/ufo-body/weapon-focus.init.gradle','work/ufo-body/engine-final-force-test.init.gradle','work/ufo-body/collect-turret-evidence-20261107.py','work/ufo-body/TestContext-bytecode.txt','work/ufo-body/GameTestState-bytecode.txt','work/ufo-body/turret-full-regressions-20261107.sh','work/ufo-body/turret-source-series-20261107.patch','work/ufo-body/read-turret-failed-entities.py','work/ufo-body/turret-failed-saved-entities.json','work/ufo-body/turret-failed-late-entities.json','work/ufo-body/turret-failed-early-entities.json','work/ufo-body/preserve-old-world-access-gametest.py','work/ufo-body/preserve-old-physics-gametest.py','work/ufo-body/preserve-old-render-gametest.py','work/preserved-disposable-worlds/render-closed-gametest-turret-20261107.zip.json','work/preserved-disposable-worlds/world-access-closed-gametest-turret-20261107.zip.json','work/preserved-disposable-worlds/physics-closed-gametest-turret-20261107.zip.json']:add(n)
for glob in ['turret-*.log','turret-*.xml','turret-*-dump-*.txt','turret-first-repro-20261107.zip']:
 for p in Path('work/ufo-body').glob(glob):add(p)
for p in Path('build/test-results/test').glob('TEST-*.xml'):add(p)
stamp=json.loads(Path('work/ufo-body/native/verified-build.json').read_text())
for p,h in stamp['jars'].items():assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==h;add(p)
markers={};nativeSource=None
round=sys.argv[1] if len(sys.argv)>1 else 'final1'
for profile in ['gl32','sodium']:
 name='flight-body-control-turret-'+round+'-'+profile;r=Path('build/cubic-client-final-'+name)
 info=json.loads((r/'inputs.json').read_text());assert not info['uncommittedDiff']
 if nativeSource is None:nativeSource=info['sourceSha']
 assert nativeSource==info['sourceSha']
 delta=subprocess.check_output(['git','diff','--name-only',nativeSource,source],text=True).splitlines();assert all(p.startswith('src/gametest/') for p in delta),delta
 seenArtifacts=set()
 for a in info['artifacts']:
  if a.get('source') in stamp['jars']:
   seenArtifacts.add(a['source']);assert a['sha256']==stamp['jars'][a['source']]
   assert hashlib.sha256((r/a['path']).read_bytes()).hexdigest()==a['sha256']
 assert seenArtifacts==set(stamp['jars'])
 for suffix in ['.log','.exit','-prepare.log']:add('work/ufo-body/native/final-'+name+suffix)
 assert Path('work/ufo-body/native/final-'+name+'.exit').read_text().strip()=='0'
 for f in ['inputs.json','launch.json','ufo-control-ok.json']:add(r/f)
 m=json.loads((r/'ufo-control-ok.json').read_text())
 for k,n in [('turretAimPackets',8),('turretFirePackets',8),('turretLaserShots',3),('turretRocketShots',1),('turretSamples',24),('brakeSamples',20),('freeSamples',10),('turretRenderedFrames',3),('exteriorVerifiedFrames',3),('exteriorRenderedFrames',6),('exteriorSubjectPixels',256)]:assert m[k]>=n,(k,m)
 for k,n in [('maxTurretAnchorError',.03),('brakedRelativeSpeed',.08),('turretMuzzleError',1e-8),('turretVelocityError',1e-8),('maxRecoilMomentumError',1e-7),('maxRecoilAngularError',1e-6),('separationError',1e-8)]:assert m[k]<n,(k,m)
 assert m['relativeTurretAngle']>.25 and m['freeModuleTravel']>.15 and m['turretKitConsumed'] and m['brokenJointAbsent'] and m['turretKitItemObserved']
 assert m['exteriorLookDot']>.98
 assert not m['contactBudgetExhausted']
 assert m['maxPredictionError']<.8 and m['pauseResumed'] and m['bayResumed'] and not m['teleportFollow']
 assert len(m['scenes'])==11
 ps=list((r/'flight-body-frames').glob('*.png'));assert len(ps)==11
 for p in ps:add(p)
 markers[profile]=m
for p in Path('work/ufo-body/native').glob('*turret*'):
 if p.is_file() and p.suffix in ['.log','.exit','.json']:add(p)
for r in [*Path('build').glob('cubic-client-before-flight-body-control-turret-*'),*Path('build').glob('cubic-client-final-flight-body-control-turret-final4-*')]:
 for f in ['inputs.json','launch.json','ufo-control-ok.json']:
  if (r/f).is_file():add(r/f)
 for folder in ['flight-body-frames','crash-reports']:
  for p in (r/folder).glob('*'):
   if p.is_file():add(p)

rs=[E.parse(p).getroot() for p in Path('build/test-results/test').glob('TEST-*.xml')];u={k:sum(int(r.get(k,0)) for r in rs) for k in ['tests','failures','errors','skipped']};cs=list(E.parse('build/gametest/reports/gametest-results.xml').iter('testcase'));g={'tests':len(cs),'failures':sum(c.find('failure') is not None for c in cs),'errors':sum(c.find('error') is not None for c in cs),'skipped':sum(c.find('skipped') is not None for c in cs)}
assert u==dict(tests=736,failures=0,errors=0,skipped=0) and g==dict(tests=316,failures=0,errors=0,skipped=0),(u,g)
assert json.loads(Path('build/resources/gametest/fabric.mod.json').read_text())['entrypoints']==json.loads(Path('src/gametest/resources/fabric.mod.json').read_text())['entrypoints']
assert 'BUILD SUCCESSFUL' in Path('work/ufo-body/turret-full-regressions-20261107.log').read_text()
focus=list(E.parse('work/ufo-body/turret-focused-46-passed-20261107.xml').iter('testcase'));assert len(focus)==46 and all(c.find('failure') is None and c.find('error') is None and c.find('skipped') is None for c in focus)
s=dict(source=source,nativeSource=nativeSource,nativeTestOnlyDelta=delta,identicalNativeArtifactBytesVerified=True,productionSource=subprocess.check_output(['git','rev-parse','5646885'],text=True).strip(),jars=stamp['jars'],unit=u,server=g,focused=46,focusedSource=subprocess.check_output(['git','rev-parse','5646885'],text=True).strip(),native=markers,releaseAccepted=False,publication='Local only',supersededNativeRound4='Functional checks passed; Sodium external image rejected by visual inspection. Accepted runs require current exterior draws, actual camera alignment and centered subject pixels.',scope='Partial S09-T03: installable yaw MOTOR weapon module, real pilot controls and physical recoil/detachment. New turret cold-world restart, pitch gimbal, AI control and full master v8/Dynamic Boarding remain open.',files={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(files)})
p=Path('docs/v8/EVIDENCE/turret-'+source[:7]+'.zip')
with zipfile.ZipFile(p,'x',zipfile.ZIP_DEFLATED) as z:
 for f in sorted(files):
  if f.suffix=='.zip':
   with zipfile.ZipFile(f) as nested:assert nested.testzip() is None,f
  z.write(f,str(f))
 z.writestr('MANIFEST.json',json.dumps(s,indent=2))
with zipfile.ZipFile(p) as z:
 assert z.testzip() is None
 for n,h in s['files'].items():assert hashlib.sha256(z.read(n)).hexdigest()==h,n
s['archive']=str(p);s['archiveSha256']=hashlib.sha256(p.read_bytes()).hexdigest();Path('work/ufo-body/turret-summary-20261107.json').write_text(json.dumps(s,indent=2)+'\n');print(json.dumps({k:v for k,v in s.items() if k!='files'},indent=2))
