import struct,zlib,io,json,pathlib
class N:
 def __init__(self,b):self.f=io.BytesIO(b)
 def u(self,fmt):return struct.unpack('>'+fmt,self.f.read(struct.calcsize('>'+fmt)))[0]
 def s(self):return self.f.read(self.u('H')).decode()
 def v(self,t):
  if t in [1,2,3,4,5,6]:return self.u({1:'b',2:'h',3:'i',4:'q',5:'f',6:'d'}[t])
  if t==8:return self.s()
  if t==9:
   k,n=self.u('B'),self.u('i');return [self.v(k) for _ in range(n)]
  if t==10:
   d={}
   while (k:=self.u('B')):name=self.s();d[name]=self.v(k)
   return d
  if t in [7,11,12]:return [self.u({7:'b',11:'i',12:'q'}[t]) for _ in range(self.u('i'))]
  raise ValueError(t)
 def root(self):t=self.u('B');self.s();return self.v(t)
res=[]
for p in pathlib.Path('build/cubic-client-automation/saves/Cubic-Gate/entities').glob('*.mca'):
 raw=p.read_bytes()
 for i in range(1024):
  loc=int.from_bytes(raw[i*4:i*4+4],'big');off=loc>>8
  if not off:continue
  off*=4096;n=int.from_bytes(raw[off:off+4],'big');t=raw[off+4];b=raw[off+5:off+4+n];b=zlib.decompress(b) if t==2 else b
  for e in N(b).root().get('Entities',[]):
   if e.get('id') in ['drmd:block_body','drmd:sky_ufo']:res.append(e)
pathlib.Path('work/ufo-body/turret-failed-saved-entities.json').write_text(json.dumps(res,indent=2))
for e in res:
 print(e.get('id'),e.keys());print({k:v for k,v in e.items() if k not in ['bodyShape','shape','body'] and not isinstance(v,(dict,list))});print('pos',e.get('Pos'))
 print('compound keys',[(k,list(v)[:15]) for k,v in e.items() if isinstance(v,dict)])
