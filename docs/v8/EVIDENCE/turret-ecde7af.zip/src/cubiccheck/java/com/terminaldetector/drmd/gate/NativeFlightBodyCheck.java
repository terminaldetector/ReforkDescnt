package com.terminaldetector.drmd.gate;

import com.terminaldetector.drmd.DescentPlayerData;
import com.terminaldetector.drmd.client.flight.*;
import com.terminaldetector.drmd.client.portal.PortalTransform.*;
import com.terminaldetector.drmd.network.*;
import com.terminaldetector.drmd.world.contraption.*;
import com.terminaldetector.drmd.world.contraption.boarding.*;
import com.terminaldetector.drmd.world.mega.SkyUfoEntity;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.client.*;
import net.minecraft.client.option.Perspective;
import net.minecraft.client.util.ScreenshotRecorder;
import net.minecraft.util.math.*;
import java.nio.file.*;
import java.util.*;

/** External entry, real free-flight authority, H-off boarding and roof CCD on the registered UFO. */
public final class NativeFlightBodyCheck {
    private static final boolean CONTROL=Boolean.getBoolean("drmd.gate.ufoControl");
    private static final boolean LIFECYCLE=Boolean.getBoolean("drmd.gate.ufoControlLifecycle");
    private static boolean deathReleased,bayWasControlled,bayResumed;
    private static int heldBayCooldown,heldBaySwarm,bayHeldSamples;
    private static volatile boolean reloadAutoPrimed;
    private static boolean pauseChecking,pauseVerified;private static int pauseTicks;
    private static int controlStep;private static volatile boolean serverControl;private static volatile Vec3 controlVelocity,controlSpin;private static Vec3 beforeControl,beforePilot;
    private static final BlockPos AT=new BlockPos(8,2156,16);
    private static boolean started,prepared,finished,capturing,flightStarted;
    private static volatile boolean ready,roofReady;private static volatile Vec3d local,serverFeet,bodyStart,bodyNow;
    private static volatile int serverEpoch=-1,roofContacts;private static volatile boolean walking;
    private static int ticks,age,bodyId=-1,frames,draws,samples,stable,captureDrawStart;private static volatile int phase;private static double maxError,walkStart;
    private static String scene;private static final List<String> scenes=new ArrayList<>();
    private static net.minecraft.entity.Entity entity(BlockBodyEntity b){return b;}
    private NativeFlightBodyCheck(){}
    public static void register(){ClientTickEvents.END_CLIENT_TICK.register(NativeFlightBodyCheck::tick);}
    private static void require(boolean value,String why){if(!value){finished=true;MinecraftClient.getInstance().scheduleStop();throw new IllegalStateException(why);}}
    public static void drew(BlockBodyEntity b){if(entity(b).getId()==bodyId&&b instanceof SkyUfoEntity)draws++;}
    public static void received(FlightBodyNetworking.State s) {
        if(finished||!s.active())return;var predicted=FlightBodyClient.predictedState(s.acknowledgment());
        if(predicted!=null){samples++;maxError=Math.max(maxError,predicted.feet().minus(new Vec3(s.x(),s.y(),s.z())).length());}
    }
    private static boolean loaded(MinecraftClient c) {
        var a=com.terminaldetector.drmd.world.access.WorldAccess.of(c.world);
        for(int x=-1;x<=1;x++)for(int y=(AT.getY()>>4)-1;y<=(AT.getY()>>4)+1;y++)for(int z=-1;z<=2;z++)
            if(!a.isVolumeAvailable(new com.terminaldetector.drmd.d6.D6ChunkPos(x,y,z)))return false;
        return true;
    }
    private static void tick(MinecraftClient c) {
        if(finished)return;if(++ticks>1800)require(false,"external UFO flight timeout: phase="+phase+" age="+age+" local="+local+" client="+(c.player==null?null:c.player.getPos())+" authority="+FlightBodyClient.active()+" serverEpoch="+serverEpoch);
        if(c.currentScreen instanceof net.minecraft.client.gui.screen.world.BackupPromptScreen p)for(var child:p.children())
            if(child instanceof net.minecraft.client.gui.widget.ButtonWidget b&&b.getMessage().getString().equals("I know what I'm doing!"))b.onPress();
        if(c.player==null||c.world==null||c.getServer()==null) {
            if(ticks%200==0)System.out.println("FLIGHT_BODY_STARTUP screen="+(c.currentScreen==null?null:c.currentScreen.getClass().getName()+" title="+c.currentScreen.getTitle()+" children="+c.currentScreen.children().stream().filter(child->child instanceof net.minecraft.client.gui.widget.ButtonWidget).map(child->((net.minecraft.client.gui.widget.ButtonWidget)child).getMessage().getString()).toList()));
            return;
        }
        com.terminaldetector.drmd.client.DescentClient.markUserFlightChoice();
        if(!started) {
            require(c.runDirectory.toPath().getFileName().toString().equals("cubic-client-automation"),"disposable native runtime only");started=true;
            c.setScreen(null);c.getTutorialManager().setStep(net.minecraft.client.tutorial.TutorialStep.NONE);c.inGameHud.getChatHud().clear(false);c.options.hudHidden=true;c.options.setPerspective(Perspective.THIRD_PERSON_BACK);
            com.terminaldetector.drmd.client.config.DescentConfig.cockpit=false;com.terminaldetector.drmd.client.config.DescentConfig.weaponView=false;
            com.terminaldetector.drmd.client.config.DescentConfig.planetFloor=false;com.terminaldetector.drmd.client.config.DescentConfig.levelSky=false;
            c.getServer().execute(()->{var p=c.getServer().getPlayerManager().getPlayer(c.player.getUuid());com.terminaldetector.drmd.flight.FlightSystem.disable(p,DescentPlayerData.get(p));p.setInvulnerable(true);p.getAbilities().flying=true;p.getAbilities().allowFlying=true;p.sendAbilitiesUpdate();p.teleport(p.getServerWorld(),8,AT.getY()+5,2,Set.of(),0,0);});return;
        }
        if(!prepared&&c.player.getY()>AT.getY()-20&&loaded(c)){prepared=true;c.getServer().execute(()->setup(c));return;}
        NativeUfoTurretCheck.trackExterior(c);
        if(!ready||capturing||!(c.world.getEntityById(bodyId) instanceof BlockBodyEntity))return;
        if(pauseChecking){
            if(c.isPaused())pauseTicks++;
            if(pauseTicks>=160){c.setScreen(null);pauseChecking=false;pauseVerified=true;age=0;c.options.forwardKey.setPressed(true);com.terminaldetector.drmd.client.input.DescentKeybinds.rollRight.setPressed(true);}
            return;
        }
        age++;
        if(age%20==0)System.out.println("FLIGHT_BODY_CLIENT_CLOCK canSend="+ClientPlayNetworking.canSend(FlightBodyNetworking.Input.ID)+" pending="+FlightBodyClient.pending()+" sequence="+FlightBodyClient.sequence());
        if(phase==14){if(NativeUfoTurretCheck.exteriorReady(c)){request("turret-module-exterior");phase=8;}return;}
        if(phase==13){if(NativeUfoWeaponsCheck.exteriorReady(c)){request("mounted-weapon-parts-exterior");phase=8;}return;}
        if(phase==12){if(NativeUfoEngineCheck.exteriorReady(c)){request("engine-pods-exterior");phase=8;}return;}
        if(phase==0&&FlightBodyClient.active()&&serverEpoch>0&&local!=null) {
            require(local.z< -11,"fixture must begin outside the actual UFO, not inside");
            c.options.forwardKey.setPressed(true);flightStarted=true;request("external-approach");phase=1;age=0;
        } else if(phase==1&&local!=null&&local.z> -4) {
            c.options.forwardKey.setPressed(false);require(local.z<0&&local.y>-.1&&Math.abs(local.x)<2,"entry must pass through the real side bay, not just rotate past the stationary pilot: "+local);
            require(bodyNow.distanceTo(bodyStart)>.2,"UFO must remain moving during the approach");request("moving-bay-entry");phase=2;age=0;
        } else if(phase==2&&age>12) {
            ClientPlayNetworking.send(new ModNetworking.ActionPayload("toggle"));phase=3;age=0;
        } else if(phase==3) {
            if(walking&&BoardingClient.drives(c.player)&&BoardingClient.state().grounded())stable++;else stable=0;
            if(stable>=12){walkStart=local.x;c.options.leftKey.setPressed(true);request("flight-to-boarding");phase=4;age=0;}
        } else if(phase==4) {
            if(age>=9)c.options.leftKey.setPressed(false);
            if(age>=24){require(walking&&local.x-walkStart>.5,"ordinary keys must walk inside the moving UFO");request("boarded-walking");phase=5;age=0;}
        } else if(phase==5&&age>4) {
            if(CONTROL){
                if(NativeUfoReloadCheck.WRITE&&!reloadAutoPrimed){c.getServer().execute(()->{((SkyUfoEntity)c.getServer().getOverworld().getEntityById(bodyId)).setAutopilot(true);reloadAutoPrimed=true;});return;}
                if(controlStep==0){
                    var hull=(BlockBodyEntity)c.world.getEntityById(bodyId);var view=BoardingClient.bodyView(hull,1);
                    // Aim through the visible top, not the buried block centre:
                    // from farther back the latter ray first hits a neighbouring deck cell.
                    var offset=new Vec3(3.5,-.001,.5).minus(hull.localCentre());var aim=(view==null?hull.localToWorld(new Vec3d(3.5,-.001,.5)):BoardingSystem.mc(view.position().plus(view.rotation().rotate(offset)))).subtract(c.player.getEyePos());
                    var angles=com.terminaldetector.drmd.client.portal.PortalTransform.vectorToYawPitch(BoardingSystem.pure(aim));c.player.setYaw((float)angles.yawDegrees());c.player.setPitch((float)angles.pitchDegrees());c.options.useKey.setPressed(true);
                    if(serverControl&&UfoControlClient.active()){c.options.useKey.setPressed(false);beforeControl=controlVelocity;beforePilot=BoardingSystem.pure(local);walkStart=local.x;c.options.forwardKey.setPressed(true);com.terminaldetector.drmd.client.input.DescentKeybinds.rollRight.setPressed(true);controlStep=1;request("control-acquired");age=0;}
                }else if(controlStep==1&&age>=14){
                    c.options.forwardKey.setPressed(false);com.terminaldetector.drmd.client.input.DescentKeybinds.rollRight.setPressed(false);
                    require(pauseVerified&&serverControl&&controlVelocity.minus(beforeControl).length()>1&&Math.abs(controlSpin.z())>.2,"actual control inputs must accelerate and turn the existing UFO");
                    require(BoardingSystem.pure(local).minus(beforePilot).length()<.4,"pilot input must drive the hull rather than walk the character");request("control-thrust-and-roll");controlStep=2;age=0;
                }else if(controlStep==2&&age>=5){
                    if(NativeUfoTurretCheck.ENABLED&&!NativeUfoTurretCheck.complete()){var extra=NativeUfoTurretCheck.tick(c);if(extra!=null)request(extra);return;}
                    if(NativeUfoEngineCheck.ENABLED&&!NativeUfoEngineCheck.complete()){var extra=NativeUfoEngineCheck.tick(c);if(extra!=null)request(extra);return;}
                    if(NativeUfoWeaponsCheck.ENABLED&&!NativeUfoWeaponsCheck.complete()){var extra=NativeUfoWeaponsCheck.tick(c);if(extra!=null)request(extra);return;}
                    ClientPlayNetworking.send(new ModNetworking.ActionPayload("toggle"));controlStep=3;age=0;
                }else if(controlStep==3&&age>=8&&!serverControl&&!UfoControlClient.active()){
                    require(!com.terminaldetector.drmd.client.DescentClientState.enabled&&walking,"H release must return to physical walking without enabling suit flight");
                    require(controlVelocity.length()>.5,"release must retain real carrier velocity");require(samples>=25&&maxError<.8&&draws>=40,"missing flight/render proof before core capture");request("control-release");phase=8;
                }
            }else{c.getServer().execute(()->roof(c));phase=6;age=0;}
        } else if(phase==9&&age>4) {
            var hull=(BlockBodyEntity)c.world.getEntityById(bodyId);var view=BoardingClient.bodyView(hull,1);
            var offset=new Vec3(3.5,-.001,.5).minus(hull.localCentre());
            var target=view==null?hull.localToWorld(new Vec3d(3.5,-.001,.5)):BoardingSystem.mc(view.position().plus(view.rotation().rotate(offset)));
            var aim=com.terminaldetector.drmd.client.portal.PortalTransform.vectorToYawPitch(BoardingSystem.pure(target.subtract(c.player.getEyePos())));
            c.player.setYaw((float)aim.yawDegrees());c.player.setPitch((float)aim.pitchDegrees());c.options.useKey.setPressed(true);
            if(serverControl&&UfoControlClient.active()){c.options.useKey.setPressed(false);request("control-reacquired");phase=10;age=0;}
        } else if(phase==11&&age>4&&!c.player.isAlive()&&!serverControl&&!UfoControlClient.active()) {
            deathReleased=true;request("control-death-release");phase=8;
        } else if(phase==6&&roofReady&&com.terminaldetector.drmd.client.DescentClientState.enabled&&FlightBodyClient.active()) {
            com.terminaldetector.drmd.client.input.DescentKeybinds.descend.setPressed(true);phase=7;age=0;
        } else if(phase==7&&roofContacts>=8) {
            com.terminaldetector.drmd.client.input.DescentKeybinds.descend.setPressed(false);
            require(local.y>1&&local.y<10,"descending suit must remain outside real roof material");
            require(samples>=25&&maxError<.8,"free-flight prediction mismatch: samples="+samples+" max="+maxError);
            require(draws>=40&&flightStarted,"actual UFO render/input proof missing");request("rotating-roof-contact");phase=8;
        }
    }
    private static void configure(net.minecraft.server.network.ServerPlayerEntity p) {
        var d=DescentPlayerData.get(p);d.setAccel(400);d.setMaxSpeed(400);d.setDrag(0);d.setGravity(0);d.setGravityFactor(0);d.setFlightAssist(true);d.setFlightVelocity(Vec3d.ZERO);
        com.terminaldetector.drmd.flight.FlightSystem.enableWithoutMount(p,d);ModNetworking.syncPlayer(p,d);
    }
    private static void setup(MinecraftClient c) {
        var w=c.getServer().getOverworld();var ufo=com.terminaldetector.drmd.entity.ModEntities.SKY_UFO.create(w);ufo.setAutopilot(false);
        entity(ufo).refreshPositionAndAngles(AT.getX(),AT.getY(),AT.getZ(),0,0);require(w.spawnEntity(ufo),"spawn real UFO");entity(ufo).tick();bodyId=entity(ufo).getId();
        ufo.physics().withLinearVelocity(new Vec3(.5,0,0)).withAngularVelocity(new Vec3(0,.08,0));ufo.setPassengerGravity(new Vec3(0,-32,0));ufo.publishPhysicsState();bodyStart=entity(ufo).getPos();
        var p=c.getServer().getPlayerManager().getPlayer(c.player.getUuid());p.teleport(w,AT.getX(),AT.getY()+.1,AT.getZ()-14,Set.of(),0,0);configure(p);w.setTimeOfDay(6000);ready=true;
        NativeUfoTurretCheck.watch(ufo,p);NativeUfoEngineCheck.watch(ufo,p);NativeUfoWeaponsCheck.watch(ufo,p);
        ServerTickEvents.END_WORLD_TICK.register(world->{
            if(world!=w||finished)return;local=ufo.worldToLocal(p.getPos());serverFeet=p.getPos();bodyNow=entity(ufo).getPos();serverEpoch=FlightBodySystem.epoch(p);walking=BoardingSystem.drives(p);serverControl=com.terminaldetector.drmd.world.mega.UfoControlSystem.controls(p);controlVelocity=ufo.physics().linearVelocity();controlSpin=ufo.physics().angularVelocity();
            if(CONTROL&&(serverControl||bayHeldSamples>0)) {
                var saved=entity(ufo).writeNbt(new net.minecraft.nbt.NbtCompound());int cooldown=saved.getInt("bayCooldown"),count=saved.getList("swarm",net.minecraft.nbt.NbtElement.COMPOUND_TYPE).size();
                if(serverControl){
                    if(!bayWasControlled){heldBayCooldown=cooldown;heldBaySwarm=count;}
                    else require(cooldown==heldBayCooldown&&count==heldBaySwarm,"captured carrier must pause its autonomous hostile bay without resetting its timer or deleting existing drones");
                    bayHeldSamples++;
                } else if(cooldown!=heldBayCooldown||count!=heldBaySwarm)bayResumed=true;
                bayWasControlled=serverControl;
            }
            if(phase>=7&&DescentPlayerData.get(p).isEnabled()&&local.y>1) {
                var velocity=DescentPlayerData.get(p).getFlightVelocity();
                if(ufo.boardingMotion().query(1).contacts(DynamicBodyAttachment.box(BoardingSystem.pure(p.getPos()),p.getWidth(),p.getHeight()),.03).stream().anyMatch(contact->contact.normal().y()>.3)&&velocity.y> -2)roofContacts++;
            }
            if(w.getTime()%20==0) {
                var state=new DynamicBodyAttachment.State(BoardingSystem.pure(p.getPos()),BoardingSystem.pure(DescentPlayerData.get(p).getFlightVelocity()),false,-1);
                var clip=BoardingWorldMotion.captureFlight(p,state,true).move(state.feet(),Quat.IDENTITY,state.velocity().scaled(.05));
                System.out.println("FLIGHT_BODY_TRACE phase="+phase+" local="+local+" p="+p.getPos()+" v="+DescentPlayerData.get(p).getFlightVelocity()+" lease="+serverEpoch+" ack="+FlightBodySystem.acknowledgment(p)+" clientPending="+FlightBodyClient.pending()+" maxError="+maxError+" clip="+clip+" box="+p.getBoundingBox()+" worldTracked="+w.getPlayers().contains(p)+" connected="+w.getServer().getPlayerManager().getPlayerList().contains(p)+" sameWorld="+(p.getWorld()==w));
            }
        });
    }
    private static void roof(MinecraftClient c) {
        var p=c.getServer().getPlayerManager().getPlayer(c.player.getUuid());var ufo=(SkyUfoEntity)BodySpatialIndex.find(p.getWorld(),bodyId).orElseThrow();
        var at=ufo.localToWorld(new Vec3d(3,9,3));p.teleport(p.getServerWorld(),at.x,at.y,at.z,Set.of(),0,0);
        ufo.physics().withAngularVelocity(new Vec3(.1,.08,.1));configure(p);roofReady=true;
    }
    private static void request(String s){scene=s;capturing=true;frames=0;captureDrawStart=draws;}
    public static void rendered() {
        if(!capturing||finished)return;if((scene.equals("engine-pods-exterior")||scene.equals("mounted-weapon-parts-exterior"))&&draws-captureDrawStart<3)return;var c=MinecraftClient.getInstance();if(c.player==null||(c.currentScreen!=null&&!scene.equals("control-death-release"))||++frames<3)return;
        try(var image=ScreenshotRecorder.takeScreenshot(c.getFramebuffer())) {
            if(scene.equals("turret-module-exterior")&&!NativeUfoTurretCheck.verifyExteriorImage(image))return;
            var out=c.runDirectory.toPath().resolve("flight-body-frames");Files.createDirectories(out);image.writeTo(out.resolve(scene+".png"));scenes.add(scene);capturing=false;
            System.out.println("FLIGHT_BODY_CLIENT "+scene+" PASS local="+local);
            if(NativeUfoReloadCheck.WRITE&&scene.equals("control-acquired")){
                NativeUfoReloadCheck.watch(c.world.getEntityById(bodyId).getUuid());finished=true;c.scheduleStop();return;
            }
            if(CONTROL&&scene.equals("control-acquired")){pauseChecking=true;pauseTicks=0;c.setScreen(new net.minecraft.client.gui.screen.GameMenuScreen(true));}
            if(NativeUfoTurretCheck.ENABLED&&scene.equals("control-release")){NativeUfoTurretCheck.prepareExterior(c);phase=14;age=0;return;}
            if(NativeUfoEngineCheck.ENABLED&&scene.equals("control-release")){NativeUfoEngineCheck.prepareExterior(c);phase=12;age=0;return;}
            if(NativeUfoWeaponsCheck.ENABLED&&scene.equals("control-release")){NativeUfoWeaponsCheck.prepareExterior(c);phase=13;age=0;return;}
            if(LIFECYCLE&&scene.equals("control-release")){phase=9;age=0;return;}
            if(LIFECYCLE&&scene.equals("control-reacquired")){
                phase=11;age=0;c.getServer().execute(()->c.getServer().getPlayerManager().getPlayer(c.player.getUuid()).setHealth(0));return;
            }
            if(phase==8) {
                if(CONTROL)require(bayHeldSamples>=8&&bayResumed,"native bay ownership pause/resume proof incomplete: samples="+bayHeldSamples+" resumed="+bayResumed);
                require(!LIFECYCLE||deathReleased,"lifecycle run must release both client and server ownership after actual player death");
                Files.writeString(c.runDirectory.toPath().resolve(CONTROL?"ufo-control-ok.json":"flight-body-ok.json"),"{\"bayPausedSamples\":"+bayHeldSamples+",\"bayResumed\":"+bayResumed+",\"deathReleased\":"+deathReleased+",\"pauseResumed\":"+pauseVerified+",\"controlCore\":"+CONTROL+",\"actualUfo\":true,\"externalEntry\":true,\"actualThrust\":true,\"walkingHandoff\":true,\"roofContacts\":"+roofContacts+",\"teleportFollow\":false,\"renderedFrames\":"+draws+",\"predictionSamples\":"+samples+",\"maxPredictionError\":"+maxError+",\"scenes\":[\""+String.join("\",\"",scenes)+"\"]}\n");
                NativeUfoTurretCheck.append(c.runDirectory.toPath().resolve("ufo-control-ok.json"));
                NativeUfoEngineCheck.append(c.runDirectory.toPath().resolve("ufo-control-ok.json"));
                NativeUfoWeaponsCheck.append(c.runDirectory.toPath().resolve("ufo-control-ok.json"));
                finished=true;c.scheduleStop();
            }
        }catch(java.io.IOException e){throw new IllegalStateException(e);}
    }
}
