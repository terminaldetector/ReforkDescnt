from pathlib import Path
import hashlib,json,zipfile,subprocess,xml.etree.ElementTree as E
root=Path.cwd();stamp=json.loads(Path('work/ufo-body/native/verified-build.json').read_text())
source=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
scenarios=['joints-seam1-gl32','joints-seam1-sodium']
files=set()
def add(p):
 p=Path(p);assert p.is_file(),p;files.add(p)
for name in ['src/main/java/com/terminaldetector/drmd/physics/collision/BodyCollisionQuery.java',
 'src/main/java/com/terminaldetector/drmd/world/contraption/boarding/DynamicBodyAttachment.java',
 'src/test/java/com/terminaldetector/drmd/BoardingSupportTransferTest.java',
 'src/gametest/java/com/terminaldetector/drmd/BoardingGameTests.java',
 'src/cubiccheck/java/com/terminaldetector/drmd/gate/NativeJointCheck.java',
 'build.gradle','gradle.properties','settings.gradle',
 'work/ufo-body/collect-boarding-seam-evidence.py','work/ufo-body/boarding-focus.init.gradle',
 'work/ufo-body/native/run-joints-seam1.sh']:
 add(name)
add('work/ufo-body/boarding-support-final-regressions.log')
add('work/ufo-body/native/verified-build.log');add('work/ufo-body/native/verified-build.json')
for p in Path('build/test-results/test').glob('TEST-*.xml'):add(p)
add('build/gametest/reports/gametest-results.xml')
for p in Path('work/ufo-body').glob('boarding-support-*'):
 if p.is_file() and p.suffix in ['.log','.zip','.xml','.java']:add(p)
markers={}
for scenario in scenarios:
 stand=Path('build/cubic-client-final-'+scenario)
 inputs=json.loads((stand/'inputs.json').read_text());assert inputs['sourceSha']==source
 for suffix in ['.log','.exit','-prepare.log']:
  add('work/ufo-body/native/final-'+scenario+suffix)
 assert Path('work/ufo-body/native/final-'+scenario+'.exit').read_text().strip()=='0'
 for name in ['inputs.json','joints-ok.json','options.txt']:add(stand/name)
 for p in (stand/'joint-frames').glob('*.png'):add(p)
 marker=json.loads((stand/'joints-ok.json').read_text())
 assert len(marker['scenes'])==5 and marker['seamSupportChanges']==1
 assert all(s['frames']>=90 for s in marker['scenes'])
 assert marker['seamLeftSamples']>=3 and marker['seamRightSamples']>=12
 markers[scenario]=marker
for f,h in stamp['jars'].items():assert hashlib.sha256(Path(f).read_bytes()).hexdigest()==h
units=[E.parse(p).getroot() for p in Path('build/test-results/test').glob('TEST-*.xml')]
unit={k:sum(int(r.get(k,0)) for r in units) for k in ['tests','failures','errors','skipped']}
cases=list(E.parse('build/gametest/reports/gametest-results.xml').iter('testcase'))
server=dict(tests=len(cases),failures=sum(c.find('failure') is not None for c in cases),errors=sum(c.find('error') is not None for c in cases))
assert unit==dict(tests=719,failures=0,errors=0,skipped=0);assert server==dict(tests=284,failures=0,errors=0)
manifest={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(files)}
summary=dict(source=source,production='48a5e97682f59ea7d48e8897ccc804db33f7cda9',jars=stamp['jars'],unit=unit,server=server,native=markers,releaseAccepted=False,publication='Local only; user publication pause in force',scope='Boarding contact ownership and joined moving-deck transition only; not full Dynamic Boarding or master v8 acceptance',files=manifest)
target=Path('docs/v8/EVIDENCE/boarding-seam-'+source[:7]+'.zip')
with zipfile.ZipFile(target,'x',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(files):z.write(p,str(p))
 z.writestr('MANIFEST.json',json.dumps(summary,indent=2))
with zipfile.ZipFile(target) as z:
 assert z.testzip() is None
 for name,h in manifest.items():assert hashlib.sha256(z.read(name)).hexdigest()==h
summary['archive']=str(target);summary['archiveSha256']=hashlib.sha256(target.read_bytes()).hexdigest()
Path('work/ufo-body/boarding-seam-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k!='files'},indent=2))
