# S07 locomotion-family inventory — source audit, 17 November 2026

Canonical audited HEAD: `f3d97844b2335d8fb9700960a12377fd8d3c2ca9`. Lane checkpoint `6b5b3a3adc01716917cfce9a36776974f70ab0d5` remains unchanged. `ActorPhysicsProfile`, `ActorFrames`, `EntityGravitySystem` and `GravityMount` have identical SHA-256 in both trees. This is read-only source/coverage work: no new gameplay test, Java process, production change or acceptance closure.

Reference: `docs/v8/reference/02_ENGINE/PHYSICS_UNIVERSAL_6DOF_RAGDOLL.md`, Universal entity classes C1–C7; `docs/v8/TASKS.yaml`, S07-T01 through T05. Every family needs a suitable adapter/fallback, species-specific movement outside fields must survive, and cross-family gravity/contact/persistence require evidence.

## Actual policy branches

`EntityGravitySystem` visits alive, non-player `LivingEntity` objects. A supported `ActorFrames` type gets the local physical pose. Otherwise an explicit `ActorPhysicsProfile.flying` type bypasses standing mounting and receives an additive field acceleration. Other living actors enter `GravityMount.safeMount` on a field/up transition, then receive ground-style probe/snap/damping. Non-living actors do not enter this loop; several have separate existing physical engines and must not be labelled missing merely from that exclusion.

`safeMount` is not a neutral fallback: after finding a surface it calls `requestTeleport`/`setPosition`, selects STANDING, clears swimming/sneaking, zeros velocity and sets onGround. Runtime gravity leases suppress scalar `getFinalGravity`; they deliberately do not own saved `NoGravity`. `ActorFrames` body/eye/ray/render/NBT support is gated by its explicit whitelist. `bankedModel` additionally names Drone/Scanner/OblivionSeeker only; force support does not itself prove rendered roll or natural AI navigation.

| Family / representative actors | Current field policy | Current scoped evidence and limit |
| --- | --- | --- |
| C1: Cow/Pig/Sheep; Zombie/Husk/Skeleton/Stray/Creeper | Explicit standing `ActorFrames`; exact EntityType checks | Cow covers six-axis body/eye/look, rejected turns/release, field force/exit and NBT aliases. The other seven vanilla whitelist types are implementation coverage, not separately exercised in these gravity cases. Villager, Mooshroom, Chicken, Drowned and other unlisted types still take generic standing fallback. |
| C2: Spider, CaveSpider | Neither frame-supported nor flying; generic standing mount/probe | No targeted local-field case found. CaveSpider inherits Spider; the native climbing navigation/flag has no explicit local-gravity policy here. |
| C3: Bee/Phantom/Ghast/Allay/Vex | Explicit flight force-only adapter | Three flyer GameTests plus related16 evidence retained: positions/propulsion/flags/controller identity, mostly AI-disabled force measurements. No general natural flight/visual six-axis acceptance. |
| Mixed C3: Bat/Parrot | Neither explicit frame nor flight adapter; generic fallback | Bat has roosting state; Parrot implements Flutterer but also has shoulder/ground behavior. No targeted field cases found. Do not select permanent flying solely from animation interface or NoGravity. |
| C4: Cod/Salmon/TropicalFish/Pufferfish | Generic standing fallback | All derive from native FishEntity, which owns water navigation/travel and dry flopping. No local-field swimming test found. This is the chosen next gap below. |
| C4: Squid/GlowSquid/Dolphin | Generic standing fallback | WaterCreatureEntity subclasses with different native travel/controllers. No targeted local-field case found; a Fish-only increment would not close these. |
| C4 / mixed: Guardian/ElderGuardian; Axolotl/Turtle; Drowned | Generic standing fallback | Guardian derives from HostileEntity; amphibians derive from AnimalEntity. Neither WaterCreature nor an always-swimming classifier can cover these safely. No targeted local-field case found. |
| C5 living flight: Drone (including typed Orb/Rocket/Jet inheritance), Scanner, OblivionSeeker, ReactorKeeper, EndReactorBoss, AirMine | Explicit flight force-only adapter | Existing six-mod-family flyer case; three banked-model native actors in NativeActorFrameCheck. Typed subclasses inherit the classifier but are not all spawned by that six-type test. Authored rigs/AI/renderers remain their own systems. |
| C5 living ground: Tripod/SpiderTurret | Explicit `ActorFrames` support through instanceof | Ground bestiary six-axis test and native actor frame case. Direct surface steering is exercised; complete autonomous multi-family local navigation is not established. |
| C5 physical ships / non-living constructs | Outside this living-actor loop, existing BlockBody/boarding/rig adapters | Separate S09/native evidence applies; do not replace them or infer absence from ActorPhysicsProfile. |
| C6 vanilla: Wither, EnderDragon | Generic standing fallback on parent living entity | Wither is HostileEntity, Dragon is MobEntity, neither FlyingEntity. Dragon parts are non-living Entity and are not independently visited. No targeted gravity/multipart case found. EndReactorBoss is explicitly handled as flight above, not proof for vanilla bosses. |
| C7: Shulker; ArmorStand; ItemFrame / hanging attachments | Shulker and ArmorStand enter generic standing fallback; non-living hanging actors are excluded | Shulker owns an attachment face; no explicit field policy preserves that contract. ArmorStand is LivingEntity. ItemFrame exclusion may be an appropriate anchored no-op but has no explicit universal attachment acceptance here. No targeted cases found. |

Mapped Minecraft class contracts were read from exact Yarn1.21.1 artifact SHA-256 `c5faef432fb699153152b47c11196d464a8d3f771b9dfd612257f94b87d8f237` using Python classfile metadata only. `native-class-contracts.json` records hierarchy/interfaces and movement declarations. This is static evidence, not class instantiation or runtime behavior.

## Existing test boundary

- `EntityFieldGravityGameTests`: six cases, using Cow for field lease/flags, six-axis scalar force, real ordinary travel, no duplicate integration and rider/clear release.
- `ActorFrameGameTests`: six cases, Cow plus Tripod/SpiderTurret for geometry/eyes/look, surface steering, obstruction/release and NBT alias handling.
- `FlyingRosterGravityGameTests`: three cases, five native C3 types and six authored mod family types. Natural AI is disabled during force measurements and re-enabled for identity/exit assertions.
- `NativeActorFrameCheck`: Cow, Tripod, SpiderTurret, Drone, Scanner, OblivionSeeker. This is not native proof for spiders, fish, anchors or vanilla bosses.
- A targeted search over GameTest/unit/native files that use EntityGravitySystem, ActorFrames or GravityFields.put found no direct Spider/CaveSpider/fish/Squid/Dolphin/Guardian/Axolotl/Turtle/Shulker/vanilla-boss/Bat/Parrot field fixtures. Other unrelated mob tests do not establish gravity acceptance.

S07-T02/T03 remain broader than these checks: `driveSurface` and local eyes/rays exist, but the presence of a physical pose does not convert every vanilla navigator or attack goal into local navigation. S07-T04 has an existing spatial field lookup index, while EntityGravitySystem still visits every loaded actor when any field is present; actor interest/subscriptions are separate. S07-T05 aliases and selected native actors are not a universal multi-process restart proof.

## One next gap and negative proposal — submerged native fish

The source-confirmed gap is a submerged FishEntity entering the standing mount/ground-damping fallback. This can strip its propulsion and manufacture ground contact despite its actual fluid locomotion. It is not yet reproduced in a new run.

Propose two test-only additions to the existing `EntityFieldGravityGameTests`, subject to root review:

1. Create real Cod/Salmon/TropicalFish/Pufferfish in a bounded, loaded water fixture beside a solid wall. Establish actual water contact using a normal entity tick before field entry; capture original native navigation/control objects, position, attitude, ground and externally owned gravity flags. Isolate the field pass from AI while measuring, then test all six field axes: no request to a standing wall position, no fake onGround or foot frame, additive sampled field impulse without ground damping. Observe water membership and restore AI after measurement. No manual swimming flag should stand in for native fluid contact.
2. In deep water away from a mountable wall, compare half/full sampled field force and field exit, both external NoGravity values, actual NBT round-trip and a same-UUID unspawned alias. Require momentum/controller/flag ownership to survive exit. Include a no-field ordinary-water control; native drag during actual travel remains owned by the species, not removed to satisfy a force-pass assertion.

These would be isolated field/locomotion ownership tests, not natural AI routing or rendered six-axis swimming acceptance. Review a FishEntity-in-water policy only after the negative; do not relabel water mobs as flying, blanket WaterCreature/amphibians/Guardian, or change shared physics. Dry flopping, other aquatic families, mixed Bat/Parrot, climbers, attachments, bosses/multipart and full C1–C7 acceptance remain open.
