#!/usr/bin/env bash
set -euo pipefail
cd /workspace/ungravity-v5/audit-next-20261109
test "${S16_JAVA_LEASE:-}" = granted
case_name="$1"
[[ "$case_name" =~ ^(enabled|disabled|capacity)$ ]]
python3 work/native-benchmark-recorder/verify_candidate.py check
case_root="/workspace/ungravity-v5/audit-next-20261109/build/native-benchmark-9426/$case_name/cubic-client-automation"
test -f "$case_root/launch.json"
out="work/native-benchmark-recorder/lease-9426/$case_name"
test -f "$out-staged.json"
test ! -e "$out-native.log"
/workspace/xvfb/usr/bin/Xvfb -displayfd 3 -screen 0 1280x1024x24 3> "$out-display.txt" > "$out-xvfb.log" 2>&1 &
display_pid=$!
trap 'kill "$display_pid" 2>/dev/null || true; wait "$display_pid" 2>/dev/null || true' EXIT
for attempt in {1..100}; do
  kill -0 "$display_pid"
  if [ -s "$out-display.txt" ]; then break; fi
  sleep .1
done
test -s "$out-display.txt"
read -r display_number < "$out-display.txt"
set +e
DISPLAY=:$display_number LIBGL_ALWAYS_SOFTWARE=1 MESA_GL_VERSION_OVERRIDE=3.3 MESA_GLSL_VERSION_OVERRIDE=330 timeout --kill-after=15 --foreground 240 python3 - "$case_root" > "$out-native.log" 2>&1 <<'PY'
import json,os,sys
from pathlib import Path
root=Path(sys.argv[1]);args=json.loads((root/'launch.json').read_text());os.chdir(root);os.execv(args[0],args)
PY
native_code=$?
set -e
printf '%s\n' "$native_code" > "$out-native.exit"
test "$native_code" -eq 0
python3 work/native-benchmark-recorder/verify_candidate.py verify "$case_name"
