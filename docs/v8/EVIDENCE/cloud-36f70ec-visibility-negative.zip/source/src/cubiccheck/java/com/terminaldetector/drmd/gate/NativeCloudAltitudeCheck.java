package com.terminaldetector.drmd.gate;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import com.terminaldetector.drmd.DescentPlayerData;
import com.terminaldetector.drmd.client.DescentClientState;
import com.terminaldetector.drmd.client.config.DescentConfig;
import com.terminaldetector.drmd.client.flight.ShipAttitudeClient;
import com.terminaldetector.drmd.client.input.DescentKeybinds;
import com.terminaldetector.drmd.client.portal.OffscreenWorldView;
import com.terminaldetector.drmd.client.presentation.PresentationProfile;
import com.terminaldetector.drmd.flight.FlightSystem;
import com.terminaldetector.drmd.gate.cloud.CloudFootprint;
import com.terminaldetector.drmd.world.access.CubicAvailability;
import com.terminaldetector.drmd.world.access.WorldAccess;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.*;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.*;
import net.minecraft.client.option.CloudRenderMode;
import net.minecraft.client.render.*;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.util.ScreenshotRecorder;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.*;
import net.minecraft.world.GameMode;
import net.minecraft.world.GameRules;
import org.joml.Matrix4f;
import org.lwjgl.opengl.*;
import org.lwjgl.system.MemoryUtil;
import org.lwjgl.system.MemoryStack;
import java.nio.*;
import java.nio.file.*;
import java.security.MessageDigest;
import java.util.*;

/** First attribution of the real cloud upload/draw. It supplies no GPU geometry or shader. */
public final class NativeCloudAltitudeCheck {
    public static final boolean ENABLED=Boolean.getBoolean("drmd.gate.cloudAltitude");
    private static final int STRIDE=4,MAX_VERTICES=262144,MAX_UPLOADS=16,MAX_FRAME_DRAWS=4,MAX_DRAWS=20;
    private static final int OBSERVER_WIDTH=1536,OBSERVER_HEIGHT=864;
    private static final long MAX_UPLOAD_BYTES=8L<<20,MAX_SOURCE_BYTES=32L<<20,MAX_READBACK_BYTES=192L<<20;
    private static final double[] HEIGHTS={224,384,512,2200,2200},ROLLS={0,0,0,0,90};
    private static final String[] NAMES={"near224","above384","far512","orbit2200","orbit2200-roll90"};
    private record Upload(CloudFootprint.Mesh mesh,String file,String sha,int bytes,String format) {}
    private record Draw(Upload upload,Matrix4f view,Matrix4f projection,CloudFootprint.Fog fog,
                        Map<String,Object> state,boolean cull,int cullMode,int front) {}
    private static final Map<VertexBuffer,Upload> UPLOADS=new IdentityHashMap<>();
    private static final Map<String,NativeImage> IMAGES=new LinkedHashMap<>();
    private static final List<Draw> DRAWS=new ArrayList<>();
    private static final List<Map<String,Object>> RESULTS=new ArrayList<>();
    private static final List<Map<String,Object>> POSE_INPUTS=new ArrayList<>();
    private static NativeImage cloudTexture;
    private static Map<String,Object> textureInfo=Map.of();
    private static net.minecraft.client.world.ClientWorld observedWorld;
    private static volatile ServerPlayerEntity player;
    private static volatile boolean poseReady,serverVolumes;
    private static volatile Map<String,Object> serverControl=Map.of();
    private static Map<String,Object> lastAdmission=Map.of();
    private static Map<String,Object> frameRequest=Map.of();
    private static boolean validated,requested,done,capturing,cloudScope,frameRequested;
    private static int pose,age,ticks,epoch,uploads,drawEvents;
    private static long sourceBytes,readbackBytes;
    private static double fixedX,fixedZ;
    private static Vec3d wantedForward,wantedUp;
    private static float[] beforeDepth;
    private static String scopeOwner="none";
    private NativeCloudAltitudeCheck() {}

    public static void register() {
        var c=MinecraftClient.getInstance();if(!c.runDirectory.getName().equals("cubic-client-automation"))throw new IllegalStateException("Cloud attribution requires disposable runtime");
        validated=true;ClientTickEvents.END_CLIENT_TICK.register(NativeCloudAltitudeCheck::tick);
        ClientLifecycleEvents.CLIENT_STOPPING.register(client->cleanup());
        ServerTickEvents.END_SERVER_TICK.register(server->{if(player!=null&&!done){
            serverVolumes=loaded(player.getServerWorld(),player.getBlockPos());
            var data=DescentPlayerData.get(player);var forward=data.shipForward(player);var up=data.shipUp(player);
            var state=new LinkedHashMap<String,Object>();state.put("position",List.of(player.getX(),player.getY(),player.getZ()));state.put("velocity",List.of(player.getVelocity().x,player.getVelocity().y,player.getVelocity().z));state.put("rotationYawPitch",List.of(player.getYaw(),player.getPitch()));state.put("sixDof",data.isEnabled());state.put("flying",player.getAbilities().flying);state.put("allowFlying",player.getAbilities().allowFlying);state.put("noGravity",player.hasNoGravity());state.put("volumesReady",serverVolumes);state.put("attitudeValid",data.hasShipAttitude());state.put("forward",List.of(forward.x,forward.y,forward.z));state.put("up",List.of(up.x,up.y,up.z));state.put("portalEpoch",data.portalEpoch());serverControl=state;
        }});
    }
    private static boolean live(){return ENABLED&&capturing&&!done&&!OffscreenWorldView.busy();}
    private static Path root(){return MinecraftClient.getInstance().runDirectory.toPath();}
    private static void write(Path path,Object value){try{Files.createDirectories(path.getParent());Files.writeString(path,new com.google.gson.Gson().toJson(value));}catch(java.io.IOException failure){throw new IllegalStateException(failure);}}
    private static void control(boolean ok,String message){
        if(ok)return;done=true;write(root().resolve("cloud-attribution-control-failure.json"),Map.of("reason",message,"pose",pose,"completedPoses",RESULTS,"sourceBytes",sourceBytes,"readbackBytes",readbackBytes,"drawEvents",drawEvents,"lastAdmission",lastAdmission,"serverControl",serverControl,"poseInputs",POSE_INPUTS));
        MinecraftClient.getInstance().scheduleStop();throw new IllegalStateException("CLOUD_ALTITUDE_CONTROL "+message);
    }
    private static boolean loaded(net.minecraft.world.World world,BlockPos pos){
        var access=WorldAccess.of(world);int cx=pos.getX()>>4,cy=pos.getY()>>4,cz=pos.getZ()>>4;
        for(int y=cy-1;y<=cy+1;y++)for(int z=cz-1;z<=cz+1;z++)for(int x=cx-1;x<=cx+1;x++)if(!access.isVolumeAvailable(new com.terminaldetector.drmd.d6.D6ChunkPos(x,y,z)))return false;
        return true;
    }
    private static String sha(byte[] bytes){try{return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(bytes));}catch(java.security.NoSuchAlgorithmException impossible){throw new IllegalStateException(impossible);}}
    private static void texture(MinecraftClient c){
        try(var stream=c.getResourceManager().getResource(Identifier.of("minecraft","textures/environment/clouds.png")).orElseThrow().getInputStream()) {
            byte[] original=stream.readAllBytes();cloudTexture=NativeImage.read(new java.io.ByteArrayInputStream(original));int w=cloudTexture.getWidth(),h=cloudTexture.getHeight();
            var out=root().resolve("cloud-input");Files.createDirectories(out);Files.write(out.resolve("texture-original.png"),original);
            write(out.resolve("texture-source.json"),Map.of("resource","minecraft:textures/environment/clouds.png","sha256",sha(original),"size",List.of(w,h)));
            control(w<=1024&&h<=1024,"bounded actual cloud texture");int[] distance=new int[w*h],queue=new int[w*h];Arrays.fill(distance,-1);int head=0,tail=0;
            for(int y=0;y<h;y++)for(int x=0;x<w;x++)if((cloudTexture.getColor(x,y)>>>24)<128){int i=y*w+x;distance[i]=0;queue[tail++]=i;}
            control(tail>0,"cloud resource contains a meaningful transparency boundary");
            while(head<tail){int i=queue[head++],x=i%w,y=i/w;for(int dy=-1;dy<=1;dy++)for(int dx=-1;dx<=1;dx++)if(dx!=0||dy!=0){int j=Math.floorMod(y+dy,h)*w+Math.floorMod(x+dx,w);if(distance[j]<0){distance[j]=distance[i]+1;queue[tail++]=j;}}}
            int best=0;for(int i=1;i<distance.length;i++)if(distance[i]>distance[best])best=i;
            control(distance[best]>=4,"actual texture has an opaque patch for near control");
            fixedX=(best%w+.5)*12;fixedZ=(best/w+.5)*12;
            textureInfo=Map.of("resource","minecraft:textures/environment/clouds.png","sha256",sha(original),"size",List.of(w,h),"selectedOpaquePixel",List.of(best%w,best/w),"opaquePatchRadiusTexels",distance[best],"fixedXZ",List.of(fixedX,fixedZ));
            write(out.resolve("texture.json"),textureInfo);
        }catch(java.io.IOException failure){throw new IllegalStateException(failure);}
    }
    private static void startPose(MinecraftClient c){
        wantedForward=new Vec3d(0,-1,0);var right=new Vec3d(1,0,0);var up=new Vec3d(0,0,-1);double roll=Math.toRadians(ROLLS[pose]);wantedUp=up.multiply(Math.cos(roll)).add(right.multiply(Math.sin(roll)));
        boolean sixDof=pose>=3;
        poseReady=false;serverVolumes=false;age=0;frameRequested=false;frameRequest=Map.of();double y=HEIGHTS[pose];
        var edge=Map.<String,Object>of("event","initial-pose-and-mode-command","pose",NAMES[pose],"requestedY",y,"expectedSixDof",sixDof,"actualClientSixDofBefore",DescentClientState.enabled,"actualServerBefore",serverControl);POSE_INPUTS.add(edge);write(root().resolve("cloud-input/pose-"+pose+"-mode-command.json"),edge);
        c.getServer().execute(()->{
            player.teleport(player.getServerWorld(),fixedX,y,fixedZ,Set.of(),0,90);var data=DescentPlayerData.get(player);
            if(sixDof)FlightSystem.enableWithoutMount(player,data);
            else{FlightSystem.disable(player,data);player.getAbilities().allowFlying=true;player.getAbilities().flying=true;player.sendAbilitiesUpdate();}
            // One admission reset only. Subsequent stability comes from ordinary Creative/END flight.
            data.setFlightVelocity(Vec3d.ZERO);player.setVelocity(Vec3d.ZERO);poseReady=true;
        });
    }
    private static void tick(MinecraftClient c){
        if(done)return;control(++ticks<2400,"timeout waiting for actual cloud scene");
        com.terminaldetector.drmd.client.DescentClient.markUserFlightChoice();
        if(observedWorld!=null&&c.world!=observedWorld){cleanup();control(false,"world switched before attribution completed");}
        if(c.currentScreen instanceof net.minecraft.client.gui.screen.world.BackupPromptScreen prompt)for(var child:prompt.children())if(child instanceof net.minecraft.client.gui.widget.ButtonWidget b&&b.getMessage().getString().equals("I know what I'm doing!"))b.onPress();
        if(c.world==null||c.player==null||c.getServer()==null)return;observedWorld=c.world;
        c.options.getCloudRenderMode().setValue(CloudRenderMode.FANCY);
        if(!requested){
            control(DescentConfig.presentationProfile==PresentationProfile.HYBRID_NATIVE&&DescentConfig.hybridRender&&DescentConfig.levelSky&&DescentConfig.planetFloor,"Native with original sky/LOD enabled");
            control(c.options.getClampedViewDistance()==4,"controlled render distance4");texture(c);requested=true;c.setScreen(null);
            c.getServer().execute(()->{player=c.getServer().getPlayerManager().getPlayer(c.player.getUuid());player.stopRiding();player.changeGameMode(GameMode.CREATIVE);var world=player.getServerWorld();control(CubicAvailability.backend(world)==CubicAvailability.Backend.NATIVE_CUBIC,"actual native cubic backend");world.setTimeOfDay(6000);world.getGameRules().get(GameRules.DO_DAYLIGHT_CYCLE).set(false,c.getServer());world.setWeather(6000,0,false,false);});return;
        }
        if(player!=null&&wantedForward==null)startPose(c);if(poseReady)age++;
        if(pose>=3&&poseReady&&age>=8&&!frameRequested&&serverVolumes&&DescentClientState.enabled&&ShipAttitudeClient.isPrimed()&&Boolean.TRUE.equals(serverControl.get("sixDof"))&&!c.player.getAbilities().flying&&!c.player.getAbilities().allowFlying&&Boolean.FALSE.equals(serverControl.get("flying"))&&Boolean.FALSE.equals(serverControl.get("allowFlying"))&&atRequestedPose(c.player.getPos())&&atRequestedPose(serverControl.get("position"))){
            var request=new LinkedHashMap<String,Object>();request.put("event","one-frame-after-real-enabled-ack");request.put("pose",NAMES[pose]);request.put("age",age);request.put("serverAcknowledgement",serverControl);request.put("clientEnabled",DescentClientState.enabled);request.put("clientPosition",List.of(c.player.getX(),c.player.getY(),c.player.getZ()));request.put("clientFlying",c.player.getAbilities().flying);request.put("clientAllowFlying",c.player.getAbilities().allowFlying);request.put("portalEpoch",ShipAttitudeClient.portalEpoch);request.put("requestedForward",List.of(wantedForward.x,wantedForward.y,wantedForward.z));request.put("requestedUp",List.of(wantedUp.x,wantedUp.y,wantedUp.z));frameRequest=request;frameRequested=true;
            // The actual enable SyncPayload has already reset the cold basis. Supply one view
            // command now; its existing normal input packet is authoritative on the server.
            ShipAttitudeClient.acceptPortalFrame(c.player,wantedForward,wantedUp);DescentKeybinds.sendInput(c);
            POSE_INPUTS.add(request);write(root().resolve("cloud-input/pose-"+pose+"-frame-request.json"),request);
        }
    }
    private static Vec3d vector(Object value){if(!(value instanceof List<?> v)||v.size()!=3)return null;return new Vec3d(((Number)v.get(0)).doubleValue(),((Number)v.get(1)).doubleValue(),((Number)v.get(2)).doubleValue());}
    private static boolean atRequestedPose(Object value){return atRequestedPose(vector(value));}
    private static boolean atRequestedPose(Vec3d value){return value!=null&&Math.abs(value.x-fixedX)<=.02&&Math.abs(value.y-HEIGHTS[pose])<=.02&&Math.abs(value.z-fixedZ)<=.02;}
    private static void clearImages(){for(var image:IMAGES.values())image.close();IMAGES.clear();beforeDepth=null;}
    private static void cleanup(){clearImages();if(cloudTexture!=null){cloudTexture.close();cloudTexture=null;}UPLOADS.clear();DRAWS.clear();cloudScope=false;}
    public static void beforeFrame(){
        if(!ENABLED||done)return;epoch++;capturing=false;cloudScope=false;scopeOwner="none";clearImages();DRAWS.clear();
        var c=MinecraftClient.getInstance();if(c.player==null||c.world==null)return;
        var admission=new LinkedHashMap<String,Object>();admission.put("pose",NAMES[pose]);admission.put("expectedControlMode",pose>=3?"6dof-END":"creative-hover-H-off");admission.put("requestedPlayerY",HEIGHTS[pose]);admission.put("clientPosition",List.of(c.player.getX(),c.player.getY(),c.player.getZ()));admission.put("clientVelocity",List.of(c.player.getVelocity().x,c.player.getVelocity().y,c.player.getVelocity().z));admission.put("clientRotationYawPitch",List.of(c.player.getYaw(),c.player.getPitch()));admission.put("clientSixDof",DescentClientState.enabled);admission.put("clientFlying",c.player.getAbilities().flying);admission.put("clientAllowFlying",c.player.getAbilities().allowFlying);admission.put("clientNoGravity",c.player.hasNoGravity());admission.put("serverControl",serverControl);admission.put("poseReady",poseReady);admission.put("age",age);admission.put("screen",c.currentScreen==null?"none":c.currentScreen.getClass().getSimpleName());lastAdmission=admission;
        admission.put("frameRequested",frameRequested);admission.put("frameRequest",frameRequest);
        if(!poseReady||age<8||!serverVolumes||c.currentScreen!=null)return;
        if(Math.abs(c.player.getY()-HEIGHTS[pose])>.02||Math.abs(c.player.getX()-fixedX)>.02||Math.abs(c.player.getZ()-fixedZ)>.02||!loaded(c.world,c.player.getBlockPos()))return;
        var serverPosition=serverControl.get("position");if(!(serverPosition instanceof List<?> position)||Math.abs(((Number)position.get(0)).doubleValue()-fixedX)>.02||Math.abs(((Number)position.get(1)).doubleValue()-HEIGHTS[pose])>.02||Math.abs(((Number)position.get(2)).doubleValue()-fixedZ)>.02)return;
        if(pose>=3){
            if(!frameRequested||!DescentClientState.enabled||!Boolean.TRUE.equals(serverControl.get("sixDof"))||c.player.getAbilities().flying||c.player.getAbilities().allowFlying||!Boolean.FALSE.equals(serverControl.get("flying"))||!Boolean.FALSE.equals(serverControl.get("allowFlying"))||!ShipAttitudeClient.isPrimed())return;
            double forward=ShipAttitudeClient.get().forward().dotProduct(wantedForward),up=ShipAttitudeClient.get().up().dotProduct(wantedUp);admission.put("forwardDot",forward);admission.put("upDot",up);if(forward<.999||up<.999)return;
            var serverForward=vector(serverControl.get("forward"));var serverUp=vector(serverControl.get("up"));if(!Boolean.TRUE.equals(serverControl.get("attitudeValid"))||serverForward==null||serverUp==null)return;double serverForwardDot=serverForward.dotProduct(wantedForward),serverUpDot=serverUp.dotProduct(wantedUp);admission.put("serverForwardDot",serverForwardDot);admission.put("serverUpDot",serverUpDot);if(serverForwardDot<.999||serverUpDot<.999)return;
        }else{
            if(DescentClientState.enabled||!Boolean.FALSE.equals(serverControl.get("sixDof"))||!c.player.getAbilities().flying||!c.player.getAbilities().allowFlying||!Boolean.TRUE.equals(serverControl.get("flying"))||!Boolean.TRUE.equals(serverControl.get("allowFlying")))return;
            if(Math.abs(MathHelper.wrapDegrees(c.player.getYaw()))>.01||Math.abs(c.player.getPitch()-90)>.01)return;
        }
        capturing=true;
    }
    public static void scope(String owner,boolean before){if(!ENABLED||!validated||done||OffscreenWorldView.busy())return;cloudScope=before;if(before)scopeOwner=owner;}
    public static void upload(VertexBuffer buffer,BuiltBuffer built){
        if(!ENABLED||!validated||done||!cloudScope||OffscreenWorldView.busy())return;
        var p=built.getDrawParameters();var format=p.format();int n=p.vertexCount(),stride=format.getVertexSizeByte();long bytes=(long)n*stride;
        control(n<=MAX_VERTICES&&bytes<=MAX_UPLOAD_BYTES&&sourceBytes+bytes<=MAX_SOURCE_BYTES&&uploads<MAX_UPLOADS,"bounded actual cloud VBO upload budget");
        control(format.has(VertexFormatElement.POSITION)&&format.has(VertexFormatElement.COLOR),"actual cloud format includes position and colour");
        var source=built.getBuffer().duplicate().order(ByteOrder.nativeOrder());control(bytes<=source.remaining(),"uploaded cloud bytes match actual vertex count");
        byte[] raw=new byte[(int)bytes];source.duplicate().get(raw);float[] pos=new float[n*3],uv=format.has(VertexFormatElement.UV_0)?new float[n*2]:new float[0];int[] colours=new int[n];
        int po=format.getOffset(VertexFormatElement.POSITION),co=format.getOffset(VertexFormatElement.COLOR),uo=uv.length==0?0:format.getOffset(VertexFormatElement.UV_0),base=source.position();
        for(int i=0;i<n;i++){int at=base+i*stride;for(int j=0;j<3;j++){float v=source.getFloat(at+po+j*4);control(Float.isFinite(v),"finite actual cloud vertex");pos[i*3+j]=v;}if(uv.length>0){uv[i*2]=source.getFloat(at+uo);uv[i*2+1]=source.getFloat(at+uo+4);}colours[i]=(source.get(at+co)&255)|((source.get(at+co+1)&255)<<8)|((source.get(at+co+2)&255)<<16)|((source.get(at+co+3)&255)<<24);}
        int id=++uploads;sourceBytes+=bytes;String file="cloud-input/vbo-"+id+".bin",digest=sha(raw);
        try{Files.createDirectories(root().resolve("cloud-input"));Files.write(root().resolve(file),raw);}catch(java.io.IOException failure){throw new IllegalStateException(failure);}
        var mesh=new CloudFootprint.Mesh(id,pos,uv,colours,p.mode().name());UPLOADS.put(buffer,new Upload(mesh,file,digest,(int)bytes,format.toString()));
        var info=new LinkedHashMap<String,Object>();info.put("id",id);info.put("file",file);info.put("sha256",digest);info.put("bytes",bytes);info.put("vertexCount",n);info.put("stride",stride);info.put("positionOffset",po);info.put("colourOffset",co);info.put("uvOffset",uv.length==0?-1:uo);info.put("mode",p.mode().name());info.put("owner",scopeOwner);
        write(root().resolve("cloud-input/vbo-"+id+".json"),info);
    }
    private static int[] pack(){int[] names={GL11.GL_PACK_ALIGNMENT,GL11.GL_PACK_ROW_LENGTH,GL11.GL_PACK_SKIP_ROWS,GL11.GL_PACK_SKIP_PIXELS},values=new int[4];for(int i=0;i<4;i++){values[i]=GL11.glGetInteger(names[i]);GL11.glPixelStorei(names[i],i==0?4:0);}return values;}
    private static void unpack(int[] values){int[] n={GL11.GL_PACK_ALIGNMENT,GL11.GL_PACK_ROW_LENGTH,GL11.GL_PACK_SKIP_ROWS,GL11.GL_PACK_SKIP_PIXELS};for(int i=0;i<4;i++)GL11.glPixelStorei(n[i],values[i]);}
    private static NativeImage screenshot(){
        var c=MinecraftClient.getInstance();readbackBytes+=(long)c.getFramebuffer().textureWidth*c.getFramebuffer().textureHeight*4;control(readbackBytes<=MAX_READBACK_BYTES,"bounded cloud readback bytes");
        int active=GL11.glGetInteger(GL13.GL_ACTIVE_TEXTURE),binding=GL11.glGetInteger(GL11.GL_TEXTURE_BINDING_2D);int[] saved=pack();try{return ScreenshotRecorder.takeScreenshot(c.getFramebuffer());}finally{GlStateManager._activeTexture(active);GlStateManager._bindTexture(binding);unpack(saved);}
    }
    private static void capture(String name){if(!live())return;var previous=IMAGES.put(name,screenshot());if(previous!=null)previous.close();}
    private static float[] depth(){
        var f=MinecraftClient.getInstance().getFramebuffer();readbackBytes+=(long)f.textureWidth*f.textureHeight*4;control(readbackBytes<=MAX_READBACK_BYTES,"bounded cloud depth readback");
        int old=GL11.glGetInteger(GL30.GL_READ_FRAMEBUFFER_BINDING);int[] saved=pack();var b=MemoryUtil.memAllocFloat(f.textureWidth*f.textureHeight);
        try{GL30.glBindFramebuffer(GL30.GL_READ_FRAMEBUFFER,f.fbo);GL11.glReadPixels(0,0,f.textureWidth,f.textureHeight,GL11.GL_DEPTH_COMPONENT,GL11.GL_FLOAT,b);float[] result=new float[((f.textureWidth+STRIDE-1)/STRIDE)*((f.textureHeight+STRIDE-1)/STRIDE)];int at=0;for(int y=0;y<f.textureHeight;y+=STRIDE)for(int x=0;x<f.textureWidth;x+=STRIDE)result[at++]=b.get((f.textureHeight-1-y)*f.textureWidth+x);return result;}finally{GL30.glBindFramebuffer(GL30.GL_READ_FRAMEBUFFER,old);unpack(saved);MemoryUtil.memFree(b);}
    }
    public static void cockpit(boolean before){capture(before?"cockpit-before":"cockpit-after");}
    public static void draw(VertexBuffer buffer,Matrix4f view,Matrix4f projection,ShaderProgram shader,boolean before){
        if(!live()||!cloudScope)return;String name=shader.getName();if(!name.endsWith("clouds"))return;
        if(!before){
            var image=screenshot();var previous=IMAGES.get("cloud-pass-"+(DRAWS.size()-1)+"-after");if(previous==null)previous=IMAGES.get("cloud-before");
            int changed=0;for(int y=0;y<image.getHeight();y+=STRIDE)for(int x=0;x<image.getWidth();x+=STRIDE)if(rgb(previous.getColor(x,y),image.getColor(x,y))>8)changed++;
            DRAWS.getLast().state.put("changedSamplesThisPass",changed);IMAGES.put("cloud-pass-"+DRAWS.size()+"-after",image);return;
        }
        control(DRAWS.size()<MAX_FRAME_DRAWS&&++drawEvents<=MAX_DRAWS,"bounded cloud draw events");
        if(!IMAGES.containsKey("cloud-before")){capture("cloud-before");beforeDepth=depth();}
        var c=MinecraftClient.getInstance();int[] viewport=new int[4],scissor=new int[4];GL11.glGetIntegerv(GL11.GL_VIEWPORT,viewport);GL11.glGetIntegerv(GL11.GL_SCISSOR_BOX,scissor);
        var s=new LinkedHashMap<String,Object>();s.put("owner",scopeOwner);s.put("shader",name);s.put("epoch",epoch);s.put("view",view.get(new float[16]));s.put("projection",projection.get(new float[16]));s.put("camera",List.of(c.gameRenderer.getCamera().getPos().x,c.gameRenderer.getCamera().getPos().y,c.gameRenderer.getCamera().getPos().z));
        s.put("cloudHeight",c.world.getDimensionEffects().getCloudsHeight());s.put("farPlane",c.gameRenderer.getFarPlaneDistance());s.put("fogStart",RenderSystem.getShaderFogStart());s.put("fogEnd",RenderSystem.getShaderFogEnd());s.put("fogShape",RenderSystem.getShaderFogShape().name());s.put("fogColour",RenderSystem.getShaderFogColor().clone());s.put("shaderColour",RenderSystem.getShaderColor().clone());
        s.put("mainFbo",c.getFramebuffer().fbo);s.put("drawFbo",GL11.glGetInteger(GL30.GL_DRAW_FRAMEBUFFER_BINDING));s.put("viewport",viewport);s.put("scissorEnabled",GL11.glIsEnabled(GL11.GL_SCISSOR_TEST));s.put("scissor",scissor);s.put("depthWrite",GL11.glGetBoolean(GL11.GL_DEPTH_WRITEMASK));s.put("depthTest",GL11.glIsEnabled(GL11.GL_DEPTH_TEST));s.put("depthFunction",GL11.glGetInteger(GL11.GL_DEPTH_FUNC));
        try(var stack=MemoryStack.stackPush()){var mask=stack.malloc(4);GL11.glGetBooleanv(GL11.GL_COLOR_WRITEMASK,mask);s.put("colourWriteMask",List.of(mask.get(0)!=0,mask.get(1)!=0,mask.get(2)!=0,mask.get(3)!=0));}
        var upload=UPLOADS.get(buffer);s.put("sourceReady",upload!=null);if(upload!=null){s.put("uploadId",upload.mesh.upload());s.put("sourceFile",upload.file);s.put("sourceSha256",upload.sha);s.put("vertexCount",upload.mesh.vertices());s.put("format",upload.format);}
        boolean cull=GL11.glIsEnabled(GL11.GL_CULL_FACE);int mode=GL11.glGetInteger(GL11.GL_CULL_FACE_MODE),front=GL11.glGetInteger(GL11.GL_FRONT_FACE);s.put("cull",cull);s.put("cullMode",mode);s.put("frontFace",front);
        boolean sodium=!name.endsWith("rendertype_clouds");var fog=new CloudFootprint.Fog(sodium,RenderSystem.getShaderFogStart(),RenderSystem.getShaderFogEnd(),RenderSystem.getShaderFogColor()[3],RenderSystem.getShaderFogShape().name(),RenderSystem.getShaderColor()[3]);
        DRAWS.add(new Draw(upload,new Matrix4f(view),new Matrix4f(projection),fog,s,cull,mode,front));
    }
    private static int rgb(int a,int b){return Math.max(Math.abs((a&255)-(b&255)),Math.max(Math.abs(((a>>>8)&255)-((b>>>8)&255)),Math.abs(((a>>>16)&255)-((b>>>16)&255))));}
    private static boolean cockpitPixel(int x,int y){var a=IMAGES.get("cockpit-before");var b=IMAGES.get("cockpit-after");return a!=null&&b!=null&&rgb(a.getColor(x,y),b.getColor(x,y))>2;}
    private static Map<String,Object> evaluate(){
        var result=new LinkedHashMap<String,Object>();var before=IMAGES.get("cloud-before");var after=IMAGES.get("cloud-pass-"+DRAWS.size()+"-after");boolean ready=before!=null&&after!=null&&!DRAWS.isEmpty()&&DRAWS.stream().allMatch(d->d.upload!=null);
        result.put("actualCloudDraws",DRAWS.stream().map(d->d.state).toList());result.put("drawSourceReady",ready);result.put("pose",NAMES[pose]);result.put("playerY",HEIGHTS[pose]);result.put("roll",ROLLS[pose]);result.put("epoch",epoch);result.put("fixedXZ",List.of(fixedX,fixedZ));result.put("texture",textureInfo);result.put("poseAdmission",lastAdmission);
        var c=MinecraftClient.getInstance();var window=c.getWindow();var main=c.getFramebuffer();boolean resolution=window.getFramebufferWidth()==OBSERVER_WIDTH&&window.getFramebufferHeight()==OBSERVER_HEIGHT&&main.textureWidth==OBSERVER_WIDTH&&main.textureHeight==OBSERVER_HEIGHT;result.put("expectedObserverResolution",resolution);result.put("actualWindowFramebuffer",List.of(window.getFramebufferWidth(),window.getFramebufferHeight()));result.put("actualMainTexture",List.of(main.textureWidth,main.textureHeight));result.put("requiredObserverResolution",List.of(OBSERVER_WIDTH,OBSERVER_HEIGHT));
        if(!ready){result.put("diagnostic","missing actual cloud draw/upload snapshot");result.put("visibilityPass",false);return result;}
        int w=before.getWidth(),h=before.getHeight();var opaque=new BitSet();var far=new BitSet();var inside=new BitSet();var zero=new BitSet();var nonzero=new BitSet();var mixed=new BitSet();int back=0,triangles=0,invalid=0;boolean target=true;
        for(var d:DRAWS){var r=CloudFootprint.project(d.upload.mesh,d.view,d.projection,d.fog,cloudTexture,w,h,STRIDE,d.cull,d.cullMode,d.front);opaque.or(r.opaque());far.or(r.outsideFarClip());inside.or(r.insideDepthClip());zero.or(r.fogZero());nonzero.or(r.fogNonzero());mixed.or(r.fullyFogMixed());triangles+=r.triangles();back+=r.backFacing();invalid+=r.nonpositiveW();target&=Objects.equals(d.state.get("mainFbo"),d.state.get("drawFbo"))&&Arrays.equals((int[])d.state.get("viewport"),new int[]{0,0,w,h})&&!Boolean.TRUE.equals(d.state.get("scissorEnabled"));}
        far.andNot(inside);zero.andNot(nonzero);int domain=0,changed=0,foreground=0,cockpit=0,farCount=0,fogZero=0,fogMixed=0,index=0,invalidDepth=0;var validDomain=new BitSet();var changedPixels=new BitSet();
        for(int y=0;y<h;y+=STRIDE)for(int x=0;x<w;x+=STRIDE){int i=index++;if(!opaque.get(i))continue;if(!Float.isFinite(beforeDepth[i])||beforeDepth[i]<0||beforeDepth[i]>1){invalidDepth++;continue;}if(beforeDepth[i]<.999995f){foreground++;continue;}if(cockpitPixel(x,y)){cockpit++;continue;}domain++;validDomain.set(i);if(rgb(before.getColor(x,y),after.getColor(x,y))>8){changed++;changedPixels.set(i);}if(far.get(i))farCount++;if(zero.get(i))fogZero++;if(mixed.get(i))fogMixed++;}
        try{var folder=root().resolve("cloud-attribution-frames").resolve(NAMES[pose]);Files.createDirectories(folder);Files.write(folder.resolve("valid-domain.bits"),validDomain.toByteArray());Files.write(folder.resolve("changed-cloud.bits"),changedPixels.toByteArray());Files.write(folder.resolve("outside-far.bits"),far.toByteArray());Files.write(folder.resolve("fog-zero.bits"),zero.toByteArray());Files.write(folder.resolve("vanilla-fog-mixed.bits"),mixed.toByteArray());var bytes=ByteBuffer.allocate(beforeDepth.length*4).order(ByteOrder.LITTLE_ENDIAN);for(float value:beforeDepth)bytes.putFloat(value);Files.write(folder.resolve("before-cloud-depth.f32"),bytes.array());}catch(java.io.IOException failure){throw new IllegalStateException(failure);}
        result.put("opaqueFootprintSamples",domain);result.put("actualChangedCloudSamples",changed);result.put("changedFraction",domain==0?0:(double)changed/domain);result.put("nearDepthExcluded",foreground);result.put("cockpitExcluded",cockpit);result.put("outsideFarClipSamples",farCount);result.put("sodiumFogZeroAlphaSamples",fogZero);result.put("vanillaFullyFogMixedSamples",fogMixed);result.put("triangles",triangles);result.put("backFacingTriangles",back);result.put("nonpositiveWVertices",invalid);result.put("expectedMainTargetViewport",target);result.put("domainModel","Actual uploaded source alpha/UV triangles projected at stride4; stock texture nearest-alpha model for UV geometry, emitted voxel coverage for Sodium. GPU captures authoritative at raster/filter boundaries.");
        result.put("maskEncoding",Map.of("type","Java BitSet little-endian bytes","stride",STRIDE,"gridWidth",(w+STRIDE-1)/STRIDE,"imageSize",List.of(w,h),"depthEncoding","float32 little-endian in the same sampled grid"));
        result.put("invalidDepthSamples",invalidDepth);
        boolean pass=domain>=500&&changed>=(pose==0?500:Math.ceil(domain*.05))&&target&&resolution&&invalid==0&&invalidDepth==0;result.put("visibilityPass",pass);return result;
    }
    public static void rendered(){
        if(!live())return;capture("final");var c=MinecraftClient.getInstance();var result=evaluate();result.put("glError",GL11.glGetError());result.put("cloudsMode",c.options.getCloudRenderModeValue().name());result.put("glVersion",GL11.glGetString(GL11.GL_VERSION));result.put("glslVersion",GL11.glGetString(GL20.GL_SHADING_LANGUAGE_VERSION));result.put("worldTimeOfDay",c.world.getTimeOfDay());result.put("rain",c.world.getRainGradient(1));result.put("thunder",c.world.getThunderGradient(1));
        try{var folder=root().resolve("cloud-attribution-frames").resolve(NAMES[pose]);Files.createDirectories(folder);for(var entry:IMAGES.entrySet())entry.getValue().writeTo(folder.resolve(entry.getKey()+".png"));write(folder.resolve("attribution.json"),result);RESULTS.add(result);}catch(java.io.IOException failure){throw new IllegalStateException(failure);}
        capturing=false;clearImages();DRAWS.clear();if(++pose<HEIGHTS.length){wantedForward=null;poseReady=false;age=0;return;}
        boolean pass=RESULTS.size()==HEIGHTS.length&&RESULTS.stream().allMatch(r->Boolean.TRUE.equals(r.get("visibilityPass"))&&((Number)r.get("glError")).intValue()==0&&"FANCY".equals(r.get("cloudsMode")));
        var report=new LinkedHashMap<String,Object>();report.put("allFivePoseFramesPreserved",true);report.put("visibilityPass",pass);report.put("sourceBytes",sourceBytes);report.put("readbackBytes",readbackBytes);report.put("uploadEvents",uploads);report.put("drawEvents",drawEvents);report.put("poses",RESULTS);report.put("thresholds",Map.of("stride",STRIDE,"minOpaqueFootprintSamples",500,"minNearChangedSamples",500,"minHighChangedFraction",.05,"maxUploadBytes",MAX_UPLOAD_BYTES,"maxSourceBytes",MAX_SOURCE_BYTES,"maxReadbackBytes",MAX_READBACK_BYTES));write(root().resolve(pass?"cloud-attribution-ok.json":"cloud-attribution-negative.json"),report);done=true;c.scheduleStop();if(!pass)throw new IllegalStateException("CLOUD_ALTITUDE_NATIVE actual near/high cloud visibility failed; all five poses preserved");
    }
}
