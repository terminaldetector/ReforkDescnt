package com.terminaldetector.drmd.climber.mixin;

import com.terminaldetector.drmd.climber.ClimberMotionTrace;
import net.minecraft.entity.Entity;
import net.minecraft.entity.MovementType;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import java.util.Map;

@Mixin(Entity.class)
public abstract class NativeMovePhaseProbe {
    @Inject(method="move",at=@At("HEAD"))
    private void beforeMove(MovementType type,Vec3d requested,CallbackInfo ci){move("MOVE_BEFORE",type,requested);}
    @Inject(method="move",at=@At("RETURN"))
    private void afterMove(MovementType type,Vec3d requested,CallbackInfo ci){move("MOVE_AFTER",type,requested);}
    @Unique private void move(String phase,MovementType type,Vec3d requested) {
        var actor=(Entity)(Object)this;if(!ClimberMotionTrace.armed(actor))return;
        ClimberMotionTrace.record(actor,phase,Map.of("movementType",type.toString(),"requestedDisplacement",ClimberMotionTrace.vector(requested)));
    }
    @Inject(method="updateVelocity",at=@At("HEAD"))
    private void beforeInput(float speed,Vec3d input,CallbackInfo ci){input("INPUT_BEFORE",speed,input);}
    @Inject(method="updateVelocity",at=@At("RETURN"))
    private void afterInput(float speed,Vec3d input,CallbackInfo ci){input("INPUT_AFTER",speed,input);}
    @Unique private void input(String phase,float speed,Vec3d input) {
        var actor=(Entity)(Object)this;if(!ClimberMotionTrace.armed(actor))return;
        ClimberMotionTrace.record(actor,phase,Map.of("nativeInputSpeed",speed,"nativeInput",ClimberMotionTrace.vector(input)));
    }
}
