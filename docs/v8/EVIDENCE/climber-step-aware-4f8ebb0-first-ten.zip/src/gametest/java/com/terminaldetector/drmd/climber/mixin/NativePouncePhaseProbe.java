package com.terminaldetector.drmd.climber.mixin;

import com.terminaldetector.drmd.climber.ClimberFollowTrace;
import net.minecraft.entity.ai.goal.PounceAtTargetGoal;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.mob.SpiderEntity;
import org.spongepowered.asm.mixin.*;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(PounceAtTargetGoal.class)
public abstract class NativePouncePhaseProbe {
    @Shadow @Final private MobEntity mob;
    @Shadow @Final private float velocity;
    @Inject(method="start",at=@At("HEAD"))
    private void before(CallbackInfo ci) {
        if(!ClimberFollowTrace.ENABLED||!(mob instanceof SpiderEntity actor))return;
        ClimberFollowTrace.pounce(actor,true,velocity);
    }
    @Inject(method="start",at=@At("RETURN"))
    private void after(CallbackInfo ci) {
        if(!ClimberFollowTrace.ENABLED||!(mob instanceof SpiderEntity actor))return;
        ClimberFollowTrace.pounce(actor,false,velocity);
    }
}
