package com.terminaldetector.drmd.climber.mixin;

import com.terminaldetector.drmd.climber.ClimberAirAcceptance;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.goal.PounceAtTargetGoal;
import net.minecraft.entity.mob.*;
import org.spongepowered.asm.mixin.*;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.*;

@Mixin(PounceAtTargetGoal.class)
public abstract class NativeAirPounceProbe {
    @Shadow @Final private MobEntity mob;
    @Shadow private LivingEntity target;
    @Shadow @Final private float velocity;
    @Inject(method="start",at=@At("HEAD"))
    private void before(CallbackInfo ci){if(ClimberAirAcceptance.ENABLED&&mob instanceof SpiderEntity actor)ClimberAirAcceptance.pounce(actor,target,velocity,true);}
    @Inject(method="start",at=@At("RETURN"))
    private void after(CallbackInfo ci){if(ClimberAirAcceptance.ENABLED&&mob instanceof SpiderEntity actor)ClimberAirAcceptance.pounce(actor,target,velocity,false);}
    @Inject(method="canStart",at=@At("RETURN"))
    private void eligibility(CallbackInfoReturnable<Boolean> cir) {
        if(ClimberAirAcceptance.ENABLED&&mob instanceof SpiderEntity actor)ClimberAirAcceptance.eligibility(actor,target,cir.getReturnValue());
    }

}
