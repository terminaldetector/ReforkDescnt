package com.terminaldetector.drmd.climber;

import com.terminaldetector.drmd.ai.BoundedFlightPath;
import com.terminaldetector.drmd.world.gravity.*;
import net.minecraft.entity.ai.pathing.Path;
import net.minecraft.entity.mob.SpiderEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import java.lang.ref.WeakReference;
import java.lang.reflect.Field;
import java.util.*;

/** Focused-only, bounded read-only request/status snapshots. Reflection reads private cache state, never writes it. */
public final class ClimberRequestTrace {
    public static final boolean ENABLED=Boolean.getBoolean("drmd.gate.climberRequests");
    private static final int MAX_ACTORS=6,MAX_EVENTS_PER_PHASE=8;
    private static final Map<UUID,Counts> COUNTS=new HashMap<>();
    private static final class Counts {
        final WeakReference<SpiderEntity> owner;final Map<String,Integer> phases=new HashMap<>();
        Counts(SpiderEntity actor){owner=new WeakReference<>(actor);}
    }
    private ClimberRequestTrace() {}
    public static void observe(SpiderEntity actor,String phase,Set<BlockPos> requested,Path returned) {
        if(!ENABLED||!LocalSurfaceNavigation.framed(actor))return;
        var counts=COUNTS.get(actor.getUuid());
        if(counts==null) {
            if(COUNTS.size()>=MAX_ACTORS)return;
            counts=new Counts(actor);COUNTS.put(actor.getUuid(),counts);
        }
        if(counts.owner.get()!=actor)return;
        int seen=counts.phases.getOrDefault(phase,0);if(seen>=MAX_EVENTS_PER_PHASE)return;
        counts.phases.put(phase,seen+1);
        var row=new LinkedHashMap<String,Object>();row.put("phase",phase);row.put("phaseCount",seen+1);
        row.put("uuid",actor.getUuid().toString());row.put("type",actor.getType().toString());
        row.put("worldTime",actor.getWorld().getTime());row.put("age",actor.age);row.put("position",vector(actor.getPos()));
        row.put("up",vector(ActorFrames.up(actor)));row.put("pose",actor.getPose().toString());row.put("aiDisabled",actor.isAiDisabled());
        row.put("gravityLease",EntityGravitySystem.suppressesVanillaGravity(actor));
        var sample=GravityFields.sample(actor.getWorld(),actor.getPos());row.put("fieldStrength",sample==null?null:sample.strength());
        row.put("fieldUp",sample==null?null:vector(sample.upDir()));row.put("requestedTargets",requested.stream().limit(16).map(ClimberRequestTrace::block).toList());
        row.put("nativeNavigationTarget",block(actor.getNavigation().getTargetPos()));row.put("currentPath",path(actor.getNavigation().getCurrentPath()));
        row.put("returnedPath",path(returned));row.put("counts",new LinkedHashMap<>(counts.phases));
        try {row.put("boundedState",state(actor));}
        catch(ReflectiveOperationException failure){throw new IllegalStateException("climber request observer reflection failed",failure);}
        System.out.println("CLIMBER_REQUEST_TRACE "+new com.google.gson.Gson().toJson(row));
    }
    public static Map<String,Object> state(SpiderEntity actor)throws ReflectiveOperationException {
        var row=new LinkedHashMap<String,Object>();var worlds=(Map<?,?>)read(LocalSurfaceNavigation.class,null,"WORLDS");
        var world=worlds.get(actor.getWorld());row.put("worldTracked",world!=null);if(world==null)return row;
        var searches=(Map<?,?>)read(world.getClass(),world,"searches");row.put("trackedActors",searches.size());
        var state=searches.get(actor.getUuid());row.put("actorTracked",state!=null);if(state==null)return row;
        var owner=(WeakReference<?>)read(state.getClass(),state,"owner");row.put("ownerIdentityMatches",owner.get()==actor);
        for(String field:List.of("seen","started","nextRequest","worked"))row.put(field,read(state.getClass(),state,field));
        row.put("target",block((BlockPos)read(state.getClass(),state,"target")));
        var up=(Vec3d)read(state.getClass(),state,"up");row.put("up",up==null?null:vector(up));
        var origin=(Vec3d)read(state.getClass(),state,"origin");row.put("origin",origin==null?null:vector(origin));
        var search=(BoundedFlightPath)read(state.getClass(),state,"search");
        row.put("searchStatus",search==null?null:search.status().toString());row.put("visitedNodes",search==null?null:search.visitedCells());
        row.put("readyPath",path((Path)read(state.getClass(),state,"ready")));
        var space=read(state.getClass(),state,"space");row.put("spaceCreated",space!=null);
        if(space!=null) {
            var nodes=(Map<?,?>)read(space.getClass(),space,"nodes");row.put("cachedNodeCount",nodes.size());
            row.put("firstCachedNodes",nodes.entrySet().stream().limit(8).map(e->Map.of("cell",e.getKey().toString(),"clear",e.getValue())).toList());
        }
        return row;
    }
    private static Object read(Class<?> type,Object owner,String name)throws ReflectiveOperationException {
        Field field=type.getDeclaredField(name);field.setAccessible(true);return field.get(owner);
    }
    private static Map<String,Object> path(Path path) {
        return path==null?null:Map.of("class",path.getClass().getName(),"identity",System.identityHashCode(path),
            "target",block(path.getTarget()),"length",path.getLength(),"index",path.getCurrentNodeIndex(),"finished",path.isFinished());
    }
    private static List<Double> vector(Vec3d p){return List.of(p.x,p.y,p.z);}
    private static List<Integer> block(BlockPos p){return p==null?null:List.of(p.getX(),p.getY(),p.getZ());}
}
