package com.terminaldetector.drmd.climber.mixin;

import com.terminaldetector.drmd.climber.ClimberRequestTrace;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ai.pathing.*;
import net.minecraft.entity.mob.*;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import java.util.Set;

/** Applied after main mixins so observation includes the new early return as well as vanilla returns. */
@Mixin(value=SpiderNavigation.class,priority=900)
public abstract class NativeSpiderRequestProbe extends MobNavigation {
    protected NativeSpiderRequestProbe(MobEntity actor,World world){super(actor,world);}
    @Inject(method="findPathTo(Lnet/minecraft/entity/Entity;I)Lnet/minecraft/entity/ai/pathing/Path;",at=@At("HEAD"))
    private void entityBefore(Entity target,int distance,CallbackInfoReturnable<Path> cir) {
        if(!ClimberRequestTrace.ENABLED||!(entity instanceof SpiderEntity spider))return;
        ClimberRequestTrace.observe(spider,"NATIVE_ENTITY_BEFORE",Set.of(target.getBlockPos()),null);
    }
    @Inject(method="findPathTo(Lnet/minecraft/entity/Entity;I)Lnet/minecraft/entity/ai/pathing/Path;",at=@At("RETURN"))
    private void entityAfter(Entity target,int distance,CallbackInfoReturnable<Path> cir) {
        if(!ClimberRequestTrace.ENABLED||!(entity instanceof SpiderEntity spider))return;
        ClimberRequestTrace.observe(spider,"NATIVE_ENTITY_AFTER",Set.of(target.getBlockPos()),cir.getReturnValue());
    }
    @Inject(method="findPathTo(Lnet/minecraft/util/math/BlockPos;I)Lnet/minecraft/entity/ai/pathing/Path;",at=@At("HEAD"))
    private void blockBefore(BlockPos target,int distance,CallbackInfoReturnable<Path> cir) {
        if(!ClimberRequestTrace.ENABLED||!(entity instanceof SpiderEntity spider))return;
        ClimberRequestTrace.observe(spider,"NATIVE_BLOCK_BEFORE",Set.of(target),null);
    }
    @Inject(method="findPathTo(Lnet/minecraft/util/math/BlockPos;I)Lnet/minecraft/entity/ai/pathing/Path;",at=@At("RETURN"))
    private void blockAfter(BlockPos target,int distance,CallbackInfoReturnable<Path> cir) {
        if(!ClimberRequestTrace.ENABLED||!(entity instanceof SpiderEntity spider))return;
        ClimberRequestTrace.observe(spider,"NATIVE_BLOCK_AFTER",Set.of(target),cir.getReturnValue());
    }
}
