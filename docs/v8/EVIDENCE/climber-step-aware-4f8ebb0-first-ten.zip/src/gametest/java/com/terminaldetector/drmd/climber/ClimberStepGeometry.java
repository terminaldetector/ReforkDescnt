package com.terminaldetector.drmd.climber;

import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

/** Test-only validation of the specifically recorded native selected-step route; not a collision replacement. */
public final class ClimberStepGeometry {
    public static final double EPS=1e-6;
    public record NativeStep(Box start,Box end,Vec3d requested,Vec3d adjustedRequested,Vec3d returned,
            Vec3d actualPositionDelta,Box selectedCandidateStart,Vec3d selectedCandidateResult,
            boolean actuallySelectedStep,boolean complete,boolean truncated,double nativeStepHeight) {}
    private ClimberStepGeometry() {}

    public static boolean pinnedSelectedStepClear(NativeStep step,Box barrier) {
        if(step==null||!step.actuallySelectedStep||!step.complete||step.truncated||!finite(barrier)
            ||!finite(step.start)||!finite(step.end)||!finite(step.selectedCandidateStart)||!finite(step.requested)
            ||!finite(step.adjustedRequested)||!finite(step.returned)||!finite(step.actualPositionDelta)||!finite(step.selectedCandidateResult)
            ||!same(step.start,step.selectedCandidateStart)||!same(step.requested,step.adjustedRequested)
            ||!same(step.returned,step.selectedCandidateResult)||!same(step.returned,step.actualPositionDelta)
            ||!same(step.start.offset(step.returned),step.end)||!Double.isFinite(step.nativeStepHeight)
            ||step.returned.y<=step.requested.y+EPS||step.returned.y>step.nativeStepHeight+EPS)return false;
        var plate=barrier.contract(EPS);var box=step.start;
        // This is the pinned1.21.1 resolver's axis order for the actually selected candidate.
        int[] order=Math.abs(step.returned.x)<Math.abs(step.returned.z)?new int[]{1,2,0}:new int[]{1,0,2};
        for(int axis:order) {
            var delta=axis==0?new Vec3d(step.returned.x,0,0):axis==1?new Vec3d(0,step.returned.y,0):new Vec3d(0,0,step.returned.z);
            var next=box.offset(delta);
            if(box.union(next).intersects(plate))return false;
            box=next;
        }
        return same(box,step.end);
    }
    public static boolean ordinaryChordHit(Box before,Box after,Box barrier) {
        var expanded=barrier.contract(EPS).expand(Math.max(before.getLengthX(),after.getLengthX())/2,
            Math.max(before.getLengthY(),after.getLengthY())/2,Math.max(before.getLengthZ(),after.getLengthZ())/2);
        return expanded.contains(before.getCenter())||expanded.contains(after.getCenter())||expanded.raycast(before.getCenter(),after.getCenter()).isPresent();
    }
    public static boolean same(Box a,Box b){return finite(a)&&finite(b)&&Math.abs(a.minX-b.minX)<=EPS&&Math.abs(a.minY-b.minY)<=EPS
        &&Math.abs(a.minZ-b.minZ)<=EPS&&Math.abs(a.maxX-b.maxX)<=EPS&&Math.abs(a.maxY-b.maxY)<=EPS&&Math.abs(a.maxZ-b.maxZ)<=EPS;}
    public static boolean same(Vec3d a,Vec3d b){return finite(a)&&finite(b)&&Math.abs(a.x-b.x)<=EPS&&Math.abs(a.y-b.y)<=EPS&&Math.abs(a.z-b.z)<=EPS;}
    private static boolean finite(Box b){return b!=null&&Double.isFinite(b.minX)&&Double.isFinite(b.minY)&&Double.isFinite(b.minZ)
        &&Double.isFinite(b.maxX)&&Double.isFinite(b.maxY)&&Double.isFinite(b.maxZ);}
    private static boolean finite(Vec3d v){return v!=null&&Double.isFinite(v.x)&&Double.isFinite(v.y)&&Double.isFinite(v.z);}
}
