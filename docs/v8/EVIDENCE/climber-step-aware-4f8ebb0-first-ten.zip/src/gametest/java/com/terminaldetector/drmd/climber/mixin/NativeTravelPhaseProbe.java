package com.terminaldetector.drmd.climber.mixin;

import com.terminaldetector.drmd.climber.ClimberMotionTrace;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import java.util.Map;

@Mixin(LivingEntity.class)
public abstract class NativeTravelPhaseProbe {
    @Inject(method="travel",at=@At("HEAD"))
    private void beforeTravel(Vec3d input,CallbackInfo ci){
        var actor=(LivingEntity)(Object)this;if(!ClimberMotionTrace.armed(actor))return;
        ClimberMotionTrace.record(actor,"TRAVEL_BEFORE",Map.of("nativeTravelInput",ClimberMotionTrace.vector(input)));
    }
    @Inject(method="travel",at=@At("RETURN"))
    private void afterTravel(Vec3d input,CallbackInfo ci){
        var actor=(LivingEntity)(Object)this;if(!ClimberMotionTrace.armed(actor))return;
        ClimberMotionTrace.record(actor,"TRAVEL_AFTER",Map.of("nativeTravelInput",ClimberMotionTrace.vector(input)));
    }
    @Inject(method="jump",at=@At("HEAD"))
    private void beforeJump(CallbackInfo ci){observed("JUMP_BEFORE",Map.of());}
    @Inject(method="jump",at=@At("RETURN"))
    private void afterJump(CallbackInfo ci){observed("JUMP_AFTER",Map.of());}
    @Unique private void observed(String phase,Map<String,Object> extra) {
        var actor=(LivingEntity)(Object)this;if(!ClimberMotionTrace.armed(actor))return;
        ClimberMotionTrace.record(actor,phase,extra);
    }
}
