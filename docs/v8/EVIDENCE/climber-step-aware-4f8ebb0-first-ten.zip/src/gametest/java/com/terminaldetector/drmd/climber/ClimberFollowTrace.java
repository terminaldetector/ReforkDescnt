package com.terminaldetector.drmd.climber;

import com.terminaldetector.drmd.world.gravity.*;
import net.minecraft.entity.ai.pathing.Path;
import net.minecraft.entity.mob.SpiderEntity;
import net.minecraft.entity.passive.CowEntity;
import java.util.*;

/** Passive first-follow window; original phase recorder retains its four-active/256-event budgets. */
public final class ClimberFollowTrace {
    public static final boolean ENABLED=Boolean.getBoolean("drmd.gate.climberFollowPhases");
    private static final int MAX_SEEN=6;
    private static final Set<UUID> SEEN=new HashSet<>();
    private static final Map<UUID,Integer> FIRST_FOLLOW_AGE=new HashMap<>();
    private static final Set<UUID> AUTO_ARMED=new HashSet<>();
    private ClimberFollowTrace() {}

    public static void before(SpiderEntity actor,LocalSurfacePath path,double speed) {
        if(!ENABLED||!ClimberMotionTrace.ENABLED||!LocalSurfaceNavigation.framed(actor))return;
        if(!SEEN.contains(actor.getUuid())) {
            if(SEEN.size()>=MAX_SEEN||!(actor.getTarget() instanceof CowEntity target))return;
            SEEN.add(actor.getUuid());FIRST_FOLLOW_AGE.put(actor.getUuid(),actor.age);
            if(!ClimberMotionTrace.armed(actor)) {
                var up=ActorFrames.up(actor);double height=actor.getEyePos().subtract(actor.getPos()).dotProduct(up);
                // This observer baseline is the first actual follow, not the actor's creation age.
                ClimberMotionTrace.armForFollow(actor,target,up,height,"LOCAL_PATH_FIRST_FOLLOW");AUTO_ARMED.add(actor.getUuid());
            }
        }
        capture(actor,path,speed,"FOLLOW_BEFORE",null);
    }
    public static void after(SpiderEntity actor,LocalSurfacePath path,double speed,boolean result) {
        if(!ENABLED||!ClimberMotionTrace.ENABLED||!ClimberMotionTrace.armed(actor))return;
        capture(actor,path,speed,"FOLLOW_AFTER",result);
    }
    private static void capture(SpiderEntity actor,LocalSurfacePath path,double speed,String phase,Boolean result) {
        if(!ClimberMotionTrace.armed(actor))return;
        var extra=new LinkedHashMap<String,Object>();extra.put("nativePath",path(path));extra.put("followSpeed",speed);
        extra.put("waypoint",ClimberMotionTrace.vector(path.getNodePosition(actor)));extra.put("followResult",result);
        extra.put("firstFollowActualAge",FIRST_FOLLOW_AGE.get(actor.getUuid()));extra.put("autoArmedAtFirstFollow",AUTO_ARMED.contains(actor.getUuid()));
        extra.put("observerSpawnAgeFieldIsArmBaseline",true);
        try {extra.put("boundedCacheSnapshot",ClimberRequestTrace.state(actor));}
        catch(ReflectiveOperationException failure){throw new IllegalStateException("climber follow observer reflection failed",failure);}
        ClimberMotionTrace.record(actor,phase,extra);
    }
    public static void pounce(SpiderEntity actor,boolean before,float nativeLeapVelocity) {
        if(!ENABLED||!ClimberMotionTrace.ENABLED||!ClimberMotionTrace.armed(actor))return;
        var extra=new LinkedHashMap<String,Object>();extra.put("nativePounceVelocity",nativeLeapVelocity);
        extra.put("nativePath",path(actor.getNavigation().getCurrentPath()));
        extra.put("firstFollowActualAge",FIRST_FOLLOW_AGE.get(actor.getUuid()));
        ClimberMotionTrace.record(actor,before?"POUNCE_BEFORE":"POUNCE_AFTER",extra);
    }
    private static Map<String,Object> path(Path path) {
        return path==null?null:Map.of("class",path.getClass().getName(),"identity",System.identityHashCode(path),
            "index",path.getCurrentNodeIndex(),"length",path.getLength(),"finished",path.isFinished());
    }
}
