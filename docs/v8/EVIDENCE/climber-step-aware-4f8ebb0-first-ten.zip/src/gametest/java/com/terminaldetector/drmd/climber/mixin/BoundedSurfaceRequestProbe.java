package com.terminaldetector.drmd.climber.mixin;

import com.terminaldetector.drmd.climber.ClimberRequestTrace;
import com.terminaldetector.drmd.world.gravity.LocalSurfaceNavigation;
import net.minecraft.entity.ai.pathing.Path;
import net.minecraft.entity.mob.SpiderEntity;
import net.minecraft.util.math.BlockPos;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import java.util.Set;

@Mixin(value=LocalSurfaceNavigation.class,remap=false)
public abstract class BoundedSurfaceRequestProbe {
    @Inject(method="request",at=@At("HEAD"),remap=false)
    private static void before(SpiderEntity actor,Set<BlockPos> targets,float range,CallbackInfoReturnable<Path> cir) {
        if(!ClimberRequestTrace.ENABLED)return;ClimberRequestTrace.observe(actor,"BOUNDED_BEFORE",targets,null);
    }
    @Inject(method="request",at=@At("RETURN"),remap=false)
    private static void after(SpiderEntity actor,Set<BlockPos> targets,float range,CallbackInfoReturnable<Path> cir) {
        if(!ClimberRequestTrace.ENABLED)return;ClimberRequestTrace.observe(actor,"BOUNDED_AFTER",targets,cir.getReturnValue());
    }
    @Inject(method="pending",at=@At("HEAD"),remap=false)
    private static void pendingBefore(SpiderEntity actor,CallbackInfo ci) {
        if(!ClimberRequestTrace.ENABLED)return;ClimberRequestTrace.observe(actor,"PENDING_BEFORE",Set.of(),null);
    }
    @Inject(method="pending",at=@At("RETURN"),remap=false)
    private static void pendingAfter(SpiderEntity actor,CallbackInfo ci) {
        if(!ClimberRequestTrace.ENABLED)return;ClimberRequestTrace.observe(actor,"PENDING_AFTER",Set.of(),null);
    }
}
