package com.terminaldetector.drmd.climber;

import net.minecraft.test.TestContext;
import net.minecraft.entity.Entity;
import net.minecraft.entity.mob.SpiderEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.*;
import java.lang.ref.WeakReference;
import java.util.*;

/** Passive old-fixture clocks/readiness, without changing the old source, tickets or time budgets. */
public final class ClimberBarrierWatch {
    public static final boolean ENABLED=Boolean.getBoolean("drmd.gate.climberBarrierWatch");
    private static WeakReference<TestContext> constructing=new WeakReference<>(null);
    private static String constructingCase;private static int required;
    public static final class RoomStats {
        final String fixture;final int requiredTicks;final long constructorTick,constructorWorldTime;
        final Map<UUID,Map<String,Object>> spawns=new LinkedHashMap<>();final ArrayDeque<Map<String,Object>> lastDarkFailures=new ArrayDeque<>();
        long loadedCalls,loadedFalse,firstFullTick=-1,lastLoadedTick=-1,darkCalls,darkFalse,firstDarkTick=-1;
        boolean lastLoadedFull;public boolean observerOrigin,snapshotWritten;
        RoomStats(String fixture,int requiredTicks,TestContext c,ServerWorld world){this.fixture=fixture;this.requiredTicks=requiredTicks;constructorTick=c.getTick();constructorWorldTime=world.getTime();}
    }
    private ClimberBarrierWatch() {}
    public static void begin(TestContext c,String fixture,int ordinaryTicks){if(ENABLED){constructing=new WeakReference<>(c);constructingCase=fixture;required=ordinaryTicks;}}
    public static void end(TestContext c){if(ENABLED&&constructing.get()==c)constructing.clear();}
    public static RoomStats room(TestContext c,ServerWorld world){return ENABLED&&constructing.get()==c?new RoomStats(constructingCase,required,c,world):null;}
    public static boolean usesExisting309Read(RoomStats stats){return stats!=null&&stats.fixture.equals("OLD_CEILING");}
    public static void loaded(RoomStats stats,TestContext c,boolean full) {
        if(stats==null)return;stats.lastLoadedTick=c.getTick();stats.lastLoadedFull=full;
        if(stats.observerOrigin)return;stats.loadedCalls++;if(!full)stats.loadedFalse++;
        else if(stats.firstFullTick<0)stats.firstFullTick=c.getTick();
    }
    public static void dark(RoomStats stats,TestContext c,Vec3d eye,boolean dark) {
        if(stats==null)return;stats.darkCalls++;if(dark){if(stats.firstDarkTick<0)stats.firstDarkTick=c.getTick();return;}
        stats.darkFalse++;stats.lastDarkFailures.addLast(Map.of("contextTick",c.getTick(),"eye",ClimberAirAcceptance.vector(eye),"actualNativeResult",false));
        while(stats.lastDarkFailures.size()>4)stats.lastDarkFailures.removeFirst();
    }
    public static void spawned(RoomStats stats,TestContext c,ServerWorld world,Entity actor) {
        if(stats==null||!(actor instanceof SpiderEntity))return;
        if(stats.spawns.size()>=2)throw new IllegalStateException("oldfixture spawn observer budget exceeded");
        stats.spawns.put(actor.getUuid(),Map.of("entityAge",actor.age,"fixtureTick",c.getTick(),"worldTime",world.getTime(),
            "serverTick",world.getServer().getTicks(),"nativeIdleTimeout",idle(world),"shouldTickEntity",world.shouldTickEntity(actor.getBlockPos()),
            "forcedColumn",world.getForcedChunks().contains(new ChunkPos(actor.getBlockPos()).toLong())));
    }
    public static void record(RoomStats stats,TestContext c,ServerWorld world,List<Entity> actors,boolean built,boolean closed,boolean full) {
        var rows=new ArrayList<Map<String,Object>>();
        for(var entity:actors)if(entity instanceof SpiderEntity actor) {
            if(rows.size()>=2)throw new IllegalStateException("oldfixture309 observer actor budget exceeded");
            var row=new LinkedHashMap<String,Object>();row.put("uuid",actor.getUuid().toString());row.put("type",actor.getType().toString());
            row.put("actualAge",actor.age);var spawn=stats.spawns.get(actor.getUuid());row.put("actualSpawnObservation",spawn);
            if(spawn!=null) {
                long tick=((Number)spawn.get("fixtureTick")).longValue();row.put("elapsedFixtureTicksSinceSpawn",c.getTick()-tick);
                row.put("elapsedWorldTicksSinceSpawn",world.getTime()-((Number)spawn.get("worldTime")).longValue());
                row.put("actualEntityAgeAdvance",actor.age-((Number)spawn.get("entityAge")).intValue());
                row.put("watch310MinusActualSpawnTick",310-tick);row.put("budgetEnoughForFrozenWindowArithmeticOnly",310-tick>=stats.requiredTicks+1);
            }
            row.put("alive",actor.isAlive());row.put("health",actor.getHealth());row.put("removed",actor.isRemoved());
            row.put("worldOwnsEntity",world.getEntityById(actor.getId())==actor);row.put("shouldTickEntity",world.shouldTickEntity(actor.getBlockPos()));
            row.put("forcedColumn",world.getForcedChunks().contains(new ChunkPos(actor.getBlockPos()).toLong()));
            row.put("position",ClimberAirAcceptance.vector(actor.getPos()));row.put("eye",ClimberAirAcceptance.vector(actor.getEyePos()));
            var box=actor.getBoundingBox();row.put("bounds",List.of(box.minX,box.minY,box.minZ,box.maxX,box.maxY,box.maxZ));
            row.put("velocity",ClimberAirAcceptance.vector(actor.getVelocity()));row.put("navigationIdle",actor.getNavigation().isIdle());
            row.put("localUp",ClimberAirAcceptance.vector(com.terminaldetector.drmd.world.gravity.ActorFrames.up(actor)));
            var field=com.terminaldetector.drmd.world.gravity.GravityFields.sample(world,actor.getPos());
            row.put("fieldStrength",field==null?null:field.strength());row.put("fieldUp",field==null?null:ClimberAirAcceptance.vector(field.upDir()));
            var path=actor.getNavigation().getCurrentPath();row.put("path",path==null?null:Map.of("identity",System.identityHashCode(path),"index",path.getCurrentNodeIndex(),"length",path.getLength()));
            rows.add(row);
        }
        var report=new LinkedHashMap<String,Object>();report.put("fixture",stats.fixture);report.put("requiredOrdinaryTicks",stats.requiredTicks);
        report.put("testTick",c.getTick());report.put("worldTime",world.getTime());report.put("serverTick",world.getServer().getTicks());
        report.put("nativeIdleTimeout",idle(world));report.put("built",built);report.put("closed",closed);report.put("fixtureFull",full);
        report.put("constructorFixtureTick",stats.constructorTick);report.put("constructorWorldTime",stats.constructorWorldTime);
        report.put("actualLoadedCalls",stats.loadedCalls);report.put("actualLoadedFalse",stats.loadedFalse);report.put("firstActualFullFixtureTick",stats.firstFullTick);
        report.put("lastLoadedReadFixtureTick",stats.lastLoadedTick);report.put("lastLoadedReadWasObserverOrigin",stats.observerOrigin);
        report.put("actualDarkCalls",stats.darkCalls);report.put("actualDarkFalse",stats.darkFalse);report.put("firstAnyDarkFixtureTick",stats.firstDarkTick);
        report.put("last4ActualFailedDarkReads",new ArrayList<>(stats.lastDarkFailures));report.put("actors",rows);
        System.out.println("CLIMBER_OLD_FIXTURE_309 "+new com.google.gson.Gson().toJson(report));
    }
    private static int idle(ServerWorld world) {
        try {var field=ServerWorld.class.getDeclaredField("idleTimeout");field.setAccessible(true);return field.getInt(world);}
        catch(ReflectiveOperationException failure){throw new IllegalStateException("oldfixture idle observer contract mismatch",failure);}
    }
}
