package com.terminaldetector.drmd;

import com.terminaldetector.drmd.climber.ClimberStepGeometry;
import com.terminaldetector.drmd.climber.ClimberStepGeometry.NativeStep;
import net.fabricmc.fabric.api.gametest.v1.FabricGameTest;
import net.minecraft.test.*;
import net.minecraft.util.math.*;

/** Pure geometry controls in the test source set; no world/actor writes or production API. */
public final class ClimberStepGeometryGameTests implements FabricGameTest {
    private static final Box START=new Box(0,25.59143284654331,-1.399999976158142,.8999999761581421,26.99143282270145,0);
    private static final Vec3d REQUEST=new Vec3d(.4000000059604645,.19396389846429676,.35058273513675187);
    private static final Vec3d STEP=new Vec3d(.4000000059604645,.4085671603679657,.35058273513675187);
    private static NativeStep sample(Box end,boolean selected,boolean truncated) {
        return new NativeStep(START,end,REQUEST,REQUEST,STEP,STEP,START,STEP,selected,true,truncated,.6);
    }
    @GameTest(templateName=EMPTY_STRUCTURE,batchId="climber-geometry-legal-step",tickLimit=10)
    public void selectedClearStepCanHaveAnIntersectingOrdinaryChord(TestContext c) {
        var end=START.offset(STEP);var plate=new Box(0,25,0,15,26,9);
        c.assertTrue(ClimberStepGeometry.ordinaryChordHit(START,end,plate),"control must reproduce the actual coarse-chord false positive");
        c.assertTrue(ClimberStepGeometry.pinnedSelectedStepClear(sample(end,true,false),plate),"pinned actual selected YXZ route is clear at the originalepsilon");c.complete();
    }
    @GameTest(templateName=EMPTY_STRUCTURE,batchId="climber-geometry-blocked-step",tickLimit=10)
    public void blockedSegmentsOrMissingIdentityCannotExcuseAChord(TestContext c) {
        var end=START.offset(STEP);var raisedPlate=new Box(0,25,0,15,26.3,9);
        c.assertTrue(!ClimberStepGeometry.pinnedSelectedStepClear(sample(end,true,false),raisedPlate),"real blocked Z segment must fail despite a selected-step label");
        var plate=new Box(0,25,0,15,26,9);
        c.assertTrue(!ClimberStepGeometry.pinnedSelectedStepClear(sample(end,false,false),plate),"candidate-only data cannot prove an actual step");
        c.assertTrue(!ClimberStepGeometry.pinnedSelectedStepClear(sample(end,true,true),plate),"truncated trace remains fail-closed");
        c.assertTrue(!ClimberStepGeometry.pinnedSelectedStepClear(sample(end.offset(.01,0,0),true,false),plate),"actual move endpoint must match the selected result");
        c.assertTrue(!ClimberStepGeometry.pinnedSelectedStepClear(null,plate),"missing trace remains fail-closed");c.complete();
    }
}
