package com.terminaldetector.drmd.climber.mixin;

import com.terminaldetector.drmd.climber.ClimberMotionTrace;
import net.minecraft.entity.mob.MobEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import java.util.Map;

@Mixin(MobEntity.class)
public abstract class NativeAiPhaseProbe {
    @Inject(method="tickNewAi",at=@At(value="INVOKE",target="Lnet/minecraft/entity/ai/pathing/EntityNavigation;tick()V"))
    private void beforeNavigation(CallbackInfo ci){observed("NAV_BEFORE");}
    @Inject(method="tickNewAi",at=@At(value="INVOKE",target="Lnet/minecraft/entity/ai/pathing/EntityNavigation;tick()V",shift=At.Shift.AFTER))
    private void afterNavigation(CallbackInfo ci){observed("NAV_AFTER");}
    @Inject(method="tickNewAi",at=@At(value="INVOKE",target="Lnet/minecraft/entity/ai/control/MoveControl;tick()V"))
    private void beforeMotor(CallbackInfo ci){observed("MOTOR_BEFORE");}
    @Inject(method="tickNewAi",at=@At(value="INVOKE",target="Lnet/minecraft/entity/ai/control/MoveControl;tick()V",shift=At.Shift.AFTER))
    private void afterMotor(CallbackInfo ci){observed("MOTOR_AFTER");}
    @Unique private void observed(String phase) {
        var actor=(MobEntity)(Object)this;if(!ClimberMotionTrace.armed(actor))return;
        ClimberMotionTrace.record(actor,phase,Map.of());
    }
}
