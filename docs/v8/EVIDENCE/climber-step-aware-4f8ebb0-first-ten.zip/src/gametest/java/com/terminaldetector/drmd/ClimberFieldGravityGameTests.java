package com.terminaldetector.drmd;

import com.terminaldetector.drmd.d6.D6ChunkPos;
import com.terminaldetector.drmd.world.access.WorldAccess;
import com.terminaldetector.drmd.world.gravity.ActorFrames;
import com.terminaldetector.drmd.world.gravity.EntityGravitySystem;
import com.terminaldetector.drmd.world.gravity.FieldShape;
import com.terminaldetector.drmd.world.gravity.GravityFields;
import net.fabricmc.fabric.api.gametest.v1.FabricGameTest;
import net.minecraft.block.Blocks;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.SpiderEntity;
import net.minecraft.entity.passive.CowEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.test.GameTest;
import net.minecraft.test.TestContext;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.*;
import net.minecraft.world.LightType;
import net.minecraft.world.RaycastContext;

import java.util.*;
import java.util.function.BooleanSupplier;

/** First-entry ownership, independent floor admission and real wall/ceiling pursuit contracts. */
public final class ClimberFieldGravityGameTests implements FabricGameTest {
    private static final EntityType<?>[] TYPES={EntityType.SPIDER,EntityType.CAVE_SPIDER};
    private static final Direction[] AXES={Direction.EAST,Direction.UP,Direction.DOWN,Direction.NORTH,Direction.SOUTH,Direction.WEST};
    private static final int ORDINARY_TICKS=60;
    private static final double MINIMUM_PURSUIT=1;

    @GameTest(templateName=EMPTY_STRUCTURE,batchId="climber-field-entry",tickLimit=180)
    public void firstEntryRetainsClimberPositionAndNativeOwnership(TestContext context) {
        var centre=context.getAbsolutePos(new BlockPos(6,80,6));
        var room=new Room(context,centre.add(-3,-3,-3),centre.add(3,3,3));
        watch(context,room,170,()->{
            if(!room.loaded())return false;
            room.build();
            for(var type:TYPES)for(boolean noGravity:new boolean[]{false,true}) {
                // An actual ordinary-floor field entry must be valid before wall cases are interpreted.
                var floor=spawnSpider(room,type,new Vec3d(centre.getX()+.5,room.min.getY()+1.02,centre.getZ()+.5),true,noGravity);
                UUID baseline=room.field(centre,new Vec3d(0,-1,0));
                var floorStart=floor.getPos();var navigation=floor.getNavigation();var control=floor.getMoveControl();
                EntityGravitySystem.tick(room.world.getServer());
                var support=room.world.raycast(new RaycastContext(floorStart.add(0,.1,0),floorStart.add(0,-.2,0),
                    RaycastContext.ShapeType.COLLIDER,RaycastContext.FluidHandling.NONE,floor));
                emit("ORDINARY_FLOOR_ENTRY",floorStart,floor,Map.of("type",type.toString(),"externallyOwnedNoGravity",noGravity));
                context.assertTrue(support.getType()==HitResult.Type.BLOCK&&support.getSide()==Direction.UP
                    &&floor.getPos().distanceTo(floorStart)<1e-9&&floor.isOnGround()&&room.world.isSpaceEmpty(floor),
                    "ordinary-floor entry fixture must be valid before C2 wall diagnosis: "+type);
                context.assertTrue(floor.getNavigation()==navigation&&floor.getMoveControl()==control&&floor.hasNoGravity()==noGravity,
                    "ordinary-floor control retains native objects and saved gravity flag: "+type);
                room.removeField(baseline);floor.discard();

                var actor=spawnSpider(room,type,Vec3d.ofCenter(centre),true,noGravity);
                try {
                    var origin=actor.getPos();var nav=actor.getNavigation();var move=actor.getMoveControl();
                    double originalGravity=actor.getFinalGravity();actor.setYaw(37);actor.setPitch(-20);
                    for(var axis:AXES) {
                        var down=Vec3d.of(axis.getVector());var propulsion=new Vec3d(.17,.03,-.04);
                        actor.setOnGround(false);actor.setVelocity(propulsion);
                        var before=state(actor);UUID field=room.field(centre,down);
                        EntityGravitySystem.tick(room.world.getServer());
                        var details=new LinkedHashMap<String,Object>();details.put("type",type.toString());details.put("axis",axis.toString());
                        details.put("before",before);details.put("externallyOwnedNoGravity",noGravity);
                        // Unsupported orientation is diagnostic only; no absent frame/classifier assertion.
                        emit("FIRST_FIELD_ENTRY",origin,actor,details);
                        context.assertTrue(actor.getPos().distanceTo(origin)<1e-9,
                            "first C2 field pass must not teleport an airborne climber onto a standing surface: "+type+" "+axis);
                        var tangent=propulsion.subtract(down.multiply(propulsion.dotProduct(down)));
                        context.assertTrue(!actor.isOnGround()&&actor.isAiDisabled()&&actor.getVelocity().dotProduct(tangent)>1e-4
                            &&actor.getNavigation()==nav&&actor.getMoveControl()==move&&actor.hasNoGravity()==noGravity
                            &&room.world.isSpaceEmpty(actor),"field cannot manufacture contact, erase propulsion or replace native control: "+type+" "+axis);
                        room.removeField(field);
                        context.assertTrue(!EntityGravitySystem.suppressesVanillaGravity(actor)&&actor.hasNoGravity()==noGravity
                            &&Math.abs(actor.getFinalGravity()-originalGravity)<1e-9,"field release restores original acceleration ownership: "+type);
                    }
                } finally {actor.discard();}
            }
            return true;
        });
    }

    @GameTest(templateName=EMPTY_STRUCTURE,batchId="climber-floor-admission",tickLimit=320)
    public void ordinaryFloorNativePursuitAdmitsOneAssignedCowTarget(TestContext context) {
        var centre=context.getAbsolutePos(new BlockPos(6,80,6));
        var room=new Room(context,centre.add(-8,0,-8),centre.add(8,5,8));
        var actors=new ArrayList<Pursuit>();boolean[] spawned={false};
        watch(context,room,310,()->{
            if(!room.loaded())return false;
            room.build();
            if(!spawned[0]) {
                // Wait for propagated darkness at both real start/target columns before enabling AI.
                for(int x:new int[]{-3,3}) {
                    var eyes=new Vec3d(centre.getX()+x+.5,room.min.getY()+1.7,centre.getZ()-3.5);
                    if(!room.dark(eyes)||!room.dark(eyes.add(0,0,5)))return false;
                }
                int index=0;
                for(var type:TYPES) {
                    var start=new Vec3d(centre.getX()+(index++==0?-3:3)+.5,room.min.getY()+1.02,centre.getZ()-3.5);
                    var actor=spawnSpider(room,type,start,false,false);
                    CowEntity target=EntityType.COW.create(room.world);target.setAiDisabled(true);target.setNoGravity(true);target.setInvulnerable(true);
                    target.setPosition(start.add(0,0,5));room.spawn(target);
                    actor.setTarget(target); // one explicit fixture assignment; not Spider's natural player/golem target choice
                    actors.add(new Pursuit(actor,target,start));
                }
                spawned[0]=true;return false;
            }
            boolean ready=true;
            for(var pursuit:actors) {
                var actor=pursuit.actor;
                context.assertTrue(room.dark(actor.getEyePos()),"ordinary-floor admission requires genuinely dark eyes; do not diagnose bright-light aggression reset");
                if(actor.age>pursuit.lastAge) {
                    pursuit.maxStep=Math.max(pursuit.maxStep,actor.getPos().distanceTo(pursuit.lastPosition));
                    pursuit.lastPosition=actor.getPos();pursuit.lastAge=actor.age;
                    pursuit.navigatorActive|=!actor.getNavigation().isIdle();
                    pursuit.targetRetained|=actor.getTarget()==pursuit.target;
                }
                if(actor.age-pursuit.spawnAge<ORDINARY_TICKS)ready=false;
            }
            if(!ready)return false;
            for(var pursuit:actors) {
                var actor=pursuit.actor;
                double improvement=pursuit.initialDistance-actor.getPos().distanceTo(pursuit.target.getPos());
                emit("ORDINARY_FLOOR_AI_ADMISSION",pursuit.start,actor,Map.of(
                    "assignedCowTargetOnce",true,"ordinaryEntityTicks",actor.age-pursuit.spawnAge,
                    "navigatorObservedActive",pursuit.navigatorActive,"targetRetained",actor.getTarget()==pursuit.target,
                    "distanceImprovement",improvement,"maximumObservedStep",pursuit.maxStep,
                    "manualEntityTicks",false,"repeatedNavigationOrVelocityCommands",false,
                    "eyeLight",List.of(room.world.getLightLevel(LightType.SKY,BlockPos.ofFloored(actor.getEyePos())),
                        room.world.getLightLevel(LightType.BLOCK,BlockPos.ofFloored(actor.getEyePos()))),"noGlobalTimeWeatherWrites",true));
                context.assertTrue(actor.isAlive()&&!actor.isAiDisabled()&&pursuit.targetRetained&&actor.getTarget()==pursuit.target
                    &&pursuit.navigatorActive&&improvement>=MINIMUM_PURSUIT&&pursuit.maxStep<=1
                    &&actor.getNavigation()==pursuit.navigation&&actor.getMoveControl()==pursuit.control,
                    "ordinary-floor native Cow pursuit admission failed; wall/ceiling AI cannot be interpreted: "+actor.getType());
            }
            return true;
        });
    }

    @GameTest(templateName=EMPTY_STRUCTURE,batchId="climber-wall-pursuit",tickLimit=320)
    public void realWallPursuitAdvancesVerticallyWithMeasuredSupport(TestContext context) {
        surfacePursuit(context,false);
    }

    @GameTest(templateName=EMPTY_STRUCTURE,batchId="climber-ceiling-pursuit",tickLimit=320)
    public void realCeilingPursuitAdvancesTangentiallyWithMeasuredSupport(TestContext context) {
        surfacePursuit(context,true);
    }

    @GameTest(templateName=EMPTY_STRUCTURE,batchId="climber-wall-route",tickLimit=320)
    public void wallRouteUsesSupportedSidePassageWithoutBarrierPhasing(TestContext context) {
        var centre=context.getAbsolutePos(new BlockPos(6,80,6));
        var room=new Room(context,centre.add(-8,0,-8),centre.add(8,12,8));
        var up=new Vec3d(1,0,0);int plateY=room.min.getY()+5;
        // A real full-depth plate blocks direct +Y travel; two three-block-wide Z passages remain.
        var barrier=new Box(room.min.getX()+1,plateY,centre.getZ()-4,room.max.getX(),plateY+1,centre.getZ()+5);
        var actors=new ArrayList<RoutePursuit>();boolean[] barrierBuilt={false},spawned={false};
        watch(context,room,310,()->{
            if(!room.loaded())return false;
            room.build();
            if(!barrierBuilt[0]) {
                for(var at:BlockPos.iterate(new BlockPos(room.min.getX()+1,plateY,centre.getZ()-4),
                    new BlockPos(room.max.getX()-1,plateY,centre.getZ()+4)))
                    room.world.setBlockState(at,Blocks.OBSIDIAN.getDefaultState(),2);
                barrierBuilt[0]=true;
            }
            if(!spawned[0]) {
                for(int index=0;index<TYPES.length;index++) {
                    var start=routeStart(room,centre,index);
                    for(int offset=0;offset<=2;offset++)
                        if(!room.dark(start.add(up.multiply(offset)))||!room.dark(start.add(0,5,0).add(up.multiply(offset))))return false;
                }
                for(int index=0;index<TYPES.length;index++) {
                    var actor=(SpiderEntity)TYPES[index].create(room.world);
                    context.assertTrue(actor!=null&&!actor.isAiDisabled(),"FIXTURE_ADMISSION: native route AI starts enabled");
                    actor.setPersistent();var start=routeStart(room,centre,index);
                    double eye=admitSurfaceActor(room,actor,start,up,"WALL_ROUTE_PASSAGE");
                    var target=EntityType.COW.create(room.world);target.setAiDisabled(true);target.setNoGravity(true);target.setInvulnerable(true);
                    double targetEye=admitSurfaceActor(room,target,start.add(0,5,0),up,"WALL_ROUTE_PASSAGE");
                    actors.add(new RoutePursuit(new SurfacePursuit(new Pursuit(actor,target,start),eye,targetEye)));
                }
                room.field(centre.add(0,6,0),up.negate());EntityGravitySystem.tick(room.world.getServer());
                for(var route:actors) {
                    var p=route.surface;var actor=p.base.actor;
                    var initial=measureSupport(room,actor,up,p.eyeHeight);
                    var targetInitial=measureSupport(room,p.base.target,up,p.targetEyeHeight);
                    emit("WALL_ROUTE_PASSAGE_ADMITTED",p.base.start,actor,Map.of(
                        "initialSupport",initial.details(),"initialTargetSupport",targetInitial.details(),
                        "barrierBounds",bounds(barrier),"passageZBounds",List.of(List.of(room.min.getZ()+1,centre.getZ()-4),List.of(centre.getZ()+5,room.max.getZ())),
                        "requiredOrdinaryTicks",120,"oneInitialFieldPass",true,"fullFixtureVolumesAvailable",room.loaded()));
                    context.assertTrue(initial.valid()&&targetInitial.valid()&&room.dark(actor.getEyePos())&&room.dark(p.base.target.getEyePos()),
                        "FIXTURE_ADMISSION: route collider/body/eye support must be real before navigation");
                    actor.setTarget(p.base.target); // the sole target assignment; native goals own every subsequent command
                }
                spawned[0]=true;return false;
            }
            boolean ready=true;
            for(var route:actors) {
                var p=route.surface;var base=p.base;var actor=base.actor;
                context.assertTrue(room.dark(actor.getEyePos()),"FIXTURE_ADMISSION: natural wall route requires actual dark eyes");
                if(actor.age>base.lastAge) {
                    var box=actor.getBoundingBox();var before=route.previousBox;var displacement=actor.getPos().subtract(base.lastPosition);
                    base.maxStep=Math.max(base.maxStep,displacement.length());base.lastPosition=actor.getPos();base.lastAge=actor.age;
                    base.navigatorActive|=!actor.getNavigation().isIdle();base.targetRetained|=actor.getTarget()==base.target;
                    context.assertTrue(diagnosticSupportAvailable(room,actor,up),"FIXTURE_ADMISSION: route support observation requires FULL bounded query volumes");
                    var support=measureSupport(room,actor,up,p.eyeHeight);p.last=support;p.samples++;
                    if(support.gap()!=null)p.maxGap=Math.max(p.maxGap,support.gap());
                    if(!support.valid())p.invalidSupport++;
                    if(!support.hit())p.missingSupport++;
                    p.minNormalDot=Math.min(p.minNormalDot,support.normalDot());p.maxEyeError=Math.max(p.maxEyeError,support.eyeError());
                    p.maxUpError=Math.max(p.maxUpError,support.upError());
                    var expanded=barrier.contract(1e-6).expand(Math.max(before.getLengthX(),box.getLengthX())/2,
                        Math.max(before.getLengthY(),box.getLengthY())/2,Math.max(before.getLengthZ(),box.getLengthZ())/2);
                    if(expanded.contains(before.getCenter())||expanded.contains(box.getCenter())
                        ||expanded.raycast(before.getCenter(),box.getCenter()).isPresent())route.barrierSweepViolations++;
                    boolean inBand=box.maxY>plateY+1e-6&&box.minY<plateY+1-1e-6;
                    boolean inPassage=box.minZ>=room.min.getZ()+1-1e-6&&box.maxZ<=centre.getZ()-4+1e-6
                        ||box.minZ>=centre.getZ()+5-1e-6&&box.maxZ<=room.max.getZ()+1e-6;
                    if(inBand&&inPassage&&support.valid()) {
                        route.usedPassage=true;
                        if(route.passageWitnesses.size()<16)route.passageWitnesses.add(Map.of(
                            "ordinaryEntityTicks",actor.age-base.spawnAge,"bounds",bounds(box),"support",support.details()));
                    }
                    route.crossedPlate|=box.minY>=plateY+1+1e-6;
                    route.maximumZExcursion=Math.max(route.maximumZExcursion,Math.abs(actor.getZ()-base.start.z));
                    var path=actor.getNavigation().getCurrentPath();
                    if(path!=null) {route.nativePathObserved=true;route.maximumPathIndex=Math.max(route.maximumPathIndex,path.getCurrentNodeIndex());
                        route.pathIdentities.add(System.identityHashCode(path));route.maximumPathLength=Math.max(route.maximumPathLength,path.getLength());}
                    route.previousBox=box;
                }
                if(actor.age-base.spawnAge<120)ready=false;
            }
            if(!ready)return false;
            for(var route:actors) {
                var p=route.surface;var base=p.base;var actor=base.actor;
                double improvement=base.initialDistance-actor.getPos().distanceTo(base.target.getPos());
                var details=new LinkedHashMap<String,Object>();details.put("ordinaryEntityTicks",actor.age-base.spawnAge);
                details.put("distanceImprovement",improvement);details.put("verticalAdvance",actor.getY()-base.start.y);
                details.put("maximumObservedStep",base.maxStep);details.put("maximumMeasuredFeetGap",p.maxGap);
                details.put("supportSamples",p.samples);details.put("invalidSupportSamples",p.invalidSupport);
                details.put("missingSupportSamples",p.missingSupport);details.put("minimumNormalDotLocalUp",p.minNormalDot);
                details.put("maximumEyeTransformError",p.maxEyeError);details.put("maximumLocalUpError",p.maxUpError);
                details.put("barrierSweepViolations",route.barrierSweepViolations);details.put("usedSupportedPassage",route.usedPassage);
                details.put("crossedPlateWithEntireBody",route.crossedPlate);details.put("passageWitnesses",route.passageWitnesses);
                details.put("maximumZExcursion",route.maximumZExcursion);details.put("nativePathObserved",route.nativePathObserved);
                details.put("maximumNativePathIndex",route.maximumPathIndex);details.put("maximumNativePathLength",route.maximumPathLength);
                details.put("observedNativePathIdentities",route.pathIdentities);details.put("navigatorObservedActive",base.navigatorActive);
                details.put("targetRetained",actor.getTarget()==base.target);details.put("fullFixtureVolumesAvailable",room.loaded());
                details.put("barrierBounds",bounds(barrier));details.put("manualEntityTicks",false);
                details.put("repeatedNavigationOrVelocityCommands",false);details.put("assignedCowTargetOnce",true);
                emit("WALL_ROUTE_PASSAGE",base.start,actor,details);
                context.assertTrue(actor.isAlive()&&!actor.isAiDisabled()&&!actor.hasNoGravity()
                    &&base.targetRetained&&actor.getTarget()==base.target&&base.navigatorActive&&route.nativePathObserved
                    &&route.maximumPathIndex>=1&&actor.getNavigation()==base.navigation&&actor.getMoveControl()==base.control
                    &&improvement>=1&&actor.getY()-base.start.y>=1&&base.maxStep<=1
                    &&p.samples>=120&&p.invalidSupport==0&&p.missingSupport==0
                    &&route.barrierSweepViolations==0&&route.usedPassage&&route.crossedPlate,
                    "C2 native wall route must use a supported passage without barrier phasing: "+actor.getType());
            }
            return true;
        });
    }

    private static Vec3d routeStart(Room room,BlockPos centre,int index) {
        return new Vec3d(room.min.getX()+1.02,room.min.getY()+2.5,centre.getZ()+(index==0?-2.5:2.5));
    }
    private static List<Double> bounds(Box b){return List.of(b.minX,b.minY,b.minZ,b.maxX,b.maxY,b.maxZ);}
    private static final class RoutePursuit {
        final SurfacePursuit surface;Box previousBox;
        boolean usedPassage,crossedPlate,nativePathObserved;int barrierSweepViolations,maximumPathIndex,maximumPathLength;
        double maximumZExcursion;final Set<Integer> pathIdentities=new LinkedHashSet<>();
        final List<Map<String,Object>> passageWitnesses=new ArrayList<>();
        RoutePursuit(SurfacePursuit surface){this.surface=surface;previousBox=surface.base.actor.getBoundingBox();}
    }

    private static void surfacePursuit(TestContext context,boolean ceiling) {
        var centre=context.getAbsolutePos(new BlockPos(6,80,6));
        var room=new Room(context,centre.add(-8,0,-8),centre.add(8,12,8));
        var up=ceiling?new Vec3d(0,-1,0):new Vec3d(1,0,0);
        var tangent=ceiling?new Vec3d(0,0,1):new Vec3d(0,1,0);
        var actors=new ArrayList<SurfacePursuit>();boolean[] spawned={false};
        String phase=ceiling?"CEILING_AI_PURSUIT":"WALL_VERTICAL_AI_PURSUIT";
        context.runAtTick(309,()->{
            if(room.closed)return;
            var rows=new ArrayList<Map<String,Object>>();
            for(var pursuit:actors) {
                var base=pursuit.base;var actor=base.actor;var target=base.target;
                var row=new LinkedHashMap<String,Object>();row.put("type",actor.getType().toString());
                row.put("actualAge",actor.age);row.put("spawnAge",base.spawnAge);row.put("lastObservedAge",base.lastAge);
                row.put("ordinaryEntityTicks",actor.age-base.spawnAge);row.put("supportSamples",pursuit.samples);
                row.put("alive",actor.isAlive());row.put("removed",actor.isRemoved());row.put("health",actor.getHealth());
                row.put("actual",state(actor));row.put("targetRetained",actor.getTarget()==target);
                row.put("targetActualAge",target.age);row.put("targetAlive",target.isAlive());row.put("targetRemoved",target.isRemoved());
                row.put("targetHealth",target.getHealth());row.put("targetPosition",vector(target.getPos()));
                row.put("targetWorldOwnsEntity",room.world.getEntityById(target.getId())==target);
                row.put("sameNativeNavigation",actor.getNavigation()==base.navigation);
                row.put("sameNativeControl",actor.getMoveControl()==base.control);
                row.put("nativeSteering",measureNativeSteering(actor,target).details());
                boolean queriesAvailable=diagnosticSupportAvailable(room,actor,up);
                row.put("supportQueryVolumesFull",queriesAvailable);
                row.put("currentSupport",queriesAvailable?measureSupport(room,actor,up,pursuit.eyeHeight).details():null);
                row.put("lastObservedSupport",pursuit.last==null?null:pursuit.last.details());
                row.put("invalidSupportSamples",pursuit.invalidSupport);row.put("maximumMeasuredFeetGap",pursuit.maxGap);
                row.put("maximumObservedStep",base.maxStep);rows.add(row);
            }
            System.out.println("CLIMBER_SURFACE_PRE_TIMEOUT "+new com.google.gson.Gson().toJson(Map.of(
                "phase",phase,"fixtureTick",309,"spawned",spawned[0],"built",room.built,
                "fixtureVolumesFull",room.loaded(),"minimumOrdinaryTicks",ORDINARY_TICKS,"actors",rows)));
        });
        watch(context,room,310,()->{
            if(!room.loaded())return false;
            room.build();
            if(!spawned[0]) {
                // Three interior cells cover each species' native eye offset; actual eyes are checked below.
                for(int index=0;index<TYPES.length;index++) {
                    var start=surfaceStart(room,centre,index,ceiling);
                    for(int offset=0;offset<=2;offset++)
                        if(!room.dark(start.add(up.multiply(offset)))
                            ||!room.dark(start.add(tangent.multiply(5)).add(up.multiply(offset))))return false;
                }
                for(int index=0;index<TYPES.length;index++) {
                    SpiderEntity actor=(SpiderEntity)TYPES[index].create(room.world);
                    context.assertTrue(actor!=null&&!actor.isAiDisabled(),"FIXTURE_ADMISSION: native climber AI starts enabled");
                    actor.setPersistent();var start=surfaceStart(room,centre,index,ceiling);
                    double actorEye=admitSurfaceActor(room,actor,start,up,phase);
                    CowEntity target=EntityType.COW.create(room.world);target.setAiDisabled(true);target.setNoGravity(true);target.setInvulnerable(true);
                    double targetEye=admitSurfaceActor(room,target,start.add(tangent.multiply(5)),up,phase);
                    actors.add(new SurfacePursuit(new Pursuit(actor,target,start),actorEye,targetEye));
                }
                room.field(centre.add(0,6,0),up.negate());
                // One setup pass arms the real field lease before ordinary actor ticks, as in SurfaceCombat.
                EntityGravitySystem.tick(room.world.getServer());
                for(var pursuit:actors) {
                    var initial=measureSupport(room,pursuit.base.actor,up,pursuit.eyeHeight);
                    var targetInitial=measureSupport(room,pursuit.base.target,up,pursuit.targetEyeHeight);
                    emit(phase+"_ADMITTED",pursuit.base.start,pursuit.base.actor,Map.of(
                        "initialSupport",initial.details(),"initialTargetSupport",targetInitial.details(),
                        "oneInitialFieldPass",true,"manualEntityTicks",false,"fullFixtureVolumesAvailable",room.loaded()));
                    context.assertTrue(initial.valid()&&targetInitial.valid()
                        &&room.dark(pursuit.base.actor.getEyePos())&&room.dark(pursuit.base.target.getEyePos()),
                        "FIXTURE_ADMISSION: actual post-field collider/body/eye contact must be valid before pursuit");
                    pursuit.base.actor.setTarget(pursuit.base.target); // exactly one disclosed fixture target assignment
                    com.terminaldetector.drmd.climber.ClimberMotionTrace.arm(pursuit.base.actor,pursuit.base.target,up,pursuit.eyeHeight,phase);
                }
                spawned[0]=true;return false;
            }
            boolean ready=true;
            for(var pursuit:actors) {
                var actor=pursuit.base.actor;
                context.assertTrue(room.dark(actor.getEyePos()),"FIXTURE_ADMISSION: natural pursuit requires actual dark eyes");
                if(actor.age>pursuit.base.lastAge) {
                    pursuit.base.maxStep=Math.max(pursuit.base.maxStep,actor.getPos().distanceTo(pursuit.base.lastPosition));
                    pursuit.base.lastPosition=actor.getPos();pursuit.base.lastAge=actor.age;
                    pursuit.base.navigatorActive|=!actor.getNavigation().isIdle();
                    pursuit.base.targetRetained|=actor.getTarget()==pursuit.base.target;
                    var steering=measureNativeSteering(actor,pursuit.base.target);
                    pursuit.lastSteering=steering;
                    if(steering.idleFallback()) {
                        pursuit.idleFallbackSamples++;
                        if(pursuit.firstIdleFallback==null)pursuit.firstIdleFallback=steering;
                    }
                    var support=measureSupport(room,actor,up,pursuit.eyeHeight);pursuit.samples++;
                    pursuit.last=support;if(support.gap()!=null)pursuit.maxGap=Math.max(pursuit.maxGap,support.gap());
                    pursuit.minNormalDot=Math.min(pursuit.minNormalDot,support.normalDot());
                    pursuit.maxNormalDrift=Math.max(pursuit.maxNormalDrift,Math.abs(actor.getPos().subtract(pursuit.base.start).dotProduct(up)));
                    pursuit.maxEyeError=Math.max(pursuit.maxEyeError,support.eyeError());
                    pursuit.maxUpError=Math.max(pursuit.maxUpError,support.upError());
                    if(!support.hit())pursuit.missingSupport++;
                    if(!support.valid()) {
                        pursuit.invalidSupport++;
                        if(pursuit.firstInvalid==null) {
                            pursuit.firstInvalid=new LinkedHashMap<>();pursuit.firstInvalid.put("ordinaryEntityTicks",actor.age-pursuit.base.spawnAge);
                            pursuit.firstInvalid.put("support",support.details());pursuit.firstInvalid.put("actor",state(actor));
                        }
                    }
                }
                if(actor.age-pursuit.base.spawnAge<ORDINARY_TICKS)ready=false;
            }
            if(!ready)return false;
            for(var pursuit:actors) {
                var base=pursuit.base;var actor=base.actor;
                double improvement=base.initialDistance-actor.getPos().distanceTo(base.target.getPos());
                double advance=actor.getPos().subtract(base.start).dotProduct(tangent);
                var details=new LinkedHashMap<String,Object>();details.put("assignedCowTargetOnce",true);
                details.put("ordinaryEntityTicks",actor.age-base.spawnAge);details.put("navigatorObservedActive",base.navigatorActive);
                details.put("nativeSteeringObserved",base.navigatorActive||pursuit.idleFallbackSamples>0);
                details.put("nativeSteeringAdmissionBranch",base.navigatorActive
                    ?(pursuit.idleFallbackSamples>0?"path-and-idle-move-control":"path")
                    :(pursuit.idleFallbackSamples>0?"idle-move-control":"none"));
                details.put("idleMoveControlFallbackSamples",pursuit.idleFallbackSamples);
                details.put("firstIdleMoveControlFallback",pursuit.firstIdleFallback==null?null:pursuit.firstIdleFallback.details());
                details.put("lastNativeSteering",pursuit.lastSteering.details());
                details.put("targetRetained",actor.getTarget()==base.target);details.put("distanceImprovement",improvement);
                details.put("tangentialAdvance",advance);details.put("maximumObservedStep",base.maxStep);
                details.put("maximumMeasuredFeetGap",pursuit.maxGap);details.put("maximumNormalDrift",pursuit.maxNormalDrift);
                details.put("minimumNormalDotLocalUp",pursuit.minNormalDot);details.put("maximumEyeTransformError",pursuit.maxEyeError);
                details.put("maximumLocalUpError",pursuit.maxUpError);details.put("supportSamples",pursuit.samples);
                details.put("missingSupportSamples",pursuit.missingSupport);details.put("invalidSupportSamples",pursuit.invalidSupport);
                details.put("firstInvalidSupport",pursuit.firstInvalid);details.put("lastSupport",pursuit.last.details());
                details.put("manualEntityTicks",false);details.put("repeatedNavigationOrVelocityCommands",false);
                details.put("noGlobalTimeWeatherWrites",true);details.put("fullFixtureVolumesAvailable",room.loaded());
                details.put("eyeLight",List.of(room.world.getLightLevel(LightType.SKY,BlockPos.ofFloored(actor.getEyePos())),
                    room.world.getLightLevel(LightType.BLOCK,BlockPos.ofFloored(actor.getEyePos()))));
                emit(phase,base.start,actor,details);
                context.assertTrue(actor.isAlive()&&!actor.isAiDisabled()&&!actor.hasNoGravity()
                    &&base.targetRetained&&actor.getTarget()==base.target&&(base.navigatorActive||pursuit.idleFallbackSamples>0)
                    &&improvement>=MINIMUM_PURSUIT&&advance>=MINIMUM_PURSUIT&&base.maxStep<=1
                    &&pursuit.invalidSupport==0&&pursuit.samples>=ORDINARY_TICKS
                    &&actor.getNavigation()==base.navigation&&actor.getMoveControl()==base.control,
                    "C2 "+phase+" natural AI/contact contract failed after admitted support: "+actor.getType());
            }
            return true;
        });
    }

    private static Vec3d surfaceStart(Room room,BlockPos centre,int index,boolean ceiling) {
        return ceiling?new Vec3d(centre.getX()+(index==0?-3:3)+.5,room.max.getY()-.02,centre.getZ()-3.5)
            :new Vec3d(room.min.getX()+1.02,room.min.getY()+2.5,centre.getZ()+(index==0?-3:3)+.5);
    }

    private static double admitSurfaceActor(Room room,LivingEntity actor,Vec3d feet,Vec3d up,String phase) {
        room.actors.add(actor);actor.setPosition(feet);
        double nativeEyeHeight=actor.getEyePos().y-actor.getY();
        boolean accepted=ActorFrames.trySetUp(actor,up);var measured=measureSupport(room,actor,up,nativeEyeHeight);
        System.out.println("CLIMBER_SURFACE_ADMISSION "+new com.google.gson.Gson().toJson(Map.of(
            "phase",phase,"type",actor.getType().toString(),"acceptedCheckedFrame",accepted,
            "beforeSpawn",true,"nativeEyeHeight",nativeEyeHeight,"support",measured.details())));
        room.context.assertTrue(accepted&&measured.valid()&&room.dark(actor.getEyePos()),
            "FIXTURE_ADMISSION: checked frame/collider/eye placement failed before real entity spawn: "+actor.getType());
        room.context.assertTrue(room.world.spawnEntity(actor),"FIXTURE_ADMISSION: real surface actor registered");
        return nativeEyeHeight;
    }

    private record Support(boolean hit,Double gap,double normalDot,double upError,double eyeError,boolean clear,
                           Vec3d localUp,Vec3d eye,Vec3d expectedEye) {
        boolean valid(){return hit&&gap!=null&&gap>=-1e-6&&gap<=.08&&normalDot>=.95&&upError<1e-6&&eyeError<1e-6&&clear;}
        Map<String,Object> details() {
            var m=new LinkedHashMap<String,Object>();m.put("colliderHit",hit);m.put("feetGap",gap);m.put("normalDotLocalUp",normalDot);
            m.put("localUpError",upError);m.put("eyeTransformError",eyeError);m.put("actualBodyClear",clear);
            m.put("actualLocalUp",vector(localUp));m.put("actualEye",vector(eye));m.put("expectedEye",vector(expectedEye));return m;
        }
    }

    private static Support measureSupport(Room room,LivingEntity actor,Vec3d expectedUp,double nativeEyeHeight) {
        var feet=actor.getPos();var localUp=ActorFrames.up(actor);var eye=actor.getEyePos();
        var expectedEye=feet.add(expectedUp.multiply(nativeEyeHeight));
        var ray=room.world.raycast(new RaycastContext(feet.add(expectedUp.multiply(.04)),feet.subtract(expectedUp.multiply(1.6)),
            RaycastContext.ShapeType.COLLIDER,RaycastContext.FluidHandling.NONE,actor));
        boolean hit=ray.getType()==HitResult.Type.BLOCK;
        Double gap=hit?feet.subtract(ray.getPos()).dotProduct(expectedUp):null;
        double normalDot=hit?Vec3d.of(ray.getSide().getVector()).dotProduct(localUp):0;
        return new Support(hit,gap,normalDot,localUp.distanceTo(expectedUp),eye.distanceTo(expectedEye),
            room.world.isSpaceEmpty(actor,actor.getBoundingBox().contract(1e-6)),localUp,eye,expectedEye);
    }

    /** Timeout observation cannot turn an unknown part of a wandered actor's envelope into a load request. */
    private static boolean diagnosticSupportAvailable(Room room,LivingEntity actor,Vec3d up) {
        var feet=actor.getPos();var query=actor.getBoundingBox()
            .union(new Box(feet.add(up.multiply(.04)),feet.subtract(up.multiply(1.6)))).expand(1);
        int x0=MathHelper.floor(query.minX)>>4,x1=MathHelper.floor(query.maxX)>>4;
        int y0=MathHelper.floor(query.minY)>>4,y1=MathHelper.floor(query.maxY)>>4;
        int z0=MathHelper.floor(query.minZ)>>4,z1=MathHelper.floor(query.maxZ)>>4;
        if((long)(x1-x0+1)*(y1-y0+1)*(z1-z0+1)>64)return false;
        var access=WorldAccess.of(room.world);
        for(int x=x0;x<=x1;x++)for(int y=y0;y<=y1;y++)for(int z=z0;z<=z1;z++)
            if(!access.isVolumeAvailable(new D6ChunkPos(x,y,z)))return false;
        return true;
    }

    /** SpiderNavigation may legitimately steer through MoveControl while its path is idle. Read getters only. */
    private static NativeSteering measureNativeSteering(SpiderEntity actor,CowEntity target) {
        var navigation=actor.getNavigation();var control=actor.getMoveControl();var targetBlock=target.getBlockPos();
        var wanted=new Vec3d(control.getTargetX(),control.getTargetY(),control.getTargetZ());
        boolean idle=navigation.isIdle();double speed=control.getSpeed();
        boolean targetMatches=wanted.x==targetBlock.getX()&&wanted.y==targetBlock.getY()&&wanted.z==targetBlock.getZ();
        boolean retained=actor.getTarget()==target;
        boolean fallback=idle&&navigation instanceof net.minecraft.entity.ai.pathing.SpiderNavigation
            &&retained&&Double.isFinite(speed)&&speed>0&&targetMatches;
        return new NativeSteering(idle,control.isMoving(),speed,wanted,targetBlock,retained,targetMatches,fallback);
    }

    private record NativeSteering(boolean navigationIdle,boolean controlMovingAfterTick,double speed,Vec3d wanted,
                                  BlockPos targetBlock,boolean targetRetained,boolean targetMatches,boolean idleFallback) {
        Map<String,Object> details() {
            var m=new LinkedHashMap<String,Object>();m.put("navigationIdle",navigationIdle);
            m.put("controlMovingAfterTickDiagnosticOnly",controlMovingAfterTick);m.put("speed",speed);
            m.put("wantedDestination",vector(wanted));m.put("assignedCowNativeBlockTarget",List.of(targetBlock.getX(),targetBlock.getY(),targetBlock.getZ()));
            m.put("assignedTargetRetained",targetRetained);m.put("wantedMatchesAssignedCowNativeBlockTarget",targetMatches);
            m.put("admittedIdleMoveControlFallback",idleFallback);return m;
        }
    }

    private static final class SurfacePursuit {
        final Pursuit base;final double eyeHeight,targetEyeHeight;
        int samples,missingSupport,invalidSupport;double maxGap=.02,maxNormalDrift,minNormalDot=1,maxEyeError,maxUpError;
        Support last;Map<String,Object> firstInvalid;
        int idleFallbackSamples;NativeSteering firstIdleFallback,lastSteering;
        SurfacePursuit(Pursuit base,double eyeHeight,double targetEyeHeight) {
            this.base=base;this.eyeHeight=eyeHeight;this.targetEyeHeight=targetEyeHeight;
        }
    }

    private static SpiderEntity spawnSpider(Room room,EntityType<?> type,Vec3d at,boolean isolated,boolean noGravity) {
        SpiderEntity actor=(SpiderEntity)type.create(room.world);
        room.context.assertTrue(actor!=null&&!actor.isAiDisabled(),"native climber AI starts enabled: "+type);
        actor.setAiDisabled(isolated);actor.setNoGravity(noGravity);actor.setPersistent();actor.setPosition(at);room.spawn(actor);
        room.context.assertTrue(room.world.isSpaceEmpty(actor),"actual initial climber collision box is clear: "+type);
        return actor;
    }

    private static final class Pursuit {
        final SpiderEntity actor;final CowEntity target;final Vec3d start;final int spawnAge;
        final Object navigation,control;final double initialDistance;
        Vec3d lastPosition;int lastAge;double maxStep;boolean navigatorActive,targetRetained;
        Pursuit(SpiderEntity actor,CowEntity target,Vec3d start) {
            this.actor=actor;this.target=target;this.start=start;spawnAge=lastAge=actor.age;lastPosition=start;
            navigation=actor.getNavigation();control=actor.getMoveControl();initialDistance=start.distanceTo(target.getPos());
        }
    }

    private static void watch(TestContext context,Room room,int limit,BooleanSupplier scenario) {
        boolean[] finished={false};
        for(int i=1;i<limit;i++)context.runAtTick(i,()->{
            if(finished[0])return;
            try {
                if(scenario.getAsBoolean()){finished[0]=true;room.close();context.complete();}
            } catch(Throwable failure){finished[0]=true;room.close();throw failure;}
        });
        context.runAtTick(limit,()->{
            if(finished[0])return;finished[0]=true;
            try {context.assertTrue(false,"C2 fixture/admission timed out before its frozen ordinary-tick contract; no wall/ceiling inference");}
            finally {room.close();}
        });
    }

    /** Bounded test-only column tickets are restored; fixture writes require actual FULL cubes first. */
    private static final class Room implements AutoCloseable {
        final TestContext context;final ServerWorld world;final BlockPos min,max;
        final Set<Long> added=new HashSet<>();final List<Entity> actors=new ArrayList<>();final Set<UUID> fields=new HashSet<>();
        boolean built,closed;
        Room(TestContext context,BlockPos min,BlockPos max) {
            this.context=context;world=context.getWorld();this.min=min;this.max=max;
            for(int x=(min.getX()-1)>>4;x<=(max.getX()+1)>>4;x++)for(int z=(min.getZ()-1)>>4;z<=(max.getZ()+1)>>4;z++) {
                long key=ChunkPos.toLong(x,z);
                if(!world.getForcedChunks().contains(key)){world.setChunkForced(x,z,true);added.add(key);}
            }
        }
        boolean loaded() {
            var access=WorldAccess.of(world);
            for(int x=(min.getX()-1)>>4;x<=(max.getX()+1)>>4;x++)
                for(int y=(min.getY()-1)>>4;y<=(max.getY()+1)>>4;y++)
                    for(int z=(min.getZ()-1)>>4;z<=(max.getZ()+1)>>4;z++)
                        if(!access.isVolumeAvailable(new D6ChunkPos(x,y,z)))return false;
            return true;
        }
        void build() {
            if(built)return;
            for(var at:BlockPos.iterate(min,max)) {
                boolean shell=at.getX()==min.getX()||at.getX()==max.getX()||at.getY()==min.getY()
                    ||at.getY()==max.getY()||at.getZ()==min.getZ()||at.getZ()==max.getZ();
                world.setBlockState(at,(shell?Blocks.OBSIDIAN:Blocks.AIR).getDefaultState(),2);
            }
            built=true;
        }
        boolean dark(Vec3d eye) {
            var at=BlockPos.ofFloored(eye);
            return world.getLightLevel(LightType.SKY,at)==0&&world.getLightLevel(LightType.BLOCK,at)==0;
        }
        void spawn(Entity actor) {actors.add(actor);context.assertTrue(world.spawnEntity(actor),"real world-owned fixture actor registered");}
        UUID field(BlockPos at,Vec3d down) {
            UUID id=UUID.randomUUID();fields.add(id);
            GravityFields.put(new GravityFields.Field(id,world.getRegistryKey(),at,down,32,1,FieldShape.SPHERE,"climber entry"));return id;
        }
        void removeField(UUID id) {GravityFields.remove(id);fields.remove(id);EntityGravitySystem.tick(world.getServer());}
        @Override public void close() {
            if(closed)return;closed=true;for(UUID id:fields)GravityFields.remove(id);for(Entity actor:actors)actor.discard();
            EntityGravitySystem.tick(world.getServer());
            if(built)for(var at:BlockPos.iterate(min,max))world.setBlockState(at,Blocks.AIR.getDefaultState(),2);
            for(long key:added)world.setChunkForced(ChunkPos.getPackedX(key),ChunkPos.getPackedZ(key),false);
        }
    }

    private static Map<String,Object> state(SpiderEntity actor) {
        var box=actor.getBoundingBox();var result=new LinkedHashMap<String,Object>();
        result.put("position",vector(actor.getPos()));result.put("bounds",List.of(box.minX,box.minY,box.minZ,box.maxX,box.maxY,box.maxZ));
        result.put("eye",vector(actor.getEyePos()));result.put("velocity",vector(actor.getVelocity()));result.put("onGround",actor.isOnGround());
        result.put("noGravity",actor.hasNoGravity());result.put("nativeClimbing",actor.isClimbing());
        result.put("uuid",actor.getUuid().toString());result.put("aiDisabled",actor.isAiDisabled());
        result.put("worldOwnsEntity",actor.getWorld() instanceof ServerWorld world&&world.getEntityById(actor.getId())==actor);
        result.put("runtimeGravityLease",EntityGravitySystem.suppressesVanillaGravity(actor));
        result.put("navigation",actor.getNavigation().getClass().getName());result.put("navigationIdentity",System.identityHashCode(actor.getNavigation()));
        result.put("control",actor.getMoveControl().getClass().getName());result.put("controlIdentity",System.identityHashCode(actor.getMoveControl()));
        result.put("orientationAdapterSupportedDiagnosticOnly",ActorFrames.supported(actor));result.put("localUpDiagnosticOnly",vector(ActorFrames.up(actor)));
        return result;
    }
    private static List<Double> vector(Vec3d v){return List.of(v.x,v.y,v.z);}
    private static void emit(String phase,Vec3d original,SpiderEntity actor,Map<String,Object> details) {
        var row=new LinkedHashMap<String,Object>();row.put("phase",phase);row.put("originalPosition",vector(original));row.put("actual",state(actor));row.putAll(details);
        System.out.println("CLIMBER_FIELD "+new com.google.gson.Gson().toJson(row));
    }
}
