package com.terminaldetector.drmd.climber;

import net.minecraft.entity.Entity;
import net.minecraft.entity.MovementType;
import net.minecraft.entity.mob.SpiderEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.*;
import java.lang.ref.WeakReference;
import java.util.*;

/** Passive finite rolling call provenance, not a replacement collision algorithm or synthetic trajectory. */
public final class ClimberStepTrace {
    public static final boolean ENABLED=Boolean.getBoolean("drmd.gate.climberStepTrace");
    private static final int ACTORS=2,MOVES=4,CANDIDATES=8,DEPTH=2;
    private static final Map<UUID,Arm> ARMS=new LinkedHashMap<>();
    private static final ThreadLocal<ArrayDeque<Move>> ACTIVE=new ThreadLocal<>();
    private static final ThreadLocal<Integer> OVERFLOW=ThreadLocal.withInitial(()->0);
    private static final class Arm {
        final WeakReference<SpiderEntity> actor;final Box barrier;final ArrayDeque<Move> history=new ArrayDeque<>();
        int moves,reentrantOverflows,boundaryOrdinal;Box boundaryBox;boolean dumped;Map<String,Object> firstExplainedStep;int explainedChords;
        Arm(SpiderEntity actor,Box barrier){this.actor=new WeakReference<>(actor);this.barrier=barrier;boundaryBox=actor.getBoundingBox();}
    }
    private static final class Move {
        final Arm arm;final UUID uuid;final int ordinal,age;final long worldTime;final Map<String,Object> row=new LinkedHashMap<>();
        final List<Map<String,Object>> candidates=new ArrayList<>();Map<String,Object> pending;int calls,sequence;
        Move(Arm arm,Entity actor,MovementType type,Vec3d requested) {
            this.arm=arm;uuid=actor.getUuid();ordinal=++arm.moves;age=actor.age;worldTime=actor.getWorld().getTime();
            row.put("ordinal",ordinal);row.put("actualAge",age);row.put("worldTime",worldTime);row.put("type",type.toString());
            row.put("requested",vector(requested));row.put("before",snapshot(actor));row.put("MOVE_HEAD_sequence",++sequence);
        }
        Map<String,Object> export(){var result=new LinkedHashMap<>(row);result.put("candidateCalls",calls);result.put("candidatesTruncated",Math.max(0,calls-CANDIDATES));result.put("candidateSnapshots",candidates);return result;}
    }
    private ClimberStepTrace() {}
    public static void arm(SpiderEntity actor,Box barrier) {
        if(!ENABLED)return;if(ARMS.size()>=ACTORS)throw new IllegalStateException("step observer actor cap exceeded");
        ARMS.put(actor.getUuid(),new Arm(actor,barrier));
    }
    private static Arm arm(Entity actor) {
        if(!ENABLED)return null;var arm=ARMS.get(actor.getUuid());
        return arm!=null&&arm.actor.get()==actor&&!actor.isRemoved()&&actor.getWorld()instanceof ServerWorld world
            &&world.getServer().isOnThread()&&world.getEntityById(actor.getId())==actor?arm:null;
    }
    private static Move current(Entity actor) {
        if(!ENABLED||OVERFLOW.get()>0)return null;var stack=ACTIVE.get();var move=stack==null?null:stack.peekLast();
        return move!=null&&move.uuid.equals(actor.getUuid())?move:null;
    }
    public static void beginMove(Entity actor,MovementType type,Vec3d requested) {
        var arm=arm(actor);if(arm==null)return;
        var stack=ACTIVE.get();if(stack==null){stack=new ArrayDeque<>();ACTIVE.set(stack);}if(OVERFLOW.get()>0||stack.size()>=DEPTH){OVERFLOW.set(OVERFLOW.get()+1);arm.reentrantOverflows++;return;}
        var move=new Move(arm,actor,type,requested);stack.addLast(move);arm.history.addLast(move);
        while(arm.history.size()>MOVES)arm.history.removeFirst();
    }
    public static void endMove(Entity actor) {
        if(arm(actor)==null)return;
        if(OVERFLOW.get()>0){OVERFLOW.set(OVERFLOW.get()-1);return;}
        var move=current(actor);if(move==null)return;move.row.put("after",snapshot(actor));move.row.put("MOVE_RETURN_sequence",++move.sequence);ACTIVE.get().removeLast();
    }
    public static void adjustBegin(Entity actor,Vec3d requested) {
        if(arm(actor)==null)return;var move=current(actor);if(move==null)return;
        move.row.put("ADJUST_HEAD_sequence",++move.sequence);move.row.put("adjustRequested",vector(requested));move.row.put("adjustStartBox",bounds(actor.getBoundingBox()));
    }
    public static void adjustEnd(Entity actor,Vec3d result,boolean selectedStep) {
        if(arm(actor)==null)return;var move=current(actor);if(move==null)return;
        move.row.put("ADJUST_RETURN_sequence",++move.sequence);move.row.put("actualSelectedBranch",selectedStep?"SELECTED_STEP_RETURN_341":"BASE_RETURN_350");
        move.row.put("actualReturnedMovement",vector(result));
    }
    public static void candidateBegin(Vec3d requested,Box box,int shapes) {
        if(!ENABLED)return;var stack=ACTIVE.get();if(stack==null||OVERFLOW.get()>0)return;var move=stack.peekLast();if(move==null)return;
        move.calls++;int order=++move.sequence;move.pending=null;if(move.calls>CANDIDATES)return;
        var row=new LinkedHashMap<String,Object>();row.put("classification","CANDIDATE_ONLY_NOT_AN_EXECUTED_SEGMENT");
        row.put("call",move.calls);row.put("headSequence",order);row.put("requested",vector(requested));row.put("box",bounds(box));row.put("shapeCount",shapes);
        move.candidates.add(row);move.pending=row;
    }
    public static void candidateEnd(Vec3d result) {
        if(!ENABLED)return;var stack=ACTIVE.get();if(stack==null||OVERFLOW.get()>0)return;var move=stack.peekLast();if(move==null)return;
        int order=++move.sequence;if(move.pending!=null){move.pending.put("returnSequence",order);move.pending.put("result",vector(result));move.pending=null;}
    }
    public static void observedBoundary(SpiderEntity actor,Box box) {
        var arm=arm(actor);if(arm!=null){arm.boundaryOrdinal=arm.moves;arm.boundaryBox=box;}
    }
    /** Only a complete identity-matched chain containing an actually selected native step can explain a chord. */
    public static boolean explainsSelectedStep(SpiderEntity actor,Box before,Box after,Box barrier) {
        var arm=arm(actor);if(arm==null||arm.reentrantOverflows!=0||!ClimberStepGeometry.same(arm.boundaryBox,before)
            ||arm.moves-arm.boundaryOrdinal<1||arm.moves-arm.boundaryOrdinal>MOVES)return false;
        var cursor=before;boolean selected=false;int ordinal=arm.boundaryOrdinal;var used=new ArrayList<Map<String,Object>>();
        for(var move:arm.history) {
            if(move.ordinal<=arm.boundaryOrdinal)continue;
            if(move.ordinal!=++ordinal)return false;
            var start=box(((Map<?,?>)move.row.get("before")).get("bounds"));
            if(!move.row.containsKey("MOVE_RETURN_sequence")||!ClimberStepGeometry.same(start,cursor))return false;
            var endRow=(Map<?,?>)move.row.get("after");var end=box(endRow.get("bounds"));
            var actualReturned=vec(move.row.get("actualReturnedMovement"));
            var positionAfter=vec(endRow.get("position"));var positionBefore=vec(((Map<?,?>)move.row.get("before")).get("position"));
            if(move.calls>CANDIDATES||actualReturned==null||positionAfter==null||positionBefore==null
                ||!ClimberStepGeometry.same(actualReturned,positionAfter.subtract(positionBefore))
                ||!ClimberStepGeometry.same(start.offset(actualReturned),end))return false;
            if("SELECTED_STEP_RETURN_341".equals(move.row.get("actualSelectedBranch"))) {
                if(move.calls>CANDIDATES)return false;
                var returned=vec(move.row.get("actualReturnedMovement"));Map<String,Object> chosen=null;
                for(var candidate:move.candidates)if(candidate.containsKey("returnSequence")
                    &&ClimberStepGeometry.same(vec(candidate.get("result")),returned)&&ClimberStepGeometry.same(box(candidate.get("box")),start))chosen=candidate;
                if(chosen==null)return false;
                var beginRow=(Map<?,?>)move.row.get("before");var actualDelta=vec(endRow.get("position")).subtract(vec(beginRow.get("position")));
                var record=new ClimberStepGeometry.NativeStep(start,end,vec(move.row.get("requested")),vec(move.row.get("adjustRequested")),returned,
                    actualDelta,box(chosen.get("box")),vec(chosen.get("result")),true,true,false,((Number)beginRow.get("nativeStepHeight")).doubleValue());
                if(!ClimberStepGeometry.pinnedSelectedStepClear(record,barrier))return false;selected=true;
            } else if(!"BASE_RETURN_350".equals(move.row.get("actualSelectedBranch"))||ClimberStepGeometry.ordinaryChordHit(start,end,barrier))return false;
            used.add(move.export());cursor=end;
            if(ordinal==arm.moves&&ClimberStepGeometry.same(cursor,after)) {
                if(!selected)return false;
                arm.explainedChords++;
                if(arm.firstExplainedStep==null)arm.firstExplainedStep=Map.of("actualAge",actor.age,"startBox",bounds(before),"endBox",bounds(after),
                    "actualIdentityMatchedChain",used,"derivedAxisRouteOnlyNotSampledSubposes",true);
                return true;
            }
        }
        return false;
    }
    public static void finalEvidence(SpiderEntity actor) {
        var arm=arm(actor);if(arm==null||arm.dumped||arm.firstExplainedStep==null)return;arm.dumped=true;
        System.out.println("CLIMBER_STEP_ASSESSMENT "+new com.google.gson.Gson().toJson(Map.of("uuid",actor.getUuid().toString(),"type",actor.getType().toString(),
            "actualAge",actor.age,"explainedChordCount",arm.explainedChords,"firstExplainedStep",arm.firstExplainedStep,
            "latestNativeHistory",arm.history.stream().map(Move::export).toList(),"candidateSnapshotsAreNotExecutedSegments",true)));
    }
    private static Vec3d vec(Object value){
        if(!(value instanceof List<?> list)||list.size()!=3||list.stream().anyMatch(v->!(v instanceof Number)))return null;
        return new Vec3d(((Number)list.get(0)).doubleValue(),((Number)list.get(1)).doubleValue(),((Number)list.get(2)).doubleValue());
    }
    private static Box box(Object value){
        if(!(value instanceof List<?> l)||l.size()!=6||l.stream().anyMatch(v->!(v instanceof Number)))return null;
        return new Box(((Number)l.get(0)).doubleValue(),((Number)l.get(1)).doubleValue(),((Number)l.get(2)).doubleValue(),
            ((Number)l.get(3)).doubleValue(),((Number)l.get(4)).doubleValue(),((Number)l.get(5)).doubleValue());
    }

    public static void beforeAssertion(SpiderEntity actor,Box before,Box after,Box expanded,ClimberAirAcceptance.Support support,int violations) {
        var arm=arm(actor);if(arm==null||arm.dumped)return;arm.dumped=true;
        var row=new LinkedHashMap<String,Object>();row.put("uuid",actor.getUuid().toString());row.put("type",actor.getType().toString());row.put("actualAge",actor.age);
        row.put("worldTime",actor.getWorld().getTime());row.put("existingIllegalSweeps",violations);row.put("beforeOrdinaryBox",bounds(before));row.put("currentOrdinaryBox",bounds(after));
        row.put("barrier",bounds(arm.barrier));row.put("existingExpandedMinkowskiBox",bounds(expanded));row.put("existingSupport",support);
        row.put("movesObserved",arm.moves);row.put("rollingMovesCap",MOVES);row.put("candidateCapPerMove",CANDIDATES);row.put("reentrantOverflows",arm.reentrantOverflows);
        row.put("actualNativeCallHistory",arm.history.stream().map(Move::export).toList());row.put("firstExplainedStep",arm.firstExplainedStep);row.put("explainedChordCount",arm.explainedChords);row.put("candidateSnapshotsAreNotExecutedSegments",true);
        System.out.println("CLIMBER_STEP_PREASSERT "+new com.google.gson.Gson().toJson(row));
    }
    private static Map<String,Object> snapshot(Entity actor) {
        return Map.of("position",vector(actor.getPos()),"bounds",bounds(actor.getBoundingBox()),"velocity",vector(actor.getVelocity()),
            "onGround",actor.isOnGround(),"horizontalCollision",actor.horizontalCollision,"verticalCollision",actor.verticalCollision,
            "nativeStepHeight",actor.getStepHeight());
    }
    private static List<Double> vector(Vec3d v){return List.of(v.x,v.y,v.z);}
    private static List<Double> bounds(Box b){return List.of(b.minX,b.minY,b.minZ,b.maxX,b.maxY,b.maxZ);}
}
