package com.terminaldetector.drmd.climber.mixin;

import com.terminaldetector.drmd.climber.ClimberFollowTrace;
import com.terminaldetector.drmd.world.gravity.LocalSurfaceNavigation;
import com.terminaldetector.drmd.world.gravity.LocalSurfacePath;
import net.minecraft.entity.mob.SpiderEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value=LocalSurfaceNavigation.class,remap=false)
public abstract class LocalSurfaceFollowProbe {
    @Inject(method="follow",at=@At("HEAD"),remap=false)
    private static void before(SpiderEntity actor,LocalSurfacePath path,double speed,CallbackInfoReturnable<Boolean> cir) {
        if(!ClimberFollowTrace.ENABLED)return;ClimberFollowTrace.before(actor,path,speed);
    }
    @Inject(method="follow",at=@At("RETURN"),remap=false)
    private static void after(SpiderEntity actor,LocalSurfacePath path,double speed,CallbackInfoReturnable<Boolean> cir) {
        if(!ClimberFollowTrace.ENABLED)return;ClimberFollowTrace.after(actor,path,speed,cir.getReturnValue());
    }
}
