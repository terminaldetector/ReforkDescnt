package com.terminaldetector.drmd.climber;

import com.terminaldetector.drmd.d6.D6ChunkPos;
import com.terminaldetector.drmd.world.access.WorldAccess;
import com.terminaldetector.drmd.world.gravity.ActorFrames;
import com.terminaldetector.drmd.world.gravity.GravityFields;
import net.minecraft.entity.Entity;
import net.minecraft.entity.mob.SpiderEntity;
import net.minecraft.entity.passive.CowEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.*;
import net.minecraft.world.RaycastContext;

import java.lang.ref.WeakReference;
import java.util.*;

/** Focused-test-only observer: no controller, movement, field, ticket or entity writes. */
public final class ClimberMotionTrace {
    public static final boolean ENABLED=Boolean.getBoolean("drmd.gate.climberMotionTrace");
    private static final int TICKS=8,MAX_ACTORS=4,MAX_EVENTS_PER_ACTOR=256;
    private static final Map<UUID,Arm> ARMS=new HashMap<>();
    private static final class Arm {
        final WeakReference<SpiderEntity> actor;
        final WeakReference<CowEntity> target;
        final Vec3d up;final double eyeHeight;final int startAge;final String fixture;
        int events,fieldDepth,snapDepth;
        Arm(SpiderEntity actor,CowEntity target,Vec3d up,double eyeHeight,String fixture,int baselineAge) {
            this.actor=new WeakReference<>(actor);this.target=new WeakReference<>(target);this.up=up;
            this.eyeHeight=eyeHeight;startAge=baselineAge;this.fixture=fixture;
        }
    }
    private ClimberMotionTrace() {}

    public static void arm(SpiderEntity actor,CowEntity target,Vec3d up,double eyeHeight,String fixture) {
        armAt(actor,target,up,eyeHeight,fixture,actor.age);
    }
    /** Follow starts during an ordinary tick: include this tick and the following seven, never nine. */
    public static void armForFollow(SpiderEntity actor,CowEntity target,Vec3d up,double eyeHeight,String fixture) {
        armAt(actor,target,up,eyeHeight,fixture,actor.age-1);
    }
    private static void armAt(SpiderEntity actor,CowEntity target,Vec3d up,double eyeHeight,String fixture,int baselineAge) {
        if(!ENABLED)return;
        ARMS.entrySet().removeIf(e->{var a=e.getValue().actor.get();return a==null||a.isRemoved()||a.age>e.getValue().startAge+TICKS;});
        if(ARMS.size()>=MAX_ACTORS)throw new IllegalStateException("climber trace actor budget exceeded");
        ARMS.put(actor.getUuid(),new Arm(actor,target,up,eyeHeight,fixture,baselineAge));
        record(actor,"ARM",Map.of("recordingOrdinaryTicks",TICKS,"eventCap",MAX_EVENTS_PER_ACTOR));
    }

    public static boolean armed(Entity entity) {
        if(!ENABLED)return false;
        var arm=ARMS.get(entity.getUuid());
        if(arm==null||arm.actor.get()!=entity)return false;
        if(entity.isRemoved()||entity.age>arm.startAge+TICKS) {ARMS.remove(entity.getUuid());return false;}
        return entity.getWorld() instanceof ServerWorld world&&world.getServer().isOnThread()
            &&world.getEntityById(entity.getId())==entity;
    }

    public static void field(Entity entity,boolean entering,Vec3d up,float strength,boolean forceOnly) {
        if(!armed(entity))return;
        var arm=ARMS.get(entity.getUuid());
        if(entering)arm.fieldDepth++;
        record(entity,entering?"FIELD_BEFORE":"FIELD_AFTER",Map.of("fieldUp",vector(up),
            "sampledStrength",strength,"forceOnly",forceOnly));
        if(!entering)arm.fieldDepth--;
    }

    public static void snap(Entity entity,boolean entering,Vec3d up) {
        if(!armed(entity))return;
        var arm=ARMS.get(entity.getUuid());if(entering)arm.snapDepth++;
        record(entity,entering?"SNAP_BEFORE":"SNAP_AFTER",Map.of("fieldUp",vector(up)));
        if(!entering)arm.snapDepth--;
    }

    public static void record(Entity entity,String phase,Map<String,Object> extra) {
        if(!armed(entity))return;
        var arm=ARMS.get(entity.getUuid());var actor=arm.actor.get();
        if(arm.events>=MAX_EVENTS_PER_ACTOR)return;
        var world=(ServerWorld)actor.getWorld();var velocity=actor.getVelocity();var up=ActorFrames.up(actor);
        var row=new LinkedHashMap<String,Object>();row.put("fixture",arm.fixture);row.put("phase",phase);
        row.put("sequence",++arm.events);row.put("uuid",actor.getUuid().toString());row.put("type",actor.getType().toString());
        row.put("worldTime",world.getTime());row.put("actualAge",actor.age);row.put("spawnAge",arm.startAge);
        row.put("ordinaryEntityTicks",actor.age-arm.startAge);row.put("context",arm.snapDepth>0?"FIELD_SNAP":arm.fieldDepth>0?"FIELD":"NATIVE");
        row.put("position",vector(actor.getPos()));row.put("velocityBlocksPerTick",vector(velocity));
        row.put("normalVelocityBlocksPerTick",velocity.dotProduct(arm.up));
        row.put("tangentVelocityBlocksPerTick",vector(velocity.subtract(arm.up.multiply(velocity.dotProduct(arm.up)))));
        var box=actor.getBoundingBox();row.put("bounds",List.of(box.minX,box.minY,box.minZ,box.maxX,box.maxY,box.maxZ));
        row.put("localUp",vector(up));row.put("eye",vector(actor.getEyePos()));row.put("health",actor.getHealth());
        row.put("onGround",actor.isOnGround());row.put("horizontalCollision",actor.horizontalCollision);
        row.put("verticalCollision",actor.verticalCollision);row.put("nativeClimbing",actor.isClimbing());
        row.put("aiDisabled",actor.isAiDisabled());row.put("noGravity",actor.hasNoGravity());row.put("yaw",actor.getYaw());
        row.put("forwardSpeed",actor.forwardSpeed);row.put("sidewaysSpeed",actor.sidewaysSpeed);row.put("upwardSpeed",actor.upwardSpeed);
        row.put("navigationIdle",actor.getNavigation().isIdle());row.put("navigationIdentity",System.identityHashCode(actor.getNavigation()));
        row.put("nativeNavigationTarget",block(actor.getNavigation().getTargetPos()));
        var control=actor.getMoveControl();row.put("controlIdentity",System.identityHashCode(control));row.put("controlMoving",control.isMoving());
        row.put("controlSpeed",control.getSpeed());row.put("wantedDestination",List.of(control.getTargetX(),control.getTargetY(),control.getTargetZ()));
        var target=arm.target.get();row.put("assignedCowRetained",target!=null&&actor.getTarget()==target);
        row.put("assignedCowNativeBlockTarget",target==null?null:block(target.getBlockPos()));
        var sample=GravityFields.sample(world,actor.getPos());
        row.put("sampledFieldDown",sample==null?null:vector(sample.downDir()));row.put("sampledFieldStrength",sample==null?null:sample.strength());
        row.put("support",support(world,actor,arm));row.putAll(extra);
        System.out.println("CLIMBER_MOTION_TRACE "+new com.google.gson.Gson().toJson(row));
    }

    private static Map<String,Object> support(ServerWorld world,SpiderEntity actor,Arm arm) {
        var feet=actor.getPos();var from=feet.add(arm.up.multiply(.04));var to=feet.subtract(arm.up.multiply(1.6));
        var query=actor.getBoundingBox().union(new Box(from,to)).expand(1);
        var result=new LinkedHashMap<String,Object>();
        if(query.minY<world.getBottomY()||query.maxY>world.getTopY()||!world.getWorldBorder().contains(query)) {
            result.put("queryAvailable",false);result.put("reason","height-or-border");return result;
        }
        int x0=MathHelper.floor(query.minX)>>4,x1=MathHelper.floor(query.maxX)>>4;
        int y0=MathHelper.floor(query.minY)>>4,y1=MathHelper.floor(query.maxY)>>4;
        int z0=MathHelper.floor(query.minZ)>>4,z1=MathHelper.floor(query.maxZ)>>4;
        if((long)(x1-x0+1)*(y1-y0+1)*(z1-z0+1)>64) {
            result.put("queryAvailable",false);result.put("reason","bounded-envelope");return result;
        }
        var access=WorldAccess.of(world);
        for(int x=x0;x<=x1;x++)for(int y=y0;y<=y1;y++)for(int z=z0;z<=z1;z++)
            if(!access.isVolumeAvailable(new D6ChunkPos(x,y,z))) {
                result.put("queryAvailable",false);result.put("reason","non-FULL-cube");return result;
            }
        result.put("queryAvailable",true);
        var hit=world.raycast(new RaycastContext(from,to,RaycastContext.ShapeType.COLLIDER,RaycastContext.FluidHandling.NONE,actor));
        boolean block=hit.getType()==HitResult.Type.BLOCK;result.put("colliderHit",block);
        if(block) {result.put("feetGap",feet.subtract(hit.getPos()).dotProduct(arm.up));
            result.put("normal",vector(Vec3d.of(hit.getSide().getVector())));
            result.put("normalDotLocalUp",Vec3d.of(hit.getSide().getVector()).dotProduct(ActorFrames.up(actor)));}
        result.put("actualBodyClear",world.isSpaceEmpty(actor,actor.getBoundingBox().contract(1e-6)));
        result.put("eyeTransformError",actor.getEyePos().distanceTo(feet.add(arm.up.multiply(arm.eyeHeight))));
        return result;
    }
    public static List<Double> vector(Vec3d v){return List.of(v.x,v.y,v.z);}
    private static List<Integer> block(BlockPos p){return p==null?null:List.of(p.getX(),p.getY(),p.getZ());}
}
