package com.terminaldetector.drmd.climber.mixin;

import com.terminaldetector.drmd.ClimberFieldGravityGameTests;
import com.terminaldetector.drmd.climber.ClimberBarrierWatch;
import net.minecraft.test.TestContext;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value=ClimberFieldGravityGameTests.class,remap=false)
public abstract class OldBarrierMethodProbe {
    @Inject(method="wallRouteUsesSupportedSidePassageWithoutBarrierPhasing",at=@At("HEAD"),remap=false)
    private void beforeBarrier(TestContext c,CallbackInfo ci){ClimberBarrierWatch.begin(c,"OLD_BARRIER",120);}
    @Inject(method="wallRouteUsesSupportedSidePassageWithoutBarrierPhasing",at=@At("RETURN"),remap=false)
    private void afterBarrier(TestContext c,CallbackInfo ci){ClimberBarrierWatch.end(c);}
    @Inject(method="realCeilingPursuitAdvancesTangentiallyWithMeasuredSupport",at=@At("HEAD"),remap=false)
    private void beforeCeiling(TestContext c,CallbackInfo ci){ClimberBarrierWatch.begin(c,"OLD_CEILING",60);}
    @Inject(method="realCeilingPursuitAdvancesTangentiallyWithMeasuredSupport",at=@At("RETURN"),remap=false)
    private void afterCeiling(TestContext c,CallbackInfo ci){ClimberBarrierWatch.end(c);}
}
