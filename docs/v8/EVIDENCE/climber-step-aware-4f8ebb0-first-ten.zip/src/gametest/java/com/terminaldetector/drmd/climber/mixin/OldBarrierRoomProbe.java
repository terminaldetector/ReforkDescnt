package com.terminaldetector.drmd.climber.mixin;

import com.terminaldetector.drmd.climber.ClimberBarrierWatch;
import net.minecraft.entity.Entity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.test.TestContext;
import net.minecraft.util.math.*;
import org.spongepowered.asm.mixin.*;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.*;
import java.util.List;

@Mixin(targets="com.terminaldetector.drmd.ClimberFieldGravityGameTests$Room",remap=false)
public abstract class OldBarrierRoomProbe {
    @Shadow @Final TestContext context;
    @Shadow @Final ServerWorld world;
    @Shadow @Final List<Entity> actors;
    @Shadow boolean built;
    @Shadow boolean closed;
    @Unique private ClimberBarrierWatch.RoomStats drmd$watch;
    @Shadow abstract boolean loaded();
    @Inject(method="<init>",at=@At("RETURN"),remap=false)
    private void created(TestContext c,BlockPos min,BlockPos max,CallbackInfo ci) {
        drmd$watch=ClimberBarrierWatch.room(c,world);if(drmd$watch==null)return;
        // Ceiling already has a native309pretimeout loaded() read; observe that return, never add another.
        if(ClimberBarrierWatch.usesExisting309Read(drmd$watch))return;
        c.runAtTick(309,()->{
            if(closed)return;drmd$watch.observerOrigin=true;
            try {ClimberBarrierWatch.record(drmd$watch,context,world,actors,built,closed,loaded());}
            finally {drmd$watch.observerOrigin=false;}
        });
    }
    @Inject(method="spawn",at=@At("RETURN"),remap=false)
    private void spawned(Entity actor,CallbackInfo ci){ClimberBarrierWatch.spawned(drmd$watch,context,world,actor);}
    @Inject(method="loaded",at=@At("RETURN"),remap=false)
    private void readiness(CallbackInfoReturnable<Boolean> cir){
        ClimberBarrierWatch.loaded(drmd$watch,context,cir.getReturnValue());
        if(!closed&&ClimberBarrierWatch.usesExisting309Read(drmd$watch)&&context.getTick()==309&&!drmd$watch.snapshotWritten) {
            drmd$watch.snapshotWritten=true;
            ClimberBarrierWatch.record(drmd$watch,context,world,actors,built,closed,cir.getReturnValue());
        }
    }
    @Inject(method="dark",at=@At("RETURN"),remap=false)
    private void darkness(Vec3d eye,CallbackInfoReturnable<Boolean> cir){ClimberBarrierWatch.dark(drmd$watch,context,eye,cir.getReturnValue());}
}
