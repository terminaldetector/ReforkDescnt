package com.terminaldetector.drmd.climber.mixin;

import com.terminaldetector.drmd.climber.ClimberAirAcceptance;
import net.minecraft.entity.Entity;
import net.minecraft.entity.mob.*;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(MobEntity.class)
public abstract class NativeAirAttackProbe {
    @Inject(method="tryAttack",at=@At("HEAD"))
    private void attempt(Entity target,CallbackInfoReturnable<Boolean> cir) {
        if(ClimberAirAcceptance.ENABLED&&(Object)this instanceof SpiderEntity actor)ClimberAirAcceptance.attack(actor,target);
    }
}
