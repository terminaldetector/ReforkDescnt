package com.terminaldetector.drmd.climber.mixin;

import com.terminaldetector.drmd.climber.ClimberMotionTrace;
import com.terminaldetector.drmd.world.gravity.EntityGravitySystem;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import java.util.Map;

@Mixin(value=EntityGravitySystem.class,remap=false)
public abstract class FieldPhaseProbe {
    @Inject(method="applyMobPhysics",at=@At("HEAD"),remap=false)
    private static void beforeField(LivingEntity actor,Vec3d up,float strength,boolean forceOnly,CallbackInfo ci) {
        if(!ClimberMotionTrace.armed(actor))return;ClimberMotionTrace.field(actor,true,up,strength,forceOnly);
    }
    @Inject(method="applyMobPhysics",at=@At("RETURN"),remap=false)
    private static void afterField(LivingEntity actor,Vec3d up,float strength,boolean forceOnly,CallbackInfo ci) {
        if(!ClimberMotionTrace.armed(actor))return;ClimberMotionTrace.field(actor,false,up,strength,forceOnly);
    }
    @Inject(method="probe",at=@At("HEAD"),remap=false)
    private static void beforeProbe(LivingEntity actor,Vec3d up,CallbackInfoReturnable<Boolean> cir) {
        if(!ClimberMotionTrace.armed(actor))return;ClimberMotionTrace.record(actor,"PROBE_BEFORE",Map.of("fieldUp",ClimberMotionTrace.vector(up)));
    }
    @Inject(method="probe",at=@At("RETURN"),remap=false)
    private static void afterProbe(LivingEntity actor,Vec3d up,CallbackInfoReturnable<Boolean> cir) {
        if(!ClimberMotionTrace.armed(actor))return;ClimberMotionTrace.record(actor,"PROBE_AFTER",Map.of("probeGrounded",cir.getReturnValue()));
    }
    @Inject(method="snap",at=@At("HEAD"),remap=false)
    private static void beforeSnap(LivingEntity actor,Vec3d up,CallbackInfo ci) {
        if(!ClimberMotionTrace.armed(actor))return;ClimberMotionTrace.snap(actor,true,up);
    }
    @Inject(method="snap",at=@At("RETURN"),remap=false)
    private static void afterSnap(LivingEntity actor,Vec3d up,CallbackInfo ci) {
        if(!ClimberMotionTrace.armed(actor))return;ClimberMotionTrace.snap(actor,false,up);
    }
}
