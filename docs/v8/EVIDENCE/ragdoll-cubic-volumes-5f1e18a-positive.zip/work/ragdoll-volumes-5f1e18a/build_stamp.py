#!/usr/bin/env python3
"""Exact source/artifact/launcher binding for the one frozen ragdoll native negative."""
from pathlib import Path
import hashlib
import json
import subprocess
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[2]
LANE = ROOT / 'work/ragdoll-volumes-5f1e18a'
SOURCE = '5f1e18ab1f71d4e9b3b63f92c3b175f75778825e'
BASE_CORE = 'cf3701b529b21633a8a3e910e6755d006d97d6349e8938d7701c82671027138d'
NEGATIVE_GATE = 'f553e766833b0a752fdd06dce61cf3ebee08766fb3e704e3031b58251aab27bf'
VERSION = 'drmd-6dof-1.1.35-ufo-dev.1'
STAMP = LANE / 'verified-build.json'
BEFORE = LANE / 'before-build.json'
BUILD_PATHS = ['src', 'gradle', 'build.gradle', 'settings.gradle', 'gradle.properties', 'gradlew']


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def source():
    head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
    assert head == SOURCE, ('frozen source differs', head)
    assert not subprocess.check_output(['git', 'status', '--porcelain', '--', *BUILD_PATHS], cwd=ROOT)
    return head


def inputs():
    tracked = subprocess.check_output(['git', 'ls-files', '-z', '--', *BUILD_PATHS], cwd=ROOT).split(b'\0')
    files = [ROOT / p.decode() for p in tracked if p]
    files += [LANE / n for n in ('build_stamp.py', 'build.sh', 'prepare.py', 'native.sh')]
    files += [ROOT / 'scripts/v5/prepare_cubic_client.py']
    return {str(p.relative_to(ROOT)): sha(p) for p in sorted(set(files))}


def artifacts():
    result = {}
    for suffix, required in [('', 'com/terminaldetector/drmd/entity/RagdollEntity.class'),
                             ('-cubiccheck', 'com/terminaldetector/drmd/gate/NativeRagdollVolumeCheck.class')]:
        path = ROOT / 'build/libs' / (VERSION + suffix + '.jar')
        with zipfile.ZipFile(path) as jar:
            assert jar.testzip() is None and required in jar.namelist(), path
            if suffix:
                manifest = json.loads(jar.read('drmd.cubiccheck.mixins.json'))
                assert 'RagdollVolumeBootstrapProbe' in manifest['client']
        result[str(path.relative_to(ROOT))] = sha(path)
    assert result['build/libs/' + VERSION + '.jar'] != BASE_CORE, 'guard correction must produce new game bytes'
    assert result['build/libs/' + VERSION + '-cubiccheck.jar'] == NEGATIVE_GATE, 'observer/assertion JAR differs from actual negative'
    return result


def no_java():
    active = []
    for pid in Path('/proc').iterdir():
        if not pid.name.isdigit():
            continue
        try:
            if (pid / 'comm').read_text().strip() in ('java', 'Xvfb') and (pid / 'stat').read_text().split()[2] != 'Z':
                active.append(pid.name)
        except (OSError, IndexError):
            pass
    assert not active, ('exclusive Java/native lease is occupied', active)


if __name__ == '__main__':
    mode = sys.argv[1]
    if mode == 'before':
        no_java()
        assert not BEFORE.exists() and not STAMP.exists(), 'preserve the first build; use a new reviewed attempt for retries'
        BEFORE.write_text(json.dumps(dict(sourceSha=source(), inputs=inputs()), indent=2) + '\n')
    elif mode == 'record':
        saved = json.loads(BEFORE.read_text())
        assert source() == saved['sourceSha'] and inputs() == saved['inputs'], 'build inputs changed during compile'
        jars = artifacts()
        saved.update(jars=jars, expectedCoreGame=jars['build/libs/' + VERSION + '.jar'], baselineCoreGame=BASE_CORE, unchangedNegativeGate=NEGATIVE_GATE, scope='native ragdoll occupied-XYZ FULL guard positive; exact unchanged observer JAR')
        STAMP.write_text(json.dumps(saved, indent=2) + '\n')
    elif mode == 'check':
        saved = json.loads(STAMP.read_text())
        assert source() == saved['sourceSha'] and inputs() == saved['inputs'] and artifacts() == saved['jars']
        print('Verified exact source', saved['sourceSha'], 'and both freshly built JARs')
    elif mode == 'idle':
        no_java()
    else:
        raise ValueError(mode)
