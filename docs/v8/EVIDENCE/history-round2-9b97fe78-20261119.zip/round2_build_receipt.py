"""Round-2 read-only original-log and pinned-source inspection. No JVM/world writes."""
import collections,datetime,gzip,hashlib,json,pathlib,re,subprocess,zipfile
REPO=pathlib.Path('/workspace/ungravity-v5/ufo-body-physics')
SOURCE='9b97fe78ccb8ea4d9d3edbec0a8024cb2ed4d1a0'
OUT=pathlib.Path('/tmp/ungravity-history-round2-9b97-20261119-first')
def sha(b):return hashlib.sha256(b).hexdigest()
def git(*args):return subprocess.check_output(['git','--no-optional-locks','--no-replace-objects','-C',str(REPO),*args])
def blob(p):return git('show',SOURCE+':'+p)
prior_path='docs/v8/BLOCK_ENTITY_FORENSICS_2026-11-17.json'
prior_raw=blob(prior_path);prior=json.loads(prior_raw)
p=pathlib.Path(prior['primary_archive']['path']);raw=p.read_bytes();archive=prior['primary_archive']
assert (sha(raw),len(raw))==(archive['sha256'],archive['bytes'])
logs=[];groups={};checks=0
with zipfile.ZipFile(p) as z:
 assert z.testzip() is None and len(z.infolist())==archive['members'];checks+=1
 for old in prior['historical_logs']:
  raw_log=z.read(old['archive_member']);plain=gzip.decompress(raw_log) if old['archive_member'].endswith('.gz') else raw_log
  lines=plain.decode().splitlines();assert (sha(raw_log),len(raw_log),sha(plain),len(plain),len(lines))==(old['raw_sha256'],old['raw_bytes'],old['uncompressed_sha256'],old['uncompressed_bytes'],old['line_count']);checks+=1
  events=[(i,line) for i,line in enumerate(lines,1) if 'Tried to load a DUMMY block entity @' in line]
  assert [i for i,line in events]==[e['line'] for e in old['dummy_events']];checks+=1
  states=[];positions=[]
  for (i,line),e in zip(events,old['dummy_events']):
   xyz=tuple(map(int,re.search(r'\{x=(-?\d+), y=(-?\d+), z=(-?\d+)\}',line).groups()))
   state=re.search(r'Block\{([^}]+)\}',line).group(1)
   assert xyz==(e['x'],e['y'],e['z']) and line[1:9]==e['time'] and state==e['state'];checks+=1
   positions.append(xyz);states.append(state)
  assert (len(positions),len(set(positions)),dict(collections.Counter(states)),min((x[1] for x in positions),default=None),max((x[1] for x in positions),default=None))==(old['dummy_count'],old['dummy_unique_positions'],old['dummy_block_counts'],old['dummy_y_min'],old['dummy_y_max']);checks+=1
  stalls=[tuple(map(int,m.groups())) for line in lines if (m:=re.search(r'Running (\d+)ms or (\d+) ticks behind',line))]
  assert (len(stalls),max((x[0] for x in stalls),default=None),max((x[1] for x in stalls),default=None))==(old['stall_count'],old['max_reported_stall_ms'],old['max_reported_stall_ticks']);checks+=1
  for frag in old.get('selected_primary_excerpts',[]):
   # Check complete recorded excerpts by original line number without exporting raw logs.
   for row in frag.get('lines',[]):
    if isinstance(row,dict) and 'line' in row and 'text' in row:
     assert lines[row['line']-1]==row['text'];checks+=1
  logs.append({k:old[k] for k in ['archive_member','raw_sha256','uncompressed_sha256','dummy_count','dummy_unique_positions','dummy_y_min','dummy_y_max','dummy_block_counts','max_reported_stall_ms']})
  groups.setdefault(sha(plain),[]).append(old['archive_member'])
assert sha(p.read_bytes())==archive['sha256'];checks+=1
unique={r['uncompressed_sha256']:r for r in logs};assert sum(r['dummy_count'] for r in unique.values())==133;checks+=1
source_files={}
for name,old in prior['source_files'].items():
 b=blob(name);source_files[name]={'sha256':sha(b),'bytes':len(b),'old_sha256':old['sha256'],'unchanged_since_prior':sha(b)==old['sha256']}
factories=[]
for old in prior['factory_inventory']:
 row={k:old[k] for k in ['registry_field','allowed_block_field','factory_class']}
 for part in ['provider','constructor']:
  spec=old[part];lines=blob(spec['path']).decode().splitlines();anchors=[]
  for excerpt in spec['excerpt']:
   needle=excerpt['text'].strip()
   if not needle:continue
   hits=[i for i,line in enumerate(lines,1) if line.strip()==needle]
   assert hits,(old['registry_field'],part,needle);checks+=1
   anchors.append({'text':needle,'actual_matching_lines':hits})
  row[part]={'path':spec['path'],'checked_exact_lines':anchors}
 factories.append(row)
registry_path='src/main/java/com/terminaldetector/drmd/entity/ModBlockEntities.java'
reg=blob(registry_path).decode();assert reg.count('Registry.register(Registries.BLOCK_ENTITY_TYPE,')==7;checks+=1
queries={}
for name,old in prior['text_queries'].items():
 cp=subprocess.run(['git','--no-optional-locks','--no-replace-objects','-C',str(REPO),'grep','-n','-E',old['regex'],SOURCE,'--','src/main'],capture_output=True)
 assert cp.returncode in (0,1)
 queries[name]={'regex':old['regex'],'matching_lines':cp.stdout.decode().splitlines(),'scope':'textual src/main inventory; not dynamic reachability or external-mod absence'}
modules=['world/contraption/BlockBodyEntity','d6/D6PhysicsBody','d6/D6PortalTransform','world/mega/SkyUfoEntity','world/mega/UfoControlSystem','world/mega/SkyUfoThrusters','world/contraption/BodyJointRegistry','world/contraption/BodyJointSystem','world/contraption/boarding/BoardingSystem','world/contraption/BlockBodyWorldAccess','world/contraption/mechanism/BodyMountedWeapons','world/portal/PortalTransfer']
ufo={}
for name in modules:
 path='src/main/java/com/terminaldetector/drmd/'+name+'.java';b=blob(path)
 ufo[path]={'bytes':len(b),'sha256':sha(b)}
task_text=blob('docs/v8/TASKS.yaml').decode();tasks={}
for key in ['S00-T01','S00-T02','S00-T03','S00-T04','S00-T05','S00-T06','S01-T05','S03-T03','S09-T01']:
 m=re.search(r'(?m)^- id: '+key+r'\s*$',task_text);assert m
 end=re.search(r'(?m)^- id:',task_text[m.end():]);section=task_text[m.start():m.end()+(end.start() if end else len(task_text))]
 tasks[key]={k:re.search(r'(?m)^  '+k+r': (.+)$',section).group(1) for k in ['title','status']}
result={'schema':1,'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source':SOURCE,'generator_sha256':sha(pathlib.Path(__file__).read_bytes()),'scope':{'read_only':True,'new_java_runs':0,'original_archive_changed':False,'production_or_world_nbt_changed':False,'no_raw_logs_exported':True},'prior_receipt':{'path':prior_path,'sha256':sha(prior_raw),'source':prior['source_revision'],'original_acceptance_boundary':prior['reproduction_contract']['acceptance_boundary']},'original_archive':{k:v for k,v in archive.items() if k not in ['path','logs_compared_byte_for_byte_with_extracted_copies']},'original_logs':logs,'decompressed_duplicate_groups':list(groups.values()),'distinct_warned_sessions':2,'distinct_dummy_warnings':133,'original_runtime_identity':prior['historical_runtime_identity'],'current_source_files':source_files,'current_factory_chains':factories,'current_text_queries':queries,'current_ufo_module_hashes':ufo,'tasks_at_pin':tasks,'assertions_checked':checks,'findings':{'inspection':'Original logs, seven custom constructor/provider chains, state/NBT writer inventory and changed-source deltas inspected at exact pin.','not_proven':['Historical producer or writer stack','Current reproduction or generation repair','Exact original audit.4 installed JAR/source/seed','Current user runtime identity','All dynamic callers/external mods/save lifecycles'],'repair_task':'S03-T03 remains OPEN; old warning-free sessions are not regression acceptance','inspection_task':'S01-T05 completion is limited to its named INSPECT deliverable; original reproduction boundary is preserved above, not retroactively changed'}}
(OUT/'block-entity-current-receipt.json').write_text(json.dumps(result,ensure_ascii=True,indent=2)+'\n')
print(json.dumps({'source':SOURCE,'assertions':checks,'original_members':archive['members'],'distinct_warnings':133,'factories':len(factories),'source_files':len(source_files),'changed_source_files':sum(not x['unchanged_since_prior'] for x in source_files.values()),'receipt_sha256':sha((OUT/'block-entity-current-receipt.json').read_bytes())},indent=2))
