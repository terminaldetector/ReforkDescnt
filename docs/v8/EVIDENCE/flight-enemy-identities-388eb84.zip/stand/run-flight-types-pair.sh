#!/usr/bin/env bash
set -euo pipefail
cd /workspace/ungravity-v5/ufo-body-physics
renderer="$1"
round="${2:-state1}"
write_scenario="flight-types-write-${round}-${renderer}"
read_scenario="flight-types-read-${round}-${renderer}"
cp work/ufo-body/native/run-native.sh "work/ufo-body/native/run-${write_scenario}.sh"
bash "work/ufo-body/native/run-${write_scenario}.sh" "$write_scenario"
mv "build/cubic-client-final-${write_scenario}" build/cubic-client-automation
mkdir build/cubic-client-automation/reload-proof
cp build/cubic-client-automation/inputs.json build/cubic-client-automation/reload-proof/write-inputs.json
cp build/cubic-client-automation/launch.json build/cubic-client-automation/reload-proof/write-launch.json
cp work/ufo-body/native/verified-build.json build/cubic-client-automation/reload-proof/verified-build.json
python3 - <<'SNAPSHOT'
from pathlib import Path
import json,hashlib,zipfile
r=Path('build/cubic-client-automation');files=sorted(p for p in (r/'saves').rglob('*') if p.is_file());hashes={str(p.relative_to(r/'saves')):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
p=r/'reload-proof/first-process-world.zip'
with zipfile.ZipFile(p,'w',zipfile.ZIP_DEFLATED) as z:
 for f in files:z.write(f,str(f.relative_to(r/'saves')))
with zipfile.ZipFile(p) as z:
 assert z.testzip() is None
 for name,h in hashes.items():assert hashlib.sha256(z.read(name)).hexdigest()==h
(r/'reload-proof/first-process-world.json').write_text(json.dumps(dict(scope='Closed first-process disposable world before reader launch',files=hashes,sha256=hashlib.sha256(p.read_bytes()).hexdigest()),indent=2))
SNAPSHOT
python3 - "$read_scenario" <<'PY'
import sys,json,pathlib,hashlib,subprocess
root=pathlib.Path('build/cubic-client-automation');p=root/'launch.json';args=json.loads(p.read_text())
args=[a for a in args if not a.startswith(('-Ddrmd.gate.flightBody=','-Ddrmd.gate.ufoControl=','-Ddrmd.gate.ufoReloadWrite='))]
args=[a for a in args if not a.startswith(('-Ddrmd.gate.swarm=','-Ddrmd.gate.droneStateWrite=','-Ddrmd.gate.flightTypesWrite='))];args.insert(1,'-Ddrmd.gate.flightTypesRead=true');p.write_text(json.dumps(args,indent=2))
p=root/'inputs.json';data=json.loads(p.read_text());data['scenario']=sys.argv[1];data['sourceSha']=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();meta=json.loads((root/'flight-types-saved.json').read_text());assert meta['saved']==3;live=json.loads((root/'flight-enemy-live-ok.json').read_text());assert live['active']==live['moving']==live['naturalTargets']==3 and len(live['shotsByKind'])==3;data['savedFlightTypes']=meta;data['beforeRestart']=live;data['worldSource']='Same saved world as the completed first client process; no new seed or NBT insertion';p.write_text(json.dumps(data,indent=2))
PY
cp work/ufo-body/native/run-flight-types-read.sh "work/ufo-body/native/run-${read_scenario}.sh"
bash "work/ufo-body/native/run-${read_scenario}.sh" "$read_scenario"
