#!/usr/bin/env bash
set -euo pipefail
cd /workspace/ungravity-v5/ufo-body-physics
scenario="$1"
python3 work/ufo-body/native/verify-build-stamp.py check
display_file="work/ufo-body/native/final-${scenario}-display.txt"
: > "$display_file"
/workspace/xvfb/usr/bin/Xvfb -displayfd 3 -screen 0 1280x1024x24 3> "$display_file" > "work/ufo-body/native/final-${scenario}-xvfb.log" 2>&1 &
display_pid=$!
trap 'kill "$display_pid" 2>/dev/null || true; wait "$display_pid" 2>/dev/null || true' EXIT
for attempt in {1..100}; do
  kill -0 "$display_pid"
  if [ -s "$display_file" ]; then break; fi
  sleep .1
done
test -s "$display_file"
read -r display_number < "$display_file"
if [[ "$scenario" == *gl32* ]]; then
 export MESA_GL_VERSION_OVERRIDE=3.2 MESA_GLSL_VERSION_OVERRIDE=150
else
 export MESA_GL_VERSION_OVERRIDE=3.3 MESA_GLSL_VERSION_OVERRIDE=330
fi
set +e
DISPLAY=:$display_number LIBGL_ALWAYS_SOFTWARE=1 timeout --foreground 360 python3 -c 'import os,json; p="/workspace/ungravity-v5/ufo-body-physics/build/cubic-client-automation"; a=json.load(open(p+"/launch.json")); os.chdir(p);os.execv(a[0],a)' < /dev/null > "work/ufo-body/native/final-${scenario}.log" 2>&1
stage_code=$?
set -e
echo "$stage_code" > "work/ufo-body/native/final-${scenario}.exit"
if [ "$stage_code" -ne 0 ]; then exit "$stage_code"; fi
test -s build/cubic-client-automation/flight-enemy-reload-ok.json
mv build/cubic-client-automation "build/cubic-client-final-${scenario}"
