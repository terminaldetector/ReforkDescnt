package com.terminaldetector.drmd.client.render;

import com.terminaldetector.drmd.client.DescentClientState;
import com.terminaldetector.drmd.weapon.items.DescentWeaponItem;
import com.terminaldetector.drmd.workshop.ClusterModule;
import com.terminaldetector.drmd.workshop.ConstructionRegistry;
import com.terminaldetector.drmd.workshop.WeaponClusters;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.Vec3d;

import java.util.List;

/**
 * First-person Doom-style weapon view from construction clusters.
 * Port of d6_wepview.lua + d6_sck_bridge VElements pipeline.
 * Modules are drawn as colored boxes relative to the camera (no GMod models).
 */
public final class WeaponViewRenderer {
	private WeaponViewRenderer() {}

    /** Hide the ordinary item only when a visible cockpit representation will replace it. */
    public static boolean replacesVanillaHand(MinecraftClient mc) {
        if(mc.player==null || mc.world==null || !mc.options.getPerspective().isFirstPerson()
                || !DescentClientState.enabled || !com.terminaldetector.drmd.client.config.DescentConfig.weaponView
                || mc.options.hudHidden || mc.currentScreen!=null)return false;
        var selected=com.terminaldetector.drmd.client.input.DroneCombatInput.primary(mc).getItem();
        if(selected instanceof com.terminaldetector.drmd.world.bombardment.BombardmentItems.BombBayItem bomb&&bomb.programmable())return true;
        if(!(selected instanceof DescentWeaponItem weapon))return false;
        return ConstructionRegistry.getModules(weapon.getDef().id).stream()
                .anyMatch(m->m.colorA>0 && m.scaleX>0 && m.scaleY>0 && m.scaleZ>0);
    }

	public static void register() {
        WorldRenderEvents.AFTER_TRANSLUCENT.register(WeaponViewRenderer::render);
    }
    private static void render(net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext context) {
            if(com.terminaldetector.drmd.client.portal.OffscreenWorldView.busy())return;
			MinecraftClient mc = MinecraftClient.getInstance();
            if(!replacesVanillaHand(mc))return;

			ItemStack stack = com.terminaldetector.drmd.client.input.DroneCombatInput.primary(mc);
            var wep=stack.getItem() instanceof DescentWeaponItem weapon?weapon:null;
            boolean cluster=stack.getItem() instanceof com.terminaldetector.drmd.world.bombardment.BombardmentItems.BombBayItem bomb&&bomb.programmable();
            if(wep==null&&!cluster)return;
			List<ClusterModule> modules = wep==null?List.of():ConstructionRegistry.getModules(wep.getDef().id);
			if (modules.isEmpty()&&!cluster) return;

			MatrixStack matrices = context.matrixStack();
			VertexConsumerProvider consumers = context.consumers();
			if (matrices == null || consumers == null) return;
            if(com.terminaldetector.drmd.client.presentation.ScenePresentation.deferOverlay(context,WeaponViewRenderer::render))return;

			matrices.push();
			// Camera-relative: origin at eye, looking down -Z in view space via camera transform already applied.
			// WorldRenderEvents gives world space — convert eye offset manually.
			Vec3d cam = context.camera().getPos();
			float yaw = context.camera().getYaw();
			float pitch = context.camera().getPitch();
			// Hull bank, not screen bank: these barrels live in world space, so the F5 front-view
			// mirroring that viewRoll() applies must not leak in here.
			float roll = DescentClientState.attitudeValid
					? com.terminaldetector.drmd.client.flight.ShipAttitudeClient.get().bankDegrees()
					: 0f;

			Vec3d look;
			Vec3d right;
			Vec3d up;
			if (DescentClientState.attitudeValid) {
				var att = com.terminaldetector.drmd.client.flight.ShipAttitudeClient.get();
				look = att.forward();
				up = att.up();
				right = att.right();
			} else {
				look = Vec3d.fromPolar(pitch, yaw);
				right = look.crossProduct(new Vec3d(0, 1, 0));
				if (right.lengthSquared() < 1e-6) right = new Vec3d(1, 0, 0);
				right = right.normalize();
				up = right.crossProduct(look).normalize();
			}
			Vec3d rr = right;
			Vec3d uu = up;
            if(cluster){
                // Same primary bank and actual muzzle offsets as WeaponCore launch. No hand/equip/bob transform.
                float scale=.18f;var anchor=cam.add(look.multiply(com.terminaldetector.drmd.world.bombardment.BombardmentItems.BombBayItem.FORWARD_MUZZLE-.57f*scale)).add(up.multiply(com.terminaldetector.drmd.world.bombardment.BombardmentItems.BombBayItem.FORWARD_HEIGHT));
                matrices.push();matrices.translate(anchor.x-cam.x,anchor.y-cam.y,anchor.z-cam.z);ModelOrientation.applyBasis(matrices,180f,look.negate(),up);matrices.scale(scale,scale,scale);drawMissilePod(matrices,consumers,0xff6b6546);matrices.pop();matrices.pop();return;
            }

			float time = (mc.player.age + context.tickCounter().getTickDelta(false)) / 20f;

			for (ClusterModule m : modules) {
                if (com.terminaldetector.drmd.workshop.HybridWeaponModels.contains(m.model)) {
                    Vec3d anchor = cam.add(look.multiply(m.posFwd / 16f))
                            .add(rr.multiply(m.posRgt / 16f)).add(uu.multiply(m.posUp / 16f));
                    matrices.push();
                    matrices.translate(anchor.x-cam.x, anchor.y-cam.y, anchor.z-cam.z);
                    ModelOrientation.applyBasis(matrices, 180f, look, up);
                    HybridWeaponRenderer.draw(matrices, consumers, m,
                            ShotFxRenderer.recoilAt(anchor, context.tickCounter().getTickDelta(false)), WeaponLoadState.get(mc.player.getId()),
                            mc.world.getLightLevel(net.minecraft.util.math.BlockPos.ofFloored(anchor)) * 0x100010);
                    matrices.pop();
                    continue;
                }
				float fwd = m.posFwd / 16f;
				float rgt = m.posRgt / 16f;
				float upp = m.posUp / 16f;
				if (m.bobAmp > 0 && m.bobFreq > 0) {
					upp += (float) (Math.sin(time * m.bobFreq * Math.PI * 2) * m.bobAmp / 16f);
				}
				Vec3d pos = cam.add(look.multiply(fwd)).add(rr.multiply(rgt)).add(uu.multiply(upp));

				matrices.push();
				matrices.translate(pos.x - cam.x, pos.y - cam.y, pos.z - cam.z);
				ModelOrientation.applyBasis(matrices, 180f, look.negate(), up);
				matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(m.roll));
                matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(m.yaw));
                matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(m.pitch));
				if (m.spin != 0) {
					matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(time * m.spin * 60f));
				}
				float s = 0.08f * m.scaleX;
				matrices.scale(s, .08f * m.scaleY, .08f * m.scaleZ * modelLength(m.model));

				int[] rgb = colorForModel(m);
				int argb = HybridWeaponRenderer.tint((rgb[0] << 16) | (rgb[1] << 8) | rgb[2], m);
				switch (m.model) {
					case "gravy" -> drawGravyClaw(matrices, consumers, argb);
					case "nosegun" -> drawNoseGun(matrices, consumers, argb);
					case "strider" -> drawMissilePod(matrices, consumers, argb);
					default -> drawBarrel(matrices, consumers, argb);
				}
				matrices.pop();
			}
			matrices.pop();
	}

	/** Gravy manipulator — fork/claw silhouette (MC is simple enough for procedural barrels). */
	private static void drawGravyClaw(MatrixStack matrices, VertexConsumerProvider consumers, int argb) {
		drawBox(matrices, consumers, argb, 15728880);
		matrices.push();
		matrices.translate(-0.7f, 0.4f, 0.6f);
		matrices.scale(0.35f, 0.35f, 1.4f);
		drawBox(matrices, consumers, argb, 15728880);
		matrices.pop();
		matrices.push();
		matrices.translate(0.7f, 0.4f, 0.6f);
		matrices.scale(0.35f, 0.35f, 1.4f);
		drawBox(matrices, consumers, argb, 15728880);
		matrices.pop();
		matrices.push();
		matrices.translate(0f, -0.55f, 0.5f);
		matrices.scale(0.3f, 0.3f, 1.2f);
		drawBox(matrices, consumers, argb, 15728880);
		matrices.pop();
	}

	private static void drawNoseGun(MatrixStack matrices, VertexConsumerProvider consumers, int argb) {
		drawBox(matrices, consumers, argb, 15728880);
		matrices.push();
		matrices.translate(0, 0, 0.55f);
		matrices.scale(0.55f, 0.55f, 0.9f);
		drawBox(matrices, consumers, argb, 15728880);
		matrices.pop();
	}

	/**
	 * Missile pod — a rack of tubes with visible warheads, not one block.
	 *
	 * <p>Loaded rounds are drawn slightly proud of the tube mouths so the pod reads as armed at a
	 * glance; the count is what the rocket sub-mode is cycling through.
	 */
	private static void drawMissilePod(MatrixStack matrices, VertexConsumerProvider consumers, int argb) {
		int tipArgb = (argb & 0xFF000000) | 0x00FFD070;
		for (int i = 0; i < 4; i++) {
			float ox = (i % 2 == 0) ? -0.32f : 0.32f;
			float oy = (i < 2) ? 0.28f : -0.28f;
			matrices.push();
			matrices.translate(ox, oy, 0f);
			matrices.scale(0.42f, 0.42f, 1.0f);
			drawBox(matrices, consumers, argb, 15728880);
			matrices.pop();
			// Warhead poking out of the tube.
			matrices.push();
			matrices.translate(ox, oy, 0.42f);
			matrices.scale(0.26f, 0.26f, 0.30f);
			drawBox(matrices, consumers, tipArgb, 15728880);
			matrices.pop();
		}
		// Spine tying the tubes together.
		matrices.push();
		matrices.scale(0.9f, 0.16f, 0.9f);
		drawBox(matrices, consumers, argb, 15728880);
		matrices.pop();
	}

	/** Plain cannon: a body with a stepped muzzle, so the firing end is readable. */
	private static void drawBarrel(MatrixStack matrices, VertexConsumerProvider consumers, int argb) {
		matrices.push();
		matrices.scale(0.7f, 0.7f, 1f);
		drawBox(matrices, consumers, argb, 15728880);
		matrices.pop();
		matrices.push();
		matrices.translate(0, 0, 0.46f);
		matrices.scale(0.44f, 0.44f, 0.28f);
		drawBox(matrices, consumers, argb, 15728880);
		matrices.pop();
	}

	private static float modelLength(String model) {
		return switch (model) {
			case "nosegun" -> 2.2f;
			case "strider" -> 2.8f;
			case "gravy" -> 1.4f;
			default -> 1.8f; // barrel
		};
	}

	private static int[] colorForModel(ClusterModule m) {
		// Tint by cluster role, modulated by model type
		int[] base = WeaponClusters.COLORS[WeaponClusters.rank(m.cluster)];
		return switch (m.model) {
			case "gravy" -> new int[]{180, 200, 255};
			case "strider" -> new int[]{220, 160, 80};
			case "nosegun" -> new int[]{Math.min(255, base[0] + 40), base[1], base[2]};
			default -> base;
		};
	}

	private static final net.minecraft.util.Identifier TEXTURE =
			net.minecraft.util.Identifier.of("minecraft", "textures/misc/white.png");

	private static void drawBox(MatrixStack matrices, VertexConsumerProvider consumers, int argb, int light) {
		// Quads, into a layer built for them. This was RenderLayer.getDebugFilledBox() (a
		// TRIANGLE_STRIP layer: the six quads below are 24 vertices, and a strip reads those as a run
		// of degenerate slivers rather than as six faces, so the module had no solid body), then
		// RenderLayer.getDebugQuads() — still a debug-only layer, and per CockpitRenderer's own
		// finding, one that "often never appears under TLauncher / sodium-class pipelines". A weapon
		// module rendered that way is a barrel that sometimes is not there at all, or is there as
		// disconnected faces instead of a solid shape. RenderLayer.getEntitySolid is the layer
		// ProjectileRenderer (and every other hand-built-cube renderer in this codebase) already
		// draws through.
		//
		// Solid, and with each face's own outward normal. Recomputing the winding of the coordinates
		// below (cross product of each face's own edges) shows all six *are* wound consistently
		// outward — the "not wound consistently" claim this comment used to make was stale, left over
		// from before these coordinates were last touched. What's actually unresolved is the other
		// half of the question: whether getEntitySolid culls backfaces at all in this MC/Fabric
		// version's RenderPhase setup, and if so, which winding it treats as front — this project has
		// no decompiled Minecraft source and no live client available to check either way. See quad()
		// below for how that is made not to matter.
		var entry = matrices.peek();
		var vc = consumers.getBuffer(net.minecraft.client.render.RenderLayer.getEntitySolid(TEXTURE));
		float a = ((argb >> 24) & 255) / 255f;
		float r = ((argb >> 16) & 255) / 255f;
		float g = ((argb >> 8) & 255) / 255f;
		float b = (argb & 255) / 255f;
		float x0 = -0.5f, y0 = -0.5f, z0 = -0.5f;
		float x1 = 0.5f, y1 = 0.5f, z1 = 0.5f;
		// 6 faces — compact
		quad(vc, entry, x0, y0, z0, x1, y0, z0, x1, y0, z1, x0, y0, z1, r, g, b, a, light, 0, -1, 0);
		quad(vc, entry, x0, y1, z0, x0, y1, z1, x1, y1, z1, x1, y1, z0, r, g, b, a, light, 0, 1, 0);
		quad(vc, entry, x0, y0, z0, x0, y1, z0, x1, y1, z0, x1, y0, z0, r, g, b, a, light, 0, 0, -1);
		quad(vc, entry, x0, y0, z1, x1, y0, z1, x1, y1, z1, x0, y1, z1, r, g, b, a, light, 0, 0, 1);
		quad(vc, entry, x0, y0, z0, x0, y0, z1, x0, y1, z1, x0, y1, z0, r, g, b, a, light, -1, 0, 0);
		quad(vc, entry, x1, y0, z0, x1, y1, z0, x1, y1, z1, x1, y0, z1, r, g, b, a, light, 1, 0, 0);
	}

	/**
	 * Emits each face in both winding orders. Whichever convention getEntitySolid actually culls
	 * against — if it culls at all, which this environment cannot check either way (see drawBox) —
	 * one ordering is front-facing and survives; the other is back-facing and gets dropped. If
	 * culling turns out to be off entirely, both orderings draw: same four corners, same colour,
	 * landing on identical depth, so the second pass paints over the first rather than showing as a
	 * seam. Either way the face is fully visible; there is no ordering under which it goes missing.
	 * Doubles the vertex count per box — negligible next to a single vanilla mob model, and not a
	 * cost worth trading the certainty for at this scale.
	 */
	private static void quad(net.minecraft.client.render.VertexConsumer vc, MatrixStack.Entry entry,
							 float x0, float y0, float z0, float x1, float y1, float z1,
							 float x2, float y2, float z2, float x3, float y3, float z3,
							 float r, float g, float b, float a, int light, float nx, float ny, float nz) {
		var m = entry.getPositionMatrix();
		vc.vertex(m, x0, y0, z0).color(r, g, b, a).texture(0, 0).overlay(net.minecraft.client.render.OverlayTexture.DEFAULT_UV).light(light).normal(nx, ny, nz);
		vc.vertex(m, x1, y1, z1).color(r, g, b, a).texture(1, 0).overlay(net.minecraft.client.render.OverlayTexture.DEFAULT_UV).light(light).normal(nx, ny, nz);
		vc.vertex(m, x2, y2, z2).color(r, g, b, a).texture(1, 1).overlay(net.minecraft.client.render.OverlayTexture.DEFAULT_UV).light(light).normal(nx, ny, nz);
		vc.vertex(m, x3, y3, z3).color(r, g, b, a).texture(0, 1).overlay(net.minecraft.client.render.OverlayTexture.DEFAULT_UV).light(light).normal(nx, ny, nz);
		vc.vertex(m, x0, y0, z0).color(r, g, b, a).texture(0, 0).overlay(net.minecraft.client.render.OverlayTexture.DEFAULT_UV).light(light).normal(nx, ny, nz);
		vc.vertex(m, x3, y3, z3).color(r, g, b, a).texture(0, 1).overlay(net.minecraft.client.render.OverlayTexture.DEFAULT_UV).light(light).normal(nx, ny, nz);
		vc.vertex(m, x2, y2, z2).color(r, g, b, a).texture(1, 1).overlay(net.minecraft.client.render.OverlayTexture.DEFAULT_UV).light(light).normal(nx, ny, nz);
		vc.vertex(m, x1, y1, z1).color(r, g, b, a).texture(1, 0).overlay(net.minecraft.client.render.OverlayTexture.DEFAULT_UV).light(light).normal(nx, ny, nz);
	}
}
