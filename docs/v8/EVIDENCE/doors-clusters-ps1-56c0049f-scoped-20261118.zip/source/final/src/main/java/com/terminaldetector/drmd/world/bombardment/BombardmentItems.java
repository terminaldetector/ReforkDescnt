package com.terminaldetector.drmd.world.bombardment;

import com.terminaldetector.drmd.DescentPlayerData;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.World;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Bomb bay / rocket bay / laser designator items for high-altitude bombardment.
 * Release point is ship belly + ahead of the bay, inheriting flight velocity.
 */
public final class BombardmentItems {
	/** Last laser mark per player. */
	private static final Map<UUID, BlockPos> LASER_MARKS = new ConcurrentHashMap<>();

	private BombardmentItems() {}

	public static BlockPos getLaserMark(UUID id) {
		return LASER_MARKS.get(id);
	}

	public static class BombBayItem extends Item {
		public static final float FORWARD_MUZZLE=.9f,FORWARD_HEIGHT=-.22f;
		private final OrdnanceType ordnance;

		public BombBayItem(OrdnanceType ordnance, Settings settings) {
			super(settings.maxCount(16));
			this.ordnance = ordnance;
		}

		public OrdnanceType getOrdnance() {
			return ordnance;
		}
        public boolean programmable(){return ordnance==OrdnanceType.CLUSTER||ordnance==OrdnanceType.HEAVY_CLUSTER;}
        @Override public void appendTooltip(ItemStack stack,Item.TooltipContext context,java.util.List<Text> tooltip,net.minecraft.item.tooltip.TooltipType kind){super.appendTooltip(stack,context,tooltip,kind);if(programmable()){tooltip.add(Text.translatable("item.drmd.cluster_controls"));tooltip.add(Text.translatable("item.drmd.cluster_select"));}}
        public TypedActionResult<ItemStack> useBank(World world,PlayerEntity user,Hand hand,int channel){return channel==0&&programmable()?launchProgram(world,user,hand,true):use(world,user,hand);}
        private TypedActionResult<ItemStack> launchProgram(World world,PlayerEntity user,Hand hand,boolean forward){
            var stack=user.getStackInHand(hand);if(world.isClient)return TypedActionResult.success(stack);
            if(!(world instanceof ServerWorld sw)||!(user instanceof ServerPlayerEntity player)||!player.isAlive()||player.isSpectator()||!player.getAbilities().allowModifyWorld||player.getItemCooldownManager().isCoolingDown(this))return TypedActionResult.fail(stack);
            var custom=stack.getOrDefault(net.minecraft.component.DataComponentTypes.CUSTOM_DATA,net.minecraft.component.type.NbtComponent.DEFAULT).copyNbt();var raw=custom.get(ClusterFlight.ITEM_KEY);
            var decoded=raw==null?java.util.Optional.of(ClusterProgram.preset(ClusterProgram.Pattern.FAN)):ClusterFlight.readProgram(raw);
            if(decoded.isEmpty()){user.sendMessage(Text.translatable("message.drmd.cluster_program_refused"),true);return TypedActionResult.fail(stack);}var program=decoded.get();
            if(!forward&&user.isSneaking()){program=program.next();custom.put(ClusterFlight.ITEM_KEY,ClusterFlight.writeProgram(program));stack.set(net.minecraft.component.DataComponentTypes.CUSTOM_DATA,net.minecraft.component.type.NbtComponent.of(custom));player.getItemCooldownManager().set(this,4);user.sendMessage(Text.translatable("message.drmd.cluster_program",Text.translatable("cluster.drmd."+program.pattern().name().toLowerCase(java.util.Locale.ROOT))),true);return TypedActionResult.success(stack);}
            var data=DescentPlayerData.get(user);var f=com.terminaldetector.drmd.weapon.core.WeaponCore.aimDir(user).normalize();var up=data.shipUp(user).normalize();var down=up.negate();
            var drop=com.terminaldetector.drmd.weapon.core.WeaponCore.muzzle(user,forward?FORWARD_MUZZLE:2.4f,0,forward?FORWARD_HEIGHT:-1.65f);
            var inherit=data.isEnabled()?data.getFlightVelocity().multiply(1.0/com.terminaldetector.drmd.DescentMod.TICKS_PER_SECOND):user.getVelocity();
            var velocity=forward?inherit.add(f.multiply(.9)):inherit.add(f.multiply(.65)).add(up.multiply(-.45));
            if(!ClusterOrdnanceSafety.volumeLoaded(sw,drop,.5)||!com.terminaldetector.drmd.world.edit.WorldEditSafety.loadedSegment(world,user.getEyePos(),drop)||!com.terminaldetector.drmd.world.edit.WorldEditSafety.mayChange(sw,BlockPos.ofFloored(drop),user))return TypedActionResult.fail(stack);
            var bomb=com.terminaldetector.drmd.entity.ModEntities.AERIAL_BOMB.create(sw);if(bomb==null)return TypedActionResult.fail(stack);bomb.setPosition(drop);if(!sw.isSpaceEmpty(bomb,bomb.getBoundingBox()))return TypedActionResult.fail(stack);
            bomb.setVelocity(velocity);bomb.configure(ordnance,user,null);bomb.program(program,forward?f:down,forward?up:f,down);
            if(!sw.spawnEntity(bomb))return TypedActionResult.fail(stack);player.getItemCooldownManager().set(this,10);if(!user.getAbilities().creativeMode)stack.decrement(1);SmokeSystemTrail(drop);return TypedActionResult.success(stack);
        }

		@Override
		public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
			if(programmable())return launchProgram(world,user,hand,false);
			ItemStack stack = user.getStackInHand(hand);
			if (world.isClient) return TypedActionResult.success(stack);
			if (!(world instanceof ServerWorld sw) || !(user instanceof ServerPlayerEntity sp)) {
				return TypedActionResult.fail(stack);
			}
			var bomb = com.terminaldetector.drmd.entity.ModEntities.AERIAL_BOMB.create(sw);
			if (bomb == null) return TypedActionResult.fail(stack);

			DescentPlayerData data = DescentPlayerData.get(user);
			Vec3d fwd = data.shipForward(user);
			Vec3d up = data.shipUp(user);
			// Bay doors: under the hull and a bit ahead — not a pure "drop from feet".
			Vec3d drop = user.getPos()
					.add(0, user.getHeight() * 0.45, 0)
					.add(fwd.multiply(2.4))
					.add(up.multiply(-1.65));
			Vec3d inherit = data.isEnabled() ? data.getFlightVelocity().multiply(1.0 / com.terminaldetector.drmd.DescentMod.TICKS_PER_SECOND) : user.getVelocity();
			// Eject forward + down so the round clears the ship before falling.
			Vec3d eject = inherit.add(fwd.multiply(0.65)).add(up.multiply(-0.45));
			if (ordnance.rocket) {
				eject = eject.add(fwd.multiply(1.55)).add(up.multiply(-0.1));
			}

			// Velocity carries attitude — no Euler pitch=90 (breaks past-vertical / banked drops).
			bomb.refreshPositionAndAngles(drop.x, drop.y, drop.z, 0f, 0f);
			bomb.setVelocity(eject);
			bomb.configure(ordnance, user, LASER_MARKS.get(user.getUuid()));
			sw.spawnEntity(bomb);
			SmokeSystemTrail(drop);
			if (!user.getAbilities().creativeMode) stack.decrement(1);
			user.sendMessage(Text.translatable(ordnance.rocket?"message.drmd.rocket_launched":"message.drmd.ordnance_launched"),true);
            com.terminaldetector.drmd.DescentMod.LOGGER.debug("Ordnance {} launched by {} at {}",ordnance,user.getUuid(),user.getPos());
			return TypedActionResult.success(stack);
		}

		private static void SmokeSystemTrail(Vec3d at) {
			com.terminaldetector.drmd.world.smoke.SmokeSystem.emit(
					at, com.terminaldetector.drmd.world.smoke.SmokeSystem.Source.ENGINE, 0.5f, 0.3f, 20);
		}
	}

	public static class LaserDesignatorItem extends Item {
		public LaserDesignatorItem(Settings settings) {
			super(settings.maxCount(1));
		}

		@Override
		public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
			ItemStack stack = user.getStackInHand(hand);
			if (world.isClient) return TypedActionResult.success(stack);
			Vec3d eye = user.getEyePos();
			// Ship-forward aim so laser marks work inverted / past vertical.
			Vec3d aim = com.terminaldetector.drmd.weapon.core.WeaponCore.aimDir(user);
			Vec3d end = eye.add(aim.multiply(256));
			BlockHitResult hit = world.raycast(new RaycastContext(eye, end,
					RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, user));
			if (hit.getType() == HitResult.Type.BLOCK) {
				BlockPos mark = hit.getBlockPos();
				LASER_MARKS.put(user.getUuid(), mark);
				user.sendMessage(Text.literal("§aLaser mark §f" + mark.toShortString()), true);
				if (world instanceof ServerWorld sw) {
					sw.spawnParticles(net.minecraft.particle.ParticleTypes.END_ROD,
							mark.getX() + 0.5, mark.getY() + 1.2, mark.getZ() + 0.5,
							16, 0.2, 0.4, 0.2, 0.02);
				}
			} else {
				user.sendMessage(Text.literal("§7No laser lock"), true);
			}
			return TypedActionResult.success(stack);
		}
	}
}
