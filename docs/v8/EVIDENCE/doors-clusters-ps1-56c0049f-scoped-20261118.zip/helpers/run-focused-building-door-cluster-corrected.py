"""First actual pending-crossing integration; unchanged prior16/44 scope is not rerun or inherited."""
from pathlib import Path
import hashlib, json, os, shutil, signal, subprocess, time
import xml.etree.ElementTree as ET

ROOT = Path('/workspace/ungravity-v5/ufo-body-physics')
SOURCE = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
assert SOURCE == '42276e7bf9b44b1ba3b119f289756e750a7fba13'
assert not subprocess.check_output(['git', 'status', '--porcelain', '--untracked-files=no'], cwd=ROOT)
OUT = ROOT / 'work/multi-agent' / ('focused-' + SOURCE[:8] + '-first')
assert not OUT.exists() and not (ROOT / 'build/gametest/world').exists()
assert shutil.disk_usage(ROOT).free >= 160 * 1024 * 1024
OUT.mkdir()
declared = json.loads((ROOT / 'src/gametest/resources/fabric.mod.json').read_text())
assert len(declared['entrypoints']['fabric-gametest']) == 100
entries = ['com.terminaldetector.drmd.BodyDoorGameTests', 'com.terminaldetector.drmd.BlastStructuralCollapseGameTests', 'com.terminaldetector.drmd.ProgrammedClusterGameTests', 'com.terminaldetector.drmd.BodyHatchGameTests', 'com.terminaldetector.drmd.CollapseGameTests', 'com.terminaldetector.drmd.ClusterLifecycleGameTests', 'com.terminaldetector.drmd.BombBayVelocityGameTests', 'com.terminaldetector.drmd.DroneTriggerEdgeGameTests']
assert all(x in declared['entrypoints']['fabric-gametest'] for x in entries)
init = OUT / 'focus.init.gradle'
init.write_text('''import groovy.json.JsonSlurper
import groovy.json.JsonOutput
gradle.projectsEvaluated {
  rootProject.tasks.named('processGametestResources') {
    outputs.upToDateWhen { false }
    doLast {
      def p = rootProject.file('build/resources/gametest/fabric.mod.json')
      def m = new JsonSlurper().parse(p)
      m.entrypoints['fabric-gametest'] = ''' + json.dumps(entries) + '''
      p.text = JsonOutput.prettyPrint(JsonOutput.toJson(m)) + '\\n'
    }
  }
}
''')
result_xml = ROOT / 'build/gametest/reports/gametest-results.xml'
if result_xml.exists():
    shutil.copyfile(result_xml, OUT / 'prior-game-results.xml')
    result_xml.unlink()
for name in ['verified-build.json', 'verified-build.inputs.json']:
    old = ROOT / 'work/ps1' / name
    if old.exists():
        shutil.copyfile(old, OUT / ('prior-ps1-' + name))
subprocess.run(['python3', 'scripts/v8/ps1_build_stamp.py', 'before'], cwd=ROOT, check=True)
start = time.time_ns()
command = ['./gradlew', 'runGametest', 'remapJar', 'remapCubiccheckJar', '--offline', '--no-daemon', '-I', str(init)]
env = dict(os.environ, JAVA_HOME='/workspace/jdk21-complete', GRADLE_USER_HOME='/workspace/.gradle')
env['PATH'] = env['JAVA_HOME'] + '/bin:' + env['PATH']
(OUT / 'start.json').write_text(json.dumps(dict(source=SOURCE, command=command, startedNs=start,
    ordinarySourceEntries=100, selectedGameClasses=entries, intendedGames=40, intendedUnits=0,
    scope='Changed building, door and cluster actual gameplay plus retained regressions. Prior21units PASS on identical production; not rerun. Originald6Gametestcompile failure retained. NewPS1clientmode separately unrun.'), indent=2) + '\n')
timed = False
with (OUT / 'first.log').open('xb') as log:
    child = subprocess.Popen(command, cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
    print(json.dumps(dict(startedGradlePid=child.pid, source=SOURCE)), flush=True)
    try:
        code = child.wait(timeout=600)
    except subprocess.TimeoutExpired:
        timed = True
        os.killpg(child.pid, signal.SIGTERM)
        try:
            code = child.wait(timeout=15)
        except subprocess.TimeoutExpired:
            os.killpg(child.pid, signal.SIGKILL)
            code = child.wait()
(OUT / 'exit.json').write_text(json.dumps(dict(actualGradleExit=code, timedOut=timed, closedNs=time.time_ns())) + '\n')
rows = []
if result_xml.exists() and result_xml.stat().st_mtime_ns >= start:
    rows = list(ET.parse(result_xml).getroot().iter('testcase'))
    shutil.copyfile(result_xml, OUT / 'gametest-results.xml')
result = dict(source=SOURCE, actualGradleExit=code, timedOut=timed,
    game=dict(tests=len(rows), failures=sum(x.find('failure') is not None for x in rows),
              errors=sum(x.find('error') is not None for x in rows), skipped=sum(x.find('skipped') is not None for x in rows)),
    unitsRun=0, fullSuiteAccepted=False, nativeClientAccepted=False)
result['passed'] = code == 0 and not timed and result['game'] == dict(tests=40, failures=0, errors=0, skipped=0)
if result['passed']:
    subprocess.run(['python3', 'scripts/v8/ps1_build_stamp.py', 'record'], cwd=ROOT, check=True)
    shutil.copyfile(ROOT / 'work/ps1/verified-build.json', OUT / 'verified-build.json')
    for suffix in ['', '-cubiccheck']:
        jar = ROOT / 'build/libs' / ('drmd-6dof-1.1.35-ufo-dev.1' + suffix + '.jar')
        result['observerSHA256' if suffix else 'jarSHA256'] = hashlib.sha256(jar.read_bytes()).hexdigest()
        shutil.copyfile(jar, OUT / jar.name)
assert json.loads((ROOT / 'src/gametest/resources/fabric.mod.json').read_text()) == declared
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == SOURCE
(OUT / 'outcome.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result), flush=True)
raise SystemExit(0 if result['passed'] else 1)
