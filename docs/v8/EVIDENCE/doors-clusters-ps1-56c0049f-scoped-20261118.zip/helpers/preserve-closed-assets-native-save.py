"""Losslessly preserve one closed, disposable canonical GameTest save."""
from pathlib import Path
import fcntl, gzip, hashlib, json, os, shutil, stat, sys, zipfile

ROOT = Path('/workspace/ungravity-v5/ufo-body-physics')
RUN = ROOT / 'work/multi-agent/native-assets-pacing-ba30a2c9-first'
assert RUN.parent == ROOT / 'work/multi-agent' and RUN.is_dir()
RESULT = dict(source=json.loads((RUN / 'verified-build.json').read_text())['sourceSha'], native=json.loads((RUN / 'native-receipt.json').read_text()))
WORLD = ROOT / 'build/cubic-client-failed-assets-pacing-ba30a2c9-sodium-first/saves/Cubic-Gate'
ARCHIVE, RECEIPT = RUN / 'closed-save.zip', RUN / 'save-preserved.json'
assert WORLD.is_dir() and WORLD.resolve() == WORLD
assert not ARCHIVE.exists() and not RECEIPT.exists()

def closed():
    for p in Path('/proc').glob('[0-9]*'):
        try:
            if (p / 'comm').read_text().strip() != 'java':
                continue
            state = (p / 'stat').read_text().rsplit(') ', 1)[1].split()[0]
            assert state in ('Z', 'X'), str(p)
        except (FileNotFoundError, ProcessLookupError, PermissionError):
            continue

def sha_file(p):
    h = hashlib.sha256()
    with p.open('rb') as stream:
        for b in iter(lambda: stream.read(1048576), b''):
            h.update(b)
    return h.hexdigest()

closed()
free_before = shutil.disk_usage(ROOT).free
with (WORLD / 'session.lock').open('r+b') as lock:
    fcntl.lockf(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)

    def lock_bytes():
        # Opening and closing another FD on this inode would release POSIX locks.
        return os.pread(lock.fileno(), os.fstat(lock.fileno()).st_size, 0)

    def inventory():
        rows = {}
        for p in sorted(WORLD.rglob('*')):
            assert not p.is_symlink()
            if not p.is_file():
                continue
            s = p.lstat()
            assert stat.S_ISREG(s.st_mode) and s.st_nlink == 1
            rel = str(p.relative_to(WORLD))
            digest = hashlib.sha256(lock_bytes()).hexdigest() if rel == 'session.lock' else sha_file(p)
            rows[rel] = dict(bytes=s.st_size, sha256=digest, dev=s.st_dev, inode=s.st_ino,
                             mtimeNs=s.st_mtime_ns, mode=stat.S_IMODE(s.st_mode), blocks=s.st_blocks * 512)
        return rows

    rows = inventory()
    assert 'level.dat' in rows and 'session.lock' in rows
    manifest = dict(source=RESULT['source'], result=RESULT, original=str(WORLD), files=rows,
                    scope='Only this closed disposable canonical focused GameTest save; other saves and evidence untouched.')
    with zipfile.ZipFile(ARCHIVE, 'x', zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for rel in rows:
            if rel == 'session.lock':
                z.writestr(rel, lock_bytes())
            else:
                z.write(WORLD / rel, rel)
        z.writestr('PRESERVATION.json', json.dumps(manifest, indent=2) + '\n')
    gzip_count = 0
    with zipfile.ZipFile(ARCHIVE) as z:
        assert z.testzip() is None and set(z.namelist()) == set(rows) | {'PRESERVATION.json'}
        for rel, row in rows.items():
            h, n = hashlib.sha256(), 0
            with z.open(rel) as stream:
                for b in iter(lambda: stream.read(1048576), b''):
                    h.update(b)
                    n += len(b)
            assert n == row['bytes'] and h.hexdigest() == row['sha256']
            with z.open(rel) as stream:
                is_gzip = stream.read(2) == b'\x1f\x8b'
            if is_gzip:
                with z.open(rel) as stream, gzip.GzipFile(fileobj=stream) as g:
                    while g.read(1048576):
                        pass
                gzip_count += 1
    closed()
    assert inventory() == rows
    held = os.fstat(lock.fileno())
    key = f'{os.major(held.st_dev):02x}:{os.minor(held.st_dev):02x}:{held.st_ino}'
    owned = [line.split() for line in Path('/proc/locks').read_text().splitlines()
             if key in line]
    assert {line[1] for line in owned if line[4] == str(os.getpid())} == {'POSIX', 'FLOCK'}
    receipt = dict(source=RESULT['source'], archive=str(ARCHIVE), archiveSHA256=sha_file(ARCHIVE),
                   archiveBytes=ARCHIVE.stat().st_size, files=len(rows), originalBytes=sum(x['bytes'] for x in rows.values()),
                   allocatedBytes=sum(x['blocks'] for x in rows.values()), fullZIPCRCAndEverySHA256=True,
                   gzipFooters=gzip_count, freshInodeMtimeHashInventory=True, exclusivePosixAndFlock=True,
                   sessionLockReadOnlyThroughHeldFD=True, beforeFreeBytes=free_before, rawWorldReclaimed=False)
    RECEIPT.write_text(json.dumps(receipt, indent=2) + '\n')
    shutil.rmtree(WORLD)
    receipt.update(rawWorldReclaimed=True, afterFreeBytes=shutil.disk_usage(ROOT).free)
    RECEIPT.write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt))
