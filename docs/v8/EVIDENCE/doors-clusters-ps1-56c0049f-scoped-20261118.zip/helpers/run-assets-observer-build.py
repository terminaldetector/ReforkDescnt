from pathlib import Path
import hashlib,json,os,shutil,subprocess,time
ROOT=Path('/workspace/ungravity-v5/ufo-body-physics')
SOURCE=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=ROOT)
changed=subprocess.check_output(['git','diff','--name-only','ba30a2c9',SOURCE,'--','src'],cwd=ROOT,text=True).splitlines()
assert changed==['src/cubiccheck/java/com/terminaldetector/drmd/gate/NativeAssetsPacingCheck.java'],changed
OUT=ROOT/('work/multi-agent/build-'+SOURCE[:8]+'-first');assert not OUT.exists();OUT.mkdir()
assert shutil.disk_usage(ROOT).free>100*1024*1024
command=['./gradlew','remapJar','remapCubiccheckJar','--offline','--no-daemon']
subprocess.run(['python3','scripts/v8/ps1_build_stamp.py','before'],cwd=ROOT,check=True)
env=dict(os.environ,JAVA_HOME='/workspace/jdk21-complete',GRADLE_USER_HOME='/workspace/.gradle');env['PATH']=env['JAVA_HOME']+'/bin:'+env['PATH']
(OUT/'start.json').write_text(json.dumps(dict(source=SOURCE,command=command,startedNs=time.time_ns(),sourceChanges=changed,scope='Observer readiness only; prior focused server results not rerun'),indent=2)+'\n')
with (OUT/'first.log').open('xb')as log:
 result=subprocess.run(command,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=360)
receipt=dict(source=SOURCE,actualGradleExit=result.returncode,closedNs=time.time_ns(),unitRun=0,gameRun=0,newFullSuiteAccepted=False)
if result.returncode==0:
 subprocess.run(['python3','scripts/v8/ps1_build_stamp.py','record'],cwd=ROOT,check=True)
 shutil.copyfile(ROOT/'work/ps1/verified-build.json',OUT/'verified-build.json')
 for name in ['drmd-6dof-1.1.35-ufo-dev.1.jar','drmd-6dof-1.1.35-ufo-dev.1-cubiccheck.jar']:
  path=ROOT/'build/libs'/name;shutil.copyfile(path,OUT/name);receipt[name]=hashlib.sha256(path.read_bytes()).hexdigest()
(OUT/'outcome.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt),flush=True)
raise SystemExit(result.returncode)
