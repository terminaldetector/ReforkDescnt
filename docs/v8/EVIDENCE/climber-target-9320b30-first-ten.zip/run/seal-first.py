from pathlib import Path
import subprocess,json,hashlib,zipfile,fcntl,shutil
root=Path.cwd();out=root/'work/climber-target-admission-20261117';source='9320b300d6cd2e34fae8648b1e6f3e4f2201b4e0'
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==source;assert not subprocess.check_output(['git','diff','HEAD','--','src'],text=True)
world=root/'build/gametest/world';assert world.is_dir()
lock=open(out/'closed-world.lock','a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
for proc in Path('/proc').iterdir():
 if not proc.name.isdigit():continue
 try:
  if(proc/'comm').read_text().strip()=='java'and(proc/'cwd').resolve()==root:raise RuntimeError('Own Java still running')
 except(FileNotFoundError,ProcessLookupError,PermissionError):pass
lines=(out/'first.log').read_text(errors='replace').splitlines();markers=[]
for line in lines:
 for key in ['CLIMBER_STEP_ASSESSMENT ','CLIMBER_STEP_PREASSERT ','CLIMBER_AIR_ACCEPTANCE ','CLIMBER_OLD_FIXTURE_309 ','CLIMBER_FIELD ','CLIMBER_SURFACE_ADMISSION ','CLIMBER_SURFACE_PRE_TIMEOUT ']:
  if key in line:markers.append({'markerType':key.strip(),'actual':json.loads(line.split(key,1)[1])});break
(out/'first-markers.json').write_text(json.dumps(markers,indent=2)+'\n')
files={}
def add(p,name=None):
 p=Path(p);name=name or str(p.relative_to(root));assert p.is_file(),p;assert name not in files,name;files[name]=p
for n in subprocess.check_output(['git','diff','--name-only','952286a',source,'--','src'],text=True).splitlines():add(root/n)
for n in ['src/gametest/java/com/terminaldetector/drmd/ClimberFieldGravityGameTests.java','src/gametest/resources/fabric.mod.json','build.gradle','settings.gradle','gradle.properties']:add(root/n)
for p in(root/'src/gametest/java/com/terminaldetector/drmd/climber').rglob('*.java'):
 if str(p.relative_to(root))not in files:add(p)
for p in(root/'build/classes/java/gametest/com/terminaldetector/drmd/climber').rglob('*.class'):add(p)
for pattern in ['ClimberFieldGravityGameTests*.class','ClimberJumpGravityGameTests*.class','ClimberStepGeometryGameTests*.class']:
 for p in(root/'build/classes/java/gametest/com/terminaldetector/drmd').glob(pattern):add(p)
for directory,patterns in [('build/classes/java/main/com/terminaldetector/drmd/world/gravity',['LocalSurface*']),('build/classes/java/main/com/terminaldetector/drmd/mixin',['LocalSurface*','LocalSpiderNavigationMixin*'])]:
 for pattern in patterns:
  for p in(root/directory).glob(pattern+'.class'):add(p)
for n in ['build/resources/main/drmd.mixins.json','build/resources/main/fabric.mod.json','build/resources/gametest/fabric.mod.json','build/resources/gametest/drmd.climber_air_acceptance.mixins.json']:add(root/n)
add(root/'work/climber-step-diagnostic-20261117/native-step-contract.json','native/native-step-contract.json')
for p in out.glob('first*'):
 if p.is_file():add(p,'run/'+p.name)
for n in ['focus.init.gradle','executing-focus.init.gradle','CONTRACT.md','source-receipt.json','derive-first.py','seal-first.py']:add(out/n,'run/'+n)
(out/'source-first.patch').write_bytes(subprocess.check_output(['git','diff','952286a',source,'--','src']));add(out/'source-first.patch','run/source-first.patch')
worldRows=[]
for p in sorted(world.rglob('*')):
 if p.is_file():
  name=str(p.relative_to(world));add(p,'world/'+name);worldRows.append({'path':name,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
(out/'world-inventory.json').write_text(json.dumps(worldRows,indent=2)+'\n');add(out/'world-inventory.json','run/world-inventory.json')
rows=[{'path':n,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}for n,p in sorted(files.items())]
archive=root/'docs/v8/EVIDENCE/climber-target-9320b30-first-ten.zip';assert not archive.exists()
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for n,p in sorted(files.items()):z.write(p,n)
 z.writestr('MANIFEST.json',json.dumps({'source':source,'payloads':rows,'worldFiles':len(worldRows),'worldBytes':sum(r['bytes']for r in worldRows),'classification':'FIRST10GT5PASS5FAIL; bothgeometrycontrolsPASS; SpiderfullroutePASS/CaverouteFAIL; standalone3.9darkpreflightFAIL; no newunits/JAR'},indent=2)+'\n')
with zipfile.ZipFile(archive)as z:
 assert z.testzip()is None
 for r in rows:assert hashlib.sha256(z.read(r['path'])).hexdigest()==r['sha256']
receipt={'source':source,'archive':str(archive.relative_to(root)),'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'bytes':archive.stat().st_size,'payloadFiles':len(rows),'worldFiles':len(worldRows),'worldBytes':sum(r['bytes']for r in worldRows),'allSha256AndZipCrcVerified':True,'exclusiveFlock':str(out/'closed-world.lock'),'gameTests':10,'passes':5,'failures':5,'errors':0,'rawAirEvents':506,'rawAirActors':4,'nativePounces':3,'oldBarrier309Rows':0,'oldCeilingPreTimeoutRows':0,'oldFixture309Rows':0,'stepPreassertDumps':0,'stepAssessments':0,'actualCanStartReturnRows':0,'geometryControlsPassed':2,'newUnitTestsRun':0,'installableJarGenerated':False,'closedOwnWorldReclaimed':False}
# Recheck the complete closed own save under the same exclusive lock before removal.
assert sorted(str(p.relative_to(world))for p in world.rglob('*')if p.is_file())==sorted(r['path']for r in worldRows)
for r in worldRows:assert hashlib.sha256((world/r['path']).read_bytes()).hexdigest()==r['sha256']
for proc in Path('/proc').iterdir():
 if not proc.name.isdigit():continue
 try:
  if(proc/'comm').read_text().strip()=='java'and(proc/'cwd').resolve()==root:raise RuntimeError('Own Java reappeared')
 except(FileNotFoundError,ProcessLookupError,PermissionError):pass
shutil.rmtree(world);receipt['closedOwnWorldReclaimed']=True;(out/'first-archive.json').write_text(json.dumps(receipt,indent=2)+'\n');fcntl.flock(lock,fcntl.LOCK_UN);lock.close();print(json.dumps(receipt,indent=2))
