from datetime import timedelta
from pathlib import Path
import hashlib
import json
import runpy
import subprocess
import sys

case = Path(sys.argv[1])
native = case / 'cubic-client-automation'
recording = native / 'swarm1024.jfr'
jfr = '/workspace/jdk21-complete/bin/jfr'
source_helper = Path('/tmp/combat-swarm-jfr-20261119/summarize_jfr.py')
helpers = runpy.run_path(str(source_helper))
def print_args(event_types, depth):
    return [jfr, 'print', '--json', '--stack-depth', str(depth), '--events', event_types, str(recording)]
windows = json.loads(subprocess.check_output(print_args('drmd.SwarmMeasurement', 0)))['recording']['events']
assert len(windows) == 1
window = windows[0]['values']
begin = helpers['moment'](window['startTime'])
end = begin + timedelta(seconds=helpers['duration'](window['duration']))
valid = [windows[0]]
def event_objects(stream):
    in_events = False
    lines = []
    for line in stream:
        if not in_events:
            if line.rstrip() == '    "events": [{':
                in_events = True
                lines = ['{']
            continue
        if line.rstrip() in ('    }, {', '    }]'):
            event = json.loads(''.join(lines) + '}')
            yield event
            if line.rstrip() == '    }]':
                return
            lines = ['{']
        else:
            lines.append(line)
    raise ValueError('Incomplete JFR JSON stream')
with subprocess.Popen(
    print_args('jdk.ExecutionSample,jdk.NativeMethodSample,jdk.ObjectAllocationSample',32), stdout=subprocess.PIPE, text=True
) as proc:
    assert proc.stdout
    for event in event_objects(proc.stdout):
        value = event['values']
        if not begin <= helpers['moment'](value['startTime']) <= end:
            continue
        if helpers['owner'](value) != 'Server thread':
            # Thread counts still cover every measured sample. Their stacks are not part of server attribution.
            value.pop('stackTrace', None)
        valid.append(event)
    assert proc.wait() == 0
report = helpers['report']({'recording': {'events': valid}})
p = native / 'swarm-capacity-1024.json'
counts = json.loads(p.read_text())
assert counts['requested'] == counts['live'] == counts['active'] == counts['moving'] == counts['synced'] == 1024
report['actualCapacityCounters'] = {k: counts.get(k) for k in ('requested','live','active','moving','synced','uniqueRendered','shots','coastingUpdates','detailedSteeringUpdates','fullWorldScansDuringMeasurement')}
p2 = native / 'inputs.json'
report['exactInputs'] = {'source':json.loads(p2.read_text())['sourceSha'],'jfrProfile':json.loads(p2.read_text())['jfrProfile']}
report['fileSha256'] = {}
for file in [recording, p, p2, source_helper, Path(__file__)]:
    with file.open('rb') as handle:
        report['fileSha256'][file.name] = hashlib.file_digest(handle,'sha256').hexdigest()
(case/'swarm-cpu-attribution.json').write_text(json.dumps(report,indent=2)+'\n')
