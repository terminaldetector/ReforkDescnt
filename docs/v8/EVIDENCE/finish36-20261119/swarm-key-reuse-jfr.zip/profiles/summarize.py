#!/usr/bin/env python3
"""Analyze EXPORTED JFR JSON; never launches Java or treats synthetic samples as runtime proof."""
from pathlib import Path
from datetime import datetime,timedelta
from collections import Counter
import argparse,hashlib,json,re

def moment(s):return datetime.fromisoformat(s.replace('Z','+00:00'))
def duration(s):
 m=re.fullmatch(r'PT(?:(\d+(?:\.\d+)?)H)?(?:(\d+(?:\.\d+)?)M)?(?:(\d+(?:\.\d+)?)S)?',s);assert m,s
 return sum(float(v or 0)*k for v,k in zip(m.groups(),[3600,60,1]))
def owner(v):
 t=v.get('sampledThread') or v.get('eventThread') or {};return t.get('javaName') or t.get('osName')
def frames(v):
 out=[]
 for f in (v.get('stackTrace') or {}).get('frames',[]):
  m=f.get('method') or {};c=(m.get('type') or {}).get('name','?').replace('/','.');out.append(c+'.'+m.get('name','?'))
 return out

def report(data):
 events=data['recording']['events'];windows=[e['values'] for e in events if e['type']=='drmd.SwarmMeasurement'];assert len(windows)==1,'need one actual committed measurement window'
 w=windows[0];assert int(w['requested'])==1024 and int(w['serverEndTick'])-int(w['serverStartTick'])==60,'actual1024/60ordinarytick window required'
 begin=moment(w['startTime']);end=begin+timedelta(seconds=duration(w['duration']));selfs=Counter();incl=Counter();alloc=Counter();threads=Counter();n=0;an=0
 for e in events:
  v=e['values'];t=moment(v['startTime'])
  if not begin<=t<=end:continue
  if e['type'] in ['jdk.ExecutionSample','jdk.NativeMethodSample']:
   name=owner(v);threads[name]+=1
   if name!='Server thread':continue
   fs=frames(v)
   if fs:selfs[fs[0]]+=1;incl.update(set(fs));n+=1
  elif e['type']=='jdk.ObjectAllocationSample' and owner(v)=='Server thread':
   alloc[(v.get('objectClass') or {}).get('name','?')]+=int(v.get('weight',0));an+=1
 assert n>0,'no measured Server thread samples; do not attribute setup/client stacks'
 return {'classification':'Actual JFR CPU samples restricted to committed existing1024/60tick window; sampling attribution only, not clean FPS/TPS or benchmark PASS','window':{'begin':begin.isoformat(),'end':end.isoformat(),'seconds':(end-begin).total_seconds(),'actualServerTickDelta':60},'measuredSamplesByThread':dict(threads),'serverExecutionSamples':n,'topSelfMethods':selfs.most_common(25),'inclusiveMethods':incl.most_common(40),'sampledAllocationEvents':an,'allocationSampleEstimatedWeightedBytes':alloc.most_common(25),'limits':['Inclusive counts overlap and must not be summed as exclusive time.','Allocation weights are JFR sampling estimates, not exact allocations/heap.','Retain exact Main/Observer/JVM/BCC/Sodium inputs; profiled timings include recording overhead.','No actor/AI/physics/target/projectile reduction is authorized by this report.']}
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('jfr_json',type=Path);p.add_argument('capacity_json',type=Path);p.add_argument('inputs_json',type=Path);p.add_argument('--out',type=Path,required=True);a=p.parse_args();assert a.jfr_json.stat().st_size<=512*1024*1024,'export too large; reduce stack-depth before parsing'
 x=report(json.loads(a.jfr_json.read_text()));c=json.loads(a.capacity_json.read_text());assert c['requested']==1024
 x['actualCapacityCounters']={k:c.get(k) for k in ['requested','live','active','moving','synced','uniqueRendered','shots','coastingUpdates','detailedSteeringUpdates','fullWorldScansDuringMeasurement']}
 x['sourceInputs']=json.loads(a.inputs_json.read_text());x['files']={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [a.jfr_json,a.capacity_json,a.inputs_json]};a.out.write_text(json.dumps(x,indent=2)+'\n')
