import java.lang.management.ManagementFactory;
import java.util.ArrayList;
import java.util.Random;
import java.util.function.IntToLongFunction;
public class Replay {
    private static final int QUERIES = 4_000;
    private static final com.sun.management.ThreadMXBean MEMORY = (com.sun.management.ThreadMXBean) ManagementFactory.getThreadMXBean();
    private record At(double x, double y, double z) {}
    public static void main(String[] args) {
        long thread = Thread.currentThread().threadId();
        for (int size : new int[]{32,1024}) {
          for (int searchRadius : new int[]{8,32}) {
            runScenario(thread, size, 8, searchRadius, false);
          }
        }
        runScenario(thread, 1024, 25, 25, true);
        runScenario(thread, 1024, 25, 32, true);
    }
    private static void runScenario(long thread, int size, int cellSize, int searchRadius, boolean nativeSpawnFormation) {
            var baseline = new old.BoundedSpatialIndex<Integer>(cellSize);
            var candidate = new current.BoundedSpatialIndex<Integer>(cellSize);
            var rng = new Random(471646);
            for (int i = 0; i < size; i++) {
                double x = rng.nextInt(25) - 12, y = rng.nextInt(11) - 5, z = rng.nextInt(25) - 12;
                if (nativeSpawnFormation) {
                    x = ((i & 15) - 7.5) * 3;
                    y = 2156 + (((i >> 8) & 3) - 1.5) * 4;
                    z = (((i >> 4) & 15) - 7.5) * 3;
                }
                baseline.add(i,x,y,z);
                candidate.add(i,x,y,z);
            }
            var points = new At[QUERIES];
            for (int i = 0; i < points.length; i++) {
                points[i] = nativeSpawnFormation
                        ? new At(rng.nextDouble(-25,25), 2156 + rng.nextDouble(-8,8), rng.nextDouble(-25,25))
                        : new At(rng.nextDouble(-7,7), rng.nextDouble(-5,5), rng.nextDouble(-7,7));
            }
            for (int i = 0; i < points.length; i++) {
                var p = points[i];
                var oldOrder = new ArrayList<Integer>();
                var newOrder = new ArrayList<Integer>();
                var before = baseline.nearest(p.x,p.y,p.z,searchRadius,32,96,i,v -> {oldOrder.add(v);return (v & 7) != 6;});
                var after = candidate.nearest(p.x,p.y,p.z,searchRadius,32,96,i,v -> {newOrder.add(v);return (v & 7) != 6;});
                if (!oldOrder.equals(newOrder)) throw new AssertionError("predicate encounter order");
                if (before.examinedCandidates()!=after.examinedCandidates() || before.occupiedBuckets()!=after.occupiedBuckets()
                        || before.hits().size()!=after.hits().size()) throw new AssertionError("bounds");
                for (int index=0;index<before.hits().size();index++) {
                    var left=before.hits().get(index);
                    var right=after.hits().get(index);
                    if (!left.value().equals(right.value()) || Double.compare(left.squaredDistance(),right.squaredDistance())!=0
                            || Double.compare(left.position().x(),right.position().x())!=0
                            || Double.compare(left.position().y(),right.position().y())!=0
                            || Double.compare(left.position().z(),right.position().z())!=0)
                        throw new AssertionError("hit ordering");
                }
            }
            IntToLongFunction runOld = i -> {
                var p=points[i];
                var hints=baseline.nearest(p.x,p.y,p.z,searchRadius,32,96,i,v -> (v & 7) != 6).hits();
                return hints.isEmpty()?0:hints.getLast().value();
            };
            IntToLongFunction runNew = i -> {
                var p=points[i];
                var hints=candidate.nearest(p.x,p.y,p.z,searchRadius,32,96,i,v -> (v & 7) != 6).hits();
                return hints.isEmpty()?0:hints.getLast().value();
            };
            for(int warm=0;warm<3;warm++){run(runOld);run(runNew);}
            long oldBytes=0,newBytes=0,oldNs=0,newNs=0,checksum=0;
            for(int trial=0;trial<8;trial++) {
                boolean isOld = trial % 4 == 0 || trial % 4 == 3;
                long memory = MEMORY.getThreadAllocatedBytes(thread);
                long start = System.nanoTime();
                checksum += run(isOld?runOld:runNew);
                long elapsed=System.nanoTime()-start;
                long allocated=MEMORY.getThreadAllocatedBytes(thread)-memory;
                if(isOld){oldBytes+=allocated; oldNs+=elapsed;}
                else{newBytes+=allocated; newNs+=elapsed;}
            }
            int ops=QUERIES*4;
            System.out.printf(java.util.Locale.ROOT,
                "{\"actors\":%d,\"cellSize\":%d,\"radius\":%d,\"exactComparisons\":%d,\"oldBytesPerQuery\":%.1f,\"newBytesPerQuery\":%.1f,\"oldNsPerQuery\":%.1f,\"newNsPerQuery\":%.1f,\"checksum\":%d}%n",
                size,cellSize,searchRadius,QUERIES,oldBytes/(double)ops,newBytes/(double)ops,oldNs/(double)ops,newNs/(double)ops,checksum);
    }
    private static long run(IntToLongFunction query) {
        long checksum=0;
        for(int i=0;i<QUERIES;i++) checksum+=query.applyAsLong(i);
        return checksum;
    }
}
