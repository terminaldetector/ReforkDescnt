#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
jdk=/workspace/jdk21-complete/bin
junit=$(find /workspace/.gradle/caches/modules-2/files-2.1/org.junit.jupiter /workspace/.gradle/caches/modules-2/files-2.1/org.junit.platform /workspace/.gradle/caches/modules-2/files-2.1/org.opentest4j /workspace/.gradle/caches/modules-2/files-2.1/org.apiguardian -name '*.jar' -print | sort | paste -sd:)
production=src/main/java/com/terminaldetector/drmd/ai/BoundedSpatialIndex.java
tests=src/test/java/com/terminaldetector/drmd/ai/BoundedSpatialIndexTest.java
mkdir -p classes replay/{old,current,classes}
"$jdk/javac" -cp "$junit" -d classes "updated/$production" "updated/$tests" UnitLauncher.java
"$jdk/java" -Xmx128m -XX:ActiveProcessorCount=2 -cp "classes:$junit" UnitLauncher | tee junit.log
sed 's/^package com.terminaldetector.drmd.ai;/package old;/' "baseline/$production" > replay/old/BoundedSpatialIndex.java
sed 's/^package com.terminaldetector.drmd.ai;/package current;/' "updated/$production" > replay/current/BoundedSpatialIndex.java
"$jdk/javac" -d replay/classes Replay.java replay/{old,current}/BoundedSpatialIndex.java
"$jdk/java" -Xmx256m -XX:ActiveProcessorCount=2 -cp replay/classes Replay | tee replay/results.jsonl
