# Bounded spatial query scratch reuse

Patch `bounded-spatial-query-reuse.patch`, based on `de7554d3c180196a4c48bc09dcc1d281c42c5f9f`. `git apply --check` passed in the shared checkout. This patch is prepared in the scratch directory.

The previous native 1,024-drone recording attributed about 124 MB of sampled allocation weight to `CellDistance` and 49 MB to `Candidate`. The query now reuses per-thread rows and retains at most 128 of each between calls. The cap limits retained storage. Large queries may still process any number of occupied rows and candidates under the original query contract. Each active row is rewritten before reuse. The stable sort keys, origins, occupied order, predicate encounter order, query counts and result ownership are unchanged. Nested queries receive independent scratch, including queries of a different generic type. Release clears index references after a normal return or a thrown filter. Immutable hit/query objects still carry the returned results.

`verify.sh` compiles the changed production class and runs the real targeted JUnit suite with a local Java 21 launcher. All six cases passed, including nested queries across types and an oversized query followed by a predicate exception. The old and changed implementations then agreed on all 24,000 deterministic queries across six cohorts, checking stored positions, distances, hit order, predicate encounter order, occupied buckets and examined candidates. The replay includes the 1,024-actor native spawn formation at Y=2,156 and the production cell size and two search radii. It models the spawn formation, without replaying live movement or the entire game.

| Actors | Cell size | Radius | Before B/query | After B/query | Reduction |
| ---: | ---: | ---: | ---: | ---: | ---: |
| 32 | 8 | 8 | 1332.0 | 466.0 | 65.02% |
| 32 | 8 | 32 | 3288.0 | 1424.0 | 56.69% |
| 1024 | 8 | 8 | 4230.3 | 2045.9 | 51.64% |
| 1024 | 8 | 32 | 6292.8 | 2240.0 | 64.40% |
| 1024 | 25 | 25 | 4026.2 | 1972.1 | 51.02% |
| 1024 | 25 | 32 | 4344.9 | 1995.5 | 54.07% |

The table uses thread-allocated bytes and alternating old/new samples after warmup. Wall-clock timings varied across cohorts and runs. No native server/Gradle build or final TPS result was produced. Raw results and launcher detail are retained in `replay/results.jsonl` and `junit.log`.
