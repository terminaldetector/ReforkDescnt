package com.terminaldetector.drmd.gate.legacy;

import com.terminaldetector.drmd.DescentPlayerData;
import com.terminaldetector.drmd.entity.ModEntities;
import com.terminaldetector.drmd.entity.PyroShipEntity;
import com.terminaldetector.drmd.flight.FlightSystem;
import net.fabricmc.fabric.api.gametest.v1.FabricGameTest;
import net.minecraft.block.Blocks;
import net.minecraft.entity.Entity;
import net.minecraft.test.GameTest;
import net.minecraft.test.TestContext;
import net.minecraft.util.math.*;
import java.nio.file.*;
import java.util.*;

/** Same actual public-API assertion on an immutable historical game, then on current game.
 * No model proxy, patched legacy methods, manual entity ticks or invented lava success. */
public final class LegacyProxyLifecycleGameTests implements FabricGameTest {
    @GameTest(templateName=EMPTY_STRUCTURE,batchId="legacy-proxy-native-exit")
    public void normalNativeDismountDoesNotReboardAnOwnedPhysicalHull(TestContext c) {
        try(var r=new Rig(c,"native-dismount")) {
            r.record("before-native-stopRiding");
            try{r.player.stopRiding();}finally{r.record("after-native-stopRiding");}
            c.assertTrue(!r.player.hasVehicle()&&!r.hull.hasPassengers(),"normal native stopRiding must sever both real ownership links without destroying the intermediary hull");
            c.assertTrue(!r.hull.isRemoved()&&r.player.isAlive(),"ordinary exit must need neither lava, hull destruction nor player death");
        }
        c.complete();
    }
    @GameTest(templateName=EMPTY_STRUCTURE,batchId="legacy-proxy-native-toggle-off")
    public void actualFlightOffDismountsTheExistingHullBeforeAWorldTickCanRearmIt(TestContext c) {
        try(var r=new Rig(c,"flight-disable")) {
            r.record("before-native-disable");
            try{FlightSystem.disable(r.player,r.data);}finally{r.record("after-native-disable");}
            c.assertTrue(!r.player.hasVehicle()&&!r.hull.hasPassengers()&&!r.data.isEnabled(),"actual flight off must sever live mount links and authority before the next native world tick");
            c.assertTrue(!r.hull.isRemoved()&&r.player.isAlive(),"the existing hull and player remain alive after ordinary off");
        }
        c.complete();
    }
    @GameTest(templateName=EMPTY_STRUCTURE,batchId="legacy-proxy-lava-fallback",tickLimit=241)
    public void observeWhetherTheHeldProxyNeedsARealHazardToRelease(TestContext c) {
        var r=new Rig(c,"held-proxy-lava");
        FlightSystem.disable(r.player,r.data);
        r.record("ordinary-flight-off");
        c.runAtTick(8,()->{
            r.record("eight-normal-world-ticks");
            if(!r.player.hasVehicle()){
                try {
                    c.assertTrue(r.player.isAlive()&&!r.hull.hasPassengers()&&!r.data.isEnabled(),
                        "ordinary exit releases the physical hull alive");
                }finally{r.close();}
                c.complete();
                return;
            }
            var world=c.getWorld();
            var center=r.player.getBlockPos();
            for(var point:BlockPos.iterate(center.add(-2,-4,-2),center.add(2,-4,2)))
                world.setBlockState(point,Blocks.OBSIDIAN.getDefaultState(),3);
            for(var point:BlockPos.iterate(center.add(-2,-3,-2),center.add(2,2,2)))
                world.setBlockState(point,Blocks.LAVA.getDefaultState(),3);
            r.record("introduced-real-lava-after-exit-remained-stuck");
            boolean[] finished={false};
            for(int tick=10;tick<=230;tick+=10){
                boolean last=tick==230;
                c.runAtTick(tick,()->{
                    if(finished[0])return;
                    r.record("lava-world-ticks");
                    if(r.player.isAlive()&&!last)return;
                    finished[0]=true;
                    try {
                        c.assertTrue(r.player.isAlive()&&!r.player.hasVehicle(),
                            "ordinary exit stayed mounted; lava alive="+r.player.isAlive()
                            +" vehicle="+r.player.hasVehicle()+" health="+r.player.getHealth());
                    }finally{r.close();}
                    c.complete();
                });
            }
        });
    }
    private static final class Rig implements AutoCloseable {
        final TestContext c;final net.minecraft.server.network.ServerPlayerEntity player;
        final PyroShipEntity ship;final Entity hull;final DescentPlayerData data;
        final io.netty.channel.embedded.EmbeddedChannel channel;
        final String label;final List<Map<String,Object>> trace=new ArrayList<>();
        Rig(TestContext c,String label) {
            this.c=c;this.label=label;var world=c.getWorld();var origin=c.getAbsolutePos(new BlockPos(5,0,5));var at=new BlockPos(origin.getX(),80,origin.getZ());
            c.assertTrue(at.getY()>70&&at.getY()<150,"fixture admission: ordinary open-air Overworld altitude, not zero-g/legacy upper layers");
            for(var p:BlockPos.iterate(at.add(-6,-8,-6),at.add(6,6,6)))world.setBlockState(p,Blocks.AIR.getDefaultState(),2);
            var profile=new com.mojang.authlib.GameProfile(UUID.randomUUID(),"legacy-exit");
            var options=net.minecraft.server.network.ConnectedClientData.createDefault(profile,false);
            player=new net.minecraft.server.network.ServerPlayerEntity(world.getServer(),world,profile,options.syncedOptions());
            var connection=new net.minecraft.network.ClientConnection(net.minecraft.network.NetworkSide.SERVERBOUND);
            channel=new io.netty.channel.embedded.EmbeddedChannel(connection);world.getServer().getPlayerManager().onPlayerConnect(connection,player,options);
            player.setPosition(Vec3d.ofCenter(at));data=DescentPlayerData.get(player);
            // Legacy JOIN can already auto-mount. Reuse that actual hull rather than attempting
            // an unmeasured dismount during admission (which is exactly the defect under test).
            var joined=player.getVehicle();c.assertTrue(joined==null||joined instanceof PyroShipEntity,"admission: native join has no foreign vehicle owner");
            ship=joined instanceof PyroShipEntity existing?existing:ModEntities.PYRO_SHIP.create(world);c.assertTrue(ship!=null,"actual registered historical Pyro type exists");
            hull=ship;hull.setPosition(player.getPos());ship.setOwnerUuid(player.getUuid());rememberHull(data,hull);
            if(joined==null)c.assertTrue(world.spawnEntity(ship),"actual physical intermediary hull registered");
            data.setEnabled(true);if(joined==null)c.assertTrue(player.startRiding(ship,true),"actual native player mounts the declared owned hull");
            c.assertTrue(player.getVehicle()==ship&&hull.getPassengerList().contains(player)&&!ship.isZeroGZone(),"admission: reciprocal real mount graph in ordinary air");
            record("admitted");
        }
        private static void rememberHull(DescentPlayerData data,Entity ship) {
            try {
                var type=data.getClass();
                try{type.getMethod("setLastShipUuid",UUID.class).invoke(data,ship.getUuid());}
                catch(NoSuchMethodException historicalAbsent){type.getMethod("setLastShip",UUID.class,BlockPos.class)
                    .invoke(data,ship.getUuid(),ship.getBlockPos());}
            }catch(ReflectiveOperationException failure){throw new IllegalStateException("Actual public hull memory API missing",failure);}
        }
        void record(String phase) {
            var row=new LinkedHashMap<String,Object>();row.put("phase",phase);row.put("world",player.getWorld().getRegistryKey().getValue().toString());
            row.put("worldTime",player.getWorld().getTime());row.put("playerId",player.getId());row.put("playerUUID",player.getUuid().toString());
            row.put("playerAlive",player.isAlive());row.put("health",player.getHealth());row.put("playerLava",player.isInLava());row.put("playerPos",List.of(player.getX(),player.getY(),player.getZ()));row.put("NoGravity",player.hasNoGravity());row.put("flightEnabled",data.isEnabled());
            var vehicle=player.getVehicle();row.put("vehicleUUID",vehicle==null?"NONE":vehicle.getUuid().toString());row.put("vehicleClass",vehicle==null?"NONE":vehicle.getClass().getName());
            row.put("declaredHullUUID",hull.getUuid().toString());row.put("declaredHullOwner",String.valueOf(ship.getOwnerUuid()));row.put("declaredHullRemoved",hull.isRemoved());
            row.put("declaredHullPassengers",hull.getPassengerList().stream().map(p->p.getUuid().toString()).toList());
            row.put("rememberedHullUUID",String.valueOf(data.getLastShipUuid()));
            row.put("nearbyHulls",player.getWorld().getEntitiesByClass(PyroShipEntity.class,player.getBoundingBox().expand(16),h->true).stream().map(h->Map.of("id",((Entity)h).getUuid().toString(),"owner",String.valueOf(h.getOwnerUuid()),"passengers",((Entity)h).getPassengerList().stream().map(p->p.getUuid().toString()).toList())).toList());
            trace.add(row);System.out.println("LEGACY_PROXY_GRAPH "+new com.google.gson.Gson().toJson(row));
            try{var folder=Path.of("legacy-proxy-proof");Files.createDirectories(folder);Files.writeString(folder.resolve(label+".json"),new com.google.gson.GsonBuilder().setPrettyPrinting().create().toJson(trace));}
            catch(java.io.IOException failure){throw new IllegalStateException(failure);}
        }
        @Override public void close() {
            // Cleanup removes the actual player first. It never changes the pre-assert trace or
            // labels destroying a disposable test actor as an acceptable ordinary exit.
            c.getWorld().getServer().getPlayerManager().remove(player);player.discard();hull.discard();channel.finishAndReleaseAll();
        }
    }
}
