#!/usr/bin/env bash
set -euo pipefail
cd /workspace/ungravity-v5/ufo-body-physics
root=/tmp/ungravity-finish-36
legacy=/tmp/gravity-original-proxy-abi
build_out=$root/legacy-proxy-lava-graph-build
test ! -e "$build_out"
mkdir "$build_out"
export JAVA_HOME=/workspace/jdk21-complete GRADLE_USER_HOME=/workspace/.gradle PATH=/workspace/jdk21-complete/bin:$PATH
git rev-parse HEAD > "$build_out/source.txt"
sha256sum "$legacy/legacy-proxy.init.gradle" "$legacy/fixture/src/main/resources/fabric.mod.json" > "$build_out/inputs.sha256"
find "$legacy/fixture/src/main/java" -type f -name '*.java' -print0 | xargs -0 sha256sum >> "$build_out/inputs.sha256"
./gradlew --no-daemon --offline -I "$legacy/legacy-proxy.init.gradle" remapLegacyProxyObserverJar > "$build_out/gradle.log" 2>&1 || { tail -35 "$build_out/gradle.log"; exit 1; }
observer="$build_out/drmd-legacy-proxy-observer.jar"
cp build/libs/drmd-6dof-1.1.35-ufo-dev.1-legacy-proxy-observer.jar "$observer"
sha256sum "$observer" > "$build_out/observer.sha256"
for mode in historical current; do
  case_root="$root/legacy-proxy-$mode-lava-graph"
  test ! -e "$case_root"
  subj="$legacy/drmd-6dof-1.1.6-fabric-1.21.1.jar"
  if test "$mode" = current; then subj="$root/structure-contact-parts-build/jars/drmd-6dof-1.1.35-ufo-dev.1.jar"; fi
  python3 - "$case_root" "$subj" "$observer" <<'PY'
import hashlib,json,os,shutil,sys,zipfile
from pathlib import Path
runtime,subject,observer=map(Path,sys.argv[1:])
donor=Path('/workspace/ungravity-v5/world/build/cubic-seed2-gate')
cache=Path('/workspace/.gradle/caches/modules-2/files-2.1/net.fabricmc.fabric-api')
api=next((cache/'fabric-api/0.116.15+1.21.1').rglob('fabric-api-0.116.15+1.21.1.jar'))
test=next((cache/'fabric-gametest-api-v1/2.0.5+6fc22b9919').rglob('fabric-gametest-api-v1-2.0.5+6fc22b9919.jar'))
runtime.mkdir()
def sha(p):
    with p.open('rb') as handle:return hashlib.file_digest(handle,'sha256').hexdigest()
def copy(src,relative):
    dst=runtime/relative
    dst.parent.mkdir(parents=True,exist_ok=True)
    try: os.link(src,dst)
    except OSError: shutil.copy2(src,dst)
    assert sha(src)==sha(dst)
    return {'path':str(relative),'sha256':sha(dst),'file':str(src)}
artifacts=[copy(donor/p,p) for p in ('fabric-server-launch.jar','server.jar')]
for subtree in ('libraries','versions'):
    for src in sorted((donor/subtree).rglob('*.jar')):
        artifacts.append(copy(src,src.relative_to(donor)))
for src in (subject,observer,api,test):
    artifacts.append(copy(src,Path('mods')/src.name))
assert len(list((runtime/'mods').glob('*.jar')))==4
# The remapped immutable Minecraft server cache has the same loader/mappings for each probe.
previous=runtime.with_name(runtime.name.removesuffix('-lava-graph'))
for cache_file in (previous/'.fabric'/'server').rglob('*'):
    if cache_file.is_file() and cache_file.name.endswith('.jar'):
        copy(cache_file,cache_file.relative_to(previous))

with zipfile.ZipFile(subject) as archive:
    artifact=json.loads(archive.read('fabric.mod.json'))
(runtime/'eula.txt').write_text('eula=true\n')
(runtime/'server.properties').write_text('level-name=world\nserver-port=0\nserver-ip=127.0.0.1\nonline-mode=false\nview-distance=3\nsimulation-distance=3\nenable-rcon=false\nenable-query=false\n')
(runtime/'inputs.json').write_text(json.dumps({'actualModVersion':artifact['version'],'artifacts':artifacts,'stock':True},indent=2)+'\n')
PY
  set +e
  (
    cd "$case_root"
    timeout -k 12 100 "$JAVA_HOME/bin/java" -Xmx950m -XX:ActiveProcessorCount=2 -Dfabric-api.gametest -Dfabric-api.gametest.report-file="$case_root/results.xml" -jar fabric-server-launch.jar nogui
  ) > "$case_root/server.log" 2>&1
  status=$?
  set -e
  printf '%s\n' "$status" > "$case_root/server.exit"
  tail -12 "$case_root/server.log"
done
