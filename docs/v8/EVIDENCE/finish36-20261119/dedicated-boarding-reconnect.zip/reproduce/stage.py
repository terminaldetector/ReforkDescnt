#!/usr/bin/env python3
"""Stage immutable dedicated boarding inputs and a closed save, without launching JVMs."""
from pathlib import Path
import argparse
import fcntl
import hashlib
import importlib.util
import json
import os
import secrets
import shutil
import sys
import uuid
import zipfile

from verify_linkage import verify_linkage

HERE = Path(__file__).resolve().parent
PRIOR = Path('/tmp/world-finish-20261119/parity-resource-compact/stage_tcp.py')
spec = importlib.util.spec_from_file_location('frozen_parity_stager', PRIOR)
prior = importlib.util.module_from_spec(spec)
spec.loader.exec_module(prior)
CONFIG = {'verticalViewDistance': 2, 'verticalLoadDistance': 2,
          'verticalGenerationLookahead': 2, 'maxConcurrentCubeGeneration': 1}
WORLD = 'Boarding-World'
PROFILES = {'crew': 'LateCrew', 'late': 'LatePassenger'}
MOD_NAMES = ('game', 'observer', 'bcc', 'api', 'sodium')
MIXIN_RESOURCE = 'drmd.lateboardcheck.mixins.json'
EXPECTED_MAPPINGS = {
    'BodyNbtProbe': {
        'readCustomDataFromNbt': 'Lcom/terminaldetector/drmd/world/contraption/BlockBodyEntity;method_5749(Lnet/minecraft/class_2487;)V',
        'writeCustomDataToNbt': 'Lcom/terminaldetector/drmd/world/contraption/BlockBodyEntity;method_5652(Lnet/minecraft/class_2487;)V',
    },
    'FrameProbe': {'render': 'Lnet/minecraft/class_757;method_3192(Lnet/minecraft/class_9779;Z)V'},
    'MotorAckProbe': {'sendPacket(Lnet/minecraft/network/packet/Packet;)V': 'Lnet/minecraft/class_8609;method_14364(Lnet/minecraft/class_2596;)V'},
    'PositionProbe': {
        'requestTeleport(DDDFFLjava/util/Set;)V': 'Lnet/minecraft/class_3244;method_14360(DDDFFLjava/util/Set;)V',
        'onTeleportConfirm': 'Lnet/minecraft/class_3244;method_12050(Lnet/minecraft/class_2793;)V',
    },
}


def verify_observer(path):
    with zipfile.ZipFile(path) as jar:
        assert json.loads(jar.read('fabric.mod.json'))['id'] == 'drmd_lateboardcheck'
        config = json.loads(jar.read(MIXIN_RESOURCE))
        mapping = json.loads(jar.read(config['refmap']))['mappings']
        for probe, expected in EXPECTED_MAPPINGS.items():
            assert mapping[config['package'].replace('.', '/') + '/' + probe] == expected
    return config['refmap']


def atomic_json(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())


def rows_in(path):
    result = {}
    for entry in sorted(path.rglob('*')):
        assert not entry.is_symlink(), f'writer save contains symlink {entry}'
        if entry.is_file():
            result[entry.relative_to(path).as_posix()] = prior.sha(entry)
    return result


def restore_writer(path, target, hashes, source, writer_observer_sha):
    receipt = json.loads(path.read_text())
    assert receipt['qualified'] and receipt['mode'] == 'writer'
    assert receipt['source'] == source and set(receipt['modHashes']) == set(hashes)
    assert len(writer_observer_sha)==64 and set(writer_observer_sha)<=set('0123456789abcdef')
    assert receipt['modHashes']['observer'] == writer_observer_sha, 'writer observer does not match explicit SHA'
    for dependency in ('game','bcc','api','sodium'):
        assert receipt['modHashes'][dependency] == hashes[dependency], f'writer and reader {dependency} bytes differ'
    assert receipt['children'] == {'server': 0, 'crew': 0, 'late': 0}
    donor = Path(receipt['world'])
    assert rows_in(donor) == receipt['worldFiles']
    with (donor/'session.lock').open('r+b') as lock:
        fcntl.lockf(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        shutil.copytree(donor, target)
        assert rows_in(target) == receipt['worldFiles'] == rows_in(donor)
        fcntl.lockf(lock, fcntl.LOCK_UN)
    for name, digest in receipt['sidecars'].items():
        assert '/' not in name and name.startswith('writer-')
        original = path.parent/name
        prior.frozen(original, digest)
        shutil.copyfile(original, target.parent.parent/name)
    return {'writerProof':str(path), 'writerProofSha256':prior.sha(path),
            'writerServerPid':receipt['serverPid'], 'worldFiles':receipt['worldFiles'], 'sidecars':receipt['sidecars'],
            'writerObserverSha256':writer_observer_sha, 'readerObserverSha256':hashes['observer'],
            'sameGameAndDependencies':{key:hashes[key] for key in ('game','bcc','api','sodium')}}


def client_runtime(root, prerequisites, args, mods):
    helper_spec = importlib.util.spec_from_file_location('official_client_stager', prior.STAGER)
    helper = importlib.util.module_from_spec(helper_spec)
    helper_spec.loader.exec_module(helper)
    copy = helper.verified_copy
    pool = Path(prerequisites['clientLibraryHardlinkPool'])

    def shared_copy(source, target, sha1=None):
        if 'libraries' not in target.parts:
            return copy(source, target, sha1)
        assert sha1 is None or helper.digest(source, 'sha1') == sha1
        relative = target.parts[target.parts.index('libraries')+1:]
        candidate = pool.joinpath(*relative)
        prior.link(candidate if candidate.is_file() and prior.sha(candidate) == prior.sha(source) else source, target)
        return target

    helper.verified_copy = shared_copy
    saved_argv = sys.argv
    try:
        sys.argv = [str(prior.STAGER), '--server-runtime', str(prior.DONOR), '--runtime', str(root),
                    '--drmd', str(mods['game']), '--gate', str(mods['observer']), '--bcc', str(mods['bcc']),
                    '--api', str(mods['api']), '--sodium', str(mods['sodium']), '--java', str(args.java)]
        helper.main()
    finally:
        sys.argv = saved_argv
    assert not (root/'saves').exists(), 'dedicated client must never contain an integrated save'


def stage(args):
    assert args.port in range(1024,65536)
    assert len(args.source) == 40 and set(args.source) <= set('0123456789abcdef')
    assert args.root.is_absolute() and not args.root.exists()
    prior.frozen(prior.PR, prior.PR_SHA)
    prior.frozen(prior.STAGER, prior.STAGER_SHA)
    prior.frozen(prior.BCC, prior.BCC_SHA)
    prior.frozen(prior.API, prior.API_SHA)
    prior.frozen(args.game, args.game_sha256)
    prior.frozen(args.observer, args.observer_sha256)
    mods = dict(game=args.game, observer=args.observer, bcc=prior.BCC, api=prior.API, sodium=args.sodium)
    for mod in mods.values(): prior.zip_ok(mod)
    observer_refmap = verify_observer(args.observer)
    observer_linkage = verify_linkage(args.observer,args.game)
    with zipfile.ZipFile(args.game) as z:
        assert json.loads(z.read('fabric.mod.json'))['id'] == 'drmd'
        assert not any(n.startswith('com/terminaldetector/drmd/lateboardcheck/') for n in z.namelist())
    hashes = {key: prior.sha(mods[key]) for key in MOD_NAMES}
    prerequisites = json.loads(prior.PR.read_text())
    assert prerequisites['clientRawOfficialMatchesMojang']
    official = [prerequisites['serverOfficialMain'], *prerequisites['serverClasspathLibraries']]
    for entry in [*official, prerequisites['clientRawOfficial'], *prerequisites['vanillaOnlyDerivedCaches']]:
        prior.frozen(Path(entry['path']), entry['sha256'])
    root = args.root
    server = root/'server'
    server.mkdir(parents=True)
    endpoints = {role: root/role for role in PROFILES}
    classpath = []
    for row in official:
        source = Path(row['path'])
        target = server/source.relative_to(prior.DONOR)
        prior.link(source, target)
        classpath.append(str(target))
    for key in ('game', 'observer', 'bcc', 'api'):
        target = server/'mods'/mods[key].name
        target.parent.mkdir(exist_ok=True)
        shutil.copy2(mods[key],target)
        assert prior.sha(target) == hashes[key]

    for path in endpoints.values(): client_runtime(path, prerequisites, args, mods)
    for row in prerequisites['vanillaOnlyDerivedCaches']:
        source=Path(row['path'])
        with zipfile.ZipFile(source) as z:
            assert not any(name.startswith('com/terminaldetector/') for name in z.namelist())
        destinations = (server,) if row['side'] == 'server' else tuple(endpoints.values())
        for destination in destinations:
            prior.link(source, destination/'.fabric/remappedJars/minecraft-1.21.1-0.19.5'/source.name)

    for endpoint in (server,*endpoints.values()):
        (endpoint/'config').mkdir(exist_ok=True)
        atomic_json(endpoint/'config/bettercubicchunks.json', CONFIG)
    cold = None
    if args.mode == 'reader':
        assert args.writer_proof and args.writer_observer_sha, 'reader requires explicit writer proof and observer SHA'
        cold = restore_writer(args.writer_proof,server/WORLD,hashes,args.source,args.writer_observer_sha)
    else:
        assert args.writer_proof is None and args.writer_observer_sha is None and not (server/WORLD).exists()

    (server/'eula.txt').write_text('eula=true\n')
    properties = {'server-ip':'127.0.0.1','server-port':args.port,'online-mode':'false',
                  'enable-rcon':'false','enable-query':'false','enable-status':'true','max-players':2,'level-name':WORLD,
                  'level-seed':271026,'level-type':'bettercubicchunks:cubic_default','spawn-protection':0,
                  'view-distance':3,'simulation-distance':5,'network-compression-threshold':256,
                  'max-tick-time':60000,'allow-flight':'true','motd':'DRMD native boarding '+secrets.token_hex(12)}
    (server/'server.properties').write_text(''.join(f'{k}={v}\n' for k,v in properties.items()))
    common = [f'-Ddrmd.lateBoarding.mode={args.mode}',f'-Ddrmd.lateBoarding.exchange={root}',
              '-XX:ActiveProcessorCount=2','-XX:+UseSerialGC']
    server_args = [str(args.java), '-Xms96M',f'-Xmx{args.server_mib}M',*common,'-Ddrmd.lateBoarding.role=server',
                   '-cp',os.pathsep.join(classpath),'net.fabricmc.loader.impl.launch.knot.KnotServer','nogui']
    launches = {'server': {'cwd': str(server),'argv': server_args}}
    for role, endpoint in endpoints.items():
        launch = json.loads((endpoint/'launch.json').read_text())
        launch = [token for token in launch if not token.startswith(('-Xmx','-Xms'))]
        launch[1:1] = ['-Xms96M',f'-Xmx{args.client_mib}M',*common,f'-Ddrmd.lateBoarding.role={role}']
        name = PROFILES[role]
        launch[launch.index('--username')+1] = name
        launch[launch.index('--uuid')+1] = uuid.UUID(bytes=hashlib.md5(('OfflinePlayer:'+name).encode()).digest(), version=3).hex
        launch[launch.index('--width')+1] = '640'
        launch[launch.index('--height')+1] = '360'
        launch += ['--quickPlayMultiplayer', f'127.0.0.1:{args.port}']
        launches[role] = {'cwd':str(endpoint),'argv':launch}
    atomic_json(root/'staging.json',{'mode':args.mode,'source':args.source,'port':args.port,
        'status':'STAGED_NOT_RUN','modHashes':hashes,'immutablePrerequisites':str(prior.PR),'observerRefmap':observer_refmap,
        'observerLinkage':observer_linkage,'java':str(args.java),'serverHeapMiB':args.server_mib,'oneClientHeapMiB':args.client_mib,
        'serverProperties':properties,'nativeBcc':CONFIG,'coldRestore':cold,'launches':launches})
    print(root/'staging.json')


if __name__ == '__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    for key in ['root','game','observer','sodium','java']: parser.add_argument('--'+key, type=Path, required=True)
    for key in ['source','game-sha256','observer-sha256']: parser.add_argument('--'+key, required=True)
    parser.add_argument('--mode', choices=('reader','writer'), required=True)
    parser.add_argument('--port', type=int, required=True)
    parser.add_argument('--writer-proof',type=Path)
    parser.add_argument('--writer-observer-sha')
    parser.add_argument('--server-mib',type=int,default=768)
    parser.add_argument('--client-mib',type=int,default=896)
    stage(parser.parse_args())
