#!/usr/bin/env python3
"""Audit observer-owned Java references against the exact remapped game JAR."""
import argparse
import json
import struct
import zipfile
from pathlib import Path

GAME = 'com/terminaldetector/drmd/'
OBSERVER = GAME + 'lateboardcheck/'


def symbols(data):
    def two(offset): return struct.unpack_from('>H', data, offset)[0]
    count = two(8)
    pool = [None] * count
    at = 10
    index = 1
    while index < count:
        tag = data[at]
        at += 1
        if tag == 1:
            length = two(at)
            at += 2
            value = data[at:at+length].decode('utf8', errors='replace')
        else:
            length = {3:4, 4:4, 5:8, 6:8, 7:2, 8:2, 9:4, 10:4, 11:4,
                      12:4, 15:3, 16:2, 17:4, 18:4, 19:2, 20:2}[tag]
            value = ([two(at), two(at+2)] if tag in (9,10,11,12)
                     else two(at) if tag == 7 else None)
        pool[index] = (tag, value)
        at += length
        index += 2 if tag in (5,6) else 1
    def text(number): return pool[number][1]
    references = set()
    for member in pool:
        if member is None or member[0] not in (9,10,11):
            continue
        kind, (owner, name_and_type) = member
        name, desc = text(name_and_type)
        references.add((text(text(owner)), kind != 9, text(name), text(desc)))

    at += 6
    at += 2 + 2 * two(at)
    declared = set()
    for method in (False, True):
        total = two(at)
        at += 2
        for _ in range(total):
            name, desc, attributes = struct.unpack_from('>HHH', data, at+2)
            declared.add((method,text(name),text(desc)))
            at += 8
            for _ in range(attributes):
                at += 6 + struct.unpack_from('>I', data, at+2)[0]
    return references, declared


def verify_linkage(observer, game):
    with zipfile.ZipFile(observer) as add_on, zipfile.ZipFile(game) as artifact:
        names = [name for name in add_on.namelist() if name.startswith(OBSERVER) and name.endswith('.class')]
        assert names, 'isolated remapped observer classes missing'
        calls = set()
        for name in names:
            calls.update(symbols(add_on.read(name))[0])
        game_calls = {(owner,method,name,desc) for owner,method,name,desc in calls
                      if owner.startswith(GAME) and not owner.startswith(OBSERVER)}
        declaration_cache = {}
        invalid = []
        for owner,method,name,desc in sorted(game_calls):
            if owner not in declaration_cache:
                declaration_cache[owner] = symbols(artifact.read(owner+'.class'))[1]
            if (method,name,desc) not in declaration_cache[owner]:
                invalid.append(f'{owner}.{name}{desc}')
        if invalid:
            raise ValueError('observer must bind inherited methods through declaring class:\n'+'\n'.join(invalid))
        return {'classes':len(names), 'declaredGameMembers':len(game_calls),
                'baseEntityOwnerReferences':sorted({name+desc for owner,method,name,desc in calls
                                                    if method and owner == 'net/minecraft/class_1297'})}


if __name__=='__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('observer',type=Path)
    p.add_argument('game',type=Path)
    a = p.parse_args()
    print(json.dumps(verify_linkage(a.observer,a.game),indent=2))
