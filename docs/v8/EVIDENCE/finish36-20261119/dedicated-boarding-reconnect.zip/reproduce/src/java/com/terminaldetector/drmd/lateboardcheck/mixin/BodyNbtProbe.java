package com.terminaldetector.drmd.lateboardcheck.mixin;

import com.terminaldetector.drmd.lateboardcheck.DedicatedBoardingServer;
import com.terminaldetector.drmd.world.contraption.BlockBodyEntity;
import net.minecraft.nbt.NbtCompound;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(BlockBodyEntity.class)
abstract class BodyNbtProbe {
    @Inject(method = "writeCustomDataToNbt", at = @At("RETURN"))
    private void recordSaved(NbtCompound tag, CallbackInfo ci) {
        DedicatedBoardingServer.savedBody((BlockBodyEntity)(Object)this, tag);
    }

    @Inject(method = "readCustomDataFromNbt", at = @At("RETURN"))
    private void recordLoaded(NbtCompound tag, CallbackInfo ci) {
        DedicatedBoardingServer.loadedBody((BlockBodyEntity)(Object)this, tag);
    }
}
