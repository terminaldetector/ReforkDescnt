package com.terminaldetector.drmd.lateboardcheck;

import com.terminaldetector.drmd.DescentPlayerData;
import com.terminaldetector.drmd.client.portal.PortalTransform.*;
import com.terminaldetector.drmd.d6.D6ChunkPos;
import com.terminaldetector.drmd.flight.FlightSystem;
import com.terminaldetector.drmd.network.BoardingNetworking;
import com.terminaldetector.drmd.physics.collision.BodyJointConstraint;
import com.terminaldetector.drmd.vendor.immptl.ImmPtlQuaternions;
import com.terminaldetector.drmd.world.access.CubicAvailability;
import com.terminaldetector.drmd.world.access.WorldAccess;
import com.terminaldetector.drmd.world.contraption.*;
import com.terminaldetector.drmd.world.contraption.boarding.BoardingSystem;
import com.terminaldetector.drmd.world.contraption.boarding.BoardingWorldMotion;
import com.terminaldetector.drmd.world.contraption.boarding.DynamicBodyAttachment;
import com.terminaldetector.drmd.world.contraption.boarding.PassengerFrame;
import com.terminaldetector.drmd.world.gravity.FootGravitySystem;
import com.terminaldetector.drmd.world.mega.UfoControlSystem;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.*;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.block.Blocks;
import net.minecraft.entity.Entity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtElement;
import net.minecraft.nbt.NbtIo;
import net.minecraft.nbt.NbtSizeTracker;
import net.minecraft.nbt.StringNbtReader;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.GameMode;
import net.minecraft.util.WorldSavePath;
import java.nio.file.Files;
import java.util.*;

import static com.terminaldetector.drmd.lateboardcheck.Gate.*;

public final class DedicatedBoardingServer implements ModInitializer {
    private static final int DECK_LENGTH=12, DECK_WIDTH=10;
    private static final Vec3d CREW_START = new Vec3d(5.35,1.003,4.45);
    private static final Vec3d PASSENGER_START = new Vec3d(6.65,1.003,5.55);
    private static final Vec3d DECK_ORIGIN = new Vec3d(8,Y,8);
    private static final Vec3d FIELD_OFFSET = new Vec3d(4,-2,3);
    private static DedicatedBoardingServer observer;
    private final Map<UUID, BlockBodyEntity> beforeFirstStep = new HashMap<>();
    private final Set<UUID> normalDisconnects = new HashSet<>();
    private UUID writerCrew, writerPassenger;
    private UUID deckId, fieldId, joint;
    private int phase, stable, placementCalls, crewEpoch, lateEpoch, admittedForwardPackets;
    private int crewAirborneBeforeLate, crewAirborneConcurrent, lateAirborneConcurrent;
    private final NavigableMap<Integer,BoardingNetworking.Input> acceptedInputs = new TreeMap<>();
    private final List<Map<String,?>> walkingTrace = new ArrayList<>();
    private record MotorSample(int sequence,int tick,Vec3d sole,boolean grounded,BoardingNetworking.Input input) {}
    private MotorSample previousMotorSample, beforeForward;
    private int latestMotorSequence = -1, neutralSamples, appliedForward, groundedForward, postForwardNeutral;
    private boolean keyReady, walkingProved;
    private ServerPlayerEntity stagedPlayer, lateConnection;
    private Vec3d placement, lateInitialFeet, phaseStart;
    private int placementId, placementTick;
    private record Acknowledgement(int id,int tick,int epoch,boolean leaseActive,Vec3d feet,Vec3d pendingAtEntry) {}
    private Acknowledgement acknowledgement;
    private boolean thrustStarted, departedLate, lateWriterWarmupRequested;
    private double clearanceDistance, turnRadians, continuedDistance, walkDistance;

    @Override public void onInitialize() {
        if (!ENABLED || !System.getProperty("drmd.lateBoarding.role", "").equals("server")) return;
        observer = this;
        exchange();
        if (READER) {
            var ship = read("writer-ship");
            deckId = UUID.fromString(ship.get("deck").getAsString());
            fieldId = UUID.fromString(ship.get("field").getAsString());
            joint = UUID.fromString(ship.get("joint").getAsString());
        }
        ServerLifecycleEvents.SERVER_STARTED.register(server -> {
            require(server.isDedicated(), "dedicated server required");
            require(CubicAvailability.backend(server.getOverworld()) == CubicAvailability.Backend.NATIVE_CUBIC, "real BCC world required");
            if (WRITER) server.getCommandManager().executeWithPrefix(server.getCommandSource(), "bcc load 8 " + Y + " 8 1");
            record("server-started", Map.of("pid", ProcessHandle.current().pid(), "mode", MODE, "dedicated", true));
        });
        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> joined(handler.player));
        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> {
            normalDisconnects.add(handler.player.getUuid());
            if (handler.player == lateConnection) departedLate = true;
        });
        ServerTickEvents.END_SERVER_TICK.register(this::tick);
    }

    private void joined(ServerPlayerEntity p) {
        if (!READER || !p.getGameProfile().getName().equals(PASSENGER)) return;
        require(phase == 1 && lateConnection == null, "late connection preceded actual offline travel");
        var original = read("writer-passenger");
        var hint = DescentPlayerData.get(p).pendingBoardingResume();
        require(p.getUuidAsString().equals(original.get("player").getAsString()) && hint != null
            && hint.anchor() != null && hint.anchor().support().equals(deckId) && fieldId.equals(hint.anchor().gravityOwner()),
            "ordinary real login did not read the same schema-2 passenger file");
        require(p.getPos().distanceTo(point(original, "worldFeet")) < 1e-7
            && BoardingSystem.mc(hint.anchor().feet()).distanceTo(point(original, "localFeet")) < 1e-7,
            "late login did not start at saved stale world feet and exact material feet");
        lateConnection = p;
        lateInitialFeet = p.getPos();
        record("reader-late-joined", Map.of("uuid", p.getUuidAsString(), "tick", p.getServer().getTicks(),
            "serverWasReady", BoardingSystem.ready(p), "worldFeet", xyz(p.getPos()), "deck", deckId, "field", fieldId));
    }

    public static void positionSent(ServerPlayerEntity p,double x,double y,double z,boolean absolute,
                                    int teleportId,Vec3d pending) {
        var run = observer;
        if (run == null || p != run.lateConnection || !READER || run.phase >= 4) return;
        require(absolute, "unexpected relative late placement packet");
        var destination = new Vec3d(x,y,z);
        // Vanilla may send the initial spawn placement after the join callback.
        // Only the later one-shot board placement changes the saved world position.
        if (destination.distanceTo(run.lateInitialFeet) < 1e-7) return;
        run.placement = destination;
        run.placementCalls++;
        if (run.placementCalls != 1) return;
        run.placementId = teleportId;
        run.placementTick = p.getServer().getTicks();
        require(pending != null && pending.distanceTo(destination)<1e-7,
            "native pending placement differs from the actual absolute packet");
        record("reader-late-placement", Map.of("id",teleportId,"tick",run.placementTick,
            "originalTarget",xyz(destination),"liveFeetAtSend",xyz(p.getPos())));
    }

    public static void confirmBefore(ServerPlayerEntity p,int id,int pendingId,Vec3d pending) {
        var run = observer;
        if (run == null || !READER || p != run.lateConnection || run.placementCalls != 1
            || id != run.placementId || id != pendingId || pending == null) return;
        run.acknowledgement = new Acknowledgement(id,p.getServer().getTicks(),BoardingSystem.epoch(p),
            BoardingSystem.drives(p),p.getPos(),pending);
        var before = run.acknowledgement;
        record("reader-late-ack-begin",Map.of("id",id,"tick",before.tick(),"epochBefore",before.epoch(),
            "leaseBefore",before.leaseActive(),"feetBefore",xyz(before.feet()),
            "pendingAtObserverEntry",xyz(before.pendingAtEntry()),"originalPlacement",xyz(run.placement),
            "advancedSincePlacement",before.feet().distanceTo(run.placement),
            "ticksSincePlacement",before.tick()-run.placementTick));
    }

    public static void confirmAfter(ServerPlayerEntity p,int id,Vec3d pending) {
        var run = observer;
        if (run == null || p != run.lateConnection || run.acknowledgement == null) return;
        var before = run.acknowledgement;
        if (id != before.id()) return;
        run.acknowledgement = null;
        record("reader-late-ack-after",Map.of("id",id,"tick",p.getServer().getTicks(),
            "epochAfter",BoardingSystem.epoch(p),"leaseAfter",BoardingSystem.drives(p),
            "feetAfter",xyz(p.getPos()),"vanillaPendingCleared",pending==null,
            "rewindDistance",before.feet().distanceTo(p.getPos())));
    }

    public static void inputAccepted(ServerPlayerEntity p, BoardingNetworking.Input input) {
        var run = observer;
        if (run == null || !READER || p != run.lateConnection || run.phase != 2 || input.epoch() != run.lateEpoch) return;
        if (forwardOnly(input)) run.admittedForwardPackets++;
        run.acceptedInputs.put(input.sequence(),input);
        // The production queue holds at most 32. Retain ample correlation history without
        // accumulating neutral commands for an indefinitely slow client.
        if (run.acceptedInputs.size()>128) run.acceptedInputs.pollFirstEntry();
    }

    public static void motorStateSent(ServerPlayerEntity p, BoardingNetworking.State packet) {
        var run = observer;
        if (run == null || !READER || p != run.lateConnection || run.phase != 2 || run.walkingProved
            || !p.getServer().isOnThread() || !packet.active() || packet.epoch()!=run.lateEpoch) return;
        int sequence = packet.acknowledgment();
        if (sequence<=run.latestMotorSequence) return;
        run.latestMotorSequence = sequence;
        var input = run.acceptedInputs.remove(sequence);
        run.acceptedInputs.headMap(sequence,false).clear();
        if (input != null) run.observeAppliedInput(p,packet,input);
    }

    private void observeAppliedInput(ServerPlayerEntity p,BoardingNetworking.State packet,BoardingNetworking.Input input) {
        var deck = BodySpatialIndex.find(p.getServerWorld(),deckId).orElse(null);
        var field = BodySpatialIndex.find(p.getServerWorld(),fieldId).orElse(null);
        if (deck==null || field==null || packet.pose().gravityOwner()!=entity(field).getId()) return;
        var feet = new Vec3d(packet.x(),packet.y(),packet.z());
        require(feet.distanceTo(p.getPos())<1e-7,"authoritative movement packet feet differ from native player");
        boolean grounded = packet.grounded() && packet.support()==entity(deck).getId() && p.isOnGround();
        var sample = new MotorSample(packet.acknowledgment(),p.getServer().getTicks(),deck.worldToLocal(feet),grounded,input);
        var preceding = previousMotorSample;
        previousMotorSample = sample;
        if (!keyReady) {
            neutralSamples = neutral(input) && grounded ? neutralSamples+1 : 0;
            if (neutralSamples>=3 && exists("reader-late-ack-after")) {
                keyReady = true;
                record("reader-key-ready",Map.of("epoch",lateEpoch,"tick",sample.tick(),"acknowledgment",sample.sequence(),
                    "consecutiveGroundedNeutral",neutralSamples,"localFeet",xyz(sample.sole())));
            }
            return;
        }
        if (beforeForward==null) {
            if (!forwardOnly(input) || preceding==null || !preceding.grounded() || !neutral(preceding.input())) return;
            beforeForward = preceding;
            walkingTrace.add(row(preceding));
        }
        require(sample.tick()-beforeForward.tick()<=48,"native forward observation exceeded its motor window");
        walkingTrace.add(row(sample));
        if (forwardOnly(input)) {
            appliedForward++;
            if (grounded) groundedForward++;
            postForwardNeutral=0;
            return;
        }
        require(neutral(input),"unexpected steering during native forward observation");
        postForwardNeutral = grounded ? postForwardNeutral+1 : 0;
        if (postForwardNeutral < 3) return;
        walkDistance = Math.hypot(sample.sole().x-beforeForward.sole().x,sample.sole().z-beforeForward.sole().z);
        if (walkDistance < .32 || groundedForward < 3) return;
        walkingProved = true;
        record("reader-motor-walk",Map.ofEntries(Map.entry("epoch",lateEpoch),Map.entry("deck",deckId),Map.entry("field",fieldId),
            Map.entry("beforeSequence",beforeForward.sequence()),Map.entry("afterSequence",sample.sequence()),
            Map.entry("beforeLocalFeet",xyz(beforeForward.sole())),Map.entry("afterLocalFeet",xyz(sample.sole())),
            Map.entry("horizontalLocalDistance",walkDistance),Map.entry("serverTicks",sample.tick()-beforeForward.tick()),
            Map.entry("acceptedForwardPackets",admittedForwardPackets),Map.entry("appliedForwardCommands",appliedForward),
            Map.entry("groundedForwardCommands",groundedForward),Map.entry("groundedNeutralAfter",postForwardNeutral),
            Map.entry("samples",List.copyOf(walkingTrace))));
    }

    private static boolean forwardOnly(BoardingNetworking.Input input) {
        return input.forward()>.5 && Math.abs(input.strafe())<1e-5 && !input.jump();
    }

    private static boolean neutral(BoardingNetworking.Input input) {
        return Math.abs(input.forward())<1e-5 && Math.abs(input.strafe())<1e-5 && !input.jump();
    }

    private static Map<String,?> row(MotorSample sample) {
        return Map.of("tick",sample.tick(),"sequence",sample.sequence(),"localFeet",xyz(sample.sole()),"grounded",sample.grounded(),
            "forward",sample.input().forward(),"strafe",sample.input().strafe(),"jump",sample.input().jump());
    }

    public static void savedBody(BlockBodyEntity body, NbtCompound tag) {
        var run = observer;
        if (run == null || !WRITER || entity(body).getWorld().isClient || !run.ours(body)) return;
        try { Files.writeString(exchange().resolve("writer-body-" + entity(body).getUuid() + ".snbt"), tag.toString()); }
        catch (Exception e) { throw new IllegalStateException("physical body save", e); }
    }

    public static void loadedBody(BlockBodyEntity body, NbtCompound tag) {
        var run = observer;
        if (run == null || !READER || entity(body).getWorld().isClient || !run.ours(body)) return;
        try {
            var original = StringNbtReader.parse(Files.readString(exchange().resolve("writer-body-" + entity(body).getUuid() + ".snbt")));
            require(!body.hasSimulatedPhysics(), "body loaded callback followed first physics step");
            var actual = entity(body).writeNbt(new NbtCompound());
            for (var key : List.of("Pos", "shape", "body", "materialDamage")) {
                require(Objects.equals(original.get(key), tag.get(key)), "saved " + key + " differs on disk");
                if (!key.equals("body")) require(Objects.equals(original.get(key), actual.get(key)), "restored " + key + " differs in entity");
            }
            var expected = original.getCompound("body"); var restored = actual.getCompound("body");
            for (String key : List.of("qx","qy","qz","qw","vx","vy","vz","lx","ly","lz","passengerGravityx","passengerGravityy","passengerGravityz")) {
                double got = restored.getDouble(key);
                require(Double.isFinite(got) && Math.abs(expected.getDouble(key) - got) < 1e-10, "cold body component " + key);
            }
            require(expected.getBoolean("gravity") == restored.getBoolean("gravity"), "cold physical gravity mode changed");
            require(run.beforeFirstStep.putIfAbsent(entity(body).getUuid(), body) == null, "original body loaded more than once");
            record("reader-native-before-tick-" + entity(body).getUuid(), Map.of("uuid", entity(body).getUuidAsString(),
                "exactRawNbt", true, "exactRuntimePose", true, "nativeVelocity", xyz(body.physicsVelocity())));
        } catch (Exception e) { throw new IllegalStateException("cold physical body read", e); }
    }

    private boolean ours(Entity body) { return body.getUuid().equals(deckId) || body.getUuid().equals(fieldId); }

    private void tick(MinecraftServer server) {
        if (server.getTicks() % 100 == 0) {
            var players = server.getPlayerManager();
            System.out.println("DEDICATED_BOARDING mode=" + MODE + " phase=" + phase + " stable=" + stable
                + " restored=" + beforeFirstStep.size() + " placements=" + placementCalls + " walk=" + walkDistance
                + " crew=" + status(players.getPlayer(CREW)) + " late=" + status(players.getPlayer(PASSENGER))
                + " deck=" + status(server.getOverworld(),deckId) + " field=" + status(server.getOverworld(),fieldId));
        }
        if (WRITER) writeTick(server); else readTick(server);
    }

    private void writeTick(MinecraftServer server) {
        var w = server.getOverworld();
        var crew = server.getPlayerManager().getPlayer(CREW);
        var late = server.getPlayerManager().getPlayer(PASSENGER);
        if (phase == 0) {
            if (crew == null) return;
            if (deckId == null) {
                if (!nativeFixtureVolume(w)) return;
                construct(w);
            }
            var deck = BodySpatialIndex.find(w,deckId).orElse(null);
            if (deck == null || !initializeWriterPlayer(crew,deck.localToWorld(CREW_START))) return;
            if (!hasContact(crew, w)) { stable = 0; return; }
            if (++stable < 10) return;
            writerCrew = crew.getUuid();
            record("writer-crew-boarded", Map.of("tick", server.getTicks(), "uuid", writerCrew));
            advance();
        } else if (phase == 1) {
            if (crew != null || !normalDisconnects.contains(writerCrew)) return;
            saveDiskPlayer("writer-crew", writerCrew, w);
            record("writer-late-launch", Map.of("tick", server.getTicks(), "crewDisconnected", true));
            advance();
        } else if (phase == 2) {
            if (late == null) return;
            if (!initializeLateWriter(late,w)) return;
            if (!hasContact(late, w)) { stable = 0; return; }
            if (++stable < 10) return;
            var deck = body(w, deckId);
            if (!thrustStarted) {
                phaseStart = entity(deck).getPos();
                var omega = new Vec3(0,.12,0);
                var v = new Vec3(3.2,0,0);
                var field = body(w, fieldId);
                giveMotion(deck, v, omega);
                giveMotion(field, v.plus(omega.cross(field.massPosition().minus(deck.massPosition()))), omega);
                thrustStarted = true;
                record("writer-departure-impulse",Map.of("tick",server.getTicks(),"deck",deckId,"field",fieldId,
                    "worldTranslation",xyz(BoardingSystem.mc(v)),"axisYaw",xyz(BoardingSystem.mc(omega)),"applications",1));
                return;
            }
            if (entity(deck).getPos().distanceTo(phaseStart) < .9 || Math.abs(deck.rotation().y()) < .01) return;
            require(deck.physics().linearVelocity().length() > 2, "writer saved a stationary ship");
            writerPassenger = late.getUuid();
            record("writer-passenger-boarded", Map.of("tick", server.getTicks(), "uuid", writerPassenger, "moving", true));
            advance();
        } else if (phase == 3 && late == null && normalDisconnects.contains(writerPassenger)) {
            saveDiskPlayer("writer-passenger", writerPassenger, w);
            record("writer-stopping", Map.of("tick", server.getTicks(), "actualConnectedPlayerCount", server.getPlayerManager().getPlayerList().size(),
                "bothNormalDisconnects", true, "manualBodyTicks", 0, "serverPid", ProcessHandle.current().pid()));
            advance();
            server.stop(false);
        }
    }

    private void readTick(MinecraftServer server) {
        var w = server.getOverworld();
        var crew = server.getPlayerManager().getPlayer(CREW);
        var late = server.getPlayerManager().getPlayer(PASSENGER);
        if (phase == 0) {
            if (crew == null || beforeFirstStep.size() != 2 || !hasContact(crew, w) || late != null) { stable = 0; return; }
            if (++stable < 12) return;
            var deck = body(w, deckId);
            var field = body(w, fieldId);
            require(BodyJointRegistry.get(w).find(joint).filter(link -> link.kind() == BodyJointConstraint.Kind.FIXED
                && link.a().body().equals(deckId) && link.b().body().equals(fieldId)).isPresent(), "original fixed registry not restored");
            var original = read("writer-passenger");
            var stale = point(original, "worldFeet");
            var transformed = deck.localToWorld(point(original, "localFeet"));
            clearanceDistance = transformed.distanceTo(stale);
            var q = original.getAsJsonArray("deckQuaternion");
            Quat old = new Quat(q.get(0).getAsDouble(), q.get(1).getAsDouble(), q.get(2).getAsDouble(), q.get(3).getAsDouble());
            turnRadians = 2*Math.acos(Math.min(1, Math.abs(ImmPtlQuaternions.dot(old, deck.rotation()))));
            if (clearanceDistance < 7.5 || turnRadians < .12 || deck.boardingMotion().query(1)
                .hasContact(DynamicBodyAttachment.box(BoardingSystem.pure(stale), .6, 1.8), .01)) return;
            require(deck.hasSimulatedPhysics() && field.hasSimulatedPhysics(), "no ordinary physics before late login");
            crewEpoch = BoardingSystem.epoch(crew);
            record("reader-late-launch", Map.of("tick", server.getTicks(), "crewEpoch", crewEpoch, "lateOffline", true,
                "staleFeetAreOutsideSupport", true, "distance", clearanceDistance, "turnRadians", turnRadians, "serverPid", ProcessHandle.current().pid()));
            advance();
        } else if (phase == 1) {
            require(nearbyFieldLease(crew,w,crewEpoch) && !departedLate,
                "crew lost the original field, support vicinity or epoch before late admission: "+status(crew));
            if (!hasContact(crew,w)) crewAirborneBeforeLate++;
            if (!hasContact(late, w)) return;
            var deck = body(w, deckId);
            var local = deck.worldToLocal(late.getPos());
            var saved = point(read("writer-passenger"), "localFeet");
            require(late == lateConnection && placementCalls == 1 && placement != null
                && late.getPos().distanceTo(placement) < 1e-7 && local.distanceTo(saved) < 1e-6
                && BoardingSystem.ready(late) && !UfoControlSystem.controls(late), "late login failed exact local support or one-position new authority");
            lateEpoch = BoardingSystem.epoch(late);
            require(lateEpoch > crewEpoch, "late player did not receive a new reader authority epoch");
            phaseStart = entity(deck).getPos();
            record("reader-walk", Map.of("tick", server.getTicks(), "deck", deckId, "field", fieldId, "crew", crew.getUuidAsString(),
                "late", late.getUuidAsString(), "lateEpoch", lateEpoch, "crewEpoch", crewEpoch,
                "localFeetError", local.distanceTo(saved), "absoluteServerPlacements", placementCalls,
                "crewAirborneBeforeLate",crewAirborneBeforeLate));
            advance();
        } else if (phase == 2 || phase == 3) {
            require(nearbyFieldLease(crew,w,crewEpoch) && nearbyFieldLease(late,w,lateEpoch)
                && !departedLate && placementCalls == 1,
                "field/epoch or one-shot placement was lost during concurrent observation: crew="+status(crew)+" late="+status(late));
            boolean crewGrounded = hasContact(crew,w), lateGrounded = hasContact(late,w);
            if (!crewGrounded) crewAirborneConcurrent++;
            if (!lateGrounded) lateAirborneConcurrent++;
            boolean dualGrounded = crewGrounded && lateGrounded;
            stable = dualGrounded ? stable+1 : 0;

            var deck = body(w, deckId);
            continuedDistance = entity(deck).getPos().distanceTo(phaseStart);
            if (phase == 2) {
                if (stable < 12 || !walkingProved || continuedDistance < 1.0 || admittedForwardPackets < 3
                    || !exists("reader-late-keyboard") || !exists("reader-late-ack-after")) return;
                record("reader-capture", Map.of("tick", server.getTicks(), "stableDualContactTicks", stable, "realLocalWalk", walkDistance,
                    "continuedShipDistance", continuedDistance, "deck", deckId, "field", fieldId, "crew", crew.getUuidAsString(), "late", late.getUuidAsString(),
                    "acceptedForwardPackets",admittedForwardPackets,"appliedGroundedForwardCommands",groundedForward));
                advance();
            } else if (stable >= 12 && exists("reader-crew-frame") && exists("reader-late-frame")) {
                record("reader-done", Map.ofEntries(Map.entry("tick", server.getTicks()),Map.entry("bothTCPPlayersConcurrent",true),
                    Map.entry("exactOriginalIds",beforeFirstStep.size()==2),Map.entry("serverSidePlacementCalls",placementCalls),
                    Map.entry("realLocalWalk",walkDistance),Map.entry("continuedShipDistance",continuedDistance),
                    Map.entry("beforeLateDistance",clearanceDistance),Map.entry("beforeLateTurnRadians",turnRadians),
                    Map.entry("manualBodyTicks",0),Map.entry("acceptedForwardPackets",admittedForwardPackets),
                    Map.entry("crewAirborneBeforeLate",crewAirborneBeforeLate),Map.entry("crewAirborneConcurrent",crewAirborneConcurrent),
                    Map.entry("lateAirborneConcurrent",lateAirborneConcurrent),Map.entry("finalConsecutiveDualGrounded",stable)));
                advance();
            }
        } else if (phase == 4 && crew == null && late == null && departedLate && normalDisconnects.size() == 2) {
            record("reader-stopping", Map.of("tick", server.getTicks(), "bothNormalDisconnects", true, "serverPid", ProcessHandle.current().pid()));
            advance();
            server.stop(false);
        }
    }

    private boolean initializeLateWriter(ServerPlayerEntity p, ServerWorld world) {
        if (p == stagedPlayer) return true;
        if (!DescentPlayerData.get(p).isSessionWelcomed() || !BoardingSystem.ready(p)) return false;
        var deck = BodySpatialIndex.find(world,deckId).orElse(null);
        var field = BodySpatialIndex.find(world,fieldId).orElse(null);
        if (deck == null || field == null) return false;

        // A second writer starts world-upright. Leave clearance for that shape even if
        // the unoccupied deck rolled while the client process was starting.
        var normal = PassengerFrame.up(deck.rotation());
        double protrusion = p.getWidth()/2 * (Math.abs(normal.x()) + Math.abs(normal.z()))
            + Math.max(0,-normal.y()*p.getHeight());
        var local = new Vec3d(PASSENGER_START.x,1.15+Math.max(.65,protrusion),PASSENGER_START.z);
        var target = deck.localToWorld(local);
        var feet = BoardingSystem.pure(target);
        var playerBox = PassengerFrame.box(feet,p.getWidth(),p.getHeight(),Quat.IDENTITY);
        var bound = playerBox.bounds();
        var area = new Box(BoardingSystem.mc(bound.min()),BoardingSystem.mc(bound.max()));
        if (!deck.collisionRegionAvailable(area)) {
            // The fresh player is still at vanilla spawn and might be outside the
            // usual volume-interest radius. Warm only the writer fixture once.
            if (!lateWriterWarmupRequested) {
                lateWriterWarmupRequested = true;
                var at = BlockPos.ofFloored(target);
                var server = world.getServer();
                server.getCommandManager().executeWithPrefix(server.getCommandSource(),
                    "bcc load "+at.getX()+" "+at.getY()+" "+at.getZ()+" 1");
                record("writer-passenger-prewarm",Map.of("around",xyz(target),"actualDeck",deckId,"requests",1));
            }
            return false;
        }
        var fieldMotion = field.boardingMotion();
        var centre = feet.plus(new Vec3(0,p.getHeight()/2,0));
        if (fieldMotion.gravity(centre,1).isEmpty()) return false;
        var state = new DynamicBodyAttachment.State(feet,new Vec3(0,0,0),false,-1);
        if (!BoardingWorldMotion.capture(p,state,true).canOrient(feet,Quat.IDENTITY)) return false;
        if (List.of(deck.boardingMotion(),fieldMotion).stream().anyMatch(body ->
                body.query(1).contacts(playerBox,0).stream().anyMatch(face -> face.penetration()>1e-6))) return false;
        if (!initializeWriterPlayer(p,target)) return false;
        record("writer-passenger-live-target",Map.of("deck",deckId,"field",fieldId,"localFeet",xyz(local),
            "deckWorldPose",xyz(entity(deck).getPos()),"gravityContains",true,"warmupRequested",lateWriterWarmupRequested));
        return true;
    }

    private boolean initializeWriterPlayer(ServerPlayerEntity p, Vec3d target) {
        if (p == stagedPlayer) return true;
        var data = DescentPlayerData.get(p);
        // New profiles arm on the ordinary join task. Its welcome and the actual
        // remote Ready must both settle before the single fixture placement.
        if (!data.isSessionWelcomed() || !BoardingSystem.ready(p)) return false;
        stagedPlayer = p;
        boolean enabledBefore = data.isEnabled();
        p.changeGameMode(GameMode.SURVIVAL);
        FlightSystem.disable(p, data);
        p.getAbilities().flying = false;
        p.sendAbilitiesUpdate();
        p.networkHandler.requestTeleport(target.x,target.y,target.z,-90,4,Set.of());
        require(!data.isEnabled(), "writer setup did not leave authoritative flight off");
        var role = p.getGameProfile().getName().equals(CREW) ? "crew" : "passenger";
        record("writer-" + role + "-placement", Map.of("player",p.getUuidAsString(),"worldFeet",xyz(p.getPos()),
            "sessionWelcomed",data.isSessionWelcomed(),"ready",BoardingSystem.ready(p),"flightBefore",enabledBefore,
            "flightAfter",data.isEnabled(),"tick",p.getServer().getTicks(),"placements",1));
        return true;
    }

    private String status(ServerPlayerEntity p) {
        if (p == null) return "absent";
        var data = DescentPlayerData.get(p);
        boolean eligible = p.isAlive() && !p.isSpectator() && !p.hasVehicle() && !p.getAbilities().flying
            && !p.isSleeping() && !p.isTouchingWater() && !p.isInLava() && !data.isEnabled() && !FootGravitySystem.isActive(p);
        var state = BoardingSystem.state(p);
        var frame = state == null ? Quat.IDENTITY : state.frame();
        var up = PassengerFrame.up(frame);
        var feet = BoardingSystem.pure(p.getPos());
        var deck = deckId == null ? null : BodySpatialIndex.find(p.getServerWorld(),deckId).orElse(null);
        var field = fieldId == null ? null : BodySpatialIndex.find(p.getServerWorld(),fieldId).orElse(null);
        var playerBox = PassengerFrame.box(feet,p.getWidth(),p.getHeight(),frame);
        var contact = deck == null ? "no hull" : deck.boardingMotion().query(1).contacts(playerBox,.01).stream()
            .max(Comparator.comparingDouble(face -> face.normal().dot(up)))
            .map(face -> face.normal()+"/up="+face.normal().dot(up)+"/penetration="+face.penetration()).orElse("none");
        boolean inField = field != null && field.boardingMotion().gravity(feet.plus(up.scaled(p.getHeight()/2)),1).isPresent();
        return p.getGameProfile().getName() + " feet=" + p.getPos() + " flight=" + data.isEnabled()
            + " welcomed=" + data.isSessionWelcomed() + " ready=" + BoardingSystem.ready(p) + " eligible=" + eligible
            + " active=" + BoardingSystem.drives(p) + " state=" + state + " fieldContains=" + inField
            + " sole=" + (deck == null ? "unknown" : deck.worldToLocal(p.getPos())) + " face=" + contact;
    }

    private static String status(ServerWorld world, UUID id) {
        var body = id == null ? null : BodySpatialIndex.find(world,id).orElse(null);
        return body == null ? "absent" : entity(body).getPos() + "/id=" + entity(body).getId()
            + "/ticked=" + body.hasSimulatedPhysics() + "/paused=" + body.boardingMotionPaused();
    }

    private static void giveMotion(BlockBodyEntity body, Vec3 v, Vec3 omega) {
        body.applyPhysicsImpulse(body.physicsCentre(), BoardingSystem.mc(v.scaled(body.physicsMass())));
        body.applyPhysicsTorque(BoardingSystem.mc(body.physics().worldInertia().transform(omega).scaled(20)));
    }

    private boolean nearbyFieldLease(ServerPlayerEntity p, ServerWorld w, int expectedEpoch) {
        if (p == null || !p.isAlive() || !BoardingSystem.drives(p) || BoardingSystem.epoch(p) != expectedEpoch) return false;
        var state = BoardingSystem.state(p);
        var deck = BodySpatialIndex.find(w,deckId).orElse(null);
        var field = BodySpatialIndex.find(w,fieldId).orElse(null);
        if (state == null || deck == null || field == null || state.gravityOwner() != entity(field).getId()) return false;
        if (state.grounded()) return state.support() == entity(deck).getId();
        // A brief near-sole excursion in the same moving field cannot masquerade
        // as a new grounding point, a new lease, or leaving the original deck.
        var feet = deck.worldToLocal(p.getPos());
        return state.support()<0 && Math.abs(feet.y-1)<.6
            && feet.x>=0 && feet.x<=DECK_LENGTH && feet.z>=0 && feet.z<=DECK_WIDTH;
    }

    private boolean hasContact(ServerPlayerEntity p, ServerWorld w) {
        if (p == null || !BoardingSystem.drives(p)) return false;
        var state = BoardingSystem.state(p);
        var deck = BodySpatialIndex.find(w, deckId).orElse(null);
        var field = BodySpatialIndex.find(w, fieldId).orElse(null);
        return state != null && state.grounded() && deck != null && field != null
            && state.support() == entity(deck).getId() && state.gravityOwner() == entity(field).getId();
    }

    private void saveDiskPlayer(String name, UUID player, ServerWorld w) {
        var saved = w.getServer().getSavePath(WorldSavePath.ROOT).resolve("playerdata/" + player + ".dat");
        try {
            var n = NbtIo.readCompressed(saved, NbtSizeTracker.of(2*1024*1024));
            var data = n.getCompound("DrmdData");
            var anchor = data.getCompound("boardingAnchor");
            require(data.getInt("boardingResumeSchema") == 2 && anchor.containsUuid("support") && anchor.getUuid("support").equals(deckId)
                && anchor.containsUuid("gravity") && anchor.getUuid("gravity").equals(fieldId), "normal on-disk player save lacks dual owners");
            var pos = n.getList("Pos", NbtElement.DOUBLE_TYPE);
            require(pos.size() == 3, "on-disk absolute feet missing");
            var local = new Vec3d(anchor.getDouble("feetx"), anchor.getDouble("feety"), anchor.getDouble("feetz"));
            var deck = body(w, deckId);
            var q = deck.rotation();
            record(name, Map.of("player", player, "deck", deckId, "field", fieldId,
                "worldFeet", new double[]{pos.getDouble(0),pos.getDouble(1),pos.getDouble(2)}, "localFeet", xyz(local),
                "deckQuaternion", new double[]{q.x(),q.y(),q.z(),q.w()}, "velocity", xyz(deck.physicsVelocity()),
                "tick", w.getServer().getTicks(), "readActualDisconnectedPlayerDisk", true));
        } catch (Exception e) { throw new IllegalStateException("normal playerdata read " + player, e); }
    }

    private static boolean nativeFixtureVolume(ServerWorld w) {
        var access = WorldAccess.of(w);
        for (int x=0;x<=1;x++) for(int z=0;z<=1;z++) for(int y=(Y>>4)-1;y<=(Y>>4)+1;y++) {
            if (!access.isVolumeAvailable(new D6ChunkPos(x,y,z))) return false;
        }
        return true;
    }

    private void construct(ServerWorld w) {
        var deckCells = new ArrayList<BlockBodyEntity.Cell>();
        var fieldCells = new ArrayList<BlockBodyEntity.Cell>();
        var iron = Blocks.IRON_BLOCK.getDefaultState();
        var copper = Blocks.COPPER_BLOCK.getDefaultState();
        for(int x=0;x<DECK_LENGTH;x++) for(int z=0;z<DECK_WIDTH;z++)
            deckCells.add(new BlockBodyEntity.Cell(new BlockPos(x,0,z),iron));
        // Symmetric ballast below the floor. Leave a central opening for the independent
        // field module. Standing players still contact exactly the local Y=1 top surface.
        for(int x=2;x<10;x++) for(int z=2;z<8;z++) {
            if (x>=4 && x<8 && z>=3 && z<7) continue;
            for(int y=-2;y<0;y++) deckCells.add(new BlockBodyEntity.Cell(new BlockPos(x,y,z),iron));
        }
        for(int x=0;x<4;x++) for(int z=0;z<4;z++) for(int y=0;y<2;y++)
            fieldCells.add(new BlockBodyEntity.Cell(new BlockPos(x,y,z),copper));
        var deck = BlockBodyEntity.createLocal(w,deckCells,DECK_ORIGIN);
        var field = BlockBodyEntity.createLocal(w,fieldCells,DECK_ORIGIN.add(FIELD_OFFSET));
        field.setPassengerGravity(new Vec3(0,-18,0));
        var comOffset = field.massPosition().minus(deck.massPosition());
        require(Math.abs(comOffset.x())<1e-9 && comOffset.y()<0 && Math.abs(comOffset.z())<1e-9,
            "field module must be directly below the actual deck centre of mass");
        deckId=entity(deck).getUuid();fieldId=entity(field).getUuid();joint=UUID.randomUUID();
        BodyJointRegistry.get(w).add(w,deck,field,new BodyJointLink(joint,
            new BodyJointLink.Endpoint(deckId,new BlockPos(5,0,4),new Vec3(6,0,5),Quat.IDENTITY),
            new BodyJointLink.Endpoint(fieldId,new BlockPos(1,1,1),new Vec3(2,2,2),Quat.IDENTITY),
            BodyJointConstraint.Kind.FIXED,0,0,0,0,Double.POSITIVE_INFINITY,Double.POSITIVE_INFINITY,false));
        record("writer-ship",Map.of("deck",deckId,"field",fieldId,"joint",joint,"nativeBodiesCreated",2,
            "setupCubeLoadRequests",1,"deckCells",deckCells.size(),"fieldCells",fieldCells.size(),
            "floorSize",new int[]{DECK_LENGTH,DECK_WIDTH},"floorLocalY",1,
            "physicalFixedAnchor",new double[]{6,0,5}));
        record("writer-ship-balance",Map.of("deckCentre",xyz(BoardingSystem.mc(deck.localCentre())),
            "fieldCentreInDeck",xyz(deck.worldToLocal(field.physicsCentre())),
            "physicalMass",deck.physicsMass()+field.physicsMass(),
            "localFieldDown",xyz(BoardingSystem.mc(field.passengerGravity()))));
    }

    // Inherited vanilla members need their vanilla declaring owner in intermediary bytecode.
    private static Entity entity(BlockBodyEntity body) { return body; }
    private static BlockBodyEntity body(ServerWorld w,UUID id) { return BodySpatialIndex.find(w,id).orElseThrow(); }
    private void advance() { phase++; stable=0; }
}
