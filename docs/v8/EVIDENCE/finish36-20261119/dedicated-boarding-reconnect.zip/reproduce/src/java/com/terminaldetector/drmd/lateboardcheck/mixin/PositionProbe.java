package com.terminaldetector.drmd.lateboardcheck.mixin;

import com.terminaldetector.drmd.lateboardcheck.DedicatedBoardingServer;
import net.minecraft.network.packet.c2s.play.TeleportConfirmC2SPacket;
import net.minecraft.server.network.ServerPlayNetworkHandler;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ServerPlayNetworkHandler.class)
abstract class PositionProbe {
    @Shadow public ServerPlayerEntity player;
    @Shadow private Vec3d requestedTeleportPos;
    @Shadow private int requestedTeleportId;

    @Inject(method = "requestTeleport(DDDFFLjava/util/Set;)V", at = @At("RETURN"))
    private void recordPosition(double x, double y, double z, float yaw, float pitch, java.util.Set<?> flags, CallbackInfo ci) {
        DedicatedBoardingServer.positionSent(player,x,y,z,flags.isEmpty(),requestedTeleportId,requestedTeleportPos);
    }

    @Inject(method = "onTeleportConfirm", at = @At("HEAD"))
    private void beforeMatchingConfirmation(TeleportConfirmC2SPacket packet, CallbackInfo ci) {
        if (player.getServer().isOnThread())
            DedicatedBoardingServer.confirmBefore(player,packet.getTeleportId(),requestedTeleportId,requestedTeleportPos);
    }

    @Inject(method = "onTeleportConfirm", at = @At("RETURN"))
    private void afterMatchingConfirmation(TeleportConfirmC2SPacket packet, CallbackInfo ci) {
        if (player.getServer().isOnThread())
            DedicatedBoardingServer.confirmAfter(player,packet.getTeleportId(),requestedTeleportPos);
    }
}
