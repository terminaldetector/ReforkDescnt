package com.terminaldetector.drmd.lateboardcheck.mixin;

import com.terminaldetector.drmd.lateboardcheck.DedicatedBoardingServer;
import com.terminaldetector.drmd.network.BoardingNetworking;
import com.terminaldetector.drmd.world.contraption.boarding.BoardingSystem;
import net.minecraft.server.network.ServerPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(BoardingSystem.class)
abstract class InputProbe {
    @Inject(method = "receive", at = @At("RETURN"), remap = false)
    private static void observeInput(ServerPlayerEntity player, BoardingNetworking.Input input, CallbackInfoReturnable<Boolean> cir) {
        if (cir.getReturnValue()) DedicatedBoardingServer.inputAccepted(player, input);
    }
}
