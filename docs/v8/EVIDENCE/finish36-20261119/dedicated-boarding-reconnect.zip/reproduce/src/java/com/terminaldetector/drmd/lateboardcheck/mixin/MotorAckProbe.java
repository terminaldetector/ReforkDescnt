package com.terminaldetector.drmd.lateboardcheck.mixin;

import com.terminaldetector.drmd.lateboardcheck.DedicatedBoardingServer;
import com.terminaldetector.drmd.network.BoardingNetworking;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.s2c.common.CustomPayloadS2CPacket;
import net.minecraft.server.network.ServerCommonNetworkHandler;
import net.minecraft.server.network.ServerPlayNetworkHandler;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ServerCommonNetworkHandler.class)
abstract class MotorAckProbe {
    @Inject(method = "sendPacket(Lnet/minecraft/network/packet/Packet;)V", at = @At("HEAD"))
    private void observeAuthoritativeMotor(Packet<?> packet, CallbackInfo ci) {
        if ((Object)this instanceof ServerPlayNetworkHandler play
            && packet instanceof CustomPayloadS2CPacket payload
            && payload.payload() instanceof BoardingNetworking.State state) {
            DedicatedBoardingServer.motorStateSent(play.player, state);
        }
    }
}
