package com.terminaldetector.drmd.lateboardcheck.mixin;

import com.terminaldetector.drmd.lateboardcheck.DedicatedBoardingClient;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.RenderTickCounter;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(GameRenderer.class)
abstract class FrameProbe {
    @Inject(method = "render", at = @At("RETURN"))
    private void recordCompletedFrame(RenderTickCounter counter, boolean ticking, CallbackInfo ci) {
        DedicatedBoardingClient.completedFrame();
    }
}
