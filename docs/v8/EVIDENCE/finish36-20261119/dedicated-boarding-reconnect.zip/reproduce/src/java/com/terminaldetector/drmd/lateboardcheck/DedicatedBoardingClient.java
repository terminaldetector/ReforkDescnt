package com.terminaldetector.drmd.lateboardcheck;

import com.terminaldetector.drmd.client.DescentClient;
import com.terminaldetector.drmd.client.config.DescentConfig;
import com.terminaldetector.drmd.client.flight.BoardingClient;
import com.terminaldetector.drmd.world.contraption.BlockBodyEntity;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.Perspective;
import net.minecraft.client.util.ScreenshotRecorder;
import java.net.InetSocketAddress;
import java.util.Map;
import java.util.UUID;

import static com.terminaldetector.drmd.lateboardcheck.Gate.*;

public final class DedicatedBoardingClient implements ClientModInitializer {
    private static final String ROLE = System.getProperty("drmd.lateBoarding.role", "");
    private static final boolean CREW_ROLE = ROLE.equals("crew");
    private static boolean observed, closed, keyDone;
    private static int keyTicks, captured;

    @Override public void onInitializeClient() {
        if (!ENABLED || !(CREW_ROLE || ROLE.equals("late"))) return;
        exchange();
        ClientTickEvents.END_CLIENT_TICK.register(DedicatedBoardingClient::tick);
    }

    private static void tick(MinecraftClient c) {
        if (closed) return;
        if (!observed) {
            c.options.getViewDistance().setValue(2);
            c.options.getMaxFps().setValue(28);
            c.options.setPerspective(Perspective.THIRD_PERSON_BACK);
            c.options.pauseOnLostFocus = false;
            DescentConfig.cockpit = false;
            DescentConfig.weaponView = false;
            DescentConfig.planetFloor = false;
            DescentConfig.levelSky = false;
        }
        if (c.player == null || c.world == null || c.getNetworkHandler() == null) return;
        DescentClient.markUserFlightChoice();
        if (!observed) {
            var connection = c.getNetworkHandler().getConnection();
            var remote = connection.getAddress();
            require(c.getServer() == null && !connection.isLocal() && remote instanceof InetSocketAddress
                && ((InetSocketAddress)remote).getAddress().isLoopbackAddress(), "actual remote loopback TCP connection required");
            require(c.player.getGameProfile().getName().equals(CREW_ROLE ? CREW : PASSENGER), "wrong client profile");
            record(MODE + "-" + ROLE + "-connected", Map.of("pid", ProcessHandle.current().pid(), "nativeTCP", true,
                "profile", c.player.getGameProfile().getName(), "uuid", c.player.getUuidAsString()));
            observed = true;
        }
        if (WRITER) {
            if (BoardingClient.drives(c.player) && exists(CREW_ROLE ? "writer-crew-boarded" : "writer-passenger-boarded")) stop(c);
            return;
        }
        if (!CREW_ROLE && !keyDone && exists("reader-key-ready") && BoardingClient.drives(c.player) && c.currentScreen == null) {
            if (keyTicks++ < 8) c.options.forwardKey.setPressed(true);
            else {
                c.options.forwardKey.setPressed(false);
                keyDone = true;
                record("reader-late-keyboard", Map.of("pid", ProcessHandle.current().pid(), "normalKeyPressedTicks", 8,
                    "epoch", BoardingClient.epoch(), "predictionSequence", BoardingClient.sequence(), "directMovementPacketsByObserver", 0));
            }
        }
        if (exists("reader-done") && exists("reader-" + ROLE + "-frame")) stop(c);
    }

    public static void completedFrame() {
        if (!READER || !observed || closed || captured < 0 || !exists("reader-capture")) return;
        var c = MinecraftClient.getInstance();
        if (c.player == null || c.world == null || c.currentScreen != null || !BoardingClient.drives(c.player)) return;
        var proof = read("reader-capture");
        var deck = UUID.fromString(proof.get("deck").getAsString());
        var field = UUID.fromString(proof.get("field").getAsString());
        var peerId = UUID.fromString(proof.get(CREW_ROLE ? "late" : "crew").getAsString());
        var peer = c.world.getPlayerByUuid(peerId);
        var state = BoardingClient.state();
        var support = c.world.getEntityById(state.support());
        var owner = c.world.getEntityById(state.gravityOwner());
        if (peer == null || !(support instanceof BlockBodyEntity) || !(owner instanceof BlockBodyEntity)
            || !support.getUuid().equals(deck) || !owner.getUuid().equals(field)) { captured = 0; return; }
        require(c.world.getPlayers().stream().filter(p -> p.getUuid().equals(peerId)).count() == 1,
            "duplicate tracked peer");
        if (++captured < 4) return;
        var frameName = "reader-" + ROLE + "-frame";
        long duplicateDeck = java.util.stream.StreamSupport.stream(c.world.getEntities().spliterator(), false).filter(e -> e.getUuid().equals(deck)).count();
        long duplicateField = java.util.stream.StreamSupport.stream(c.world.getEntities().spliterator(), false).filter(e -> e.getUuid().equals(field)).count();
        require(duplicateDeck == 1 && duplicateField == 1, "exact original native bodies must each replicate once");
        try (var image = ScreenshotRecorder.takeScreenshot(c.getFramebuffer())) {
            image.writeTo(exchange().resolve(frameName + ".png"));
            record(frameName, Map.of("nativeTCP", true, "peer", peerId, "localEpoch", BoardingClient.epoch(), "own", c.player.getUuidAsString(),
                "predictionSequence", BoardingClient.sequence(), "deck", deck, "field", field, "freshNativeFrames", captured,
                "renderSize", new int[]{image.getWidth(), image.getHeight()}));
            captured = -1;
        } catch (Exception e) { throw new IllegalStateException("capture of reciprocal native frame failed", e); }
    }

    private static void stop(MinecraftClient c) {
        closed = true;
        c.options.forwardKey.setPressed(false);
        record(MODE + "-" + ROLE + "-shutdown", Map.of("pid", ProcessHandle.current().pid(), "clientNormalShutdownRequested", true));
        c.scheduleStop();
    }
}
