package com.terminaldetector.drmd.lateboardcheck;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.minecraft.util.math.Vec3d;
import java.io.IOException;
import java.nio.file.*;
import java.util.Map;

final class Gate {
    static final String CREW = "LateCrew";
    static final String PASSENGER = "LatePassenger";
    static final String MODE = System.getProperty("drmd.lateBoarding.mode", "");
    static final boolean READER = MODE.equals("reader");
    static final boolean WRITER = MODE.equals("writer");
    static final boolean ENABLED = READER || WRITER;
    static final int Y = 192;
    private static final Gson JSON = new Gson();

    private Gate() {}

    static Path exchange() {
        String setting = System.getProperty("drmd.lateBoarding.exchange", "");
        var path = Path.of(setting).normalize();
        require(!setting.isBlank() && path.isAbsolute() && Files.isRegularFile(path.resolve("staging.json")), "frozen disposable stage required");
        return path;
    }

    static boolean exists(String name) { return Files.isRegularFile(exchange().resolve(name + ".json")); }
    static JsonObject read(String name) {
        try { return JsonParser.parseString(Files.readString(exchange().resolve(name + ".json"))).getAsJsonObject(); }
        catch (IOException e) { throw new IllegalStateException("read " + name, e); }
    }
    static void record(String name, Map<String, ?> value) {
        var target = exchange().resolve(name + ".json");
        require(!Files.exists(target), "duplicate receipt " + name);
        try {
            var pending = Files.createTempFile(exchange(), name, ".tmp");
            Files.writeString(pending, JSON.toJson(value) + "\n");
            Files.move(pending, target, StandardCopyOption.ATOMIC_MOVE);
        } catch (IOException e) { throw new IllegalStateException("write " + name, e); }
    }
    static void require(boolean condition, String detail) {
        if (!condition) throw new IllegalStateException("DEDICATED_BOARDING " + detail);
    }
    static double[] xyz(Vec3d p) { return new double[]{p.x, p.y, p.z}; }
    static Vec3d point(JsonObject row, String name) {
        var v = row.getAsJsonArray(name);
        return new Vec3d(v.get(0).getAsDouble(), v.get(1).getAsDouble(), v.get(2).getAsDouble());
    }
}
