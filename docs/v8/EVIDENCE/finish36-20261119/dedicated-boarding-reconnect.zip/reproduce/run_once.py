#!/usr/bin/env python3
"""Run one explicitly staged dedicated writer or reader. No build, automatic retry or next stage."""
from pathlib import Path
import argparse
import io
import json
import math
import os
import signal
import socket
import struct
import subprocess
import time
import traceback

from stage import WORLD, atomic_json, prior, rows_in, verify_observer


def varint(number):
    encoded = bytearray()
    while number > 127:
        encoded.append((number & 127) | 128)
        number >>= 7
    encoded.append(number)
    return bytes(encoded)


def read_varint(stream):
    value = 0
    for shift in range(0, 35, 7):
        raw = stream.read(1)
        if not raw:
            raise EOFError('incomplete Minecraft VarInt')
        value |= (raw[0] & 127) << shift
        if raw[0] < 128:
            return value
    raise ValueError('oversized Minecraft VarInt')


def framed(payload):
    return varint(len(payload)) + payload


def loopback_motd(port):
    address = b'127.0.0.1'
    handshake = (b'\0' + varint(767) + varint(len(address)) + address
                 + struct.pack('>H', port) + b'\x01')
    try:
        with socket.create_connection(('127.0.0.1', port), timeout=.5) as connection:
            connection.sendall(framed(handshake) + framed(b'\0'))
            with connection.makefile('rb') as wire:
                length = read_varint(wire)
                if not 0 < length <= 1048576:
                    return None
                packet = io.BytesIO(wire.read(length))
            if read_varint(packet) != 0:
                return None
            size = read_varint(packet)
            payload = packet.read()
            if size != len(payload):
                return None
            status = json.loads(payload)
            if status['version']['protocol'] != 767:
                return None
            description = status['description']
            return description if isinstance(description, str) else description['text']
    except (OSError, EOFError, KeyError, TypeError, ValueError):
        return None


def matching_listener(stage, marker, pid):
    if not marker.is_file():
        return False
    receipt = json.loads(marker.read_text())
    return (receipt['pid'] == pid and receipt['dedicated'] and receipt['mode'] == stage['mode']
            and loopback_motd(stage['port']) == stage['serverProperties']['motd'])


def resources():
    def read(path):
        p = Path('/sys/fs/cgroup')/path
        return p.read_text().strip() if p.exists() else None
    return {'memoryCurrent':read('memory.current'), 'memoryMax':read('memory.max'),
            'memoryEvents':read('memory.events'), 'memoryStat':read('memory.stat')}


def verify_motor_walk(motor, key_ready, keyboard, proof, walk, after, late_pid):
    assert keyboard['pid']==late_pid and keyboard['epoch']==walk['lateEpoch']
    assert keyboard['normalKeyPressedTicks']==8 and keyboard['directMovementPacketsByObserver']==0
    assert motor['epoch']==key_ready['epoch']==walk['lateEpoch']
    assert [motor['deck'],motor['field']]==[walk['deck'],walk['field']]
    assert key_ready['tick']>=after['tick'] and key_ready['consecutiveGroundedNeutral']>=3
    def neutral(sample):
        return abs(sample['forward'])<1e-5 and abs(sample['strafe'])<1e-5 and not sample['jump']
    def forward(sample):
        return sample['forward']>.5 and abs(sample['strafe'])<1e-5 and not sample['jump']
    trace = motor['samples']
    assert all(b['sequence']>a['sequence'] and b['tick']>=a['tick'] for a,b in zip(trace,trace[1:]))
    assert trace[0]['sequence']==motor['beforeSequence']>=key_ready['acknowledgment']
    assert trace[-1]['sequence']==motor['afterSequence'] and 0<motor['serverTicks']<=48
    assert trace[-1]['tick']-trace[0]['tick']==motor['serverTicks']
    assert trace[0]['grounded'] and neutral(trace[0]) and motor['groundedNeutralAfter']>=3
    assert all(sample['grounded'] and neutral(sample) for sample in trace[-3:])
    assert all(neutral(sample) or forward(sample) for sample in trace)
    applied=sum(forward(sample) for sample in trace)
    grounded=sum(forward(sample) and sample['grounded'] for sample in trace)
    assert grounded==motor['groundedForwardCommands']>=3
    assert grounded<=applied==motor['appliedForwardCommands']<=motor['acceptedForwardPackets']<=proof['acceptedForwardPackets']
    before,finish=motor['beforeLocalFeet'],motor['afterLocalFeet']
    assert before==trace[0]['localFeet'] and finish==trace[-1]['localFeet']
    actual=math.hypot(finish[0]-before[0],finish[2]-before[2])
    assert actual>=.32 and abs(actual-motor['horizontalLocalDistance'])<1e-9
    assert abs(actual-proof['realLocalWalk'])<1e-9


def prove(root, stage, children):
    def read(name): return json.loads((root/(name+'.json')).read_text())
    mode = stage['mode']
    for role in ('crew','late'):
        native = read(mode+'-'+role+'-connected')
        assert native['nativeTCP'] and native['pid'] == children[role].pid
        assert read(mode+'-'+role+'-shutdown')['clientNormalShutdownRequested']
    assert read('server-started')['pid'] == children['server'].pid
    listener = read('tcp-listener-accepted')
    assert listener['serverPid'] == children['server'].pid and listener['port'] == stage['port']
    assert listener['privateMotd'] == stage['serverProperties']['motd'] and listener['protocol'] == 767
    stopping = read(mode+'-stopping')
    assert stopping['bothNormalDisconnects'] and stopping['serverPid'] == children['server'].pid
    world = Path(stage['launches']['server']['cwd'])/WORLD
    files = rows_in(world)
    assert 'session.lock' in files and 'level.dat' in files
    base = {'qualified':True, 'mode':mode, 'source':stage['source'], 'modHashes':stage['modHashes'],
            'children':{name:child.returncode for name,child in children.items()},
            'serverPid':children['server'].pid,'world':str(world),'worldFiles':files}
    if mode == 'writer':
        ship = read('writer-ship')
        assert ship['nativeBodiesCreated'] == 2 and stopping['manualBodyTicks'] == 0
        assert ship['deckCells']==184 and ship['fieldCells']==32 and ship['floorSize']==[12,10]
        assert ship['floorLocalY']==1 and ship['physicalFixedAnchor']==[6,0,5]
        balance = read('writer-ship-balance')
        assert abs(balance['physicalMass']-216)<1e-9 and balance['localFieldDown']==[0,-18,0]
        for axis,expected in ((0,6),(2,5)):
            assert abs(balance['deckCentre'][axis]-expected)<1e-9 and abs(balance['fieldCentreInDeck'][axis]-expected)<1e-9
        assert balance['fieldCentreInDeck'][1]<balance['deckCentre'][1]
        thrust = read('writer-departure-impulse')
        assert thrust['applications']==1 and thrust['worldTranslation']==[3.2,0,0] and thrust['axisYaw']==[0,.12,0]
        sidecars = ['writer-ship.json','writer-ship-balance.json','writer-departure-impulse.json',
                    'writer-crew.json','writer-passenger.json',
                    *[f'writer-body-{ship[k]}.snbt' for k in ('deck','field')]]
        for person in ('crew','passenger'):
            saved = read('writer-'+person)
            setup = read('writer-'+person+'-placement')
            assert setup['placements'] == 1 and setup['ready'] and setup['sessionWelcomed'] and not setup['flightAfter']
            assert setup['player'] == saved['player'] and saved['readActualDisconnectedPlayerDisk']
            assert 'playerdata/'+saved['player']+'.dat' in files
            assert (saved['deck'], saved['field']) == (ship['deck'], ship['field'])
        assert read('late-child-start')['priorCrewExited'] == 0
        target = read('writer-passenger-live-target')
        assert (target['deck'],target['field']) == (ship['deck'],ship['field']) and target['gravityContains']
        if target['warmupRequested']:
            assert read('writer-passenger-prewarm')['requests'] == 1
        return {**base,'sidecars':{name:prior.sha(root/name) for name in sidecars}}
    cold = stage['coldRestore']
    assert cold['writerServerPid'] != children['server'].pid
    assert cold['readerObserverSha256'] == stage['modHashes']['observer']
    launch = read('reader-late-launch')
    joined = read('reader-late-joined')
    walk = read('reader-walk')
    proof = read('reader-done')
    assert launch['lateOffline'] and launch['staleFeetAreOutsideSupport'] and launch['distance'] >= 7.5 and launch['turnRadians'] >= .12
    assert launch['tick'] < joined['tick'] <= walk['tick'] and not joined['serverWasReady']
    assert proof['bothTCPPlayersConcurrent'] and proof['exactOriginalIds'] and proof['manualBodyTicks'] == 0
    placement = read('reader-late-placement')
    begin = read('reader-late-ack-begin')
    after = read('reader-late-ack-after')
    assert placement['id'] == begin['id'] == after['id']
    assert placement['tick'] <= begin['tick'] == after['tick']
    assert begin['leaseBefore'] and after['leaseAfter'] and after['vanillaPendingCleared']
    assert begin['epochBefore'] == after['epochAfter'] == walk['lateEpoch']
    assert after['rewindDistance'] < 1e-7, 'matching native confirmation rewound the authoritative actor'
    motor = read('reader-motor-walk')
    key_ready = read('reader-key-ready')
    keyboard = read('reader-late-keyboard')
    verify_motor_walk(motor,key_ready,keyboard,proof,walk,after,children['late'].pid)
    assert proof['serverSidePlacementCalls'] == 1 and proof['realLocalWalk'] >= .32 and proof['continuedShipDistance'] >= 1
    assert proof['acceptedForwardPackets'] >= 3 and proof['finalConsecutiveDualGrounded'] >= 12
    assert read('reader-capture')['stableDualContactTicks'] >= 12
    assert proof['crewAirborneBeforeLate'] == walk['crewAirborneBeforeLate']
    assert all(proof[k]>=0 for k in ('crewAirborneBeforeLate','crewAirborneConcurrent','lateAirborneConcurrent'))
    assert read('late-child-start')['crewAliveAtLaunch']
    for key in ('deck','field'):
        saved = read('reader-native-before-tick-'+walk[key])
        assert saved['exactRawNbt'] and saved['exactRuntimePose']
    frames = {}
    for role, peer, own in [('crew','late','crew'), ('late','crew','late')]:
        frame = read('reader-'+role+'-frame')
        path = root/f'reader-{role}-frame.png'
        assert frame['nativeTCP'] and frame['own'] == walk[own] and frame['peer'] == walk[peer]
        assert frame['deck'] == walk['deck'] and frame['field'] == walk['field']
        assert frame['freshNativeFrames'] >= 4 and path.stat().st_size > 1000
        frames[role] = {'receipt':frame,'pngSha256':prior.sha(path)}
    return {**base, 'originalWriter':stage['coldRestore'], 'proof':proof, 'reciprocalNativeFrames':frames,
            'lateAcknowledgement':{'placement':placement,'before':begin,'after':after},
            'nativeMotorWalk':{'ready':key_ready,'keyboard':keyboard,'applied':motor}}


def run(path, wall):
    root = path.parent
    stage = json.loads(path.read_text())
    assert path.resolve() == (root/'staging.json').resolve()
    assert stage['status'] == 'STAGED_NOT_RUN' and not (root/'actual-start.json').exists()
    if stage['mode'] == 'reader':
        cold = stage['coldRestore']
        assert cold['readerObserverSha256'] == stage['modHashes']['observer']
        assert all(stage['modHashes'][key]==sha for key,sha in cold['sameGameAndDependencies'].items())
        prior.frozen(Path(cold['writerProof']),cold['writerProofSha256'])
        assert rows_in(Path(stage['launches']['server']['cwd'])/WORLD) == cold['worldFiles']
        for name,expected in cold['sidecars'].items():
            prior.frozen(root/name,expected)
    for name, launch in stage['launches'].items():
        mods = {prior.sha(jar) for jar in (Path(launch['cwd'])/'mods').glob('*.jar')}
        expected = {digest for key,digest in stage['modHashes'].items() if key!='sodium' or name!='server'}
        assert mods == expected, f'unexpected mods before launch {name}'
        observer = next(jar for jar in (Path(launch['cwd'])/'mods').glob('*.jar')
                        if prior.sha(jar) == stage['modHashes']['observer'])
        assert verify_observer(observer) == stage['observerRefmap']
    port = stage['port']
    with socket.socket() as test: test.bind(('127.0.0.1',port))
    started = time.monotonic()
    deadline = started+wall
    atomic_json(root/'actual-start.json',{'wallSeconds':wall,'stageSha256':prior.sha(path),'resources':resources()})
    children, logs = {}, {}
    x = None
    error = None

    def check_native_crashes():
        for role in children:
            directory = Path(stage['launches'][role]['cwd'])/'crash-reports'
            report = next(directory.glob('crash-*.txt'), None)
            if report is not None:
                raise RuntimeError(f'{role} wrote a native crash report: {report}')

    def wait_for(predicate, label, living=()):
        while not predicate():
            check_native_crashes()
            for role,process in children.items():
                code=process.poll()
                if code not in (None,0) or role in living and code is not None:
                    raise RuntimeError(f'{role} closed with {code} before {label}')
            if time.monotonic() >= deadline: raise TimeoutError(label)
            time.sleep(.1)

    def child(role, env=None, **detail):
        launch = stage['launches'][role]
        logs[role] = (root/(role+'-first.log')).open('xb')
        process = subprocess.Popen(launch['argv'], cwd=launch['cwd'], stdout=logs[role], stderr=subprocess.STDOUT,
                                   stdin=subprocess.PIPE if role=='server' else subprocess.DEVNULL,
                                   env=env, start_new_session=True)
        children[role] = process
        atomic_json(root/(role+'-child-start.json'), {'pid':process.pid,'monotonic':time.monotonic(),**detail})

    try:
        child('server')
        wait_for(lambda: matching_listener(stage,root/'server-started.json',children['server'].pid),
                 'dedicated startup and unique Minecraft status reply on loopback', ('server',))
        atomic_json(root/'tcp-listener-accepted.json',{'serverPid':children['server'].pid,
            'address':'127.0.0.1','port':port,'protocol':767,'privateMotd':stage['serverProperties']['motd'],
            'proof':'actual Minecraft status reply matches unique launched stage and server-started PID'})
        logs['xvfb'] = (root/'xvfb-first.log').open('xb')
        display_path = root/'xvfb-display.txt'
        with display_path.open('xb') as display_file:
            x = subprocess.Popen(['/workspace/xvfb/usr/bin/Xvfb','-displayfd',str(display_file.fileno()),
                                  '-screen','0','1024x768x24','-nolisten','tcp'], pass_fds=(display_file.fileno(),),
                                 stdout=logs['xvfb'],stderr=subprocess.STDOUT,start_new_session=True)
        wait_for(lambda: display_path.read_bytes().endswith(b'\n'), 'Xvfb ready', ('server',))
        display = display_path.read_text().strip()
        assert display.isdigit() and Path('/tmp/.X11-unix/X'+display).is_socket()
        env = dict(os.environ,DISPLAY=':'+display,LIBGL_ALWAYS_SOFTWARE='1',MESA_GL_VERSION_OVERRIDE='3.3',
                   MESA_GLSL_VERSION_OVERRIDE='330',LP_NUM_THREADS='2',MALLOC_ARENA_MAX='2')
        child('crew',env)
        marker = root/(stage['mode']+'-late-launch.json')
        if stage['mode'] == 'writer':
            wait_for(lambda: marker.is_file() and children['crew'].poll() == 0, 'crew normal exit before second writer client', ('server',))
            child('late',env,priorCrewExited=children['crew'].returncode)
        else:
            wait_for(marker.is_file,'real offline carrier motion clearance',('server','crew'))
            assert children['crew'].poll() is None
            child('late',env,crewAliveAtLaunch=True,actualCrewPid=children['crew'].pid)
        while any(child.poll() is None for child in children.values()):
            check_native_crashes()
            assert all(child.poll() in (None,0) for child in children.values()),'child closed nonzero'
            if time.monotonic() >= deadline: raise TimeoutError('normal shutdown and receipts')
            time.sleep(.1)
        assert all(child.returncode==0 for child in children.values())
        atomic_json(root/'qualified-proof.json',prove(root,stage,children))
    except BaseException:
        error = traceback.format_exc()
    finally:
        server = children.get('server')
        if server is not None and server.poll() is None:
            try:
                server.stdin.write(b'stop\n')
                server.stdin.flush()
            except (BrokenPipeError,OSError):
                pass
            try: server.wait(timeout=15)
            except subprocess.TimeoutExpired: pass
        for process in [*children.values(),x]:
            if process is None: continue
            if process.poll() is None: os.killpg(process.pid,signal.SIGTERM)
            try: process.wait(timeout=8)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid,signal.SIGKILL)
                process.wait()
        for file in logs.values(): file.close()
    closure = {role:{'pid':process.pid,'exit':process.returncode} for role,process in children.items()}
    atomic_json(root/'actual-close.json',{'children':closure,'resources':resources(),'error':error,
                'seconds':time.monotonic()-started,'qualified':error is None})
    print(json.dumps({'qualified':error is None,'root':str(root),'children':closure}))
    return int(error is not None)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--staging',required=True,type=Path)
    parser.add_argument('--wall',type=int,default=360)
    args=parser.parse_args()
    raise SystemExit(run(args.staging.resolve(),args.wall))
