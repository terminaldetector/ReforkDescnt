#!/usr/bin/env python3
"""Read-only, fail-closed validator. Never edits the native first outcome."""
import argparse
import hashlib
import json
from pathlib import Path


def require(ok, why):
    if not ok:
        raise ValueError(why)


def read(path):
    return json.loads(path.read_text())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def validate(writer, reader, writer_exit, reader_exit):
    require(writer_exit.read_text().strip() == '0', 'actual writer JVM exit must be zero')
    require(reader_exit.read_text().strip() == '0', 'actual reader JVM exit must be zero')
    before = read(writer / 'manifest.json')
    ready = read(writer / 'writer-ready.json')
    closed = read(writer / 'writer-closed.json')
    after = read(reader / 'reader-result.json')
    loads = read(reader / 'reader-load-events.json')
    require(ready['status'] == 'READY_TO_SAVE', 'writer readiness is not a completed save')
    require(closed['status'] == 'PASS' and closed['nativeShutdownWrites'] == 7,
            'seven real native closing serializations required')
    require(before['process'] == ready['process'] == closed['process'], 'writer identity mismatch')
    require(before['pid'] == ready['pid'] == closed['pid'], 'actual writer PID mismatch')
    require(after['status'] == 'PASS' and after['mode'] == 'READ', 'actual reader scope must PASS')
    require(after['writerProcess'] == before['process'] and after['process'] != before['process'],
            'different reader process bound to the actual writer required')
    require(after['writerPid'] == before['pid'] and after['pid'] != before['pid'],
            'actual second process PID required')
    require(loads['writerProcess'] == before['process'] and loads['readerProcess'] == after['process'],
            'native storage/load events belong to the actual pair')
    require(after['sourceBinding'] != 'UNBOUND' and after['sourceBinding'] == ready['sourceBinding'],
            'exact same bound production source required')
    expected = before['actors']
    actual = after['actors']
    events = {a['uuid']: a for a in loads['actors']}
    require(len(expected) == len(actual) == len(events) == 7, 'seven actual family objects required')
    require([a['index'] for a in expected] == list(range(7)), 'fixed seven-family order')
    require([a['familyId'] for a in expected] == [f'C{i}' for i in range(1, 8)], 'family label mismatch')
    hashes = {}
    for old, new in zip(expected, actual):
        for key in ('index', 'familyId', 'uuid', 'type', 'javaClass', 'navigation', 'control', 'noGravity', 'aiDisabled', 'source', 'base', 'worldKey'):
            require(old[key] == new[key], f'cold identity/flag/controller changed: {old["familyId"]} {key}')
        require(old['aiDisabled'] is (old['index'] >= 2), 'actual declared native AI policy differs from its family')
        uuid = old['uuid']
        source = writer / f'{uuid}.snbt'
        copied = reader / f'{uuid}.snbt'
        require(source.is_file() and source.stat().st_size > 0 and sha(source) == sha(copied),
                'reader uses immutable actual native closing NBT receipts')
        hashes[uuid] = sha(source)
        require(new['admittedAge'] >= 8, f'ordinary native post-load ages missing: {uuid}')
        for label in ('nativeDecode', 'nativeEntityLoad'):
            row = events[uuid][label]
            require(row is not None and row['uuid'] == uuid and row['lease'] is False,
                    f'pre-tick native restored identity must not borrow a previous process lease: {label}')
            require(row['noGravity'] == old['noGravity'], 'native restored authored gravity flag changed')
            require(row['worldKey'] == old['worldKey'], 'native restored world context changed')
            require(row['aiDisabled'] is old['aiDisabled'], 'native restored per-family NoAI flag changed')
        if 2 <= new['index'] <= 5:
            force = new['force']
            require(new['forceCalls'] > 0 and force['forceOnly'] and force['forceDeltaExact']
                    and force['strength'] >= .05, 'actual restored force-only operator not observed')
        elif new['index'] == 6:
            require(new['forceCalls'] == 0 and events[uuid]['nativeEntityLoad']['attachment'] == 'DOWN',
                    'native anchored actor must retain attachment without a force lease')
    for report in (ready, after):
        require(report['noGravityMutations'] == report['manualActorTicks'] == 0
                and report['forcedActorFrame'] is False
                and report['setupAiPolicy'] == 'C1/C2 native AI; C3-C7 isolated',
                'fixture intervention receipts changed')
    return {'status': 'PASS', 'scope': 'seven actual cold native torch policies, not universal AI',
            'writerPid': before['pid'], 'readerPid': after['pid'], 'serializedActorSha256': hashes,
            'writerResultSha256': sha(writer / 'writer-ready.json'),
            'readerResultSha256': sha(reader / 'reader-result.json')}


if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('writer', type=Path, help='retained writer mob-torch-cold directory')
    p.add_argument('reader', type=Path, help='reader mob-torch-cold directory')
    p.add_argument('--writer-exit', type=Path, required=True, help='actual writer native.exit file')
    p.add_argument('--reader-exit', type=Path, required=True, help='actual reader native.exit file')
    a = p.parse_args()
    print(json.dumps(validate(a.writer, a.reader, a.writer_exit, a.reader_exit), indent=2))
