package com.terminaldetector.drmd.gate.legacy;

import com.terminaldetector.drmd.DescentPlayerData;
import com.terminaldetector.drmd.entity.ModEntities;
import com.terminaldetector.drmd.entity.PyroShipEntity;
import com.terminaldetector.drmd.flight.FlightSystem;
import net.fabricmc.fabric.api.gametest.v1.FabricGameTest;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.block.Blocks;
import net.minecraft.entity.Entity;
import net.minecraft.registry.Registries;
import net.minecraft.registry.tag.FluidTags;
import net.minecraft.test.GameTest;
import net.minecraft.test.TestContext;
import net.minecraft.util.math.*;
import java.nio.file.*;
import java.util.*;

/** Causal matched successor of the sealed legacy graph, not the original incident save.
 * Only fixture creation and genuine block-fluid authoring; every observation runs on
 * ordinary TestServer ticks. No damage calls, entity tick calls, immunity or player rescue.
 */
public final class LegacyProxyHazardControlGameTests implements FabricGameTest {
    private static final int AUTHOR_AT=8, END_AT=230;

    @GameTest(templateName=EMPTY_STRUCTURE,batchId="proxy-causal-air",tickLimit=241)
    public void matchedNoLavaControlRetainsHistoricalHullBeyondOldRemovalWindow(TestContext c) {
        observe(c,false);
    }
    @GameTest(templateName=EMPTY_STRUCTURE,batchId="proxy-causal-lava",tickLimit=241)
    public void actualLavaRemovesHistoricalIntermediaryWithNativeReasonWhilePlayerLives(TestContext c) {
        observe(c,true);
    }
    private static void observe(TestContext c,boolean lava) {
        var r=new Rig(c,lava?"causal-lava":"matched-no-lava");
        String version=FabricLoader.getInstance().getModContainer("drmd").orElseThrow().getMetadata().getVersion().getFriendlyString();
        boolean historical=version.equals("1.1.6");
        c.assertTrue(historical||version.equals("1.1.35-ufo-dev.1"),"unsupported subject version: "+version);
        r.subjectVersion=version;
        FlightSystem.disable(r.player,r.data);
        r.record("ordinary-flight-off");
        try {
            c.assertTrue(!r.data.isEnabled(),"both subjects disable authority synchronously");
            c.assertTrue(r.player.hasVehicle()==historical,"exact legacy/current mount contrast is an admission, not a silently changed expectation");
            if(!historical)c.assertTrue(!r.hull.hasPassengers(),"current ordinary off severs reciprocal mount immediately");
        }catch(RuntimeException|Error failure){r.close();throw failure;}
        for(int tick=1;tick<=END_AT;tick++) {
            final int elapsed=tick;
            c.runAtTick(tick,()->{
                if(r.closed)return;
                try {
                    r.observerTick=elapsed;
                    if(elapsed==AUTHOR_AT) {
                        r.record("before-matched-geometry");
                        c.assertTrue(r.player.isAlive(),"fixture player survives the eight ordinary air ticks");
                        if(historical)c.assertTrue(r.player.getVehicle()==r.hull&&!r.hull.isRemoved()&&r.data.isEnabled(),"old live hull must actually rearm the disabled mounted pilot");
                        else c.assertTrue(!r.player.hasVehicle()&&!r.hull.hasPassengers()&&!r.data.isEnabled(),"current normal off must stay released without a hazard");
                        // The current subject already completed the unforced ordinary exit;
                        // do not put its free player into lava and call that an exit test.
                        if(lava&&!historical){r.record("hazard-unneeded-current-exit");r.close();c.complete();return;}
                        var center=r.player.getBlockPos();r.geometryCenter=center.toImmutable();
                        for(var p:BlockPos.iterate(center.add(-2,-4,-2),center.add(2,-4,2)))
                            c.getWorld().setBlockState(p,Blocks.OBSIDIAN.getDefaultState(),3);
                        for(var p:BlockPos.iterate(center.add(-2,-3,-2),center.add(2,2,2)))
                            c.getWorld().setBlockState(p,(lava?Blocks.LAVA:Blocks.AIR).getDefaultState(),3);
                        r.record(lava?"introduced-real-lava":"introduced-matched-air-no-lava");
                    }
                    r.record("ordinary-world-tick");
                    c.assertTrue(r.player.isAlive(),"the player must remain alive; destruction of a proxy is not player death");
                    if(elapsed==END_AT) {
                        c.assertTrue(r.lastWorldTime-r.firstWorldTime>=END_AT,"matched control spans230 actual world ticks, beyond original removal at10");
                        if(historical&&!lava) {
                            c.assertTrue(!r.hull.isRemoved()&&r.player.getVehicle()==r.hull&&r.hull.getPassengerList().contains(r.player)&&r.data.isEnabled(),"without lava the same original historical mount and rearmed authority must remain through230 ticks");
                            c.assertTrue(!r.sawHullLava&&!r.sawLocalHullLava,"no-lava control must actually stay free of hull/local lava");
                        } else if(historical) {
                            c.assertTrue(r.hull.isRemoved()&&r.firstRemovedTick>AUTHOR_AT&&r.firstRemovedTick<=END_AT,"same historical intermediary actually removed after genuine lava introduction");
                            c.assertTrue(r.hull.getRemovalReason()!=null,"actual native removal reason must be observed before cleanup");
                            c.assertTrue(r.sawHullLava&&r.sawLocalHullLava,"native lava contact AND bounded world-fluid overlap must be observed, not inferred from authored block names");
                            c.assertTrue(!r.player.hasVehicle()&&r.hull.getPassengerList().isEmpty(),"hazard releases both ownership edges while player lives");
                        } else c.assertTrue(!r.player.hasVehicle()&&!r.hull.hasPassengers()&&!r.data.isEnabled(),"current no-hazard release remains stable through the matched window");
                        r.record("completed-before-cleanup");r.close();c.complete();
                    }
                }catch(RuntimeException|Error failure){r.record("assertion-failure-before-cleanup");r.close();throw failure;}
            });
        }
    }
    private static final class Rig implements AutoCloseable {
        final TestContext c;final net.minecraft.server.network.ServerPlayerEntity player;
        final PyroShipEntity ship;final Entity hull;final DescentPlayerData data;
        final io.netty.channel.embedded.EmbeddedChannel channel;
        final String label;final List<Map<String,Object>> trace=new ArrayList<>();
        String subjectVersion="admission";int observerTick,firstRemovedTick=-1;
        long firstWorldTime=-1,lastWorldTime;boolean sawHullLava,sawLocalHullLava,closed;
        BlockPos geometryCenter;
        Rig(TestContext c,String label) {
            this.c=c;this.label=label;var world=c.getWorld();var origin=c.getAbsolutePos(new BlockPos(5,0,5));var at=new BlockPos(origin.getX(),80,origin.getZ());
            c.assertTrue(at.getY()>70&&at.getY()<150,"fixture admission: ordinary open-air Overworld altitude, not zero-g/legacy upper layers");
            for(var p:BlockPos.iterate(at.add(-6,-8,-6),at.add(6,6,6)))world.setBlockState(p,Blocks.AIR.getDefaultState(),2);
            var profile=new com.mojang.authlib.GameProfile(UUID.randomUUID(),"legacy-exit");
            var options=net.minecraft.server.network.ConnectedClientData.createDefault(profile,false);
            player=new net.minecraft.server.network.ServerPlayerEntity(world.getServer(),world,profile,options.syncedOptions());
            var connection=new net.minecraft.network.ClientConnection(net.minecraft.network.NetworkSide.SERVERBOUND);
            channel=new io.netty.channel.embedded.EmbeddedChannel(connection);world.getServer().getPlayerManager().onPlayerConnect(connection,player,options);
            player.setPosition(Vec3d.ofCenter(at));data=DescentPlayerData.get(player);
            // Legacy JOIN can already auto-mount. Reuse that actual hull rather than attempting
            // an unmeasured dismount during admission (which is exactly the defect under test).
            var joined=player.getVehicle();c.assertTrue(joined==null||joined instanceof PyroShipEntity,"admission: native join has no foreign vehicle owner");
            ship=joined instanceof PyroShipEntity existing?existing:ModEntities.PYRO_SHIP.create(world);c.assertTrue(ship!=null,"actual registered historical Pyro type exists");
            hull=ship;hull.setPosition(player.getPos());ship.setOwnerUuid(player.getUuid());rememberHull(data,hull);
            if(joined==null)c.assertTrue(world.spawnEntity(ship),"actual physical intermediary hull registered");
            data.setEnabled(true);if(joined==null)c.assertTrue(player.startRiding(ship,true),"actual native player mounts the declared owned hull");
            c.assertTrue(player.getVehicle()==ship&&hull.getPassengerList().contains(player)&&!ship.isZeroGZone(),"admission: reciprocal real mount graph in ordinary air");
            record("admitted");
        }
        private static void rememberHull(DescentPlayerData data,Entity ship) {
            try {
                var type=data.getClass();
                try{type.getMethod("setLastShipUuid",UUID.class).invoke(data,ship.getUuid());}
                catch(NoSuchMethodException historicalAbsent){type.getMethod("setLastShip",UUID.class,BlockPos.class)
                    .invoke(data,ship.getUuid(),ship.getBlockPos());}
            }catch(ReflectiveOperationException failure){throw new IllegalStateException("Actual public hull memory API missing",failure);}
        }
        void record(String phase) {
            var row=new LinkedHashMap<String,Object>();row.put("phase",phase);row.put("world",player.getWorld().getRegistryKey().getValue().toString());
            row.put("worldTime",player.getWorld().getTime());row.put("playerId",player.getId());row.put("playerUUID",player.getUuid().toString());
            row.put("playerAlive",player.isAlive());row.put("health",player.getHealth());row.put("playerLava",player.isInLava());row.put("playerPos",List.of(player.getX(),player.getY(),player.getZ()));row.put("NoGravity",player.hasNoGravity());row.put("flightEnabled",data.isEnabled());
            var vehicle=player.getVehicle();row.put("vehicleUUID",vehicle==null?"NONE":vehicle.getUuid().toString());row.put("vehicleClass",vehicle==null?"NONE":vehicle.getClass().getName());
            row.put("declaredHullUUID",hull.getUuid().toString());row.put("declaredHullOwner",String.valueOf(ship.getOwnerUuid()));row.put("declaredHullRemoved",hull.isRemoved());
            row.put("declaredHullPassengers",hull.getPassengerList().stream().map(p->p.getUuid().toString()).toList());
            row.put("rememberedHullUUID",String.valueOf(data.getLastShipUuid()));
            row.put("nearbyHulls",player.getWorld().getEntitiesByClass(PyroShipEntity.class,player.getBoundingBox().expand(16),h->true).stream().map(h->Map.of("id",((Entity)h).getUuid().toString(),"owner",String.valueOf(h.getOwnerUuid()),"passengers",((Entity)h).getPassengerList().stream().map(p->p.getUuid().toString()).toList())).toList());
            row.put("subjectVersion",subjectVersion);row.put("observerTick",observerTick);
            lastWorldTime=player.getWorld().getTime();if(firstWorldTime<0)firstWorldTime=lastWorldTime;
            row.put("elapsedWorldTicks",lastWorldTime-firstWorldTime);
            row.put("hullPos",List.of(hull.getX(),hull.getY(),hull.getZ()));
            row.put("nativeRemovalReason",String.valueOf(hull.getRemovalReason()));
            row.put("hullInLava",hull.isInLava());row.put("hullSubmergedInLava",hull.isSubmergedIn(FluidTags.LAVA));
            row.put("hullNativeLavaHeight",hull.getFluidHeight(FluidTags.LAVA));
            row.put("hullFireImmune",hull.isFireImmune());
            var box=hull.getBoundingBox();
            row.put("hullBounds",List.of(box.minX,box.minY,box.minZ,box.maxX,box.maxY,box.maxZ));
            var low=BlockPos.ofFloored(box.minX+1e-7,box.minY+1e-7,box.minZ+1e-7);
            var high=BlockPos.ofFloored(box.maxX-1e-7,box.maxY-1e-7,box.maxZ-1e-7);
            long cells=(long)(high.getX()-low.getX()+1)*(high.getY()-low.getY()+1)*(high.getZ()-low.getZ()+1);
            if(cells<1||cells>512)throw new IllegalStateException("Unexpected hull fluid footprint:"+cells);
            int lavaCells=0;var fluids=new ArrayList<Map<String,Object>>();
            for(var p:BlockPos.iterate(low,high)) {
                var fluid=c.getWorld().getFluidState(p);if(fluid.isEmpty())continue;
                boolean actualLava=fluid.isIn(FluidTags.LAVA);
                double height=fluid.getHeight(c.getWorld(),p);
                boolean overlap=box.maxY>p.getY()&&box.minY<p.getY()+height;
                if(actualLava&&overlap)lavaCells++;
                fluids.add(Map.of("pos",List.of(p.getX(),p.getY(),p.getZ()),"fluid",Registries.FLUID.getId(fluid.getFluid()).toString(),"height",height,"intersectsHull",overlap,"lava",actualLava));
            }
            row.put("localFluidCells",fluids);row.put("localLavaOverlapCells",lavaCells);
            row.put("localFluidCellsQueried",cells);
            if(geometryCenter!=null)row.put("geometryCenter",List.of(geometryCenter.getX(),geometryCenter.getY(),geometryCenter.getZ()));
            sawHullLava|=hull.isInLava();sawLocalHullLava|=lavaCells>0;
            if(hull.isRemoved()&&firstRemovedTick<0)firstRemovedTick=observerTick;
            row.put("firstRemovedTick",firstRemovedTick);
            if(trace.size()>=240)throw new IllegalStateException("Bounded observer receipt exhausted");
            trace.add(row);System.out.println("LEGACY_PROXY_CAUSAL "+new com.google.gson.Gson().toJson(row));
            try{var folder=Path.of("legacy-proxy-causal-proof");Files.createDirectories(folder);Files.writeString(folder.resolve(label+".json"),new com.google.gson.GsonBuilder().setPrettyPrinting().create().toJson(trace));}
            catch(java.io.IOException failure){throw new IllegalStateException(failure);}
        }
        @Override public void close() {
            if(closed)return;closed=true;
            // Cleanup removes the actual player first. It never changes the pre-assert trace or
            // labels destroying a disposable test actor as an acceptable ordinary exit.
            c.getWorld().getServer().getPlayerManager().remove(player);player.discard();hull.discard();channel.finishAndReleaseAll();
        }
    }
}
