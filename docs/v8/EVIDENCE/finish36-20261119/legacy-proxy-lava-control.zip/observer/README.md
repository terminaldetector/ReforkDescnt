# S01-T01 matched native hazard successor (source only)

Prepared19 November2026. Nothing in this directory has been compiled or launched. Original fixture, observer, historical/current JARs and all existing outcomes remain unchanged.

## Exact inputs

- Historical Fabric1.21.1 `1.1.6`: `/tmp/gravity-original-proxy-abi/drmd-6dof-1.1.6-fabric-1.21.1.jar`, SHA256 `e1b31f01495d9f5a43e19d36310825f9c6382b7322c7789aff6a5a483074ffb0`; reconstructed source lineage `6b5332711a293880adbc576bb1489950aeeeb6c4`.
- Current comparison `1.1.35-ufo-dev.1`: `/tmp/ungravity-finish-36/structure-contact-parts-build/jars/drmd-6dof-1.1.35-ufo-dev.1.jar`, SHA256 `3ed8301cfc8cbe0ff754d1f16e64fd747563c9aa3f6a1c2b356521b7c37c6a30`; source `d1db371eab6295056ffdd7128741be6ed3ec831c`.
- Original independent graph evidence: canonical `docs/v8/EVIDENCE/finish36-20261119/legacy-proxy-native-graph.zip`, SHA256 `d9246ace4ba5699802398415bd8b1d366f8ebc0f8fb6bf0d2fcd4585107cd3ea`.

These are the SAME subjects as the existing native comparison, not today's canonical game and not a claimed exact incident binary/save. The original incident save, seed, exact launched version and input recording remain unavailable. The video account distinguishes destroying the intermediary while the player survives from later unrelated player death.

## Existing observation and missing causal link

Original actual historical graph: world877 admission/disable; world885 still same mounted hull and rearmed authority; real lava authored885; hull removed and player unmounted887; player alive20health through1107. Current disable immediately severs both mount edges and stays disabled through eight ordinary ticks. Existing code never recorded native removal reason or hull-fluid state. Thus that graph alone does not establish why the hull disappeared.

## Two new finite ordinary-world cases

`LegacyProxyHazardControlGameTests` reuses the original actual connected-player/hull construction and native FlightSystem.disable path. It adds two separate ordinary TestServer cases, fresh batch IDs:

1. **Matched no-lava control:** same initial mount, disable, eight-tick ordinary rearm admission, same5×5 obsidian floor and5×6×5 AIR volume, then observation through230 ticks. Historical subject must retain the SAME owned reciprocal hull and rearmed authority, actual player alive, and actual hull/local overlap free of lava. Current subject must remain released/disabled and alive through the matched window.
2. **Actual lava:** identical historical setup/floor/volume except genuine LAVA states, no direct damage or entity tick calls. Require actual original-hull removal after introduction, observed native removal reason, actual `isInLava()` and bounded geometry-overlapping world-fluid evidence, severed ownership and live player through230 ticks. Current exits by ordinary disable before hazard, so records hazard-unneeded and closes at8; no current-player lava-survival acceptance is claimed.

Every ordinary observer tick records world time, original UUID/owner/passengers, player health/lava/state, actual native reason, hull in-lava/submerged/height, actual local fluid IDs/heights/box overlap, plus first removed tick. No player immunity, synthetic kill/damage, manually invoked tick, post-admission rescue/pose/velocity or mock hull. At most240 rows/case,512 bounded hull-footprint fluid cells/row; ordinary test limit241. Trace writes before cleanup; cleanup discard is never counted as success or causal removal. Existing three-case fixture is untouched; this observer manifest names only the TWO new cases.

A native removal reason is a native lifecycle reason, not a damage-source identifier. Pairing same-hull persistence in AIR with actual lava contact/removal is the causal control; if that evidence is insufficient, report it rather than infer a specific damage source.

## Future root execution (separate explicit JVM lease required)

`python3 verify-inputs.py` is CPU-only, verifies both complete JAR SHA/CRC/fabric versions and unchanged old fixture, and emits `readiness.json` as SOURCE_ONLY_NOT_COMPILED_NOT_RUN. `bash -n run-pair-first.sh` only checks shell syntax.

After root review/grant, the single convenience runner is:

```sh
LEGACY_PROXY_CAUSAL_JAVA_LEASE=granted bash /tmp/gravity-original-proxy-causal-pair-v2/run-pair-first.sh
```

It creates uniquely named new `runs/legacy-proxy-causal-build-first` and `runs/proxy-causal-{historical,current}-first`, refuses overwrite, builds only the new standalone observer, installs the immutable subjects into separate stock Fabric runtimes and captures actual server logs/exits/XML. Subject and source input hashes are recorded. It reuses identical existing vanilla/Fabric cache bytes when available and never installs into the main runtime. Root must preserve first compile/remap/ABI/startup/test outcomes. No success is implied until both actual cases are assessed with their ownership/fluid traces. Do not reinterpret an early timeout or absent native fluid receipt as success, and do not rerun over the first directories.

Historical stuck/rearm can be an expected reproduced defect in this comparison; that does not mean historical ordinary exit was correct. This bounded experiment cannot claim the original user's exact save or that player death was required.
