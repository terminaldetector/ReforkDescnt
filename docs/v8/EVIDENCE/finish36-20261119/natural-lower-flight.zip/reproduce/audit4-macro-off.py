from argparse import ArgumentParser, Namespace
from pathlib import Path
from runpy import run_path
import json

root=Path(__file__).parent
native=run_path(str(root/'run-once.py'))
plan=native['run'].__globals__['PROFILES']['compact']
assert plan['serverHeapMiB']==640 and plan['clientHeapMiB']==768
plan['serverHeapMiB']=1056
identity='controlled historical audit4, 1056 MiB server heap, ordinary surface macro queue disabled and the stock lower Nether band enabled'
parser=ArgumentParser()
parser.add_argument('action',choices=['stage','run'])
parser.add_argument('case',type=Path)
args=parser.parse_args()
manifest=args.case/'inputs.json'
if args.action=='stage':
    older=Path('/workspace/Refork-audit/build/libs/drmd-6dof-1.1.14-audit.4.jar')
    observer=Path('/tmp/ungravity-final-gradle-storage/libs/drmd-6dof-1.1.35-ufo-dev.1-lower-observer.jar')
    native['stage'](Namespace(case=args.case,mode='current',profile='compact',port=25929,
                            subject=older,subject_sha='9be0f587ad8af834e08f4c13aa348a9b10cf57c455e66ba6464aa962279a5414',
                            observer=observer,observer_sha='3195954ae571f15ad4b0ce5954e4aa421e97f2ba7c36fa90681067621b1b1cb0'))
    inputs=json.loads(manifest.read_text())
    inputs['experimentalControl']=identity
    for role in ('server','client'):
        name=f'{role}/config/drmd-server.properties'
        profile=args.case/name
        stock=profile.read_text()
        assert 'macroWorldgen=true\n' in stock and 'netherBand=true\n' in stock
        profile.write_text(stock.replace('macroWorldgen=true\n','macroWorldgen=false\n'))
        inputs['inputs'][name]=native['sha'](profile)
    native['save'](manifest,inputs)
else:
    inputs=json.loads(manifest.read_text())
    assert inputs['experimentalControl']==identity and inputs['memoryPlanMiB']==plan
    execution=native['run'](Namespace(case=args.case,inputs_sha=native['sha'](manifest)))
    qualified=run_path(str(root/'qualify.py'))['inspect'](args.case)
    native_log=(args.case/'server.log').read_text(errors='replace').splitlines()
    qualified['actualOrdinaryConfig']={'netherBand':any('DRMD server config' in x and 'netherBand=true' in x for x in native_log),
                                       'macroOff':any('Descent stock worldgen seeded' in x and 'macro=false' in x for x in native_log)}
    native['save'](args.case/'qualification.json',qualified)
    print(json.dumps(qualified,indent=2))
    raise SystemExit(execution)
