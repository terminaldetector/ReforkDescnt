#!/usr/bin/env python3
"""Stage or execute one fixed-seed lower-flight case. Each case is freshly generated."""
from argparse import ArgumentParser
from pathlib import Path
from zipfile import ZipFile
import hashlib
import json
import os
import re
import shutil
import socket
import subprocess
import tempfile
import time

ROOT = Path(__file__).resolve().parent
JAVA = Path("/workspace/jdk21-complete/bin/java")
XVFB = Path("/workspace/xvfb/usr/bin/Xvfb")
SERVER_DONOR = Path("/tmp/gravity-original-proxy-causal-pair-v2/runs/proxy-causal-historical-first")
CLIENT_DONOR = Path("/tmp/ungravity-finish-36/vertical-first/cubic-client-automation")
HISTORICAL = Path("/tmp/gravity-original-proxy-abi/drmd-6dof-1.1.6-fabric-1.21.1.jar")
HISTORICAL_SHA = "e1b31f01495d9f5a43e19d36310825f9c6382b7322c7789aff6a5a483074ffb0"
SERVER_CACHE = {
    ".fabric/server/1.21.1-server.jar": "e3bc55693e93cda0188f2e60aea28113fc647c5e85a15fa3d1b347349231b4bb",
    ".fabric/server/fabric-loader-server-0.19.5-minecraft-1.21.1.jar": "689e2ec9c35ccbf28918d5c586f27a4017d064d76f00a7fedf7cc79499dc1bc9",
    ".fabric/remappedJars/minecraft-1.21.1-0.19.5/server-intermediary.jar": "b51c2baaab994bbad4c023427554fcda9e4caaae3d0b4485dd39b522f3c3cf4c",
}
CLIENT_CACHE = {
    ".fabric/remappedJars/minecraft-1.21.1-0.19.5/client-intermediary.jar": "74ac90e2d69b09cc011990505f0b85e894befef84414516ca6630e0f21038ebd",
}
MIB = 1024**2
CGROUP = Path("/sys/fs/cgroup")
PROFILES = {
    "standard": {"serverHeapMiB": 1152, "clientHeapMiB": 1536, "nativeReserveMiB": 896, "growthReserveMiB": 256},
    "compact": {"serverHeapMiB": 640, "clientHeapMiB": 768, "nativeReserveMiB": 768, "growthReserveMiB": 32},
}
CONFIG = """worldKind=STOCK
worldModLevel=ADVANCED
netherBand=true
endBand=true
klondikeIslands=true
macroWorldgen=true
surfaceDistricts=true
orbitJunk=true
cubicSnapshots=false
"""

def verify(ok, detail):
    if not ok:
        raise ValueError(detail)

def sha(path):
    with path.open("rb") as handle:
        return hashlib.file_digest(handle, "sha256").hexdigest()

def metadata(path):
    with ZipFile(path) as archive:
        verify(archive.testzip() is None, f"bad archive {path}")
        return json.loads(archive.read("fabric.mod.json"))

def save(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n")

def binding_path(runtime, name):
    if name.startswith("clientClasspath:"):
        return Path(name.removeprefix("clientClasspath:"))
    return runtime/name

def jvm_flags(profile, role):
    flags = [f"-Xmx{PROFILES[profile][role + 'HeapMiB']}m", "-XX:ActiveProcessorCount=2"]
    if profile == "compact":
        flags += ["-Xms128m", "-XX:+UseSerialGC", "-XX:MaxDirectMemorySize=128m"]
    return flags

def memory_snapshot():
    raw_limit = (CGROUP/"memory.max").read_text().strip()
    used = int((CGROUP/"memory.current").read_text())
    stat = dict(line.split() for line in (CGROUP/"memory.stat").read_text().splitlines())
    events = dict(line.split() for line in (CGROUP/"memory.events").read_text().splitlines())
    inactive = int(stat.get("inactive_file", 0))
    return {"limit": None if raw_limit == "max" else int(raw_limit), "current": used,
            "inactiveFile": inactive, "headroom": None if raw_limit == "max" else int(raw_limit) - used + inactive,
            "oom": int(events.get("oom", 0)), "oomKill": int(events.get("oom_kill", 0))}

def stock_server_bindings():
    manifest = json.loads((SERVER_DONOR/"inputs.json").read_text())
    verify(manifest["stock"] and (SERVER_DONOR/"server.exit").read_text().strip() == "0",
           "require completed stock Fabric runtime donor")
    return {row["path"]:row["sha256"] for row in manifest["artifacts"]
            if not row["path"].startswith("mods/")} | SERVER_CACHE

def freeze_artifact(source, checksum):
    """Share one checksum-bound test or subject JAR across all cases."""
    source = source.resolve(strict=True)
    verify(sha(source) == checksum, f"artifact bytes changed: {source}")
    if source.stat().st_dev == ROOT.stat().st_dev:
        return source
    share = ROOT/"frozen-mod-artifacts"
    share.mkdir(exist_ok=True)
    target = share/(checksum + ".jar")
    if not target.is_file():
        with tempfile.NamedTemporaryFile(dir=share, delete=False) as handle:
            temporary = Path(handle.name)
            with source.open("rb") as original:
                shutil.copyfileobj(original, handle)
        try:
            verify(sha(temporary) == checksum, f"artifact copy changed: {source}")
            try:
                os.link(temporary, target)
            except FileExistsError:
                pass
        finally:
            temporary.unlink()
    verify(target.stat().st_dev == ROOT.stat().st_dev and sha(target) == checksum, target)
    return target

def stage(args):
    runtime = args.case.resolve()
    verify(runtime.parent.resolve() == ROOT, "case must be a fresh direct child of this scratch root")
    verify(not runtime.exists(), "fresh case required")
    subject = HISTORICAL if args.mode == "historical" else args.subject.resolve()
    subject_sha = HISTORICAL_SHA if args.mode == "historical" else args.subject_sha
    verify(sha(subject) == subject_sha and metadata(subject)["id"] == "drmd", "subject SHA/identity")
    if args.mode == "historical":
        verify(metadata(subject)["version"] == "1.1.6", "historical exact artifact required")
    verify(sha(args.observer) == args.observer_sha, "observer SHA")
    verify(metadata(args.observer)["id"] == "drmd_lower_flight_observer", "wrong observer addon")
    published = {row["path"]: row["sha256"]
                 for row in json.loads((CLIENT_DONOR/"inputs.json").read_text())["artifacts"]}
    api_name = "mods/fabric-api-0.116.15+1.21.1.jar"
    api = CLIENT_DONOR/api_name
    verify(sha(api) == published[api_name], "frozen Fabric API SHA")
    verify(metadata(api)["id"] == "fabric-api", "wrong Fabric API")
    mods = ((subject, subject_sha), (args.observer, args.observer_sha), (api, published[api_name]))
    new_mod_bytes = sum(path.stat().st_size for path, checksum in mods if path.stat().st_dev != ROOT.stat().st_dev
                        and not (ROOT/"frozen-mod-artifacts"/(checksum + ".jar")).exists())
    verify(shutil.disk_usage(ROOT).free >= new_mod_bytes + MIB, "not enough tmpfs for immutable stage metadata and mod bytes")
    runtime.mkdir()
    server, client, proof = (runtime/name for name in ("server", "client", "proof"))
    for path in (server, client, proof):
        path.mkdir()
    bindings = {}
    def link(source, destination, checksum):
        source = source.resolve(strict=True)
        verify(source.is_file() and source.stat().st_dev == runtime.stat().st_dev, source)
        verify(sha(source) == checksum, f"immutable donor drift: {source}")
        destination.parent.mkdir(parents=True, exist_ok=True)
        os.link(source, destination)
        verify(destination.samefile(source) and sha(destination) == checksum, destination)
        bindings[str(destination.relative_to(runtime))] = checksum
    for name, checksum in stock_server_bindings().items():
        link(SERVER_DONOR/name, server/name, checksum)
    for name, checksum in CLIENT_CACHE.items():
        link(CLIENT_DONOR/name, client/name, checksum)
    for artifact, checksum in mods:
        frozen = freeze_artifact(artifact, checksum)
        for directory in (server, client):
            link(frozen, directory/"mods"/artifact.name, checksum)
    for directory in (server, client):
        (directory/"config").mkdir()
        (directory/"config"/"drmd-server.properties").write_text(CONFIG)
    (server/"eula.txt").write_text("eula=true\n")
    settings = {"level-name": "LowerFlightWorld", "level-seed": "271026", "level-type": "minecraft:normal",
                "initial-enabled-packs": "vanilla,fabric,drmd:advanced_column",
                "server-ip": "127.0.0.1", "server-port": str(args.port),
                "online-mode": "false", "spawn-protection": "0", "allow-flight": "true",
                "enable-query": "false", "enable-rcon": "false", "difficulty": "normal",
                "gamemode": "survival", "view-distance": "5", "simulation-distance": "3",
                "max-tick-time": "60000", "max-players": "1"}
    (server/"server.properties").write_text("".join(f"{k}={v}\n" for k,v in settings.items()))
    (client/"options.txt").write_text("onboardAccessibility:false\npauseOnLostFocus:false\n"
                                     "maxFps:30\nrenderDistance:5\nsimulationDistance:3\nlang:en_us\n")
    launch = json.loads((CLIENT_DONOR/"launch.json").read_text())
    cp = launch[launch.index("-cp")+1]
    for elem in cp.split(os.pathsep):
        p = Path(elem)
        relative = str(p.relative_to(CLIENT_DONOR))
        verify(sha(p) == published[relative], f"client donor drift: {relative}")
        bindings["clientClasspath:"+str(p)] = published[relative]
    assets = CLIENT_DONOR/"assets"
    argv = [str(JAVA), *jvm_flags(args.profile, "client"),
            f"-Ddrmd.lowerFlight.proof={proof}", "-cp", cp, "net.fabricmc.loader.impl.launch.knot.KnotClient",
            "--gameDir", str(client), "--assetsDir", str(assets), "--assetIndex", launch[launch.index("--assetIndex")+1],
            "--version", "1.21.1", "--versionType", "Lower flight observer", "--username", "LowerFlightPilot",
            "--uuid", "6c6e50a984e352c899a79bd48610070b", "--accessToken", "0", "--userType", "legacy",
            "--width", "960", "--height", "540", "--quickPlayMultiplayer", f"127.0.0.1:{args.port}"]
    server_argv = [str(JAVA), *jvm_flags(args.profile, "server"),
                   f"-Ddrmd.lowerFlight.proof={proof}", "-jar", "fabric-server-launch.jar", "nogui"]
    save(runtime/"launch.json", {"server": server_argv, "client": argv})
    save(runtime/"inputs.json", {"mode": args.mode, "profile": args.profile, "memoryPlanMiB": PROFILES[args.profile],
                                "status": "STAGED_NOT_RUN", "seed": 271026, "port": args.port,
                                "subject": str(subject), "subjectSha256": subject_sha, "observerSha256": args.observer_sha,
                                "bindingMode": "same_device_byte_verified_hardlinks_and_readonly_client_classpath",
                                "bindings": bindings, "inputs": {str(p.relative_to(runtime)):sha(p) for p in
                                    (runtime/"launch.json", server/"config"/"drmd-server.properties",
                                     server/"server.properties", client/"options.txt")}})
    print(runtime/"inputs.json")

def run(args):
    runtime = args.case.resolve()
    verify(runtime.parent.resolve() == ROOT and not (runtime/"processes.json").exists(), "staged one-shot case required")
    verify(shutil.disk_usage(ROOT).free >= 160 * 1024**2, "fresh stock world capacity changed")
    inp = json.loads((runtime/"inputs.json").read_text())
    verify(sha(runtime/"inputs.json") == args.inputs_sha, "exact inputs manifest required")
    verify(inp["status"] == "STAGED_NOT_RUN" and not (runtime/"server"/"LowerFlightWorld").exists(), "empty native save only")
    profile = inp.get("profile", "standard")
    required_headroom = sum(PROFILES[profile].values()) * MIB
    for name, h in (inp["bindings"] | inp["inputs"]).items():
        path = binding_path(runtime, name)
        verify(sha(path) == h, path)
    launch = json.loads((runtime/"launch.json").read_text())
    for role, command in launch.items():
        expected = jvm_flags(profile, role)
        verify(command[1:len(expected) + 1] == expected, f"{role} JVM memory profile differs from staged manifest")
    port = inp["port"]
    with socket.socket() as sock:
        sock.bind(("127.0.0.1", port))
    proof = runtime/"proof"
    initial_memory = memory_snapshot()
    headroom = initial_memory["headroom"]
    if headroom is not None:
        verify(headroom >= required_headroom,
               f"{profile} profile needs {required_headroom // MIB} MiB cgroup headroom; observed {headroom // MIB} MiB")
    result = {"status": "STARTED", "server": {}, "client": {}, "profile": profile,
              "memory": {"initial": initial_memory, "highestCurrentBytes": initial_memory["current"],
                         "lowestHeadroomBytes": headroom, "requiredHeadroomBytes": required_headroom}}
    server, client, xvfb = None, None, None
    def observe_memory():
        if profile != "compact":
            return
        sample = memory_snapshot()
        measurements = result["memory"]
        measurements["highestCurrentBytes"] = max(measurements["highestCurrentBytes"], sample["current"])
        if sample["headroom"] is not None:
            measurements["lowestHeadroomBytes"] = min(measurements["lowestHeadroomBytes"], sample["headroom"])
        if sample["oom"] > initial_memory["oom"] or sample["oomKill"] > initial_memory["oomKill"] \
                or (sample["headroom"] is not None and sample["headroom"] < 128 * MIB):
            raise RuntimeError("compact pressure guard stopped the native case before qualification")

    def await_event(predicate, description, seconds, proc=None):
        deadline = time.monotonic() + seconds
        while time.monotonic() < deadline:
            observe_memory()
            if predicate():
                return
            if proc is not None and proc.poll() is not None:
                raise RuntimeError(f"{description}: child exited {proc.returncode}")
            time.sleep(0.4)
        raise TimeoutError(description)
    try:
        with (runtime/"server.log").open("wb") as log:
            server = subprocess.Popen(launch["server"], cwd=runtime/"server", stdin=subprocess.PIPE, stdout=log,
                                      stderr=subprocess.STDOUT)
        result["server"]["pid"] = server.pid
        save(runtime/"processes.json", result)
        await_event(lambda: (proof/"identity.json").is_file() and "Done (" in (runtime/"server.log").read_text(errors="replace"),
                    "authoritative dedicated server seed/bounds readiness", 140, server)
        if (proof/"server-result.json").exists():
            raise RuntimeError("actual server admission failed; preserved its input observation")
        with tempfile.TemporaryFile(mode="w+b") as display, (runtime/"xvfb.log").open("wb") as xlog:
            xvfb = subprocess.Popen([str(XVFB), "-displayfd", str(display.fileno()), "-screen", "0", "1024x768x24",
                                     "-nolisten", "tcp"], pass_fds=(display.fileno(),), stdout=xlog, stderr=subprocess.STDOUT)
            await_event(lambda: os.fstat(display.fileno()).st_size > 0, "Xvfb display", 12, xvfb)
            display.seek(0)
            value = display.read().decode().strip()
            verify(re.fullmatch(r"\d+", value) is not None, "bad display number")
        env = os.environ | {"DISPLAY": ":" + value, "LIBGL_ALWAYS_SOFTWARE": "1",
                            "MESA_GL_VERSION_OVERRIDE": "3.3", "MESA_GLSL_VERSION_OVERRIDE": "330"}
        with (runtime/"client.log").open("wb") as clog:
            client = subprocess.Popen(launch["client"], cwd=runtime/"client", env=env, stdout=clog,
                                      stderr=subprocess.STDOUT)
        result["client"]["pid"] = client.pid
        save(runtime/"processes.json", result)
        if profile == "compact":
            await_event(lambda: client.poll() is not None, "actual client completion", 175)
            result["client"]["exit"] = client.returncode
        else:
            result["client"]["exit"] = client.wait(timeout=175)
        result["status"] = "BOTH_RESULTS_PRESENT" if all((proof/x).exists() for x in
                            ("server-result.json", "client-result.json")) else "RESULT_NOT_OBSERVED"
    except (ValueError, RuntimeError, TimeoutError, OSError, subprocess.SubprocessError) as problem:
        result["status"] = "UNOBSERVED"
        result["failure"] = str(problem)
    finally:
        for label, job in (("client", client), ("server", server), ("xvfb", xvfb)):
            if job is None:
                continue
            if job.poll() is None:
                if label == "server":
                    try:
                        job.stdin.write(b"stop\n")
                        job.stdin.flush()
                    except (OSError, AttributeError):
                        job.terminate()
                else:
                    job.terminate()
                try:
                    job.wait(timeout=12)
                except subprocess.TimeoutExpired:
                    job.kill()
                    job.wait(timeout=8)
            result.setdefault(label,{})["exit"] = job.returncode
        changed = [name for name, checksum in inp["bindings"].items()
                   if not (path := binding_path(runtime, name)).is_file() or sha(path) != checksum]
        result["artifactDigestsUnchanged"] = not changed
        if changed:
            result["status"] = "UNOBSERVED"
            result["changedArtifacts"] = changed
        result["memory"]["final"] = memory_snapshot()
        save(runtime/"processes.json", result)
        print(json.dumps(result, indent=2))
    return int(result["status"] != "BOTH_RESULTS_PRESENT" or result["server"]["exit"] != 0
               or result["client"]["exit"] != 0)

def main():
    parser = ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="action", required=True)
    stage_command = sub.add_parser("stage")
    stage_command.add_argument("case", type=Path)
    stage_command.add_argument("--mode", choices=("historical", "current"), required=True)
    stage_command.add_argument("--profile", choices=PROFILES, default="standard")
    stage_command.add_argument("--port", type=int, required=True)
    stage_command.add_argument("--observer", type=Path, required=True)
    stage_command.add_argument("--observer-sha", required=True)
    stage_command.add_argument("--subject", type=Path)
    stage_command.add_argument("--subject-sha")
    runner = sub.add_parser("run")
    runner.add_argument("case", type=Path)
    runner.add_argument("--inputs-sha", required=True)
    args = parser.parse_args()
    if args.action == "stage":
        verify(1024 <= args.port <= 65535, "unprivileged local port required")
        if args.mode == "current":
            verify(args.subject is not None and args.subject_sha is not None, "provide exact frozen current JAR and SHA")
        stage(args)
        return 0
    return run(args)

if __name__ == "__main__":
    raise SystemExit(main())
