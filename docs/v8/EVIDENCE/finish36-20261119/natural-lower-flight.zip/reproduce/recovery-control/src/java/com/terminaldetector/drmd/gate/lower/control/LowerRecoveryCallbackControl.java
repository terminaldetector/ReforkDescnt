package com.terminaldetector.drmd.gate.lower.control;

import com.terminaldetector.drmd.world.level.LowerWorldRecovery;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.World;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Isolated historical test intervention. No world, entity or game configuration writes. */
@Mixin(LowerWorldRecovery.class)
abstract class LowerRecoveryCallbackControl {
    @Unique private static final Logger drmdControl$logger = LoggerFactory.getLogger("drmd-lower-recovery-control");
    @Unique private static boolean drmdControl$started;
    @Unique private static boolean drmdControl$crossingObserved;

    @Inject(method = "tick", at = @At("HEAD"), cancellable = true, remap = false, require = 1)
    private static void drmdControl$omitRecovery(MinecraftServer server, CallbackInfo callback) {
        if (!Boolean.getBoolean("drmd.lowerFlight.omitRecoveryCallback")) return;
        if (!drmdControl$started) {
            var subject = FabricLoader.getInstance().getModContainer("drmd").orElseThrow();
            if (!server.isDedicated() || !"1.1.14-audit.4".equals(subject.getMetadata().getVersion().getFriendlyString()))
                throw new IllegalStateException("Lower-flight control requires exact audit.4 on a dedicated test server");
            drmdControl$logger.info("Historical causal control is omitting only LowerWorldRecovery.tick");
            drmdControl$started = true;
        }
        if (!drmdControl$crossingObserved) {
            for (var player : server.getPlayerManager().getPlayerList()) {
                var world = player.getServerWorld();
                if (player.isAlive() && !player.isSpectator() && world.getRegistryKey().equals(World.OVERWORLD)
                        && world.getBottomY() == -784 && player.getY() < world.getBottomY() + 4) {
                    drmdControl$logger.info("Survival pilot crossed normal lower recovery threshold with callback omitted at Y={}", player.getY());
                    drmdControl$crossingObserved = true;
                    break;
                }
            }
        }
        callback.cancel();
    }
}
