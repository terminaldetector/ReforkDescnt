#!/usr/bin/env python3
"""Independently classify immutable lower-shaft event receipts. Never upgrades a healthy floor to a failure."""
from pathlib import Path
from sys import argv
from collections import Counter
import hashlib
import json

def inspect(path):
    p = Path(path).resolve()
    files = ("inputs.json", "processes.json", "proof/identity.json", "proof/server-result.json", "proof/client-result.json")
    absent = [name for name in files if not (p/name).is_file()]
    if absent:
        return {"classification": "UNOBSERVED", "missingReceipts": absent, "case": str(p)}
    manifest, processes, identity, server, client = [json.loads((p/name).read_text()) for name in files]
    status = server.get("status")
    checks = {
        "completedNativeCase": processes.get("status") == "BOTH_RESULTS_PRESENT",
        "normalBothChildrenExited": processes.get("server", {}).get("exit") == processes.get("client", {}).get("exit") == 0,
        "immutableRuntimeBindings": processes.get("artifactDigestsUnchanged") is True,
        "twoRealProcesses": "pid" in processes.get("server", {}) and "pid" in processes.get("client", {})
            and processes["server"]["pid"] != processes["client"]["pid"],
        "tallActualLegacyRegistry": identity["seed"] == manifest["seed"] == 271026
            and identity["bottom"] == -784 and identity["exclusiveTop"] == 1888,
        "actualAdvancedPack": "drmd:advanced_column" in identity["packs"],
        "observedOrdinaryKey": client["armed"] and client["heldNativeDescendKeyTicks"] >= 5,
        "noFixtureWorldOrVelocityMutation": server["fixtureBlockWrites"] == server["fixtureVelocityWrites"]
            == server["fixtureManualGameTicks"] == 0 and server["fixtureTeleports"] == 1,
        "nativeMotion": len(server["nativeMoves"]) >= 5 and any(
            move["attempt"][1] < -0.001 and move["after"][1] < move["before"][1]
            for move in server["nativeMoves"]),
        "realSurvival": len(server["serverTicks"]) >= 5 and
            all(row["collidingSurvival"] for row in server["serverTicks"][:-1]),
    }
    records = server["serverTicks"]
    floors = Counter((x["floor"].get("column"), x["floor"].get("intendedFloorBlock")) for x in records)
    qualification = "OBSERVED_NON_REPRODUCTION" if all(checks.values()) else "UNOBSERVED"
    if all(checks.values()) and status == "ACTUAL_VOID_DEATH":
        if (server["deathType"] == "minecraft:out_of_world"
                and server["lowestNativeY"] < identity["bottom"]
                and any(m["after"][1] < identity["bottom"] for m in server["nativeMoves"])):
            qualification = "CONTROLLED_ACTUAL_VOID_DEATH"
    elif all(checks.values()) and status == "RECOGNIZED_SUBJECT_RECOVERY":
        if any(t["from"][1] < identity["bottom"]+4 < t["to"][1] and any(
                source.startswith("com.terminaldetector.drmd.world.level.LowerWorldRecovery.") for source in t["source"])
               for t in server["subjectTeleports"]):
            qualification = "CURRENT_ACTUAL_EMERGENCY_RECOVERY"
    elif all(checks.values()) and status == "NATURAL_FLOOR_STOP" and server["floorContacts"] > 0:
        qualification = "ACTUAL_NATURAL_FLOOR_STOP"
    return {"classification": qualification, "subjectEngineStatus": status, "case": str(p),
            "checks": checks, "subjectSha256": manifest["subjectSha256"],
            "deathType": server["deathType"], "lowestNativeY": server["lowestNativeY"],
            "legacyNetherBandActuallyEnabled": identity["effectiveNetherBand"],
            "floorCounts": [[key[0], key[1], count] for key,count in sorted(floors.items(), key=lambda x:str(x[0]))],
            "receiptsSha256": {name: hashlib.sha256((p/name).read_bytes()).hexdigest() for name in files}}

if __name__ == "__main__":
    print(json.dumps([inspect(path) for path in argv[1:]], indent=2, ensure_ascii=False))
