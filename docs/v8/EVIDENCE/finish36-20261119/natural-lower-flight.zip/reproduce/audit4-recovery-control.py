#!/usr/bin/env python3
"""Run the matched historical audit.4 causal control with one standalone callback shim."""
from argparse import ArgumentParser, Namespace
from pathlib import Path
from runpy import run_path
import json
import os
import re

ROOT = Path(__file__).resolve().parent
REFERENCE = ROOT / "historical-audit4-macro-off"
REFERENCE_INPUT_SHA = "99fa21afd628297f469581f6f0be2357e35395003a71cd28ec2525f1a94da6e4"
REFERENCE_RESULT_SHA = "d44566d43bd664ff2fc7fbb22fe8f03748d06ed030ef55a55d01f51586d41fa6"
SUBJECT = Path("/workspace/Refork-audit/build/libs/drmd-6dof-1.1.14-audit.4.jar")
SUBJECT_SHA = "9be0f587ad8af834e08f4c13aa348a9b10cf57c455e66ba6464aa962279a5414"
OBSERVER = Path("/tmp/ungravity-final-gradle-storage/libs/drmd-6dof-1.1.35-ufo-dev.1-lower-observer.jar")
OBSERVER_SHA = "3195954ae571f15ad4b0ce5954e4aa421e97f2ba7c36fa90681067621b1b1cb0"
CONTROL = "omit_only_lower_world_recovery_tick"
PROPERTY = "-Ddrmd.lowerFlight.omitRecoveryCallback=true"
GATE = run_path(str(ROOT / "run-once.py"))
check, sha, save = (GATE[k] for k in ("verify", "sha", "save"))

def bind_reference():
    check(sha(REFERENCE / "inputs.json") == REFERENCE_INPUT_SHA, "bound live reference inputs changed")
    check(sha(REFERENCE / "qualification.json") == REFERENCE_RESULT_SHA, "bound live reference result changed")
    baseline = json.loads((REFERENCE / "inputs.json").read_text())
    result = json.loads((REFERENCE / "qualification.json").read_text())
    check(result["classification"] == "CURRENT_ACTUAL_EMERGENCY_RECOVERY" and result["subjectSha256"] == SUBJECT_SHA
          and result["actualOrdinaryConfig"] == {"netherBand": True, "macroOff": True}, "bound reference not qualified")
    GATE["run"].__globals__["PROFILES"]["compact"] = baseline["memoryPlanMiB"]
    return baseline, result

def stage(args):
    baseline, _ = bind_reference()
    control = args.control.resolve()
    metadata = GATE["metadata"](control)
    check(metadata["id"] == "drmd_lower_recovery_control" and metadata["environment"] == "server"
          and metadata["custom"]["drmd:historical_control"] == CONTROL, "require server-side historical control addon")
    frozen = GATE["freeze_artifact"](control, args.control_sha)
    GATE["stage"](Namespace(case=args.case, mode="current", profile="compact", port=25930, subject=SUBJECT,
                           subject_sha=SUBJECT_SHA, observer=OBSERVER, observer_sha=OBSERVER_SHA))
    root = args.case.resolve()
    path = root / "inputs.json"
    inp = json.loads(path.read_text())
    check(inp["bindings"] == baseline["bindings"], "historical pair subject/runtime artifact bindings differ")
    installed = root / "server" / "mods" / control.name
    os.link(frozen, installed)
    check(installed.samefile(frozen) and sha(installed) == args.control_sha, "control addon hardlink verification")
    inp["bindings"][str(installed.relative_to(root))] = args.control_sha
    for role in ("server", "client"):
        name = f"{role}/config/drmd-server.properties"
        cfg = root / name
        cfg.write_text(GATE["CONFIG"].replace("macroWorldgen=true\n", "macroWorldgen=false\n"))
        inp["inputs"][name] = sha(cfg)
        check(inp["inputs"][name] == baseline["inputs"][name], f"configuration differs from reference: {role}")
    argv = json.loads((root / "launch.json").read_text())
    argv["server"].insert(len(GATE["jvm_flags"]("compact", "server")) + 1, PROPERTY)
    save(root / "launch.json", argv)
    inp["inputs"]["launch.json"] = sha(root / "launch.json")
    check(inp["inputs"]["client/options.txt"] == baseline["inputs"]["client/options.txt"], "client initial options drift")
    inp["causalControl"] = {"modSha256": args.control_sha, "intervention": CONTROL, "targetCommit": "12d875dad165bc16111e2930f0e7997ffd273054",
                            "referenceInputsSha256": REFERENCE_INPUT_SHA, "referenceQualificationSha256": REFERENCE_RESULT_SHA,
                            "originalVideoTupleKnown": False}
    save(path, inp)
    print(path, sha(path))

def inspect(root):
    _, reference = bind_reference()
    qualification = run_path(str(ROOT / "qualify.py"))["inspect"](root)
    qualification["control"] = CONTROL
    qualification["scope"] = "causal historical audit.4 pair; original video tuple remains unknown"
    qualification["reference"] = {"result": "historical actual emergency recovery", "lowestY": reference["lowestNativeY"],
                                   "sha256": REFERENCE_RESULT_SHA}
    log = root / "server.log"
    if not log.is_file():
        return qualification
    contents = log.read_text(errors="replace")
    applied = contents.count("Historical causal control is omitting only LowerWorldRecovery.tick") == 1
    crossing = re.search(r"Survival pilot crossed normal lower recovery threshold with callback omitted at Y=(-[0-9.]+)", contents)
    nether = any("DRMD server config" in line and "netherBand=true" in line and "macroWorldgen=false" in line
                 for line in contents.splitlines())
    macro = any("Descent stock worldgen seeded" in line and "macro=false" in line for line in contents.splitlines())
    qualification["actualDedicatedControl"] = applied
    qualification["controlledUnderflowY"] = float(crossing[1]) if crossing else None
    qualification["actualOrdinaryConfig"] = {"netherBand": nether, "macroOff": macro}
    qualification["controlServerLogSha256"] = sha(log)
    if not (applied and nether and macro):
        qualification["classification"] = "UNOBSERVED"
    elif classification := qualification.get("classification"):
        if classification == "CONTROLLED_ACTUAL_VOID_DEATH" and crossing and float(crossing[1]) < -780:
            qualification["classification"] = "AUDIT4_CAUSAL_CONTROL_ACTUAL_VOID_DEATH"
        elif classification == "CONTROLLED_ACTUAL_VOID_DEATH" or classification == "CURRENT_ACTUAL_EMERGENCY_RECOVERY":
            qualification["classification"] = "UNOBSERVED"
    return qualification

if __name__ == "__main__":
    parser = ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="action", required=True)
    stager = commands.add_parser("stage")
    stager.add_argument("case", type=Path)
    stager.add_argument("--control", type=Path, required=True)
    stager.add_argument("--control-sha", required=True)
    runner = commands.add_parser("run")
    runner.add_argument("case", type=Path)
    runner.add_argument("--inputs-sha", required=True)
    args = parser.parse_args()
    if args.action == "stage":
        stage(args)
    else:
        bind_reference()
        case = args.case.resolve()
        staged = json.loads((case / "inputs.json").read_text())
        check(staged["causalControl"]["intervention"] == CONTROL, "staged causal intervention required")
        execution = GATE["run"](args)
        qualified = inspect(case)
        save(case / "qualification.json", qualified)
        print(json.dumps(qualified, indent=2))
        raise SystemExit(execution)
