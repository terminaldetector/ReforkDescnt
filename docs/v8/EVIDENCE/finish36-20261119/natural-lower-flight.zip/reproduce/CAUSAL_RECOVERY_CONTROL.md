# Historical audit.4 lower recovery control

The retained audit.4 binary from `12d875dad165bc16111e2930f0e7997ffd273054` has SHA-256 `9be0f587ad8af834e08f4c13aa348a9b10cf57c455e66ba6464aa962279a5414`. A run with the independent surface macro generator off and the Nether band on exercised ordinary Survival descent, reached Y −780.9372267655629, and observed `LowerWorldRecovery` return the real player to a safe position. Both game processes exited normally. The reference proof observed `FULL_STOCK_COLUMN` and air at the intended floor in all 295 flight samples. [Historical run proof](historical-audit4-macro-off/qualification.json)

`9b715a2c84dfb784d272e70ff8f3bbb223604c2d` introduced the lower recovery callback. Its immediate parent `10ff4db584c6f153530cecbde2ba3866782fcd2f` has no callback and predates `e91f4053c61d8ffd718e082e6db9c1e25daa5f19`, the published correction for recursive chunk loading. The exact audit.4 reference includes both fixes. Exact 1.1.6 startup hit an earlier recursive chunk wait before it could reach the lower route. [Historical watchdog analysis](HISTORICAL_WATCHDOG.md)

The control keeps the exact audit.4 subject JAR, client, observer and runtime artifacts from the successful reference. A separate server-only test mod omits the normal `LowerWorldRecovery.tick(MinecraftServer)` callback immediately on entry. Activation requires an explicit JVM property, dedicated client/server topology and the audit.4 mod version. It logs that it took effect, then records the first real Survival player crossing below Y −780. The control writes no block, entity, world generation, input, position, velocity, or damage state. The actual native void damage path is observed by the existing independent observer.

The run starts a fresh same-seed world and retains the reference configuration, including `macroWorldgen=false` and `netherBand=true`. It uses the same stock Advanced pack, initial placement, yaw and pitch, Survival transition and descend key. The launch port and scratch paths are separate. The external control records its own exact bytes and binds the exact reference manifest and qualification. Qualification requires normal native exits, an unmodified game JAR, native movement below the dimension and actual `minecraft:out_of_world`. The paired result tests the purpose of the specific recovery callback in a controlled world. The original video’s JAR, world save, route and seed remain unknown.

## Launch after allocating the native slot

```sh
flight_root=/tmp/s01-t02-natural-lower-flight-20261120
cd /workspace/ungravity-v5/ufo-body-physics
JAVA_HOME=/workspace/jdk21-complete GRADLE_USER_HOME=/workspace/.gradle \
  ./gradlew --offline --no-daemon --max-workers=1 \
  -I "$flight_root/recovery-control/observer.init.gradle" \
  -Ddrmd.lowerRecoveryControl.sourceDir="$flight_root/recovery-control" \
  remapLowerRecoveryControlJar
control=$(realpath build/libs/drmd-6dof-1.1.35-ufo-dev.1-lower-recovery-control.jar)
control_sha=$(sha256sum "$control" | cut -f1 -d' ')
case_path="$flight_root/historical-audit4-causal-no-recovery"
python3 "$flight_root/audit4-recovery-control.py" stage "$case_path" \
  --control "$control" --control-sha "$control_sha"
inputs_sha=$(sha256sum "$case_path/inputs.json" | cut -f1 -d' ')
python3 "$flight_root/audit4-recovery-control.py" run "$case_path" --inputs-sha "$inputs_sha"
```

The launcher uses the qualified reference memory profile of 1,056 MiB server and 768 MiB client. It requires 2,624 MiB effective cgroup headroom and 160 MiB of scratch. The only output intended for the assembly phase is the separate test control JAR. Production and earlier case files remain untouched. At source preparation time the standalone control has not been compiled or run.
