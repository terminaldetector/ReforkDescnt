#!/usr/bin/env python3
"""Validate an actual completed observer run against its exact closed donor receipt."""
from pathlib import Path
import json
import math
import sys

root = Path(sys.argv[1])
def load(name):
    return json.loads((root / name).read_text())

outcome = load('intact-asteroid-outcome.json')
mask = load('orbital-mask-observations.json')
inputs = load('inputs.json')
pair = mask.get('intactAsteroidFogPair', {})
geometry = mask.get('physicalFieldViews', [])
distance = pair.get('trueDistance', 0)
amounts = pair.get('minimumAndMaximumAmount', [])
density = pair.get('actualFogDensity', [])
range_ = pair.get('actualFogRange', [])
sky = pair.get('actualSkyTarget', [])
alpha = pair.get('actualFogAlpha', 0)
eye = pair.get('actualEye', [])
epochs = pair.get('epochs', [])
captures = root / 'orbital-mask-frames'

def valid_geometry(row):
    case = row.get('case')
    regions = row.get('regions', [])
    if case not in (0,1,2) or len(regions) != 1:
        return False
    region, = regions
    changed = region.get('changedPixels', -1)
    full = row.get('clientFullAabbCubes')
    return (full == (row.get('aabbCubes') if case == 0 else 0)
            and row.get('colourSemanticSameSourceAndMask') is True
            and region.get('depthUnchanged') is True
            and (changed == 0 if case == 0 else changed >= (4 if case == 1 else 1)))

def expected_amount(point):
    t = max(0., min(1., (point-range_[0])/(range_[1]-range_[0])))
    return t*t*(3-2*t)*alpha

def valid_pixel(pixel):
    if pixel.get('witness') is not True:
        return False
    raw = pixel['neutralAfter']
    hazy = pixel['enabledAfter']
    if not (pixel['coveringOpaqueAsteroidFaces'] > 0 and .999995 <= pixel['depth'] <= 1
            and raw != pixel['neutralBackground'] and hazy != pixel['enabledBackground']
            and max(abs(a-b) for a,b in zip(raw,hazy)) >= 4):
        return False
    for channel in range(3):
        target = sky[channel]*255
        limits = [raw[channel]+(target-raw[channel])*a for a in amounts]
        if not min(limits)-2 <= hazy[channel] <= max(limits)+2:
            return False
    return True

donor = inputs.get('reopenedWriterWorld',{})
checks = {
    'exactClosedDonor': donor.get('archiveSha256') == 'af24856d87490ec56c6bdf44334f947c5b72ea4bde36014f3b43b97e1368b75c',
    'realEnginePass': outcome.get('status') == 'PASS' and mask.get('failure') is None,
    'explicitFogMode': outcome.get('intactAsteroidFogMode') is True and outcome.get('asteroidFogPairObserved') is True,
    'originalGates': (outcome.get('verifiedOriginalCells') == 2304 and outcome.get('setupTeleports') == 3
                       and outcome.get('fixtureBlockWrites') == outcome.get('fixtureCatalogueWrites') == 0
                       and [r.get('stage') for r in outcome.get('rows', [])] == [0,1,2]
                       and mask.get('physicalFieldViewFrames') == [8,8,8,0]
                       and len(geometry) == 24 and all(valid_geometry(r) for r in geometry)),
    'sameActualDrawInputs': (pair.get('outcome') == 'PASS'
                             and pair.get('sameActualSourceFboPoseMatricesAndMasks') is True
                             and len(epochs) == 2 and epochs[0] < epochs[1]
                             and 2 <= pair.get('fogScans', 0) <= 8 and pair.get('fbo', 0) > 0
                             and 2048 < distance < 8192 and len(eye) == 3
                             and pair.get('sourceIdentity') is not None),
    'actualNeutralToEnabledFog': (len(density) == len(range_) == 2 and density[0] == 0 < density[1]
                                  and 0 <= range_[0] < distance < range_[1] and 0 < alpha <= 1
                                  and len(sky) == 3 and all(math.isfinite(v) for v in sky)
                                  and len(amounts) == 2 and 0 < amounts[0] <= amounts[1] <= 1
                                  and all(math.isclose(actual,expected_amount(point),abs_tol=1e-6)
                                          for actual,point in zip(amounts,(distance-12,distance+12)))),
    'depthPreservedAndAsteroidRgb': len(sky) == 3 and len(amounts) == 2
                                   and any(valid_pixel(p) for p in pair.get('pixels', [])),
    'readbackCap': 0 < mask.get('actualReadbackBytes', 0) <= 64*1024*1024,
    'completedFrames': all((captures / name).is_file() for name in [
        *(f'intact-asteroid-physical-view-{n}.png' for n in range(3)),
        'intact-asteroid-far-enabled-fog.png']),
}
result = {
    'status': 'PASS' if all(checks.values()) else 'NONPASS',
    'scope': 'Native original intact FAR asteroid, PS1 scene enable-vs-neutral fog colour pair',
    'checks': checks,
}
print(json.dumps(result, indent=2))
sys.exit(result['status'] != 'PASS')
