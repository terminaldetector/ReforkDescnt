# S03-T03 generated dungeon origin and deferred owner replay

Current native evidence already shows correct pending WorldChunk spawner to air
replacement at −512 and +2150, with unchanged neighboring spawners restored in
a second BCC process. This packet adds an independent, optional natural world
generation and adjacent typed-owner test. No shared source, Gradle or Minecraft
session was changed during preparation.

## Exact current negative first

The game baseline is the previously frozen fifth build, source
`97a4a70ddc10795ab2bdef1499b633363927cae3`, game SHA-256
`2e7172fe16ae8f4714de4e8d348b1854dec3224d9563f6eb2b8c86821c318800`.
Build only the observer in the scheduler's next combined Gradle invocation.
The supplied init script adds a separate source set and leaves the normal
cubiccheck and release trees in place.

```sh
./gradlew --offline -I /tmp/ungravity-spawner-origin-audit/observer.init.gradle \
  -Ddrmd.spawnerObserver.sourceDir=/tmp/ungravity-spawner-origin-audit/overlay \
  remapGeneratedSpawnerCheckJar
```

Freeze the resulting `build/libs/drmd-6dof-1.1.35-ufo-dev.1-spawner-origin.jar`
under a new exact artifact root with its SHA. It is intentionally separate
from the existing main JAR. CPU-verified plan is `current-negative-inputs.json`.
For a fresh run staging, set `probe` to that frozen remapped observer path:

```sh
probe=/tmp/EXACT-OBSERVER/drmd-6dof-1.1.35-ufo-dev.1-spawner-origin.jar
probe_sha=$(sha256sum "$probe" | cut -d ' ' -f 1)
run=/tmp/ungravity-spawner-origin-audit/generated-negative-97a4a70d/generated-spawner-probe
python3 /tmp/ungravity-spawner-origin-audit/stage_stock_probe.py "$run" \
  --mode write --seed 271026 --port 25871 \
  --game-jar /tmp/ungravity-remaining-round/fifth-build/jars/drmd-6dof-1.1.35-ufo-dev.1.jar \
  --game-sha 2e7172fe16ae8f4714de4e8d348b1854dec3224d9563f6eb2b8c86821c318800 \
  --source 97a4a70ddc10795ab2bdef1499b633363927cae3 \
  --probe-jar "$probe" --probe-sha "$probe_sha" --stage
cd "$run"
timeout --kill-after=15 300 bash command.txt </dev/null >process.log 2>&1
```

Measure the actual process exit separately, preserve the first log and
`generated-spawner-write-ready.json`. Only
`BASELINE_GENERATED_TYPED_SPAWNER_HYDRATED_AFTER_OWNER_CHANGED` with
a real `loadBlockEntity` row after SPAWNER changed to chest qualifies the
specific baseline negative. Readiness failure means natural dungeon controls
did not reach the ordinary loaded set on that run. A warning-free run or a
receipt without the required chain is insufficient.

The observer watches actual `DungeonFeature.generate` in `ChunkRegion`, the
valid origin `DUMMY` in the native ProtoChunk's pending map and the real
materialized MobSpawnerBlockEntity plus `SpawnData` on successful feature
return. No injection alters the generated terrain or supplies a replacement
NbtCompound. Later it waits for two distinct naturally generated spawners in
ordinary FULL stock columns. It repacks **only one** genuine configured owner,
on the server owner thread, then calls ordinary `setBlockState` to place a
chest. This deterministically exercises delivery of an otherwise valid typed
pending payload. It does not claim the test-controlled repack occurs naturally.
An independent generated spawner supplies the untouched control.

When the negative exists, `deferred-spawner-before-new-owner.patch` is the
narrow source candidate. Its MixinExtras WrapOperation intercepts
`BlockState.onStateReplaced` after the section commits and before native
`getBlockEntity(CHECK)` can consume the old typed payload. It calls the
original exactly once with original arguments. It removes only the valid
pending spawner type and coordinates, at an actual on-thread transition into a
different BE-owning block. Generic DUMMY and unrelated typed records keep their
native path. The existing non-BE return guard remains. MixinExtras WrapOperation
exists in Fabric Loader's bundled 0.4.1 (compile/development loader 0.16.14) and
0.5.5 (actual release loader 0.19.5). The optional cached compileOnly stanza is
separate and needed only if the local compile classpath lacks the already cached
artifact. Runtime remapping and mixin application still require confirmation.

Repeat a qualifying negative with a newly frozen fixed game SHA, the same
observer SHA and seed in a fresh runtime. Expected writer result is
`GENERATED_TYPED_REPLACEMENT_READY_FOR_SAVE`, old hydration count zero,
normal chest owner, and unchanged control. After successful full shutdown,
retain the original exact closed world then stage a fresh read runtime using
the same command with `--mode read --closed-writer /path/to/closed/writer/runtime`.
The cold observer performs zero fixture writes. It verifies the persisted new
chest, no old spawner pending ownership at that point, and the same immutable
SpawnData compound on the untouched naturally generated control. A positive
stock generated and cold receipt complements the separate signed native
replacement evidence. The BCC generator branch and historical writer identity
remain distinct until actually observed.

## Historical stock build, no invented user provenance

`/workspace/Gjnv/drmd-6dof-1.1.14-audit.4.jar` is byte-verified SHA
`9be0f587ad8af834e08f4c13aa348a9b10cf57c455e66ba6464aa962279a5414`.
It is an exact local version-labelled artifact, identified in v5 as
`user_tlauncher_binary=false`. Source candidate `12d875da` is the commit
introducing the version, explicitly cited as audit.4 by the terrain checkpoint.
Original user install hash and seed remain unknown. The supplied local BCC-free
headless pipeline pins exact 1.21.1 dedicated server bytes and Loader 0.19.5,
but uses available Fabric API 0.116.15 rather than historical log 0.116.17.
Its result is a replay stand for the local binary.

The CPU preflight `historical-stock-inputs.json` passed without an observer JAR
or Java launch. To stage later, omit the current game arguments, select
`--mode observe`, provide exact observer hash and stage a fresh runtime. The old
mode is STOCK/ADVANCED with all six historical switches. Confirm actual tall
pack plus normal original log mode at runtime. The historical mantle fill
originally required resident ordinary players. An idle dedicated process can
observe natural generation, but absence of a stale replacement while idle is
inconclusive for the old writer. For the writer replay, join locally and
traverse at the historical deep-flyer/admission depth. The observer performs no
fixture block writes in observe mode and records an exact raw incompatible
owner and writer stack only when encountered.

## CPU source findings

- Original affected sessions were STOCK/ADVANCED without BCC. At (334,−21,496)
  the save hydration exposed `minecraft:mob_spawner` under air. Its stack did
  not include the writer. The local old JAR registers LevelBuilder chunk-load
  and tick work, and its cached raw direct WorldChunk write is shown in
  `local-audit4-binary.txt`. It remains a candidate until an actual transition
  is captured.
- Vanilla DungeonFeature places the spawner through ChunkRegion, receives
  genuine pending DUMMY, materializes and configures it. ProtoChunk's native
  removeBlockEntity deletes both maps. Normal materialization itself leaves
  the deferred marker alongside the typed materialized owner, prioritizing the
  live owner for later retrieval. The current typed game fixture takes care to
  preserve that exact generated data rather than invent a stale pair.
- In pinned BCC 0.1.1, decoration uses `CubeGenResult.capture(..., false,...)`
  and its diff application drops pending ownership at BE→non-BE changes.
  Incoming BE payloads over non-BE targets are skipped. Bulk section Replace
  belongs primarily to NOISE/TERRAIN setup and bypasses per-cell lifecycle;
  its path was inspected without an actual overlap over an already-owned cell.
  A broad BCC writer patch lacks a demonstrated current trigger. Offsets and
  call chains are retained in `class-routes.txt`.
