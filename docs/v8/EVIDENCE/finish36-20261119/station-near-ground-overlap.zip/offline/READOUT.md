# First station NEAR failure: exact limits of attribution

The first actual `/tmp/ungravity-finish-36/intact-station-ps1-first` remains FAIL. It verified7680 original cells, six FULL station AABB cubes and eight actual NEAR_FULL_ZERO_PROXY GPU-mask observations. It then failed the WHOLE Horizon before/after RGB pair. The failing code threw before appending the region row: the actual offending opaque/window name, changed count and before/after bytes were not retained. They cannot be reconstructed from the later overall screenshot. No claim is made that this was an authored station-proxy or native-depth defect.

The actual retained screenshot already shows a broad grey plane in the station opening. Read-only closed-source facts: all six station L0 SurfaceStore columns have height1423/colour0xa7a7a7 above eye1417.62. `SurfaceIngest.onChunkLoad` picks WORLD_SURFACE max over256positions without orbital exclusion; `PlanetSurfaceMesh` consumes that observed top in a separate untagged ground heightfield. Authored orbital opacity0 does not suppress that independent ground layer. `saved-surface-source.json` proves persisted values, not the exact lost per-frame ground quad.

## Stronger separate observer patch

`stronger-sensor-receipt.patch` changes ONLY `NativeOrbitalMaskCheck`. It leaves production, camera, opaque target, scene640×360, source/colour/semantic requirements, eight-frame counts, pixel/depth thresholds, deadlines and GPU readback cap unchanged.

For the NEW intactStation case only, window sampling moves to the real upper-front opening: centre+(.5,5.5,-8.5). The same camera still sees the same opaque control. CPU ray tests of all940actual authored iron voxels give opaque25/25 and upper-window0/25 at both FOV70 and ordinary Creative77. All25new window rays point upwards (minimum normalized worldY≈+.244 at77), physically excluding ordinary earth/cloud layers below the eye. The runtime requires that actual inverse-projection/view property before admitting a frame. Old mission-station and asteroid sensors are unchanged. This is a new, explicitly unrun sensor contract; it does not reclassify the old failed window.

On the first RGB OR depth failure, the observer now reads both original regions before any throw and preserves: exact named rectangles, counts, before/after RGBA bytes and float depths, view/projection, source identity/origin/quads, verified actual authored-mask values and live client L0 samples. Output `orbital-first-pixel-failure.json` identifies whether opaque, window or both changed, without inferring which primitive drew. No additional GPU copies/queries or unbounded reads are introduced; both regions already belonged to the original bounded pair.

## Ingest correction: compact blocker/handoff

A safe ordinary-ground ingest filter must use the persisted catalogue's exact XYZ extents, including invalidated original objects, filtered by actual dimension/seed. Filtering only `visible()` is wrong after damage: invalidating a proxy must not turn its roof into ground. No global height cutoff, store reset or tile deletion is justified.

Skipping excluded WORLD_SURFACE winners alone is insufficient. Under the SAME actual saved station columns there are no saved native CY3/4/5 sections, whereas CY79/80/87/88 are present (`actual-saved-column-ranges.json`). Saved presence is not runtimeFULL, but it establishes that this donor does not contain an independently preserved ordinary low-ground witness to fall back to. A loaded-only descent must stop at the first unknown cube; placeholder AIR cannot be treated as an empty column down to the planet. `sampleHeightmap` stores only the current maximum, not a second layer below the roof. A fully covered tile can therefore have no reliable replacement ground sample.

Do not replace such a tile with procedural height labelled observed, bottomY, AIR, or an invented lower colour. Preserve any known eligible prior ordinary-ground value; queue loaded-only resampling through the existing budget. Legacy contaminated fine/coarse cells need an explicit eligibility/quarantine view or corrected real fine commits followed by normal parent rebuilds. Blindly retaining the old contaminated roof keeps the ghost; blindly clearing cache files loses history. Resolving that distinction safely requires a separate agreed metadata policy, not a fabricated fallback method. No incomplete production patch was added here.

The stronger upper-sky test may still expose the observed roof-derived heightfield above the lens. That would be an actual attributable next result, captured with the new exact masks/L0/region receipt. It must remain FAIL if it occurs. FAR station subpixel risk is independent and remains in the preceding station packet.

Root may compile/apply the one observer patch, then reuse the SAME closed-donor station runner with a FRESH case name. Native launch remains unexecuted here. No JVM or canonical files were changed.
