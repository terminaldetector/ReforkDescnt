# Scoped S11-T04 / S16-T02 read-only audit — 19 November 2026

No JVM/Gradle/native launch, gameplay edits or ledger changes were performed. `receipt.json` binds the original files and independently checks selected source parity. Its `collect.py` is CPU-only and reads existing outputs.

The five actual native capacity runs all exit0 on source `df1c5fe9d1c5ee50ec51d8f472491dc034d41500`, game `2e459208c089c2dd582a2b404124797b2bf1894ea1cf6840bcefeec132a98f38`, observer `6c6fde59a3b3df55d90ca8ec6876366ec8bb35b277f56efdced439b3d955e250`. Every requested entity was alive, active, moving, indexed and client-synced; all three independently registered ORB/ROCKET/JET types actually rendered and shot. Cleanup remaining0 and no measurement-time full-world index scans. This is a controlled native workload, not Survival acceptance.

| Count | Unique rendered | Actual shots | Server p95 ms | Observed TPS | Frame p95 ms |
|---:|---:|---:|---:|---:|---:|
|32|24|268|75.1396|19.569|82.3684|
|128|103|1827|143.0409|11.388|140.3430|
|256|222|3796|274.3697|8.000|171.9318|
|512|451|8378|317.0582|5.351|204.2798|
|1024|915|18754|498.7516|3.106|203.4383|

These are measured degradation, not a stable20TPS performance pass. Server spans are actual ordinary-tick event spans; raw frame intervals and sampled used Java heap are retained. `-Xmx2G` is the heap limit. `loadedCubeWindow` measures at most567 queried cells near the swarm, not the world's total loaded cubes. GPU execution uses Mesa software rendering; no Intel/physical-hardware benchmark is inferred.

Every five-level raw result truthfully reports drawCalls=null. Separately, the marked32 run on source `26bdf5f214a394be5a6c56473ae5392239711dc6`, game `f69d14554d669c0bfafb73ce38c00dd755617f1909d57d33edf9d385f648695d`, observer `223e9f85a6007458882baf14f46053d2f7b7cf205d713bff3a72009ed1c49150`, exits0. Its actual23,931,837-byte apitrace `twentysecond/swarm-traces/32.trace` hashes to `71b870225389822ae81b4276ea9fe6fb8fc0a9774b4e8329e28eb541108ea002`; its34 marked completed frames have11–20 GL API draw submissions, median14. A multi/indirect invocation counts as one submission. These values cannot populate the other four missing draw-call rows.

## Source versus actual LOD proof

`DroneFlightDetail` explicitly selects FULL/NEAR/REMOTE planning (1/4/16-tick decision spacing), with target/combat/support/wake safeguards. `mayCoast` requires live loaded-route clearance; physical motion, collision and unknown refusal remain active every ordinary tick. `FlightEnemyRenderer` selects real coarse-detail geometry beyond56m. This is planning/render detail LOD; it does not implement dormant entity physics or aggregated combat.

The five near capacity cases record coastingUpdates=0. Two separate genuine STOCK cases prove remote physical coasting followed by a real Survival target40m above, and an actual shield-absorbed projectile waking planning. Their actual XML is SHA `5d19bb73d42abf44c651f8fedcb515b5832da3cd2f701fcba0350e4a458655c0`; both cases have no failure/error/skipped. IMPORTANT: that mixed whole process exited3 due to other cases; only these two cases pass. Source `c3c1ab6597963cc17977e3e8033f24d223ecb4ed` has byte-identical DroneFlightDetail, DroneAi, FlightEnemyRenderer and interest-test sources to the capacity producer. This is selected source parity, not whole-JAR identity.

## Defensible decision

- **S11-T04:** substantial new scaling/profiler proof exists; it must not be described as absent. Strict clause remains partial: no capacity stress exercising explicit far/reduced/dormant physics tiers or native tier-transition acceptance. `GravityClusterInterest` field-discovery sleeping cadence is a different subsystem and cannot fill that gap. Keeping full physical ticks is a concrete safe policy, but cannot be relabelled reduced/dormant physics.
- **S16-T02:** most actual measurements now exist at all five levels; preserve them. Full title remains open for actual draw submissions at128/256/512/1024 and a clearly scoped cube-count interpretation. The existing raw nulls remain truthful; no inferred draw counts or throughput claims. FPS may be derived explicitly from the sampled raw frame intervals, with that algorithm and coverage stated.

Smallest remaining work: run the existing immutable marked-trace path at the four missing counts, and separately measure a bounded native far-interest/near wake transition at capacity with actual planning/physics/render tier counters. No repeated five-level uninstrumented capacity run is needed.
