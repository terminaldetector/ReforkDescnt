# Native climber field entry — negative, correction and floor admission

Test-only source `875f2b1c2fef6a418e20493379adb8c11cd0f042`, based on fish-integrated canonical `bd738926`, runs two dedicated C2 cases. Compilation succeeds. Fresh XML is timestamped `2026-11-17T12:40:44.209742165Z`: **one failure, one pass**, zero errors, Gradle exit1 in49seconds. No production classifier or geometry changes precede this negative checkpoint.

## Actual first-entry failure

A real ordinary-floor Spider field-entry control passes first: feet remain at Y18.02, the UP floor support is present, body space is clear, native controllers and the original NoGravity flag survive. Only then is the separate airborne centre entry measured.

On the first Spider/EAST field pass, position X changes from `-5297759.5` to `-5297757.02`: a **2.48-block jump** to the standing surface. Velocity changes from `(0.17,0.03,-0.04)` to zero and onGround changes from false to true. The same registered entity UUID, native SpiderNavigation/MoveControl objects and saved NoGravity=false remain. Actual position, collision box, eye, velocity and control identities are captured before/after in the raw log. This fails the actual position assertion, not an absent-classifier or desired-orientation assertion.

`ActorFrames.supported=false` and local-up zero are diagnostic fields only. The failing case stops at its first Spider/EAST sample, before CaveSpider, other axes and the external NoGravity=true pass. No result for those unreached checks is inferred.

## Independent ordinary-floor AI admission

The other case passes for both species in an opaque room. Actual eye SKY/BLOCK light is0/0. No shared world time/weather is modified. Each Cow target is assigned once explicitly; this is not a claim that vanilla spiders naturally choose cows instead of their player/golem targets. Normal AI stays enabled, real navigator activity and retained target are observed, with no manual entity tick or repeated navigation/velocity commands.

| Species | Observed ordinary entity ticks | Distance improvement, blocks | Maximum observed step, blocks |
| --- | --- | --- | --- |
| Spider | 65 | 3.805982724 | 0.645784880 |
| CaveSpider | 60 | 3.903090031 | 0.645150588 |

The frozen admission thresholds are at least60 ordinary ticks, at least1block improvement and no step over1block. Spider is measured at65ticks because the shared case waits for CaveSpider to reach60; this is not an identical first60-tick-window comparison. Both native controllers remain the original instances. Bounded fixture-only forced columns are restored; actual FULL cubes are required before block writes. Ordinary-floor admission permits future wall/ceiling tests; it does not establish their behavior.

## Entry-only correction proposal

The current unsupported branch enters `GravityMount.safeMount`, which requests a position change and clears velocity. Existing `ActorFrames.trySetUp` offers an in-place, server-owned admission path: it tests FULL occupied/neighbour volumes and free actual geometry before changing the tracker. Its body uses the entity's actual width/standing height; recorded Spider dimensions are approximately1.4×0.9 and CaveSpider0.7×0.5. WORLD_UP matches their ordinary vanilla boxes and native eye heights remain species-derived.

Production correction `8918ca1765357563d598a8c3e430f90dbe217832` adds one explicit `SpiderEntity` branch in `ActorFrames.supported`, covering native Spider and its CaveSpider subclass. It uses the existing in-place checked frame adapter. It does not classify climbers as flying/force-only, rewrite native navigation or climbing flags, or alter shape/eyes/force/NoGravity/AI implementations. No production correction is included in the immutable negative archive. Wall/ceiling pursuit and native field/render orientation require their own evidence.

## Scoped positive on unchanged tests

On exact production source `8918ca1`, compilation and both focused GameTests pass: zero failures/errors, Gradle exit0 in46seconds, fresh XML `2026-11-17T12:50:11.491159663Z`. Test source, actual executing helper and source-manifest hashes match the first negative.

The entry case now completes24 independent samples: Spider/CaveSpider × six axes × both externally owned NoGravity values. Maximum observed entry position change is exactly0.0. Four ordinary-floor field-entry controls remain valid. The no-fake-contact, retained tangential propulsion, native controller/flag ownership and safe release checks all pass. Bounds/eyes/local-up are still diagnostic snapshots rather than full geometry or renderer acceptance.

The independent ordinary-floor AI admission also passes again, with the same dark-room, one-target-assignment and no-manual-tick conditions:

| Species | Observed ordinary entity ticks | Distance improvement, blocks | Maximum observed step, blocks |
| --- | --- | --- | --- |
| Spider | 60 | 3.538968661 | 0.645156196 |
| CaveSpider | 60 | 3.704152737 | 0.646862297 |

Actual eye SKY/BLOCK light remains0/0, the assigned Cow is retained and the native navigator is observed active. This establishes ordinary-floor admission and entry ownership only. Here native means the unchanged vanilla mob/controller running on stock Fabric GameTests; no BCC client or rendered field-orientation verification was performed. Layer2 real wall-vertical/ceiling-tangent pursuit remains untested, and no prior combined full-suite result is inherited by this correction.

## Preservation

[climber-entry-875f2b1-negative.zip](EVIDENCE/climber-entry-875f2b1-negative.zip) retains exact source/patch, the actual executing init and input hashes, original raw log/XML/exit/freshness records, parsed real-state markers, compiled tested classes and the complete closed disposable save. No installable JAR is generated by this command. CRC and every manifest SHA-256 are verified before removing only the archived closed test world. Completed fish/ragdoll checkpoints remain unchanged. Work remains local; wider C2/C1–C7, wall/ceiling navigation, native rendering and combined-suite acceptance stay open.

[climber-entry-8918ca1-positive.zip](EVIDENCE/climber-entry-8918ca1-positive.zip) retains the original positive log/XML/exits/input identities, all30 captured state markers, exact one-line source patch and before/after adapter source, unchanged test/helper/compiled test classes and the complete closed positive world. All CRC and per-file hashes are checked before removing only that archived disposable world. The original negative remains immutable; no installable JAR/release is certified by this focused gate.
