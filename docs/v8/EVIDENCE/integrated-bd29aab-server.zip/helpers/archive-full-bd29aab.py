from pathlib import Path
import hashlib,json,tarfile,xml.etree.ElementTree as ET,zipfile
root=Path.cwd();full=root/'work/multi-agent/integrated-bd29aab';source='bd29aab11f6fcba71f5234b64616d2284bf0aec8'
out=root/'docs/v8/EVIDENCE/integrated-bd29aab-server.zip';assert not out.exists()
sha=lambda b:hashlib.sha256(b).hexdigest();stamp=json.loads((full/'verified-build.json').read_text());assert stamp['sourceSha']==source
counts=json.loads((full/'counts.json').read_text());assert counts=={'unit':dict(tests=803,failures=0,errors=0,skipped=0),'game':dict(tests=406,failures=0,errors=0,skipped=0)}
with tarfile.open(full/'unit-results.tar.gz') as t:cases=[c for m in t.getmembers() if m.name.endswith('.xml') for c in ET.fromstring(t.extractfile(m).read()).iter('testcase')]
assert len(cases)==803 and all(c.find('failure') is None and c.find('error') is None and c.find('skipped') is None for c in cases)
cases=list(ET.parse(full/'full-game-results.xml').getroot().iter('testcase'));assert len(cases)==406 and all(c.find('failure') is None and c.find('error') is None and c.find('skipped') is None for c in cases)
assert len(json.loads((full/'processed-full-manifest.json').read_text())['entrypoints']['fabric-gametest'])==64
for p,h in stamp['jars'].items():
    assert sha(Path(p).read_bytes())==h
    with zipfile.ZipFile(p) as z:assert z.testzip() is None
fresh=json.loads((full/'report-freshness.json').read_text());assert fresh['gameReportExists'] and fresh['gameReportMtimeNs']>=fresh['startNs']
payload={'full/'+p.name:p.read_bytes() for p in full.iterdir() if p.is_file()}
payload['helpers/'+Path(__file__).name]=Path(__file__).read_bytes()
summary=dict(source=source,unit=counts['unit'],game=counts['game'],entrypoints=64,jars=stamp['jars'],gameReportFresh=True,
    scope='Actual complete ordinary server suite and remapped artifacts. TestServer enables discoverable legacy Advanced registry pack; this does not establish default Vanilla bounds. Dedicated surface Vanilla2 and legacy tall8 remain separate. No native/performance/full specification/release acceptance inherited.',releaseAccepted=False)
payload['SUMMARY.json']=(json.dumps(summary,indent=2)+'\n').encode();manifest={n:sha(b) for n,b in sorted(payload.items())}
with zipfile.ZipFile(out,'x',zipfile.ZIP_DEFLATED) as z:
    for n,b in sorted(payload.items()):z.writestr(n,b)
    z.writestr('MANIFEST.json',json.dumps({'source':source,'files':manifest},indent=2)+'\n')
with zipfile.ZipFile(out) as z:
    assert z.testzip() is None
    for n,h in manifest.items():assert sha(z.read(n))==h
r=dict(archive=str(out.relative_to(root)),sha256=sha(out.read_bytes()),payloadFiles=len(payload),bytes=out.stat().st_size,allHashesAndCrcVerified=True,**summary)
Path('docs/v8/EVIDENCE/integrated-bd29aab-server.json').write_text(json.dumps(r,indent=2)+'\n');print({k:r[k] for k in ('archive','sha256','bytes','payloadFiles')})
