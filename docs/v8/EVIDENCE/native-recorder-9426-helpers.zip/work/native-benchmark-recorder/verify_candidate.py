"""Local command-plan helper. Java is launched only by separately leased shell scripts."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import zipfile

ROOT=Path('/workspace/ungravity-v5/audit-next-20261109')
CANON=Path('/workspace/ungravity-v5/ufo-body-physics')
SOURCE='9426a6549fc91abc8c7e060a2eef9f184742dc3d'
GAME_SHA='cf3701b529b21633a8a3e910e6755d006d97d6349e8938d7701c82671027138d'
NAME='drmd-6dof-1.1.35-ufo-dev.1'
OUT=ROOT/'work/native-benchmark-recorder/lease-9426'
sys.path.insert(0,str(ROOT/'scripts/v8'))
from audit_task_evidence import Repository
from collect_benchmark_context import collect,observations


def write(path,value):
    with path.open('x') as stream:json.dump(value,stream,indent=2);stream.write('\n')


def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda:stream.read(1024*1024),b''):h.update(block)
    return h.hexdigest()


def frozen():
    r=Repository(ROOT)
    assert r.git('rev-parse','HEAD').decode().strip()==SOURCE,'frozen source changed'
    assert not r.git('diff','--name-only','HEAD'),'tracked source changed'
    expected=r.source_inputs(SOURCE)
    actual={str(p.relative_to(ROOT)):sha(p) for p in [*(ROOT/'src').rglob('*'),ROOT/'build.gradle',ROOT/'settings.gradle',ROOT/'gradle.properties'] if p.is_file()}
    assert expected==actual,'working build inputs differ from frozen source'
    return actual


def build_before():
    assert os.environ.get('S16_JAVA_LEASE')=='granted','root Java lease not granted'
    assert shutil.disk_usage(ROOT).free>=192*1024*1024,'need >=192 MiB free before private build/staging; do not delete proof'
    inputs=frozen();OUT.mkdir(parents=True,exist_ok=False)
    write(OUT/'build-inputs-before.json',inputs)


def record():
    inputs=frozen();assert inputs==json.loads((OUT/'build-inputs-before.json').read_text())
    jars={}
    for suffix in ('','-cubiccheck'):
        p=ROOT/'build/libs'/(NAME+suffix+'.jar')
        with zipfile.ZipFile(p) as z:assert z.testzip() is None
        jars[str(p.relative_to(ROOT))]=sha(p)
    assert jars['build/libs/'+NAME+'.jar']==GAME_SHA,'main JAR differs from retained583 game; do not borrow its test results'
    write(OUT/'verified-build.json',dict(source=SOURCE,inputs=inputs,jars=jars))


def checked_stamp():
    saved=json.loads((OUT/'verified-build.json').read_text());assert saved['inputs']==frozen()
    for name,expected in saved['jars'].items():assert sha(ROOT/name)==expected,(name,'artifact changed')
    return saved


def runtime(case):return ROOT/'build/native-benchmark-9426'/case/'cubic-client-automation'


def stage(case):
    assert os.environ.get('S16_JAVA_LEASE')=='granted','root lease not granted'
    saved=checked_stamp();target=runtime(case);assert not target.exists()
    assert shutil.disk_usage(ROOT).free>=48*1024*1024,'need >=48 MiB for one fresh copied runtime and logs'
    args=['python3',str(CANON/'work/ufo-body/native/prepare-with-verified-library-links.py'),
        '--server-runtime','/workspace/ungravity-v5/world/build/cubic-seed2-gate','--runtime',str(target),
        '--drmd',str(ROOT/'build/libs'/(NAME+'.jar')),'--gate',str(ROOT/'build/libs'/(NAME+'-cubiccheck.jar')),
        '--bcc','/workspace/Refork-audit/work/master-v5/upstream/bettercubicchunks-fabric-0.1.1+mc1.21.1.jar',
        '--api','/workspace/.gradle/caches/modules-2/files-2.1/net.fabricmc.fabric-api/fabric-api/0.116.15+1.21.1/d25c793833a90cc028c9a61bc4546cd578a70ce1/fabric-api-0.116.15+1.21.1.jar',
        '--sodium','/workspace/ungravity-v5/world/work/gate0/upstream/sodium-fabric-0.8.13+mc1.21.1.jar',
        '--java','/workspace/jdk21-complete/bin/java','--copy-test-world']
    with (OUT/(case+'-prepare.log')).open('x') as log:subprocess.run(args,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,check=True)
    donor=CANON/'build/cubic-client-final-flight-body-current-phase-sodium'
    inputs=json.loads((target/'inputs.json').read_text());prior=json.loads((donor/'inputs.json').read_text())
    official='libraries/com/mojang/minecraft/1.21.1/minecraft-1.21.1-client.jar'
    assert next(a['sha256'] for a in inputs['artifacts'] if a['path']==official)==next(a['sha256'] for a in prior['artifacts'] if a['path']==official)
    cache=Path('.fabric/remappedJars/minecraft-1.21.1-0.19.5/client-intermediary.jar')
    with zipfile.ZipFile(donor/cache) as z:
        assert z.testzip() is None
        assert not any(n.startswith('com/terminaldetector/') for n in z.namelist())
    (target/cache).parent.mkdir(parents=True,exist_ok=True);os.link(donor/cache,target/cache)
    launch=json.loads((target/'launch.json').read_text())
    flags=['-Ddrmd.gate.mountedMechanisms=true']
    if case!='disabled':
        flags += ['-Ddrmd.gate.benchmark=true','-Ddrmd.benchmark.mode=sidecar',
            '-Ddrmd.benchmark.runId=9426-'+case,'-Ddrmd.benchmark.scenario=instrumentation-smoke-mounted-'+case,
            '-Ddrmd.benchmark.warmupSeconds=1','-Ddrmd.benchmark.sampleSeconds='+('30' if case=='capacity' else '1'),
            '-Ddrmd.benchmark.maxSamples='+('16' if case=='capacity' else '65536')]
    launch[1:1]=flags
    (target/'launch.json').write_text(json.dumps(launch,indent=2)+'\n')
    inputs.update(sourceSha=SOURCE,uncommittedDiff='',scenario=case,candidateJars=saved['jars'],
        derivedMinecraftCache=dict(path=str(donor/cache),sha256=sha(donor/cache),scope='Closed Minecraft/Fabric derivative only; no application code/save/marker copied'))
    (target/'inputs.json').write_text(json.dumps(inputs,indent=2)+'\n')
    write(OUT/(case+'-staged.json'),dict(runtime=str(target),flags=flags,source=SOURCE,game_sha256=GAME_SHA,observer_sha256=saved['jars']['build/libs/'+NAME+'-cubiccheck.jar']))


def verify(case):
    checked_stamp();target=runtime(case)
    assert (OUT/(case+'-native.exit')).read_text().strip()=='0','native process failed/timed out; keep first log'
    assert not list((target/'crash-reports').glob('*')),'crash report exists'
    assert (target/'mounted-mechanisms-ok.json').is_file(),'existing sidecar gate did not complete'
    marker=json.loads((target/'mounted-mechanisms-ok.json').read_text())
    assert marker['frames']==['connected-off','laser-fire','rocket-fire','fire-off-reversed','bearing-detached']
    assert marker['actualUseAndSneakKeys'] and not marker['operatorFollowTeleport'] and not marker['fixtureSuppliedJointOrShots']
    assert len(list((target/'mounted-mechanism-frames').glob('*.png')))==5
    outputs=list((target/'benchmark-observations').glob('*.json'))
    if case=='disabled':
        assert not outputs,'disabled recorder wrote observations'
        assert 'BENCHMARK_RECORDER armed' not in (OUT/(case+'-native.log')).read_text(errors='replace')
        print('Disabled control: gate finished; no recorder output/armed log. Not a memory benchmark.');return
    assert len(outputs)==1,outputs
    parsed,_=observations(outputs[0]);raw=json.loads(outputs[0].read_text())
    wanted='truncated_sample_capacity' if case=='capacity' else 'target_window_complete'
    assert 'capture_status='+wanted in raw['known_issues'],raw['known_issues']
    assert parsed['window']['value'] is not None
    for name in ('frame_time_ms','server_tick_ms','heap_used_bytes'):
        values=raw['samples'][name]['values'];assert isinstance(values,list) and len(values)>=1,name
        assert parsed['metrics'][name]['value']['samples']==len(values)
        if case=='capacity':assert len(values)<=16,name
    for name in ('seed','runtime_source_sha','runtime_game_sha256','cubes_loaded','draw_calls','requested_entities'):
        assert parsed['context'][name]['value'] is None and parsed['context'][name]['reason'],name
    for name in ('gpu_frame_ms','cubes_loaded','draw_calls','mesh_queue'):
        assert parsed['metrics'][name]['value'] is None and parsed['metrics'][name]['reason'],name
    assert parsed['context']['gpu_hardware']['value']=='software','software-renderer smoke expected; not Intel benchmark'
    result=collect(ROOT,SOURCE,ROOT/'build/libs'/(NAME+'.jar'),target/'mods',outputs[0],OUT/'verified-build.json')
    assert not result['performance_accepted'] and not result['release_accepted']
    write(OUT/(case+'-context.json'),result)
    print('Actual observations/receipt validation complete; raw timing only, no performance threshold/acceptance.')


if __name__=='__main__':
    os.chdir(ROOT);command=sys.argv[1]
    if command=='before':build_before()
    elif command=='record':record()
    elif command=='check':checked_stamp()
    elif command in ('stage','verify'):
        assert sys.argv[2] in ('enabled','disabled','capacity')
        (stage if command=='stage' else verify)(sys.argv[2])
    else:raise SystemExit('unsupported plan command')
