"""Synthetic Python child processes only; these are not native/game evidence."""
import io
import json
import os
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch
import immutable_native_runner as runner


class ExitReceipts(unittest.TestCase):
    def test_nonzero_child_receipt_exists_before_postcheck(self):
        with tempfile.TemporaryDirectory() as directory:
            p=Path(directory)
            with patch('sys.stdout',new_callable=io.StringIO):
                result=runner.wait_and_record([sys.executable,'-c','raise SystemExit(7)'],p,os.environ.copy(),p,5)
            self.assertEqual(result['returncode'],7)
            self.assertEqual(json.loads((p/'child-exit.json').read_text())['returncode'],7)
            self.assertFalse(result['timed_out'])

    def test_timeout_cannot_look_like_normal_exit(self):
        with tempfile.TemporaryDirectory() as directory:
            p=Path(directory)
            with patch('sys.stdout',new_callable=io.StringIO):
                result=runner.wait_and_record([sys.executable,'-c','import time;time.sleep(10)'],p,os.environ.copy(),p,.1)
            self.assertTrue(result['timed_out']);self.assertNotEqual(result['returncode'],0)
            self.assertTrue((p/'child-exit.json').is_file())

    def test_broken_wrapper_stdout_cannot_lose_child_exit_receipt(self):
        class BrokenOutput:
            def write(self,_):raise BrokenPipeError()
        with tempfile.TemporaryDirectory() as directory:
            p=Path(directory)
            with patch('sys.stdout',BrokenOutput()):
                result=runner.wait_and_record([sys.executable,'-c','raise SystemExit(0)'],p,os.environ.copy(),p,5)
            self.assertEqual(result['returncode'],0)
            self.assertEqual(json.loads((p/'child-exit.json').read_text())['returncode'],0)

    def test_preparation_snapshots_real_input_bytes_without_running_child(self):
        with tempfile.TemporaryDirectory() as directory:
            p=Path(directory);runtime=p/'runtime';runtime.mkdir();launch=runtime/'launch.json'
            launch.write_text(json.dumps(['never-execute','-Ddrmd.gate.mountedMechanisms=true','-Ddrmd.gate.benchmark=true','-Ddrmd.benchmark.mode=sidecar',
                '-Ddrmd.benchmark.warmupSeconds=1','-Ddrmd.benchmark.sampleSeconds=1','--gameDir',str(runtime)]))
            with patch('sys.stdout',new_callable=io.StringIO):runner.snapshot(launch,p/'run')
            m=json.loads((p/'run/manifest.json').read_text())
            self.assertEqual(m['runner_sha256'],runner.digest(p/'run/runner.snapshot.py'))
            self.assertEqual(m['launch_sha256'],runner.digest(launch))
            self.assertFalse((p/'run/native.log').exists())


if __name__=='__main__':unittest.main()
