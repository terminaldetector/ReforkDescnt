"""One fresh9426 enabled retry; preparation and execution require a separate root lease."""
import hashlib
import json
import os
from pathlib import Path
import sys

import verify_candidate as prior
import immutable_native_runner as runner

ROOT=prior.ROOT
STAGE=ROOT/'work/native-benchmark-recorder/retry-9426-enabled1-stage'
RUN=ROOT/'work/native-benchmark-recorder/retry-9426-enabled1'
RUNTIME=ROOT/'build/native-benchmark-9426/enabled-retry1/cubic-client-automation'
RUN_ID='9426-enabled-retry1'


def configure():
    prior.OUT=STAGE
    prior.runtime=lambda _:RUNTIME


def prepare():
    assert os.environ.get('S16_JAVA_LEASE')=='granted','no Java/native retry lease'
    prior.checked_stamp() # first build/source/JARs must still match; no rebuild or source edit
    assert not STAGE.exists() and not RUN.exists() and not RUNTIME.exists(),'fresh unique retry required'
    STAGE.mkdir()
    with (STAGE/'verified-build.json').open('xb') as stream:
        stream.write((prior.OUT/'verified-build.json').read_bytes())
    configure();prior.stage('enabled')
    path=RUNTIME/'launch.json';args=json.loads(path.read_text())
    args=[('-Ddrmd.benchmark.runId='+RUN_ID if a.startswith('-Ddrmd.benchmark.runId=') else
           '-Ddrmd.benchmark.scenario=instrumentation-smoke-mounted-enabled-retry1' if a.startswith('-Ddrmd.benchmark.scenario=') else a) for a in args]
    path.write_text(json.dumps(args,indent=2)+'\n')
    (STAGE/'enabled-staged.json').rename(STAGE/'initial-generic-staging.json')
    inputs_path=RUNTIME/'inputs.json';inputs=json.loads(inputs_path.read_text())
    inputs['scenario']='instrumentation-smoke-mounted-enabled-retry1';inputs['runId']=RUN_ID
    inputs_path.write_text(json.dumps(inputs,indent=2)+'\n')
    runner.snapshot(path,RUN)
    runner.write_new(STAGE/'retry-preparation.json',dict(source=prior.SOURCE,run_id=RUN_ID,
        runner_preparation_sha256=runner.digest(Path(runner.__file__)),retry_control_sha256=runner.digest(Path(__file__)),
        runtime=str(RUNTIME),flags=[a for a in args if a.startswith('-Ddrmd.')],
        scope='Fresh copied runtime; original9426 build receipt reused explicitly; no Java launched by preparation'))


def verify():
    configure();prior.checked_stamp()
    receipt=json.loads((RUN/'child-exit.json').read_text())
    assert receipt['returncode']==0 and not receipt['timed_out'] and not receipt['forced_kill'],'native exit was not clean'
    before=json.loads((RUN/'execution-inputs-before.json').read_text());after=json.loads((RUN/'execution-inputs-after.json').read_text())
    assert before==after,'execution inputs changed'
    manifest=json.loads((RUN/'manifest.json').read_text())
    assert runner.digest(RUN/'runner.snapshot.py')==manifest['runner_sha256']
    assert runner.digest(RUN/'launch.snapshot.json')==manifest['launch_sha256']
    assert not list((RUNTIME/'crash-reports').glob('*')),'crash reports present'
    marker=json.loads((RUNTIME/'mounted-mechanisms-ok.json').read_text())
    assert marker['frames']==['connected-off','laser-fire','rocket-fire','fire-off-reversed','bearing-detached']
    assert marker['actualUseAndSneakKeys'] and not marker['operatorFollowTeleport'] and not marker['fixtureSuppliedJointOrShots']
    assert len(list((RUNTIME/'mounted-mechanism-frames').glob('*.png')))==5
    raw_path=RUNTIME/'benchmark-observations'/('benchmark-'+RUN_ID+'.json')
    raw=json.loads(raw_path.read_text());parsed,_=prior.observations(raw_path)
    assert raw['run_id']==RUN_ID and 'capture_status=target_window_complete' in raw['known_issues'],raw['known_issues']
    for field in ('frame_time_ms','server_tick_ms','heap_used_bytes'):
        assert parsed['metrics'][field]['value']['samples']>=1,field
    for field in ('seed','runtime_source_sha','runtime_game_sha256','requested_entities','active_entities','cubes_loaded','draw_calls'):
        assert parsed['context'][field]['value'] is None and parsed['context'][field]['reason'],field
    assert parsed['context']['gpu_hardware']['value']=='software'
    context=prior.collect(ROOT,prior.SOURCE,ROOT/'build/libs'/(prior.NAME+'.jar'),RUNTIME/'mods',raw_path,STAGE/'verified-build.json')
    assert not context['performance_accepted'] and not context['release_accepted']
    runner.write_new(RUN/'verified-context.json',context)
    runner.write_new(RUN/'outcome.json',dict(source=prior.SOURCE,run_id=RUN_ID,clean_exit_and_instrumentation='PASS',
        raw_sha256=runner.digest(raw_path),sample_counts={n:parsed['metrics'][n]['value']['samples'] for n in ['frame_time_ms','server_tick_ms','heap_used_bytes']},
        performance_accepted=False,release_accepted=False,disabled_control_run=False,capacity_control_run=False))
    print('Clean enabled instrumentation smoke verified; no performance/release acceptance.')


if __name__=='__main__':
    os.chdir(ROOT)
    if sys.argv[1]=='prepare':prepare()
    elif sys.argv[1]=='verify':verify()
    else:raise SystemExit('unsupported retry command')
