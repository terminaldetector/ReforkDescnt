"""Prepare a readonly execution snapshot; execute only under a separately granted Java lease."""
import argparse
from datetime import datetime,timezone
import hashlib
import json
import os
from pathlib import Path
import select
import signal
import subprocess
import sys


def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()


def write_new(path,value):
    with path.open('x') as stream:json.dump(value,stream,indent=2);stream.write('\n');stream.flush();os.fsync(stream.fileno())


def wait_and_record(args,cwd,env,out,timeout):
    """The exit receipt is written before hashes, verification, Xvfb cleanup or other post-work."""
    with (out/'native.log').open('x') as log:
        child=subprocess.Popen(args,cwd=cwd,env=env,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
        timed_out=False;forced_kill=False
        try:code=child.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            timed_out=True
            try:os.killpg(child.pid,signal.SIGTERM)
            except ProcessLookupError:pass
            try:code=child.wait(timeout=15)
            except subprocess.TimeoutExpired:
                forced_kill=True
                try:os.killpg(child.pid,signal.SIGKILL)
                except ProcessLookupError:pass
                code=child.wait()
        receipt=dict(child_pid=child.pid,returncode=code,timed_out=timed_out,forced_kill=forced_kill,
                     observed_at=datetime.now(timezone.utc).isoformat())
        try:write_new(out/'child-exit.json',receipt)
        finally:
            # Broken wrapper stdout must not prevent persisting the actual child exit.
            try:print('CHILD_EXIT_RECEIPT '+json.dumps(receipt),flush=True)
            except BrokenPipeError:pass
    return receipt


def snapshot(launch,out):
    assert not out.exists(),'use a new run-specific directory'
    launch_bytes=launch.read_bytes()
    args=json.loads(launch_bytes);assert isinstance(args,list) and args and all(isinstance(a,str) for a in args)
    assert args.count('--gameDir')==1,'ambiguous game directory'
    runtime=Path(args[args.index('--gameDir')+1]);assert launch.parent.resolve()==runtime.resolve()
    properties={}
    for arg in args:
        if arg.startswith(('-Ddrmd.gate.','-Ddrmd.benchmark.')):
            name,value=arg.split('=',1);assert name not in properties,'duplicate fixture/recorder property';properties[name]=value
    flags=['-Ddrmd.gate.mountedMechanisms=true','-Ddrmd.gate.benchmark=true','-Ddrmd.benchmark.mode=sidecar','-Ddrmd.benchmark.warmupSeconds=1','-Ddrmd.benchmark.sampleSeconds=1']
    assert all(a in args for a in flags),'fresh enabled1s/1s sidecar launch required'
    out.mkdir(parents=True)
    code=out/'runner.snapshot.py';code.write_bytes(Path(__file__).read_bytes());code.chmod(0o444)
    copied=out/'launch.snapshot.json';copied.write_bytes(launch_bytes);copied.chmod(0o444)
    assert launch.read_bytes()==launch_bytes,'launch changed during snapshot preparation'
    manifest=dict(schema='ungravity.native-runner-snapshot.v1',runtime=str(runtime.resolve()),
        runner_sha256=digest(code),launch_sha256=digest(copied),original_launch_path=str(launch.resolve()),
        original_launch_sha256=digest(launch),timeout_seconds=240,
        note='Snapshot files are actual execution inputs. Never edit them while running. No performance acceptance inferred.')
    write_new(out/'manifest.json',manifest);(out/'manifest.json').chmod(0o444)
    print('Prepared snapshot; no process launched:',code)


def execute(manifest_path):
    assert os.environ.get('S16_JAVA_LEASE')=='granted','no Java lease'
    out=manifest_path.parent.resolve();manifest=json.loads(manifest_path.read_text())
    assert Path(__file__).resolve()==out/'runner.snapshot.py','execute the snapshot, never the mutable preparation file'
    code=out/'runner.snapshot.py';launch=out/'launch.snapshot.json'
    assert digest(code)==manifest['runner_sha256'] and digest(launch)==manifest['launch_sha256']
    assert digest(Path(manifest['original_launch_path']))==manifest['original_launch_sha256']
    assert not (out/'native.log').exists() and not (out/'child-exit.json').exists()
    args=json.loads(launch.read_text());runtime=Path(manifest['runtime'])
    read_fd,write_fd=os.pipe();display=None
    try:
        with (out/'xvfb.log').open('x') as log:
            display=subprocess.Popen(['/workspace/xvfb/usr/bin/Xvfb','-displayfd',str(write_fd),'-screen','0','1280x1024x24'],
                pass_fds=(write_fd,),stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT)
            os.close(write_fd);write_fd=None
            assert select.select([read_fd],[],[],10)[0],'Xvfb readiness timeout'
            number=os.read(read_fd,64).decode().strip();assert number.isdigit(),number
            env=os.environ.copy();env.update(DISPLAY=':'+number,LIBGL_ALWAYS_SOFTWARE='1',MESA_GL_VERSION_OVERRIDE='3.3',MESA_GLSL_VERSION_OVERRIDE='330')
            write_new(out/'execution-inputs-before.json',dict(runner_sha256=digest(code),launch_sha256=digest(launch),manifest_sha256=digest(manifest_path)))
            receipt=wait_and_record(args,runtime,env,out,manifest['timeout_seconds'])
            after=dict(runner_sha256=digest(code),launch_sha256=digest(launch),manifest_sha256=digest(manifest_path))
            write_new(out/'execution-inputs-after.json',after)
            assert after==json.loads((out/'execution-inputs-before.json').read_text()),'execution inputs changed'
            assert receipt['returncode']==0 and not receipt['timed_out'],'child failed or external timeout occurred'
    finally:
        os.close(read_fd)
        if write_fd is not None:os.close(write_fd)
        if display is not None and display.poll() is None:
            display.terminate()
            try:display.wait(timeout=5)
            except subprocess.TimeoutExpired:display.kill();display.wait()


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);sub=parser.add_subparsers(dest='command',required=True)
    prep=sub.add_parser('snapshot');prep.add_argument('--launch',type=Path,required=True);prep.add_argument('--out',type=Path,required=True)
    run=sub.add_parser('execute');run.add_argument('--manifest',type=Path,required=True)
    args=parser.parse_args()
    if args.command=='snapshot':snapshot(args.launch,args.out)
    else:execute(args.manifest)
