# Future clean enabled retry — separate Java grant required

The first case's wrapper failed after the native client closed. Preserve `lease-9426/first-outcome-classification.json`, `first-wrapper-failure.json` and `runner-byte-provenance.json`. Native exit is unknown; no clean-exit native PASS is established. The original pre-run shell file was not snapshotted and cannot be recovered as original execution-input proof. `post-failure-current-runner.sh` is explicitly the modified post-failure file. Reconstructing the creation patch is not recovery of original proof.

Retire the shell runner for native execution. The replacement `immutable_native_runner.py` snapshots its actual bytes and the fresh launch JSON into a new run-specific directory, marks snapshot/manifest files readonly, and requires executing the copied Python file. It hashes execution inputs before and after. The child exit receipt is persisted immediately after `wait`, before post-verification, hashing or Xvfb cleanup; nonzero exit, timeout and signals remain explicit. Broken wrapper stdout cannot prevent writing the receipt.

Prepare a NEW copied/staged runtime with source9426 and the unchanged verified game/observer bytes. It must use a distinct run ID such as `9426-enabled-retry1`, sidecar mode, 1s warmup/1s requested duration and the existing mounted gate. Do not reuse a prior saved world, success marker, log or run directory. No new Java run or world staging is authorized until the coordinator grants the next lease.

After fresh staging, the command pattern is:

```sh
python3 work/native-benchmark-recorder/immutable_native_runner.py snapshot \
  --launch build/native-benchmark-9426/enabled-retry1/cubic-client-automation/launch.json \
  --out work/native-benchmark-recorder/retry-9426-enabled1
S16_JAVA_LEASE=granted python3 work/native-benchmark-recorder/retry-9426-enabled1/runner.snapshot.py execute \
  --manifest work/native-benchmark-recorder/retry-9426-enabled1/manifest.json
```

Never edit preparation or snapshot files while a process is running. `CREATE_NEW`-style exclusive outputs and readonly snapshots protect the review trail; hashes are not protection against a malicious actor restoring changed bytes. There is no silent retry, marker substitution, exit-code inference or performance acceptance.

Four Python-only controls passed: actual nonzero child receipt; timeout/signalled child receipt; broken wrapper stdout retaining the receipt; and preparation copying/hash-binding real input bytes without starting a child. These use synthetic Python subprocesses, not Minecraft or Java. Log: `immutable-runner-python-controls-final.log`. The clean enabled retry, disabled/capacity controls and native acceptance remain pending.
