#!/usr/bin/env bash
set +e
cd /workspace/ungravity-v5/ps1-render
bash scripts/v8/ps1_build.sh
build_code=$?
cp work/ps1/verified-build.log work/cloud-occlusion/iron-first-build.log
echo "$build_code" > work/cloud-occlusion/iron-first-build.exit
if [ "$build_code" -ne 0 ]; then exit "$build_code"; fi
cp work/ps1/verified-build.json work/cloud-occlusion/iron-first-build.json
python3 - <<'PY' > work/cloud-occlusion/iron-first-game-parity.log 2>&1
from pathlib import Path
import hashlib
p=Path('build/libs/drmd-6dof-1.1.35-ufo-dev.1.jar');expected='b6c653a4729e7dd4a8158ba1b8704fc31434c89d0c7cabaefbee4e1266d3df8c';actual=hashlib.sha256(p.read_bytes()).hexdigest();assert actual==expected,(actual,expected);print('Observer-only cloud source retains exact accepted palette game bytes',actual)
PY
parity_code=$?
echo "$parity_code" > work/cloud-occlusion/iron-first-game-parity.exit
if [ "$parity_code" -ne 0 ]; then exit "$parity_code"; fi
python3 - <<'CAPACITY' > work/cloud-occlusion/iron-capacity-admission.log 2>&1
from pathlib import Path
import hashlib,json,shutil,subprocess,time
r=Path.cwd();m=json.loads(Path('work/cloud-occlusion/iron-executed-inputs.json').read_text());source=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert source==m['source'];assert all(hashlib.sha256((r/p).read_bytes()).hexdigest()==h for p,h in m['files'].items());e=m['externalOfficialStager'];assert hashlib.sha256(Path(e['path']).read_bytes()).hexdigest()==e['sha256'];free=shutil.disk_usage(r).free
j={'source':source,'utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'actualFreeBeforeNativeBytes':free,'minimumBytes':140*1024*1024,'nativeCapacityPermitted':free>=140*1024*1024,'actualNativeCommand':['bash','scripts/v8/ps1_native.sh','ps1-cloud-attribution-occlusion-iron-d4a287f-sodium'],'allEightHelpersUnchanged':True,'externalOfficialStagerUnchanged':True}
Path('work/cloud-occlusion/iron-native-admission.json').write_text(json.dumps(j,indent=2)+'\n');print(json.dumps(j,indent=2));raise SystemExit(0 if j['nativeCapacityPermitted'] else 78)
CAPACITY
capacity_code=$?
echo "$capacity_code" > work/cloud-occlusion/iron-capacity.exit
if [ "$capacity_code" -ne 0 ]; then exit "$capacity_code"; fi
bash scripts/v8/ps1_native.sh ps1-cloud-attribution-occlusion-iron-d4a287f-sodium
native_code=$?
echo "$native_code" > work/cloud-occlusion/iron-first-native.exit
exit "$native_code"
