package com.terminaldetector.drmd.gate.cloud;

import com.terminaldetector.drmd.DescentPlayerData;
import com.terminaldetector.drmd.gate.NativeCloudAltitudeCheck;
import com.terminaldetector.drmd.flight.FlightSystem;
import com.terminaldetector.drmd.client.planet.HorizonLandmark;
import com.terminaldetector.drmd.vendor.immptl.ImmPtlQuaternions;
import com.terminaldetector.drmd.client.portal.PortalTransform.Vec3;
import com.terminaldetector.drmd.world.WorldRules;
import com.terminaldetector.drmd.world.access.WorldAccess;
import com.terminaldetector.drmd.world.contraption.BlockBodyEntity;
import com.terminaldetector.drmd.world.gen2.*;
import com.terminaldetector.drmd.world.planet.*;
import net.minecraft.block.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.math.*;
import java.nio.file.*;
import java.util.*;

/** Real disposable blocks, a real normal catalogue packet and a freely simulated body. */
public final class CloudOcclusionFixture {
    public static final int COLOUR=0xD83EC7,MAX_WRITES=512;
    private static final List<BlockPos> prefab=new ArrayList<>();
    private static final Queue<Map<String,Object>> writes=new java.util.concurrent.ConcurrentLinkedQueue<>();
    private static final java.util.concurrent.atomic.AtomicInteger eventSequence=new java.util.concurrent.atomic.AtomicInteger();
    private static volatile boolean setupRequested,setupReady,packetAccepted,poseReady;
    private static volatile int pose=-1,bodyId=-1;
    private static volatile BlockPos marker;
    private static volatile MacroEntry entry;
    private static BlockBodyEntity body;
    private static volatile Vec3d[] serverBodyCorners;
    private static volatile Vec3d setupPosition;
    private static volatile Map<String,Object> acceptedPacket=Map.of();
    private static double fixedX,fixedZ;
    private static int next;
    private static volatile int writeCount;
    private static int readySincePlayerAge=-1;
    private CloudOcclusionFixture() {}
    private static void require(boolean value,String message){NativeCloudAltitudeCheck.witnessControl(value,message);}
    public static boolean setup(MinecraftClient c,ServerPlayerEntity player,double x,double z){
        if(setupReady)return packetAccepted;
        if(!setupRequested){
            setupRequested=true;fixedX=x;fixedZ=z;double clouds=c.world.getDimensionEffects().getCloudsHeight();
            c.getServer().execute(()->{
                var world=player.getServerWorld();int lx=(int)x+24,lz=(int)z+24;
                int base=(int)Math.ceil(Math.max(PlanetMap.SEA_LEVEL,PlanetMap.height(world.getSeed(),lx,lz)));
                int height=(int)Math.ceil(clouds+48-base);require(height>=64&&height<=208&&base<clouds-16,"real landmark must straddle cloud plane within bounded height");
                for(int y=0;y<=height;y++){prefab.add(new BlockPos(lx-32,base+y,lz));prefab.add(new BlockPos(lx+31,base+y,lz));}
                for(int d=-31;d<31;d++)prefab.add(new BlockPos(lx+d,base+height,lz));
                require(prefab.size()+10<=MAX_WRITES,"total physical/local-grid write budget");
                entry=new MacroEntry(UUID.nameUUIDFromBytes("cloud-occlusion-real-arch".getBytes(java.nio.charset.StandardCharsets.UTF_8)),MacroEntry.Kind.ARCH,WorldRules.Layer.SURFACE,new BlockPos(lx,base+height/2,lz),64,height+1,1,COLOUR,"Cloud occlusion real arch");
                FlightSystem.disable(player,DescentPlayerData.get(player));player.getAbilities().allowFlying=true;player.getAbilities().flying=true;player.sendAbilitiesUpdate();
                setupPosition=new Vec3d(lx-8,base+height/2.0,lz-8);player.teleport(world,setupPosition.x,setupPosition.y,setupPosition.z,Set.of(),0,90);player.setVelocity(Vec3d.ZERO);
            });
        }
        return false;
    }
    public static void serverTick(ServerPlayerEntity player){
        if(!setupRequested||entry==null)return;var world=player.getServerWorld();var access=WorldAccess.of(world);
        if(!setupReady){
            require(setupPosition!=null&&player.getPos().distanceTo(setupPosition)<=.02&&!DescentPlayerData.get(player).isEnabled()&&player.getAbilities().flying&&player.getAbilities().allowFlying,"ordinary setup hover remains genuinely stable");
            // Metadata never loads cubes. Ordinary setup-player interest must satisfy every cell.
            for(var p:prefab)if(access.readIfLoaded(p).isEmpty())return;
            int limit=Math.min(prefab.size(),next+32);for(;next<limit;next++)write(player,prefab.get(next),Blocks.MAGENTA_CONCRETE.getDefaultState());
            if(next==prefab.size()){
                for(var p:prefab)require(access.readIfLoaded(p).filter(Blocks.MAGENTA_CONCRETE.getDefaultState()::equals).isPresent(),"physical prefab readback");
                setupReady=true;checkpoint("prefab-full-readback",Map.of("checkedRealCells",prefab.size()));MacroWorld.put(entry);checkpoint("normal-landmark-registered",Map.of("kind",entry.kind.name()));PlanetSync.pushTo(player);
            }
            return;
        }
        if(pose<0||poseReady)return;
        if(access.readIfLoaded(marker).isEmpty())return;
        write(player,marker,Blocks.BLUE_CONCRETE.getDefaultState());
        if(body!=null&&!body.isRemoved())body.discard();
        var at=new Vec3d(fixedX-2,marker.getY()+.2,fixedZ+2);var turn=ImmPtlQuaternions.rotationByDegrees(new Vec3(0,0,1),20);
        var material=Blocks.IRON_BLOCK.getDefaultState();checkpoint("before-body-create",Map.of("actualPlayerPosition",List.of(player.getX(),player.getY(),player.getZ()),"requestedGridOrigin",List.of(at.x,at.y,at.z),"requestedCell",material.toString(),"productionSupportsMaterial",BlockBodyEntity.supports(material)));require(BlockBodyEntity.supports(material),"fixture material must already be supported by production");
        try{body=BlockBodyEntity.createLocal(world,List.of(new BlockBodyEntity.Cell(BlockPos.ORIGIN,material)),at,turn,Vec3d.ZERO,Vec3d.ZERO);}
        catch(RuntimeException failure){var trace=new java.io.StringWriter();failure.printStackTrace(new java.io.PrintWriter(trace));checkpoint("body-create-rejected",Map.of("originalException",failure.toString(),"originalStack",trace.toString()));require(false,"actual createLocal rejected fixture: "+failure);throw failure;}
        body.setPhysicsGravity(false);writeCount++;require(writeCount<=MAX_WRITES,"local-grid write budget");bodyId=body.getId();serverBodyCorners=corners(body);poseReady=true;checkpoint("actual-body-created",Map.of("actualBodyCell",body.getLocalBlock(BlockPos.ORIGIN).toString(),"actualBodyCorners",Arrays.stream(serverBodyCorners).map(v->List.of(v.x,v.y,v.z)).toList(),"actualPhysicsGravity",body.physicsGravity()));
    }
    private static void write(ServerPlayerEntity player,BlockPos p,BlockState replacement){
        var access=WorldAccess.of(player.getServerWorld());var before=access.snapshotIfLoaded(p);require(before.isPresent()&&before.get().entityData()==null,"known inert write cell");require(++writeCount<=MAX_WRITES,"total real write budget");
        player.getServerWorld().setBlockState(p,replacement,3);require(access.readIfLoaded(p).filter(replacement::equals).isPresent(),"normal block write readback");writes.add(Map.of("position",List.of(p.getX(),p.getY(),p.getZ()),"before",before.get().state().toString(),"after",replacement.toString()));
    }
    public static void beginPose(int index,double y){pose=index;poseReady=false;readySincePlayerAge=-1;marker=new BlockPos((int)fixedX+2,(int)y-(index==0?16:32),(int)fixedZ+2);}
    public static void acceptedPacket(long seed,List<HorizonLandmark> marks){var wanted=entry;if(wanted==null||!setupReady)return;for(var m:marks)if(m.x()==wanted.center.getX()&&m.y()==wanted.center.getY()&&m.z()==wanted.center.getZ()&&m.sizeX()==wanted.sizeX&&m.sizeY()==wanted.sizeY&&m.sizeZ()==wanted.sizeZ&&m.colour()==wanted.colorRgb&&m.kind()==wanted.kind){acceptedPacket=Map.of("actualSeed",seed,"actualAcceptedLandmarks",marks.size(),"matchingCenter",List.of(m.x(),m.y(),m.z()),"matchingSize",List.of(m.sizeX(),m.sizeY(),m.sizeZ()),"actualColour",m.colour(),"actualKind",m.kind().name());packetAccepted=true;checkpoint("actual-normal-packet-accepted",acceptedPacket);}}
    public static boolean ready(MinecraftClient c){
        if(!setupReady||!packetAccepted||!poseReady||marker==null||c.world==null)return waiting();
        if(WorldAccess.of(c.world).readIfLoaded(marker).filter(Blocks.BLUE_CONCRETE.getDefaultState()::equals).isEmpty())return waiting();
        if(!(c.world.getEntityById(bodyId) instanceof BlockBodyEntity b)||b.cells().size()!=1||!b.getLocalBlock(BlockPos.ORIGIN).isOf(Blocks.IRON_BLOCK)||b.physicsGravity())return waiting();
        var actual=corners(b);for(int i=0;i<8;i++)if(actual[i].distanceTo(serverBodyCorners[i])>.005)return waiting();if(readySincePlayerAge<0)readySincePlayerAge=c.player.age;return c.player.age-readySincePlayerAge>=8;
    }
    private static boolean waiting(){readySincePlayerAge=-1;return false;}
    public static Vec3d[] worldCorners(){var result=new Vec3d[8];for(int i=0;i<8;i++)result[i]=new Vec3d(marker.getX()+(i&1),marker.getY()+((i>>1)&1),marker.getZ()+((i>>2)&1));return result;}
    public static Vec3d[] bodyCorners(MinecraftClient c){return corners((BlockBodyEntity)c.world.getEntityById(bodyId));}
    private static Vec3d[] corners(BlockBodyEntity b){var result=new Vec3d[8];for(int i=0;i<8;i++)result[i]=b.localToWorld(new Vec3d(i&1,(i>>1)&1,(i>>2)&1));return result;}
    public static Map<String,Object> status(){var out=new LinkedHashMap<String,Object>();out.put("setupRequested",setupRequested);out.put("setupReady",setupReady);out.put("normalPacketAccepted",packetAccepted);out.put("actualAcceptedPacket",acceptedPacket);out.put("writeCount",writeCount);out.put("maxWrites",MAX_WRITES);out.put("physicalWrites",new ArrayList<>(writes));out.put("bodyId",bodyId);out.put("bodyControl","free gravity-off, initial zero velocity only; no anchor");out.put("poseReady",poseReady);if(setupPosition!=null)out.put("requestedSingleSetupHover",List.of(setupPosition.x,setupPosition.y,setupPosition.z));if(entry!=null)out.put("realLandmark",Map.of("center",List.of(entry.center.getX(),entry.center.getY(),entry.center.getZ()),"sizes",List.of(entry.sizeX,entry.sizeY,entry.sizeZ),"colour",entry.colorRgb,"kind",entry.kind.name(),"physicalCells",prefab.size()));return out;}
    private static void checkpoint(String event,Map<String,Object> detail){try{var folder=MinecraftClient.getInstance().runDirectory.toPath().resolve("cloud-occlusion-fixture-events");Files.createDirectories(folder);var record=new LinkedHashMap<String,Object>();record.put("event",event);record.put("pose",pose);record.put("fixture",status());record.put("detail",detail);Files.writeString(folder.resolve(String.format(Locale.ROOT,"%03d-%s.json",eventSequence.incrementAndGet(),event)),new com.google.gson.Gson().toJson(record));}catch(java.io.IOException failure){throw new IllegalStateException("CLOUD_OCCLUSION_CONTROL cannot preserve actual fixture checkpoint",failure);}}
    public static void releaseWorldReference(){body=null;}
}
