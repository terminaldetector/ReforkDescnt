#!/usr/bin/env bash
set -euo pipefail
lane_dir=$(cd -- "$(dirname -- "$0")" && pwd)
repo_dir=$(cd -- "$lane_dir/../.." && pwd)
cd "$repo_dir"
scenario=ragdoll-volumes-20fb873-negative-gl32
test ! -e "$lane_dir/native.log"
test ! -e "$lane_dir/prepare.log"
test ! -e "build/cubic-client-final-${scenario}"
python3 "$lane_dir/build_stamp.py" idle
python3 "$lane_dir/prepare.py" > "$lane_dir/prepare.log" 2>&1
display_file="$lane_dir/display.txt"
: > "$display_file"
/workspace/xvfb/usr/bin/Xvfb -displayfd 3 -screen 0 1280x1024x24 3> "$display_file" > "$lane_dir/xvfb.log" 2>&1 &
display_pid=$!
trap 'kill "$display_pid" 2>/dev/null || true; wait "$display_pid" 2>/dev/null || true' EXIT
for attempt in {1..100}; do
    kill -0 "$display_pid"
    if [ -s "$display_file" ]; then break; fi
    sleep .1
done
test -s "$display_file"
read -r display_number < "$display_file"
set +e
DISPLAY=:$display_number LIBGL_ALWAYS_SOFTWARE=1 MESA_GL_VERSION_OVERRIDE=3.2 MESA_GLSL_VERSION_OVERRIDE=150 timeout --kill-after=10 --foreground 180 python3 -c 'import os,json; from pathlib import Path; p=Path("build/cubic-client-automation").resolve(); a=json.loads((p/"launch.json").read_text()); os.chdir(p);os.execv(a[0],a)' < /dev/null > "$lane_dir/native.log" 2>&1
native_code=$?
printf '%s\n' "$native_code" > "$lane_dir/native.exit"
python3 - "$native_code" > "$lane_dir/native-validation.log" 2>&1 <<'PY'
from pathlib import Path
import json,shutil,sys
lane=Path('work/ragdoll-volumes');runtime=Path('build/cubic-client-automation')
report={'nativeProcessExit':int(sys.argv[1]),'atomicManualProductionTick':True,'naturalMultiFrameStreamingAcceptance':False,'nativeVisualAcceptance':False}
for name in ('inputs.json','launch.json','ragdoll-volumes-failure.json','ragdoll-volumes-ok.json'):
    if (runtime/name).is_file():shutil.copyfile(runtime/name,lane/name)
report['failureMarkerPresent']=(runtime/'ragdoll-volumes-failure.json').is_file()
report['successMarkerPresent']=(runtime/'ragdoll-volumes-ok.json').is_file()
if report['failureMarkerPresent']:report['failure']=json.loads((runtime/'ragdoll-volumes-failure.json').read_text())
if report['successMarkerPresent']:report['success']=json.loads((runtime/'ragdoll-volumes-ok.json').read_text())
report['crashReports']=[str(p.relative_to(runtime)) for p in (runtime/'crash-reports').glob('*.txt')]
(lane/'first-native-outcome.json').write_text(json.dumps(report,indent=2)+'\n')
ok=report['nativeProcessExit']==0 and not report['failureMarkerPresent'] and not report['crashReports'] and report['successMarkerPresent']
if ok:
    result=report['success'];ok=result.get('pass') is True and result.get('realNativeCubic') is True and result.get('queriesLeaveNativeStateUnchanged') is True and result.get('nativeMetadataAndAdmissionUnchanged') is True and result.get('unknownStillUnavailableAfterTick') is True and result.get('occupiedUnavailableCubeAfterTick') is False and result.get('sameEntityAndSimulationOwner') is True and result.get('loadedControlMovedY',0)>.01
sys.exit(0 if ok else 1)
PY
validation_code=$?
printf '%s\n' "$validation_code" > "$lane_dir/native-validation.exit"
set -e
mv build/cubic-client-automation "build/cubic-client-final-${scenario}"
printf 'RAGDOLL_NATIVE_CLOSED process_exit=%s validation_exit=%s\n' "$native_code" "$validation_code"
if [ "$native_code" -ne 0 ]; then exit "$native_code"; fi
exit "$validation_code"
