#!/usr/bin/env python3
"""Own-tree official stager; borrow only hash-verified immutable MC/library bytes."""
from pathlib import Path
import hashlib
import importlib.util
import json
import os
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parents[2]
LANE = ROOT / 'work/ragdoll-volumes'
SCENARIO = 'ragdoll-volumes-20fb873-negative-gl32'
RUNTIME = ROOT / 'build/cubic-client-automation'
SERVER = Path('/workspace/ungravity-v5/world/build/cubic-seed2-gate')
LIBRARIES = Path('/workspace/ungravity-v5/boarding-attachment/build/cubic-client-final-body-scale-volumes-final-gl32/libraries')
DONOR = Path('/workspace/ungravity-v5/ufo-body-physics/build/cubic-client-final-flight-body-current-phase-sodium')
OFFICIAL = ROOT / 'scripts/v5/prepare_cubic_client.py'
JAVA = Path('/workspace/jdk21-complete/bin/java')
VERSION = 'drmd-6dof-1.1.35-ufo-dev.1'

spec = importlib.util.spec_from_file_location('own_official_stager', OFFICIAL)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
original_copy = module.verified_copy


def copy(source, target, sha1=None):
    if 'libraries' in target.parts:
        prior = LIBRARIES.joinpath(*target.parts[target.parts.index('libraries') + 1:])
        if prior.is_file() and module.digest(prior) == module.digest(source) and (not sha1 or module.digest(prior, 'sha1') == sha1):
            target.parent.mkdir(parents=True, exist_ok=True)
            os.link(prior, target)
            return target
    return original_copy(source, target, sha1)


def world_inputs(root):
    return {str(p.relative_to(root)): module.digest(p) for p in sorted(root.rglob('*'))
            if p.is_file() and p.name != 'session.lock'}


if __name__ == '__main__':
    subprocess.run(['python3', str(LANE / 'build_stamp.py'), 'check'], check=True)
    assert not RUNTIME.exists(), 'a fresh staged runtime is required'
    for variable in ('JAVA_TOOL_OPTIONS', 'JDK_JAVA_OPTIONS', '_JAVA_OPTIONS'):
        assert 'drmd.gate.' not in os.environ.get(variable, ''), 'gate flags must be explicit in the saved launch JSON'
    fixture = SERVER / 'gate-v5-cubic-fixed'
    fixture_before = world_inputs(fixture)
    assert fixture_before and 'level.dat' in fixture_before
    args = ['--server-runtime', str(SERVER), '--runtime', str(RUNTIME),
            '--drmd', str(ROOT / 'build/libs' / (VERSION + '.jar')),
            '--gate', str(ROOT / 'build/libs' / (VERSION + '-cubiccheck.jar')),
            '--bcc', '/workspace/Refork-audit/work/master-v5/upstream/bettercubicchunks-fabric-0.1.1+mc1.21.1.jar',
            '--api', '/workspace/.gradle/caches/modules-2/files-2.1/net.fabricmc.fabric-api/fabric-api/0.116.15+1.21.1/d25c793833a90cc028c9a61bc4546cd578a70ce1/fabric-api-0.116.15+1.21.1.jar',
            '--java', str(JAVA), '--copy-test-world']
    import sys
    sys.argv = [str(OFFICIAL), *args]
    module.verified_copy = copy
    module.main()
    assert fixture_before == world_inputs(fixture) == world_inputs(RUNTIME / 'saves/Cubic-Gate')
    stamp = json.loads((LANE / 'verified-build.json').read_text())
    manifest = json.loads((RUNTIME / 'inputs.json').read_text())
    for relative, digest in stamp['jars'].items():
        candidate = RUNTIME / 'mods' / Path(relative).name
        assert module.digest(candidate) == digest
        assert next(a['sha256'] for a in manifest['artifacts'] if a['path'] == str(candidate.relative_to(RUNTIME))) == digest
    original_donor = json.loads((DONOR / 'inputs.json').read_text())
    original_name = 'libraries/com/mojang/minecraft/1.21.1/minecraft-1.21.1-client.jar'
    assert next(a['sha256'] for a in manifest['artifacts'] if a['path'] == original_name) == next(
        a['sha256'] for a in original_donor['artifacts'] if a['path'] == original_name)
    assert module.digest(RUNTIME / original_name) == module.digest(DONOR / original_name)
    cache = DONOR / '.fabric/remappedJars/minecraft-1.21.1-0.19.5/client-intermediary.jar'
    with zipfile.ZipFile(cache) as jar:
        assert jar.testzip() is None and not any(n.startswith('com/terminaldetector/') for n in jar.namelist())
    derived = RUNTIME / cache.relative_to(DONOR)
    derived.parent.mkdir(parents=True, exist_ok=True)
    os.link(cache, derived)
    launch = json.loads((RUNTIME / 'launch.json').read_text())
    removed = [a for a in launch if a.startswith('-Ddrmd.gate.')]
    launch = [a for a in launch if not a.startswith('-Ddrmd.gate.')]
    launch.insert(1, '-Ddrmd.gate.ragdollVolumes=true')
    assert [a for a in launch if a.startswith('-Ddrmd.gate.')] == ['-Ddrmd.gate.ragdollVolumes=true']
    (RUNTIME / 'launch.json').write_text(json.dumps(launch, indent=2) + '\n')
    manifest.update(sourceSha=stamp['sourceSha'], candidateJars=stamp['jars'], expectedCoreGame=stamp['expectedCoreGame'],
                    scenario=SCENARIO, glOverride='3.2/150', gateFlags=['drmd.gate.ragdollVolumes=true'],
                    removedGateFlags=removed, officialStagerSha256=module.digest(OFFICIAL),
                    launcherInputs=stamp['inputs'], initialFixtureWorld=fixture_before,
                    atomicManualProductionTick=True, naturalMultiFrameStreamingAcceptance=False,
                    nativeVisualAcceptance=False, derivedMinecraftCache=dict(source=str(cache), sha256=module.digest(cache),
                    scope='Minecraft-only intermediary cache; exact official original MC inputs verified; no DRMD classes or saves reused'))
    (RUNTIME / 'inputs.json').write_text(json.dumps(manifest, indent=2) + '\n')
    print('STAGED_NOT_RUN', SCENARIO, 'source', stamp['sourceSha'], 'sole flag ragdollVolumes; direct atomic production tick scope')
