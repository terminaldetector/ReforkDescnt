#!/usr/bin/env bash
set -euo pipefail
lane_dir=$(cd -- "$(dirname -- "$0")" && pwd)
repo_dir=$(cd -- "$lane_dir/../.." && pwd)
cd "$repo_dir"
test ! -e "$lane_dir/build.log"
test ! -e "$lane_dir/build-preflight.log"
python3 "$lane_dir/build_stamp.py" before > "$lane_dir/build-preflight.log" 2>&1
set +e
JAVA_HOME=/workspace/jdk21-complete PATH=/workspace/jdk21-complete/bin:$PATH GRADLE_USER_HOME=/workspace/.gradle ./gradlew remapJar remapCubiccheckJar --offline --no-daemon > "$lane_dir/build.log" 2>&1
compile_code=$?
printf '%s\n' "$compile_code" > "$lane_dir/build.exit"
set -e
if [ "$compile_code" -ne 0 ]; then exit "$compile_code"; fi
set +e
python3 "$lane_dir/build_stamp.py" record > "$lane_dir/build-verification.log" 2>&1
verify_code=$?
printf '%s\n' "$verify_code" > "$lane_dir/build-verification.exit"
exit "$verify_code"
