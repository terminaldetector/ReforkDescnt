#!/usr/bin/env python3
import datetime,hashlib,json,os,pathlib,shutil,signal,subprocess,sys,time,xml.etree.ElementTree as ET

ROOT=pathlib.Path('/workspace/ungravity-v5/audit-next-20261109')
RUN=pathlib.Path(__file__).resolve().parent
SOURCE='e0478ce8d4e79cc73678582bafa4f539978e9a26'
JAVA=pathlib.Path('/usr/lib/jvm/java-21-openjdk-amd64')
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p):
 h=hashlib.sha256()
 with p.open('rb')as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def write(name,data):
 with (RUN/name).open('x')as f:json.dump(data,f,indent=2);f.write('\n')
def inputs():
 files=[p for p in (ROOT/'src').rglob('*')if p.is_file()]
 files += [ROOT/p for p in ['build.gradle','gradle.properties','settings.gradle','gradlew','gradle/wrapper/gradle-wrapper.jar','gradle/wrapper/gradle-wrapper.properties']]
 return [{'path':str(p.relative_to(ROOT)),'bytes':p.stat().st_size,'sha256':sha(p)}for p in sorted(files)]
started=now();started_ns=time.time_ns();runner_sha=sha(pathlib.Path(__file__))
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
assert head==SOURCE,(head,SOURCE)
assert not subprocess.check_output(['git','diff','--name-only'],cwd=ROOT,text=True).strip()
assert not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=ROOT,text=True).strip()
manifest=json.loads((ROOT/'docs/v8/DRONE_LOADOUT_PREVIEW_CANDIDATE_2026-11-17.json').read_text())
for item in manifest['files']:assert sha(ROOT/item['path'])==item['sha256'],item['path']
assert shutil.disk_usage(ROOT).free>=48*1024*1024,'Insufficient disk before first compile; no cleanup authorized'
named=next((ROOT/'.gradle/loom-cache/minecraftMaven').rglob('minecraft-merged*.jar'))
command=['./gradlew','--offline','--no-daemon','--no-parallel','--max-workers=1',
 '-Dorg.gradle.jvmargs=-Xmx1G -Dfile.encoding=UTF-8','--console=plain',
 'compileJava','compileTestJava','test','--tests','com.terminaldetector.drmd.DronePreviewProjectionTest']
before=inputs();write('inputs-before.json',{'source':SOURCE,'captured_utc':now(),'files':before})
runtime={'java_home':str(JAVA),'java_executable_sha256':sha(JAVA/'bin/java'),
 'libjvm_sha256':sha(JAVA/'lib/server/libjvm.so'),'release':(JAVA/'release').read_text(),
 'named_minecraft':{'path':str(named),'sha256':sha(named),'bytes':named.stat().st_size},
 'gradle_user_home':'/workspace/.gradle','command':command,'runner':{'path':str(pathlib.Path(__file__)),'sha256':runner_sha},
 'started_utc':started,'started_unix_ns':started_ns,'disk_free_before':shutil.disk_usage(ROOT).free}
write('runtime-inputs.json',runtime)
env=os.environ.copy();env['JAVA_HOME']=str(JAVA);env['PATH']=str(JAVA/'bin')+os.pathsep+env.get('PATH','');env['GRADLE_USER_HOME']='/workspace/.gradle'
timed_out=False;forced_kill=False
with (RUN/'gradle-first.log').open('xb') as log:
 child=subprocess.Popen(command,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 write('child-start.json',{'pid':child.pid,'started_utc':now(),'command':command})
 try:returncode=child.wait(timeout=420)
 except subprocess.TimeoutExpired:
  timed_out=True;os.killpg(child.pid,signal.SIGTERM)
  try:returncode=child.wait(timeout=10)
  except subprocess.TimeoutExpired:forced_kill=True;os.killpg(child.pid,signal.SIGKILL);returncode=child.wait()
 write('child-exit.json',{'pid':child.pid,'returncode':returncode,'closed_utc':now(),'timed_out':timed_out,'forced_kill':forced_kill})
 print(json.dumps({'event':'GRADLE_CLOSED','returncode':returncode,'timed_out':timed_out,'forced_kill':forced_kill,'closed_utc':now()}),flush=True)
after=inputs();write('inputs-after.json',{'source':SOURCE,'captured_utc':now(),'files':after,'byte_identical':before==after,'runner_sha256':sha(pathlib.Path(__file__)),'runner_unchanged':runner_sha==sha(pathlib.Path(__file__))})
xml=ROOT/'build/test-results/test/TEST-com.terminaldetector.drmd.DronePreviewProjectionTest.xml'
report={'source':SOURCE,'first_attempt':True,'returncode':returncode,'xml_present':xml.exists(),
 'compile_or_test_runtime_pass':False,'native_run':False,'remap_run':False,'source_inputs_unchanged':before==after,'closed_utc':now()}
if xml.exists():
 fresh=xml.stat().st_mtime_ns>=started_ns
 shutil.copy2(xml,RUN/'DronePreviewProjectionTest.xml')
 suite=ET.parse(xml).getroot();report.update(xml_sha256=sha(xml),xml_fresh=fresh,xml_attributes=suite.attrib,
  testcase_names=[x.attrib.get('name')for x in suite.findall('testcase')])
 report['compile_or_test_runtime_pass']=returncode==0 and fresh and int(suite.attrib['tests'])==6 and all(int(suite.attrib[k])==0 for k in ['failures','errors','skipped']) and before==after
write('first-outcome.json',report);print(json.dumps(report),flush=True)
sys.exit(0 if report['compile_or_test_runtime_pass']else returncode or 1)
