#!/usr/bin/env python3
"""Single first outcome on a frozen source; preserve child exit and fresh reports."""
import hashlib,json,os,pathlib,shutil,subprocess,sys,time,xml.etree.ElementTree as ET

root=pathlib.Path('/workspace/ungravity-v5/ufo-body-physics')
os.chdir(root)
expected='3920768301320fa35af5b178a85ebf92bed99ef6'
head=lambda:subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert head()==expected
assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'])
out=root/'work/multi-agent/linear-first-3920768'
out.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
shutil.copyfile(__file__,out/'executing-runner.py')
helper=root/'scripts/v8/linear_mechanism_focus.init.gradle'
shutil.copyfile(helper,out/'focus.init.gradle')
files=subprocess.check_output(['git','ls-files','-z'],text=True).split('\0')
inputs={f:sha(root/f) for f in files if f and (root/f).is_file() and (f.startswith(('src/','scripts/')) or f in ('build.gradle','settings.gradle','gradle.properties','gradlew'))}
(out/'inputs.json').write_text(json.dumps({'source':expected,'files':inputs,'helperSHA256':sha(helper),'runnerSHA256':sha(out/'executing-runner.py')},indent=2)+'\n')
report=root/'build/gametest/reports/gametest-results.xml'
if report.exists():
    shutil.copyfile(report,out/'prior-game-results.xml')
    report.unlink()
generated=root/'build/resources/gametest'
if generated.exists():
    assert generated.is_dir() and not generated.is_symlink()
    shutil.rmtree(generated)
env=os.environ.copy()
env['JAVA_HOME']='/workspace/jdk21-complete'
env['PATH']=env['JAVA_HOME']+'/bin:'+env['PATH']
env['GRADLE_USER_HOME']='/workspace/.gradle'
cmd=['./gradlew','compileJava','compileGametestJava','runGametest','remapJar','--no-daemon','--offline','-I',str(out/'focus.init.gradle')]
started=time.time_ns()
(out/'launch.json').write_text(json.dumps({'source':expected,'startNs':started,'command':cmd},indent=2)+'\n')
print('START',expected,flush=True)
with (out/'gradle.log').open('xb') as log:
    result=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT)
(out/'child.exit').write_text(str(result.returncode)+'\n')
receipt={'source':expected,'endSource':head(),'childExit':result.returncode,'freshReport':report.exists() and report.stat().st_mtime_ns>=started,'endNs':time.time_ns()}
if report.exists():
    shutil.copyfile(report,out/'game-results.xml')
    cases=list(ET.parse(report).getroot().iter('testcase'))
    receipt['counts']={'tests':len(cases),**{k:sum(c.find(tag) is not None for c in cases) for k,tag in [('failures','failure'),('errors','error'),('skipped','skipped')]}}
    receipt['failedCases']=[{'name':c.get('name'),'detail':''.join(c.find('failure').itertext())} for c in cases if c.find('failure') is not None]
manifest=root/'build/resources/gametest/fabric.mod.json'
if manifest.exists():shutil.copyfile(manifest,out/'actual-processed-manifest.json')
for p in (root/'build/gametest/logs/latest.log',root/'build/gametest/logs/debug.log'):
    if p.exists():shutil.copyfile(p,out/p.name)
receipt['jarHashes']={str(p.relative_to(root)):sha(p) for p in (root/'build/libs').glob('*.jar')}
receipt['sourceInputsStillEqual']=all((root/f).is_file() and sha(root/f)==s for f,s in inputs.items())
receipt['helperStillEqual']=sha(helper)==sha(out/'focus.init.gradle')
passed=result.returncode==0 and receipt['freshReport'] and receipt.get('counts')=={'tests':17,'failures':0,'errors':0,'skipped':0} and receipt['endSource']==expected and receipt['sourceInputsStillEqual'] and receipt['helperStillEqual']
receipt['gatePassed']=passed
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
code=0 if passed else result.returncode or 1
(out/'wrapper.exit').write_text(str(code)+'\n')
print(json.dumps(receipt,indent=2),flush=True)
sys.exit(code)
