"""Compact local proof for the Debug compositor fix, preserving each independent first outcome."""
from pathlib import Path
import hashlib,json,subprocess,zipfile,xml.etree.ElementTree as E

root=Path.cwd();work=root/'work/ps1'
source='7df89aaf1e8f65a7493a9f86a6a31a74303f2f0a'
production='efa5b3ffef7398d6630fc96f311e6b639b170e78'
negative='09b50e0fa8b88a3918f8671b61369cb04e98c11e'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
subprocess.run(['python3','scripts/v8/ps1_build_stamp.py','check'],check=True)
stamp=json.loads((work/'verified-build.json').read_text());assert stamp['sourceSha']==source
assert not subprocess.check_output(['git','diff',production,source,'--','src/main','src/test','src/gametest','build.gradle','settings.gradle','gradle.properties'])
assert not subprocess.check_output(['git','status','--porcelain','--','src','scripts/v8/ps1*','build.gradle','settings.gradle','gradle.properties'])
unit=E.parse(work/'debug-positive-five-unit.xml').getroot()
assert {k:int(unit.get(k,0)) for k in ['tests','failures','errors','skipped']}==dict(tests=5,failures=0,errors=0,skipped=0)
first=json.loads((work/'debug-negative-measured.json').read_text());assert first['source']==negative and first['exit']==255
assert first['worldEdges']['hits']==3 and first['worldEdges']['samples']==346
replay=json.loads((work/'debug-contrast-offline-replay.json').read_text());assert replay['negativeExactStoredPreOverlay']['hits']==3
weak=json.loads((work/'debug-gl32-passed.json').read_text());assert weak['debugPostprocessExceptionRestored']
weakStamp=json.loads((work/'debug-gl32-build.json').read_text());assert weakStamp['sourceSha']==production and weakStamp['jars'][next(k for k in stamp['jars'] if not k.endswith('-cubiccheck.jar'))]==stamp['jars'][next(k for k in stamp['jars'] if not k.endswith('-cubiccheck.jar'))]
names=['native-baseline','ps1-360','native-restored','debug-wireframe','ps1-180-resized','native-window-restored']
cases=['ps1-debug-contrast-fixed-fabulous-gl32','ps1-debug-contrast-fixed-sodium'];native={};runtimePaths=[]
for case in cases:
    runtime=root/'build'/('cubic-client-final-'+case);runtimePaths.append(runtime)
    manifest=json.loads((runtime/'inputs.json').read_text());assert manifest['sourceSha']==source and manifest['candidateJars']==stamp['jars']
    assert (work/(case+'.exit')).read_text().strip()=='0' and not list((runtime/'crash-reports').glob('*.txt'))
    for relative,wanted in stamp['jars'].items():assert sha(runtime/'mods'/Path(relative).name)==wanted
    marker=json.loads((runtime/'presentation-ok.json').read_text())
    for key in ['runtimeToggleWithoutReload','actualWindowResizeAndRestore','exceptionTargetsRestored','debugPostprocessExceptionRestored','blockstoreHashUnchanged','independentHybridChoiceUnchanged']:assert marker[key]
    assert [x['scene'] for x in marker['scenes']]==names
    assert len(list((runtime/'presentation-frames').glob('*.png')))==9
    for scene in marker['scenes']:
        assert scene['glError']==0 and scene['nativeHudPixel']
        assert (runtime/'presentation-frames'/(scene['scene']+'.png')).is_file()
        if scene['profile']=='PS1_HYBRID':
            assert scene['worldNearestGridRatio']>.97 and scene['deferredOverlayPasses']>=2
            assert scene['sampleEpoch']==scene['frameEpoch']==scene['mirrorEpoch']
            assert scene['mergedMirrorSurfaces']==1 and scene['projectedMirrorPanes']==8 and scene['reflectedGoldPixels']>=30
            assert (runtime/'presentation-frames'/(scene['scene']+'-world-before-overlays.png')).is_file()
        elif scene['profile']=='RENDER_DEBUG':
            edge=scene['debugWorldEdges'];assert edge['samples']>=100 and edge['ratio']>=.70 and min(edge['horizontalBins'])>=20
            assert edge['frameEpoch']==edge['sampleEpoch']==edge['projectionEpoch']
            assert (runtime/'presentation-frames'/'debug-wireframe-world-before-overlays.png').is_file()
        else:assert scene['reflectedGoldPixels']>=30
    sodium=any('sodium' in a['path'].lower() for a in manifest['artifacts'])
    assert sodium==('sodium' in case)
    if 'fabulous' in case:assert 'graphicsMode:2' in (runtime/'options.txt').read_text() and manifest['glOverride']=='3.2/150'
    native[case]=marker
summary=dict(source=source,productionSource=production,negativeSource=negative,jars=stamp['jars'],unit=dict(source=production,tests=5,failures=0,errors=0,skipped=0),native=native,imagesInspected=18,
    firstNegative=dict(source=negative,hits=3,samples=346,ratio=3/346,scope='Actual native first failure and pure-world PNG; stricter contrast algorithm also replayed offline without weakening thresholds.'),
    firstFixedRun=dict(source=production,scope='GL/FBO/window/profile and raster exception cleanup only; brightness-only count superseded by strict contrast proof.'),
    strictThresholds=dict(minSampleCount=100,minHitRatio=.70,minHitsPerScreenThird=20,pixelRadius=2,minMaxRgb=60,minRgbSum=100,minLocalRgbSumContrast=96),
    scope='Debug compositor-fill fix only; original scene-target proof remains separate. No full canonical regression count, full S04/S05/v8 or S05-T04/viewmodel acceptance.',
    openViewmodelDifference='Native gold center weapon tip is absent in PS1 frames, including old703 and new7df; separate pixel/viewmodel follow-up.',releaseAccepted=False,publication='Local only')
(work/'debug-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
(work/'debug-source-series.patch').write_text(subprocess.check_output(['git','diff','c326018',source,'--','src'],text=True))
files={}
def add(p,name=None):
    assert p.is_file() and not p.is_symlink(),p
    files[name or str(p.relative_to(root))]=p
for p in work.iterdir():
    if p.is_file() and p.name.startswith('debug-') and p.suffix in {'.json','.log','.txt','.xml','.patch','.exit'}:add(p)
add(work/'ps1-debug-world-negative-fabulous-gl32.exit')
add(work/'ps1-debug-world-fixed-fabulous-gl32.exit')
add(work/'collect-debug-evidence.py')
for runtime in [*runtimePaths,root/'build/cubic-client-failed-ps1-debug-09b50e0',root/'build/cubic-client-final-ps1-debug-world-fixed-fabulous-gl32']:
    for name in ['inputs.json','launch.json','options.txt','presentation-ok.json']:
        p=runtime/name
        if p.exists():add(p)
    for folder in ['presentation-frames','presentation-failure','crash-reports']:
        for p in (runtime/folder).glob('*'):
            if p.is_file():add(p)
for case in cases:
    for suffix in ['.exit','-prepare.log','-display.txt','-xvfb.log']:add(work/(case+suffix))
for p in (root/'scripts/v8').glob('ps1*'):
    if p.is_file():add(p)
for relative in ['src/main/java/com/terminaldetector/drmd/client/presentation/ScenePresentation.java','src/main/java/com/terminaldetector/drmd/mixin/client/DebugWorldRasterMixin.java','src/main/resources/drmd.mixins.json','src/cubiccheck/java/com/terminaldetector/drmd/gate/NativePresentationCheck.java','docs/v8/PS1_PRESENTATION_WIP.md']:add(root/relative)
oldReceipt=root/'docs/v8/EVIDENCE/ps1-target-703ea85.json';add(oldReceipt)
official=Path('/workspace/ungravity-v5/ufo-body-physics/scripts/v5/prepare_cubic_client.py')
for runtime in runtimePaths:assert sha(official)==json.loads((runtime/'inputs.json').read_text())['officialStagerSha256']
add(official,'official_stager/prepare_cubic_client.py')
manifest={name:sha(p) for name,p in sorted(files.items())}
dest=root/'docs/v8/EVIDENCE/ps1-debug-7df89aa.zip';dest.parent.mkdir(parents=True,exist_ok=True);assert not dest.exists()
with zipfile.ZipFile(dest,'x',zipfile.ZIP_DEFLATED) as z:
    for name,p in sorted(files.items()):z.write(p,name)
    z.writestr('MANIFEST.json',json.dumps(dict(source=source,productionSource=production,files=manifest),indent=2))
with zipfile.ZipFile(dest) as z:
    assert z.testzip() is None
    for name,digest in manifest.items():assert hashlib.sha256(z.read(name)).hexdigest()==digest,name
receipt=dict(source=source,productionSource=production,jars=stamp['jars'],unit=summary['unit'],nativeStrictCases=cases,imagesInspected=18,firstNegative=summary['firstNegative'],scope=summary['scope'],openViewmodelDifference=summary['openViewmodelDifference'],archive=str(dest.relative_to(root)),archiveSha256=sha(dest),verifiedFiles=len(manifest),crcAndHashesVerified=True,releaseAccepted=False)
dest.with_suffix('.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
