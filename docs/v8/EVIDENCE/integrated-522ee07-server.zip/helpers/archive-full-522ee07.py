from pathlib import Path
import hashlib,json,tarfile,xml.etree.ElementTree as ET,zipfile
root=Path.cwd();full=root/'work/multi-agent/integrated-522ee07';source='522ee0765fe1a439b0a079120d5282f498c64533'
out=root/'docs/v8/EVIDENCE/integrated-522ee07-server.zip';assert not out.exists()
sha=lambda b:hashlib.sha256(b).hexdigest();stamp=json.loads((full/'verified-build.json').read_text());assert stamp['sourceSha']==source
counts=json.loads((full/'counts.json').read_text());assert counts=={'unit':dict(tests=866,failures=0,errors=0,skipped=0),'game':dict(tests=450,failures=0,errors=0,skipped=0)}
with tarfile.open(full/'unit-results.tar.gz') as t:cases=[c for m in t.getmembers() if m.name.endswith('.xml') for c in ET.fromstring(t.extractfile(m).read()).iter('testcase')]
assert len(cases)==866 and all(c.find('failure') is None and c.find('error') is None and c.find('skipped') is None for c in cases)
cases=list(ET.parse(full/'full-game-results.xml').getroot().iter('testcase'));assert len(cases)==450 and all(c.find('failure') is None and c.find('error') is None and c.find('skipped') is None for c in cases)
assert len(json.loads((full/'processed-full-manifest.json').read_text())['entrypoints']['fabric-gametest'])==73
for p,h in stamp['jars'].items():
    assert sha(Path(p).read_bytes())==h
    with zipfile.ZipFile(p) as z:assert z.testzip() is None
fresh=json.loads((full/'report-freshness.json').read_text());assert fresh['gameReportExists'] and fresh['gameReportMtimeNs']>=fresh['startNs']
payload={'full/'+p.name:p.read_bytes() for p in full.iterdir() if p.is_file()}
payload['helpers/'+Path(__file__).name]=Path(__file__).read_bytes()
for name in ['integrated-522ee07-outer-executed.sh','integrated-522ee07-full-executed.sh','integrated-522ee07-prelaunch-source-rejection.json','integrated-522ee07-outer.exit']:
    p=root/'work/multi-agent'/name;payload['outer/'+name]=p.read_bytes()
p=root/'work/ufo-body/integrated-522ee07-closed-world.json';payload['world/closed-world-receipt.json']=p.read_bytes()
artifacts=full/'artifacts';artifacts.mkdir(exist_ok=False)
for name,h in stamp['jars'].items():
    p=root/name;b=p.read_bytes();assert sha(b)==h;(artifacts/p.name).write_bytes(b)
    payload['artifacts/'+p.name]=b
summary=dict(source=source,unit=counts['unit'],game=counts['game'],entrypoints=73,jars=stamp['jars'],gameReportFresh=True,
    scope='Actual866-unit/450-ordinary-server/73-entrypoint source522ee07 and remapped artifacts. Three non-autostart siege data/state files are the only production delta from accepted20ef2c4. No new candidate client was executed; accepted20ef2c4 two-client proof belongs to its own earlier bytes. TestServer enables discoverable legacy Advanced registry pack; this does not establish default Vanilla bounds. Dedicated surface Vanilla2 and legacy tall8 remain separate. No native/performance/full specification/release acceptance inherited.',releaseAccepted=False)
payload['SUMMARY.json']=(json.dumps(summary,indent=2)+'\n').encode();manifest={n:sha(b) for n,b in sorted(payload.items())}
with zipfile.ZipFile(out,'x',zipfile.ZIP_DEFLATED) as z:
    for n,b in sorted(payload.items()):z.writestr(n,b)
    z.writestr('MANIFEST.json',json.dumps({'source':source,'files':manifest},indent=2)+'\n')
with zipfile.ZipFile(out) as z:
    assert z.testzip() is None
    for n,h in manifest.items():assert sha(z.read(n))==h
r=dict(archive=str(out.relative_to(root)),sha256=sha(out.read_bytes()),payloadFiles=len(payload),bytes=out.stat().st_size,allHashesAndCrcVerified=True,**summary)
Path('docs/v8/EVIDENCE/integrated-522ee07-server.json').write_text(json.dumps(r,indent=2)+'\n');print({k:r[k] for k in ('archive','sha256','bytes','payloadFiles')})
