# C2 source-only negative contract

Base: canonical fish-integrated bd7389265c028dc265801117b5f5734730c8146c. Completed fish9b and ragdoll6b branches are preserved.

Two dedicated GameTests, no production edits. Only own dedicated class plus one authorized source-manifest registration. Not compiled or run yet.

1. Real Spider/CaveSpider, both original NoGravity flags. Actual ordinary-floor field-entry control must remain clear/supported and keep position/native controller objects. Then all six independent first entries from room centre (>STICK from faces) capture actual position, box, eye, velocity, flags, world registration and navigation/control identity before assertions. Actual teleport/fake contact/erased tangential propulsion fail. Missing ActorFrames orientation is recorded only, never a classifier-only assertion. AI is isolated for this force-pass case; no native AI/roll completion is claimed.
2. A separate sequential batch admits native ordinary-floor pursuit only. Opaque room, actual propagated SKY/BLOCK=0 at starts/targets and actor eyes, no shared time/weather writes. Default AI stays enabled. Cow target is assigned once explicitly (not claimed as natural Spider target choice); no subsequent nav/velocity commands or manual entity ticks. At least60 ordinary actor ticks, >=1m distance improvement, observed navigator activity, retained target/control identity and <=1m observed per-tick step. Missing tick/darkness/target admission is a fixture/AI-admission failure, not wall/ceiling diagnosis.

WorldAccess must report actual FULL availability before any fixture block writes. Bounded fixture-only forced X/Z columns are restored to their previous state; each owned field/actor/block room is cleaned even on failure. Layer2 live wall-vertical and ceiling-tangent pursuit is deliberately absent until ordinary-floor admission actually passes. No Java allowed before the root grants the exact frozen revision.
