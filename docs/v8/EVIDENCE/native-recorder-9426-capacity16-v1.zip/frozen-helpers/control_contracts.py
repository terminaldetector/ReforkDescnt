"""Pure disabled/capacity16 contracts and snapshots; no Java launch or world staging."""
import hashlib
import json
import os
from pathlib import Path
import shlex
import sys

sys.path.insert(0,str(Path(__file__).resolve().parents[2]/'scripts/v8'))

import immutable_native_runner as runner

SOURCE='9426a6549fc91abc8c7e060a2eef9f184742dc3d'
RUNNER_SHA='1946e64f61de6d676f1cf4e09e519e59174fad3356de3eea56e13ed5ab56fc64'
CONTRACTS={
 'disabled':dict(run_id='9426-disabled-v1',scenario='instrumentation-smoke-mounted-disabled-v1',
                 expected='No recorder file or armed log; existing mounted gate cleanly finishes; not an allocation/performance proof'),
 'capacity16':dict(run_id='9426-capacity16-v1',scenario='instrumentation-smoke-mounted-capacity16-v1',
                   expected='Explicit truncated_sample_capacity; each observed series <=16 samples; not full window coverage')}


def properties(args):
    result={}
    for arg in args:
        if arg.startswith(('-Ddrmd.gate.','-Ddrmd.benchmark.')):
            assert '=' in arg,'unsupported implicit flag'
            key,value=arg.split('=',1);assert key not in result,'duplicate controlled property';result[key]=value
    return result


def validate(args,case,env):
    assert case in CONTRACTS
    assert isinstance(args,list) and args and all(isinstance(v,str) for v in args)
    assert args.count('--gameDir')==1,'ambiguous game directory'
    for key in ['JAVA_TOOL_OPTIONS','_JAVA_OPTIONS','JDK_JAVA_OPTIONS']:
        assert not any(a.startswith(('-Ddrmd.gate.','-Ddrmd.benchmark.')) for a in shlex.split(env.get(key,''))), 'controlled Java flags in external environment'
    actual=properties(args)
    expected={'-Ddrmd.gate.mountedMechanisms':'true'}
    if case=='capacity16':
        expected.update({'-Ddrmd.gate.benchmark':'true','-Ddrmd.benchmark.mode':'sidecar',
            '-Ddrmd.benchmark.warmupSeconds':'1','-Ddrmd.benchmark.sampleSeconds':'30','-Ddrmd.benchmark.maxSamples':'16',
            '-Ddrmd.benchmark.runId':CONTRACTS[case]['run_id'],'-Ddrmd.benchmark.scenario':CONTRACTS[case]['scenario']})
    assert actual==expected,'controlled properties differ from frozen case contract'
    return dict(case=case,tested_source=SOURCE,**CONTRACTS[case],controlled_properties=actual,
                timeout_seconds=240,performance_accepted=False,release_accepted=False)


def snapshot(launch,out,case):
    assert not out.exists(),'new run-specific directory required'
    raw=launch.read_bytes();args=json.loads(raw);contract=validate(args,case,os.environ)
    runtime=Path(args[args.index('--gameDir')+1]);assert runtime.resolve()==launch.parent.resolve()
    code=Path(runner.__file__).read_bytes();assert hashlib.sha256(code).hexdigest()==RUNNER_SHA,'enabled executor bytes changed'
    out.mkdir(parents=True)
    for name,value in [('runner.snapshot.py',code),('launch.snapshot.json',raw)]:
        with (out/name).open('xb') as f:f.write(value)
        (out/name).chmod(0o444)
    assert launch.read_bytes()==raw,'launch changed while copying'
    manifest=dict(schema='ungravity.native-runner-snapshot.v1',runtime=str(runtime.resolve()),
        runner_sha256=RUNNER_SHA,launch_sha256=hashlib.sha256(raw).hexdigest(),original_launch_path=str(launch.resolve()),
        original_launch_sha256=hashlib.sha256(raw).hexdigest(),timeout_seconds=240,contract=contract,
        contract_helper_sha256=runner.digest(Path(__file__)),
        note='Case-specific actual input snapshot; execute copied runner only after a separate root grant; no performance acceptance')
    runner.write_new(out/'manifest.json',manifest);(out/'manifest.json').chmod(0o444)


def checked_inputs(root):
    """Keep Java/build inputs pinned while permitting evidence-only commits after9426."""
    from audit_task_evidence import Repository
    repo=Repository(root);head=repo.git('rev-parse','HEAD').decode().strip()
    delta=[p for p in repo.delta(SOURCE,head) if p]
    assert all(p.startswith('docs/v8/') for p in delta),'post9426 non-documentation changes require new source review'
    assert not repo.git('diff','--name-only','HEAD'),'tracked working files changed'
    expected=repo.source_inputs(SOURCE)
    actual={str(p.relative_to(root)):runner.digest(p) for p in [*(root/'src').rglob('*'),root/'build.gradle',root/'settings.gradle',root/'gradle.properties'] if p.is_file()}
    assert expected==actual,'Java/build input bytes differ from tested9426'
    return actual
