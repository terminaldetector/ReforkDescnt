"""Prepare/verify one separately leased disabled or capacity16 control; never launches Java."""
import json
import os
from pathlib import Path
import sys

import control_contracts as controls
import verify_candidate as prior
import immutable_native_runner as runner

ROOT=prior.ROOT
FIRST_BUILD=ROOT/'work/native-benchmark-recorder/lease-9426/verified-build.json'


def locations(case):
    case_id=controls.CONTRACTS[case]['run_id']
    return (ROOT/'work/native-benchmark-recorder'/(case_id+'-stage'),ROOT/'work/native-benchmark-recorder'/case_id,
            ROOT/'build/native-benchmark-9426'/case_id/'cubic-client-automation')


def configure(case):
    stage,run,runtime=locations(case)
    prior.OUT=stage;prior.runtime=lambda _:runtime;prior.frozen=lambda:controls.checked_inputs(ROOT)
    return stage,run,runtime


def prepare(case):
    assert os.environ.get('S16_JAVA_LEASE')=='granted','separate root Java/native control grant required'
    controls.checked_inputs(ROOT);stage,run,runtime=locations(case)
    assert not stage.exists() and not run.exists() and not runtime.exists(),'fresh unique control required'
    stage.mkdir()
    with (stage/'verified-build.json').open('xb') as stream:stream.write(FIRST_BUILD.read_bytes())
    configure(case);prior.checked_stamp()
    old_case='disabled' if case=='disabled' else 'capacity';prior.stage(old_case)
    path=runtime/'launch.json';args=json.loads(path.read_text())
    if case=='capacity16':
        args=[('-Ddrmd.benchmark.runId='+controls.CONTRACTS[case]['run_id'] if a.startswith('-Ddrmd.benchmark.runId=') else
               '-Ddrmd.benchmark.scenario='+controls.CONTRACTS[case]['scenario'] if a.startswith('-Ddrmd.benchmark.scenario=') else a) for a in args]
        path.write_text(json.dumps(args,indent=2)+'\n')
    controls.validate(args,case,os.environ)
    (stage/(old_case+'-staged.json')).rename(stage/'initial-generic-staging.json')
    p=runtime/'inputs.json';inputs=json.loads(p.read_text());inputs.update(scenario=controls.CONTRACTS[case]['scenario'],runId=controls.CONTRACTS[case]['run_id']);p.write_text(json.dumps(inputs,indent=2)+'\n')
    controls.snapshot(path,run,case)
    runner.write_new(stage/'control-preparation.json',dict(case=case,tested_source=controls.SOURCE,
        contract_helper_sha256=runner.digest(Path(controls.__file__)),plan_helper_sha256=runner.digest(Path(__file__)),
        executor_sha256=controls.RUNNER_SHA,control=controls.CONTRACTS[case],runtime=str(runtime),
        scope='One fresh control; original9426 recorded build inputs/JAR bytes reused; no Java process launched by preparation'))


def verify(case):
    stage,run,runtime=configure(case);saved=prior.checked_stamp()
    receipt=json.loads((run/'child-exit.json').read_text());assert receipt['returncode']==0 and not receipt['timed_out'] and not receipt['forced_kill']
    before=json.loads((run/'execution-inputs-before.json').read_text());after=json.loads((run/'execution-inputs-after.json').read_text());assert before==after
    m=json.loads((run/'manifest.json').read_text());assert runner.digest(run/'runner.snapshot.py')==m['runner_sha256']==controls.RUNNER_SHA
    assert runner.digest(run/'launch.snapshot.json')==m['launch_sha256']
    controls.validate(json.loads((run/'launch.snapshot.json').read_text()),case,{})
    assert not list((runtime/'crash-reports').glob('*'))
    gate=json.loads((runtime/'mounted-mechanisms-ok.json').read_text())
    assert gate['frames']==['connected-off','laser-fire','rocket-fire','fire-off-reversed','bearing-detached']
    assert gate['actualUseAndSneakKeys'] and not gate['operatorFollowTeleport'] and not gate['fixtureSuppliedJointOrShots']
    assert len(list((runtime/'mounted-mechanism-frames').glob('*.png')))==5
    for name,wanted in saved['jars'].items():assert runner.digest(runtime/'mods'/Path(name).name)==wanted
    outputs=list((runtime/'benchmark-observations').glob('*.json'))
    if case=='disabled':
        assert not outputs,'disabled recorder wrote output'
        log=(run/'native.log').read_text(errors='replace');assert 'BENCHMARK_RECORDER armed' not in log and 'BENCHMARK_RECORDER wrote' not in log
        outcome=dict(control='PASS_DISABLED_OUTPUT_CONTROL',allocation_measurement_performed=False)
    else:
        assert len(outputs)==1 and outputs[0].name=='benchmark-'+controls.CONTRACTS[case]['run_id']+'.json'
        raw=json.loads(outputs[0].read_text());parsed,_=prior.observations(outputs[0])
        assert 'capture_status=truncated_sample_capacity' in raw['known_issues']
        assert not any('inconsistent JVM heap' in s or 'Non-positive monotonic span' in s for s in raw['known_issues'])
        counts={name:0 if value['values'] is None else len(value['values']) for name,value in raw['samples'].items()}
        assert counts['frame_time_ms']>=1 and counts['heap_used_bytes']>=1
        assert max(counts.values())==16 and all(n<=16 for n in counts.values()),counts
        context=prior.collect(ROOT,controls.SOURCE,ROOT/'build/libs'/(prior.NAME+'.jar'),runtime/'mods',outputs[0],stage/'verified-build.json')
        assert not context['performance_accepted'] and not context['release_accepted']
        runner.write_new(run/'verified-context.json',context)
        outcome=dict(control='PASS_EXPLICIT_CAPACITY16_TRUNCATION',raw_counts=counts,raw_sha256=runner.digest(outputs[0]),full_window_coverage=False)
    runner.write_new(run/'control-outcome.json',dict(source=controls.SOURCE,case=case,run_id=controls.CONTRACTS[case]['run_id'],
        **outcome,child_exit=receipt,performance_accepted=False,full_s16_accepted=False,release_accepted=False))


if __name__=='__main__':
    os.chdir(ROOT);assert len(sys.argv)==3 and sys.argv[2] in controls.CONTRACTS
    if sys.argv[1]=='prepare':prepare(sys.argv[2])
    elif sys.argv[1]=='verify':verify(sys.argv[2])
    else:raise SystemExit('unsupported control-plan action')
