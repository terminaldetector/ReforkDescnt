#!/usr/bin/env bash
set -euo pipefail
cd /workspace/ungravity-v5/ufo-body-physics
case_dir=$1
mode=$2
source_sha=$3
build_input=$4
export ROUND3_GRAPHICS=${ROUND3_GRAPHICS:-3.3/330}
sodium=()
if [[ ${ROUND3_SODIUM:-yes} = yes ]]; then sodium=(--sodium /workspace/ungravity-v5/world/work/gate0/upstream/sodium-fabric-0.8.13+mc1.21.1.jar); fi
mkdir -p "$case_dir"
runtime="$case_dir/cubic-client-automation"
export ROUND2_NATIVE_RUNTIME="$runtime" ROUND2_NATIVE_MODE="$mode" ROUND2_NATIVE_SOURCE="$source_sha"
python3 scripts/v5/prepare_cubic_client.py --server-runtime /workspace/ungravity-v5/world/build/cubic-seed2-gate --runtime "$runtime" --drmd "$build_input/drmd-6dof-1.1.35-ufo-dev.1.jar" --gate "$build_input/drmd-6dof-1.1.35-ufo-dev.1-cubiccheck.jar" --bcc /workspace/Refork-audit/work/master-v5/upstream/bettercubicchunks-fabric-0.1.1+mc1.21.1.jar --api /workspace/.gradle/caches/modules-2/files-2.1/net.fabricmc.fabric-api/fabric-api/0.116.15+1.21.1/d25c793833a90cc028c9a61bc4546cd578a70ce1/fabric-api-0.116.15+1.21.1.jar --java /workspace/jdk21-complete/bin/java --copy-test-world "${sodium[@]}" > "$case_dir/prep.log" 2>&1
python3 - <<'PY'
from pathlib import Path
import hashlib,json,os,shutil,zipfile
runtime=Path(os.environ['ROUND2_NATIVE_RUNTIME'])
donor=Path('build/cubic-client-final-flight-body-current-phase-sodium')
name='libraries/com/mojang/minecraft/1.21.1/minecraft-1.21.1-client.jar'
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
inputs=json.loads((runtime/'inputs.json').read_text())
reference=json.loads((donor/'inputs.json').read_text())
assert sha(runtime/name)==sha(donor/name)
assert next(a['sha256'] for a in inputs['artifacts'] if a['path']==name)==next(a['sha256'] for a in reference['artifacts'] if a['path']==name)
cache='.fabric/remappedJars/minecraft-1.21.1-0.19.5/client-intermediary.jar'
with zipfile.ZipFile(donor/cache) as z:
 assert z.testzip() is None and all(not n.startswith('com/terminaldetector/') for n in z.namelist())
(runtime/cache).parent.mkdir(parents=True)
shutil.copyfile(donor/cache,runtime/cache)
inputs.update(sourceSha=os.environ['ROUND2_NATIVE_SOURCE'],observer=os.environ['ROUND2_NATIVE_MODE'],minecraftIntermediarySHA256=sha(runtime/cache),glOverride=os.environ['ROUND3_GRAPHICS'])
(runtime/'inputs.json').write_text(json.dumps(inputs,indent=2)+'\n')
p=runtime/'launch.json'
args=[a for a in json.loads(p.read_text()) if not a.startswith('-Ddrmd.gate.')]
mode=os.environ['ROUND2_NATIVE_MODE']
if mode!='baseline': args.insert(1,'-Ddrmd.gate.'+mode+'=true')
p.write_text(json.dumps(args,indent=2)+'\n')
PY
display_file="$case_dir/display.txt"
: > "$display_file"
/workspace/xvfb/usr/bin/Xvfb -displayfd 3 -screen 0 1280x1024x24 3>"$display_file" >"$case_dir/xvfb.log" 2>&1 &
display_pid=$!
trap 'kill "$display_pid" 2>/dev/null || true; wait "$display_pid" 2>/dev/null || true' EXIT
for attempt in {1..100}; do kill -0 "$display_pid"; test ! -s "$display_file" || break; sleep .1; done
read -r display_number < "$display_file"
set +e
DISPLAY=:$display_number LIBGL_ALWAYS_SOFTWARE=1 MESA_GL_VERSION_OVERRIDE=${ROUND3_GRAPHICS%/*} MESA_GLSL_VERSION_OVERRIDE=${ROUND3_GRAPHICS#*/} timeout --kill-after=15 --foreground "${ROUND3_TIMEOUT:-310}" python3 -c 'import os,json; from pathlib import Path; p=Path(os.environ["ROUND2_NATIVE_RUNTIME"]); a=json.loads((p/"launch.json").read_text()); os.chdir(p);os.execv(a[0],a)' </dev/null > "$case_dir/native.log" 2>&1
status=$?
printf '%s\n' "$status" > "$case_dir/native.exit"
tail -12 "$case_dir/native.log"
exit "$status"
