# First full orbital placement proof — source handoff only

NO WORKER JAVA EXECUTED. This temporary source is outside frozen canonical files.
Root must snapshot all actual source/helpers/classpath before a separately granted
serial compile/game. No automatic execution/reader/retry is supplied.

Source: src/com/terminaldetector/drmd/OrbitalPlacementProofGameTests.java.
One additional test mod class, not shared source-manifest registration. Init adds
only this source dir and focuses generated metadata, leaves canonical sources alone.
It routes runGametest's workingDir to this /tmp namespace; root must verify ACTUAL
launcher working directory/report location before first execution. Init is source,
not a claim its task DSL or runtime integration has already been compiled.

New first-proof bounds: setup20wall seconds; one local test-only50ms driver
cadence (not global server pacing or tick/sprint/time mutation); <=6000runtime
actual ticks, no reset across warm reopen;6400driver/6500framework. External game
bound360wall+20cleanup. This is PACED STOCK GameTest, not native or performance.
No original production batch/reach/collision/permission condition is relaxed.

The test discloses loading144ordinary stock columns for fixture admission only,
then uses normal connected Creative+realOP2 commands planorbital→READY→apply.
No direct job.tick, session.apply, ledger/controller injection or forced production
loads. Observe cursor and actualCAS counters per real tick (<=64cells/<=1CAS),
require COMPLETE+durably acknowledged/no pending and then read every planned
solid and AIR at256cells/tick, matching registry ID/zeroBE. Actual bounded actor
query confirms zero created actors in the full pilot bounds. Actor/disconnect
cleanup restores ordinary operator entry and closes the EmbeddedChannel.

Then normal cancel→closed I/O→inspect existing explicitly reopens the ACTUAL
manifest/journal, requiring same jobUUID/hash/ORBITAL_PILOT/cursor and every real
world cell unchanged. This is HONEST WARM FILE REOPEN, NOT NEW-JVM/world reload.
The terminal cancelled journal remains a truthful fixture consequence. No cold
active-placement/cold pacing claim or fabricated pre-stop save follows.

Quantitative static upper envelope: eight arc modules have <=9264solid attempts,
hangar<400 and hub<1800; clear route<=8910AIR attempts. Unique plan therefore
<20374cells (runtime records exact counts/hash). At most432occupied pages yields
<751bounded batches before sparse-page splitting, plus<160verification ticks;
6000runtime ticks gives explicit I/O slack without altering the64cell contract.
Real first timeout/failure must be retained; no post-failure deadline expansion.

Suggested root stages (NO commands were run):
1. -I /tmp/ungravity-orbital-placement-proof-20261119/source.init.gradle
   -PorbitalProofStage=compile compileGametestJava
2. Only on compilePASS, freeze actual runtime then SAME init with
   -PorbitalProofStage=game runGametest (all JavaCompile disabled).

Next after a genuine positive: separately scoped real shutdown/new-JVM reopen of
all saved blocks+schema2/owner/instance, then actual 6DoF/normal-movement route
traversal and collision/pacing. No near/mid/far/native/render proof is inferred.
