#!/usr/bin/env bash
set -euo pipefail
cd /workspace/ungravity-v5/ufo-body-physics
export JAVA_HOME=/workspace/jdk21-complete GRADLE_USER_HOME=/workspace/.gradle
export PATH=$JAVA_HOME/bin:$PATH
input=/tmp/ungravity-orbital-placement-proof-20261119
out=/tmp/ungravity-round3/orbital-leased
mkdir -p "$out"
while test ! -f /tmp/ungravity-round3/native-connectedPortal-final/native.exit; do sleep 2; done
git rev-parse HEAD > "$out/source.txt"
git diff --quiet -- src
sha256sum "$input/source.init.gradle" "$input/src/com/terminaldetector/drmd/OrbitalPlacementProofGameTests.java" > "$out/inputs.sha256"
./gradlew --offline --no-daemon -I "$input/source.init.gradle" -PorbitalProofStage=compile compileGametestJava > "$out/compile.log" 2>&1 || { tail -28 "$out/compile.log"; exit 1; }
original=build/gametest
saved=build/gametest.before-round3-orbital
mkdir -p "$out/runtime"
test -d "$original" && test ! -L "$original" && test ! -e "$original/world" && test ! -e "$saved"
mv "$original" "$saved"
restore(){ if test -L "$original" && test "$(readlink "$original")" = "$out/runtime"; then unlink "$original"; mv "$saved" "$original"; fi; }
trap restore EXIT
ln -s "$out/runtime" "$original"
set +e
timeout -k 20 390 ./gradlew --offline --no-daemon -I "$input/source.init.gradle" -PorbitalProofStage=game runGametest > "$out/game.log" 2>&1
status=$?
printf '%s\n' "$status" > "$out/game.exit"
tail -25 "$out/game.log"
exit "$status"
