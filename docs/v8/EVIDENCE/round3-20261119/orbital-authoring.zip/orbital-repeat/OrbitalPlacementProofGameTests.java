package com.terminaldetector.drmd;

import com.mojang.authlib.GameProfile;
import com.terminaldetector.drmd.world.fixture.city.*;
import com.terminaldetector.drmd.world.access.WorldAccess;
import io.netty.channel.embedded.EmbeddedChannel;
import net.fabricmc.fabric.api.gametest.v1.FabricGameTest;
import net.minecraft.entity.Entity;
import net.minecraft.network.*;
import net.minecraft.registry.Registries;
import net.minecraft.server.OperatorEntry;
import net.minecraft.server.network.*;
import net.minecraft.test.*;
import net.minecraft.util.TypeFilter;
import net.minecraft.util.math.*;
import net.minecraft.world.GameMode;
import java.util.*;
import java.util.concurrent.locks.LockSupport;

/** Separately focused PACED STOCK GameTest; not native, performance or cold-JVM proof. */
public final class OrbitalPlacementProofGameTests implements FabricGameTest {
    @GameTest(templateName=EMPTY_STRUCTURE,batchId="orbital-full-placement",tickLimit=6500)
    public void fullNormalOrbitalAuthoringAndExplicitWarmReopen(TestContext c){
        var driver=new Driver(c);c.runAtEveryTick(()->{
            if(driver.closed)return;
            try{driver.tick();}catch(RuntimeException|Error bad){driver.close();throw bad;}
        });
    }
    private static final class Driver {
        final TestContext c;final net.minecraft.server.world.ServerWorld w;
        final long began=System.nanoTime();long previousNano,lastGame=-1,runtimeStarted=-1,lastCursor,verifyCursor;int phase;
        final CityBlueprint.Point anchor;final CityBlueprint.Plan expected;
        ServerPlayerEntity owner;EmbeddedChannel channel;OperatorEntry previousOp;CityRuntimeSession session;
        java.util.UUID planId;boolean closed;long lastCas;int maxCursorDelta,maxCasDelta;
        Driver(TestContext c){
            this.c=c;w=c.getWorld();
            int y=Math.max(w.getBottomY()+48,Math.min(w.getSeaLevel()+96,w.getTopY()-80));
            BlockPos a=c.getAbsolutePos(new BlockPos(0,0,0));anchor=new CityBlueprint.Point(Math.floorDiv(a.getX(),16)*16,y,Math.floorDiv(a.getZ(),16)*16);
            int min=(int)Math.max(-29_999_984,Math.ceil(w.getWorldBorder().getBoundWest()));int max=(int)Math.min(29_999_983,Math.floor(w.getWorldBorder().getBoundEast())-1);
            expected=OrbitalRouteBlueprint.create(2,anchor,new CityBlueprint.Limits(w.getBottomY(),w.getTopY(),min,max,
                (int)Math.max(-29_999_984,Math.ceil(w.getWorldBorder().getBoundNorth())),(int)Math.min(29_999_983,Math.floor(w.getWorldBorder().getBoundSouth())-1)));
            c.assertTrue(WorldAccess.of(w).backend()==com.terminaldetector.drmd.world.access.CubicAvailability.Backend.STOCK,"this first placement fixture is explicitly STOCK; native needs its own gate");
        }
        void command(String text){w.getServer().getCommandManager().executeWithPrefix(owner.getCommandSource(),text);}
        void event(String name){
            var row=new LinkedHashMap<String,Object>();row.put("event",name);row.put("gameTick",c.getTick());row.put("worldTime",w.getTime());row.put("wallNanos",System.nanoTime()-began);row.put("phase",phase);
            row.put("anchor",anchor);row.put("planHash",expected.hash());row.put("solids",expected.solidCount());row.put("cuts",expected.cutCount());row.put("verifiedCells",verifyCursor);row.put("maxCursorDelta",maxCursorDelta);row.put("maxCasDelta",maxCasDelta);
            if(owner!=null)row.put("owner",owner.getUuid().toString());if(session!=null){var s=session.inspect();row.put("state",s.state().name());row.put("detail",s.detail());s.job().ifPresent(j->{row.put("cursor",j.cursor());row.put("total",j.total());row.put("authoring",j.state().name());});}
            System.out.println("ORBITAL_FULL_PLACEMENT="+new com.google.gson.Gson().toJson(row));
        }
        void tick(){
            // This one focused driver is paced. No global server tick/sprint/clock override.
            long now=System.nanoTime();
            if(previousNano!=0){
                long deadline=previousNano+50_000_000L;
                while(now<deadline){
                    if(Thread.currentThread().isInterrupted())throw new IllegalStateException("orbital proof tick interrupted");
                    LockSupport.parkNanos(deadline-now);
                    now=System.nanoTime();
                }
            }
            now=System.nanoTime();if(previousNano!=0)c.assertTrue(now-previousNano>=49_000_000L,"actual paced-driver monotonic receipt >=49ms");previousNano=now;
            if(lastGame>=0)c.assertTrue(c.getTick()==lastGame+1,"consecutive real GameTest ticks");lastGame=c.getTick();
            c.assertTrue(c.getTick()<6400,"fixed first proof6400driver ticks within6500framework");
            if(runtimeStarted>=0)c.assertTrue(c.getTick()-runtimeStarted<=6000,"fixed6000runtime ticks; no budget reset through warm reopen");
            else c.assertTrue(now-began<=20_000_000_000L,"fixture setup20wall deadline");
            if(phase==0){
                // Disclosed test-only ordinary column admission, never production authoring tickets.
                for(int x=-6;x<=5;x++)for(int z=-6;z<=5;z++)w.getChunk((anchor.x()>>4)+x,(anchor.z()>>4)+z);
                connect();runtimeStarted=c.getTick();event("144_FIXTURE_COLUMNS_AND_REAL_OP2_CONNECTED");
                command("ungravitycity planorbital 2 "+anchor.x()+" "+anchor.y()+" "+anchor.z());
                session=CityAuthoringSystem.active(owner).orElseThrow();phase=1;return;
            }
            var state=session.inspect();
            c.assertTrue(state.state()!=CityRuntimeSession.State.FAILED,"first actual authoring failure: "+state.detail());
            if(phase==1){
                if(state.state()!=CityRuntimeSession.State.READY)return;
                var manifest=state.manifest().orElseThrow();c.assertTrue(manifest.kind()==CityManifest.Kind.ORBITAL_PILOT&&manifest.identity().planHash().equals(expected.hash()),"normal command bound actual orbital plan/context");
                planId=manifest.identity().jobId();event("ACTUAL_READY_INERT");command("ungravitycity apply");phase=2;return;
            }
            if(phase==2){
                var job=state.job().orElseThrow();long cursor=job.cursor(),calls=state.storage().orElseThrow().casCalls();
                maxCursorDelta=Math.max(maxCursorDelta,(int)(cursor-lastCursor));maxCasDelta=Math.max(maxCasDelta,(int)(calls-lastCas));
                c.assertTrue(cursor>=lastCursor&&cursor-lastCursor<=64&&calls>=lastCas&&calls-lastCas<=1,"existing64cell/oneCAS per actual tick limits remain");lastCursor=cursor;lastCas=calls;
                if(job.state()!=CityAuthoringJob.State.COMPLETED)return;
                c.assertTrue(cursor==expected.cells().size()&&job.pending().isEmpty(),"all original geometry durably committed without pending batch");event("FULL_ACTUAL_PLACEMENT_COMPLETE");phase=3;return;
            }
            if(phase==3||phase==6){
                var access=WorldAccess.of(w);int limit=(int)Math.min(expected.cells().size(),verifyCursor+256);
                while(verifyCursor<limit){var cell=expected.cells().get((int)verifyCursor++);var p=cell.position();var actual=access.readIfLoaded(new BlockPos(p.x(),p.y(),p.z())).orElseThrow();
                    c.assertTrue(Registries.BLOCK.getId(actual.getBlock()).toString().equals(cell.state())&&!actual.hasBlockEntity(),"every actual loaded final cell matches expected state: "+p);}
                if(verifyCursor<expected.cells().size())return;
                var actors=new ArrayList<Entity>(1);w.collectEntitiesByType(TypeFilter.instanceOf(Entity.class),new Box(anchor.x()-67,anchor.y(),anchor.z()-67,anchor.x()+68,anchor.y()+35,anchor.z()+68),e->e!=owner&&!e.isRemoved(),actors,1);
                c.assertTrue(actors.isEmpty(),"pilot creates zero actors");
                if(phase==3){event("ALL_CELLS_VERIFIED_BEFORE_WARM_REOPEN");command("ungravitycity cancel");phase=4;return;}
                event("WARM_REOPEN_ALL_ACTUAL_CELLS_UNCHANGED_NOT_COLD_JVM");close();c.complete();return;
            }
            if(phase==4){
                if(!session.settled())return;
                command("ungravitycity inspect");session=CityAuthoringSystem.active(owner).orElseThrow();phase=5;return;
            }
            if(phase==5){
                if(state.manifest().isEmpty()||state.job().isEmpty())return;
                var manifest=state.manifest().orElseThrow();var job=state.job().orElseThrow();
                c.assertTrue(manifest.kind()==CityManifest.Kind.ORBITAL_PILOT&&manifest.identity().jobId().equals(planId)&&manifest.identity().planHash().equals(expected.hash())&&job.cursor()==expected.cells().size(),"real manifest/journal reopens same completed geometry identity; no fresh plan");
                verifyCursor=0;event("ACTUAL_WARM_MANIFEST_JOURNAL_REOPEN");phase=6;
            }
        }
        void connect(){
            var profile=new GameProfile(UUID.randomUUID(),"orbital-full");var data=ConnectedClientData.createDefault(profile,false);owner=new ServerPlayerEntity(w.getServer(),w,profile,data.syncedOptions());
            var connection=new ClientConnection(NetworkSide.SERVERBOUND);channel=new EmbeddedChannel(connection);var pm=w.getServer().getPlayerManager();previousOp=pm.getOpList().get(profile);pm.onPlayerConnect(connection,owner,data);
            pm.getOpList().add(new OperatorEntry(profile,2,false));owner.changeGameMode(GameMode.CREATIVE);
            c.assertTrue(pm.getPlayer(owner.getUuid())==owner&&w.getEntity(owner.getUuid())==owner&&owner.hasPermissionLevel(2),"actual connected Creative authority and identity");
        }
        void close(){
            if(closed)return;closed=true;
            if(owner!=null){
                CityAuthoringSystem.active(owner).ifPresent(s->s.cancel(owner.getUuid()));var pm=w.getServer().getPlayerManager();var profile=owner.getGameProfile();
                if(previousOp!=null)pm.getOpList().add(previousOp);else if(pm.isOperator(profile))pm.removeFromOperators(profile);
                if(pm.getPlayer(owner.getUuid())==owner)pm.remove(owner);owner.discard();
            }
            if(channel!=null)channel.finishAndReleaseAll();
        }
    }
}
