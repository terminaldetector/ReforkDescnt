package com.terminaldetector.drmd.climber.mixin;

import com.terminaldetector.drmd.climber.ClimberCornerTrace;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(targets="com.terminaldetector.drmd.world.gravity.LocalSurfaceGeometry",remap=false)
public abstract class SurfaceGeometryCornerProbe {
    @Inject(method="supported",at=@At("RETURN"),remap=false)
    private static void support(LivingEntity actor,Vec3d feet,Vec3d up,CallbackInfoReturnable<Boolean> cir){
        ClimberCornerTrace.guard(actor,"EXISTING_SUPPORTED_RETURN",feet,feet,up,false,cir.getReturnValue());
    }
    @Inject(method="clear",at=@At("RETURN"),remap=false)
    private static void clearance(LivingEntity actor,Vec3d from,Vec3d to,Vec3d up,boolean margin,CallbackInfoReturnable<Boolean> cir){
        ClimberCornerTrace.guard(actor,"EXISTING_CLEAR_RETURN",from,to,up,margin,cir.getReturnValue());
    }
}
