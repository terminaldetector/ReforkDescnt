package com.terminaldetector.drmd.climber;

import com.terminaldetector.drmd.world.gravity.LocalSurfacePath;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.pathing.Path;
import net.minecraft.entity.mob.SpiderEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.*;
import java.lang.ref.WeakReference;
import java.util.*;

/** Two actual barrier actors only; passive finite histories of native/local navigation boundaries. */
public final class ClimberCornerTrace {
    public static final boolean ENABLED=Boolean.getBoolean("drmd.gate.climberReadiness");
    private static final int MAX_ACTORS=2,MAX_FOLLOW=120,MAX_TRANSITIONS=512,MAX_GUARDS=8;
    private static final Map<UUID,Arm> ARMS=new LinkedHashMap<>();
    private static final ThreadLocal<Follow> ACTIVE=new ThreadLocal<>();
    private static final class Arm {
        final WeakReference<SpiderEntity> owner;final Map<String,Integer> phases=new LinkedHashMap<>();
        final ArrayDeque<Map<String,Object>> follows=new ArrayDeque<>(),transitions=new ArrayDeque<>();
        final List<Map<String,Object>> firstFalse=new ArrayList<>(),firstTransitions=new ArrayList<>(),firstInvalidates=new ArrayList<>();
        int followCalls,transitionCalls,guardCalls,followOverflow,transitionOverflow,reentrantOverflow;boolean finished;
        Arm(SpiderEntity actor){owner=new WeakReference<>(actor);}
    }
    private static final class Follow {
        final Arm arm;final SpiderEntity actor;final LocalSurfacePath path;final Map<String,Object> row;
        final List<Map<String,Object>> guards=new ArrayList<>();int calls;
        Follow(Arm arm,SpiderEntity actor,LocalSurfacePath path,double speed){this.arm=arm;this.actor=actor;this.path=path;
            row=new LinkedHashMap<>();row.put("ordinal",arm.followCalls);row.put("speed",speed);row.put("before",snapshot(actor,path));}
    }
    private ClimberCornerTrace(){}
    public static void arm(SpiderEntity actor){
        if(!ENABLED)return;if(ARMS.size()>=MAX_ACTORS)throw new IllegalStateException("corner observer actor cap2 exceeded");
        ARMS.put(actor.getUuid(),new Arm(actor));
    }
    private static Arm arm(LivingEntity actor){
        if(!ENABLED)return null;var arm=ARMS.get(actor.getUuid());
        return arm!=null&&arm.owner.get()==actor&&!arm.finished&&actor.getWorld()instanceof ServerWorld world
            &&world.getServer().isOnThread()&&world.getEntityById(actor.getId())==actor?arm:null;
    }
    public static void before(SpiderEntity actor,LocalSurfacePath path,double speed){
        var arm=arm(actor);if(arm==null)return;arm.followCalls++;
        if(arm.followCalls>MAX_FOLLOW){arm.followOverflow++;return;}
        if(ACTIVE.get()!=null){arm.reentrantOverflow++;return;}
        ACTIVE.set(new Follow(arm,actor,path,speed));
    }
    public static void after(SpiderEntity actor,LocalSurfacePath path,boolean result){
        var follow=ACTIVE.get();if(follow==null||follow.actor!=actor||follow.path!=path)return;ACTIVE.remove();
        follow.row.put("returned",result);follow.row.put("after",snapshot(actor,path));follow.row.put("actualGuardCalls",follow.calls);
        follow.row.put("guardCap",MAX_GUARDS);follow.row.put("existingGuardReturns",follow.guards);
        if(!result&&follow.arm.firstFalse.size()<4)follow.arm.firstFalse.add(follow.row);
        follow.arm.follows.addLast(follow.row);while(follow.arm.follows.size()>8)follow.arm.follows.removeFirst();
    }
    public static void guard(LivingEntity actor,String phase,Vec3d from,Vec3d to,Vec3d up,boolean margin,boolean returned){
        var follow=ACTIVE.get();if(follow==null||follow.actor!=actor)return;follow.arm.guardCalls++;follow.calls++;
        if(follow.calls>MAX_GUARDS)return;var row=new LinkedHashMap<String,Object>();row.put("phase",phase);row.put("returned",returned);
        row.put("from",vector(from));row.put("to",vector(to));row.put("up",vector(up));row.put("margin",margin);
        row.put("actualAge",actor.age);row.put("worldTick",actor.getWorld().getTime());follow.guards.add(row);
    }
    public static void transition(SpiderEntity actor,String phase,Set<BlockPos> targets,Path returned){
        var arm=arm(actor);if(arm==null)return;arm.transitionCalls++;arm.phases.merge(phase,1,Integer::sum);
        if(arm.transitionCalls>MAX_TRANSITIONS){arm.transitionOverflow++;return;}
        var row=snapshot(actor,actor.getNavigation().getCurrentPath());row.put("phase",phase);row.put("ordinal",arm.transitionCalls);
        row.put("requested",targets.stream().limit(16).map(ClimberCornerTrace::block).toList());row.put("returnedPath",path(actor,returned));
        if(arm.firstTransitions.size()<8)arm.firstTransitions.add(row);
        if(phase.startsWith("INVALIDATE")&&arm.firstInvalidates.size()<4)arm.firstInvalidates.add(row);
        arm.transitions.addLast(row);while(arm.transitions.size()>16)arm.transitions.removeFirst();
    }
    public static void finish(SpiderEntity actor){
        if(!ENABLED)return;var arm=ARMS.get(actor.getUuid());
        if(arm==null||arm.owner.get()!=actor||arm.finished)return;
        arm.finished=true;var row=snapshot(actor,actor.getNavigation().getCurrentPath());
        row.put("uuid",actor.getUuid().toString());row.put("type",actor.getType().toString());row.put("actualFollowCalls",arm.followCalls);
        row.put("actualTransitionCalls",arm.transitionCalls);row.put("actualGuardCalls",arm.guardCalls);row.put("transitionPhases",arm.phases);
        row.put("followOverflow",arm.followOverflow);row.put("transitionOverflow",arm.transitionOverflow);row.put("reentrantOverflow",arm.reentrantOverflow);
        row.put("followScopeCap",MAX_FOLLOW);row.put("transitionCallCap",MAX_TRANSITIONS);row.put("last8Follows",List.copyOf(arm.follows));
        row.put("first4FalseFollows",arm.firstFalse);row.put("first8Transitions",arm.firstTransitions);
        row.put("last16Transitions",List.copyOf(arm.transitions));row.put("first4Invalidations",arm.firstInvalidates);
        row.put("noAdditionalGeometryQueries",true);System.out.println("CLIMBER_CORNER_LIFECYCLE "+new com.google.gson.Gson().toJson(row));
    }
    private static Map<String,Object> snapshot(SpiderEntity actor,Path observed){
        var row=new LinkedHashMap<String,Object>();row.put("actualAge",actor.age);row.put("worldTick",actor.getWorld().getTime());row.put("nanos",System.nanoTime());
        row.put("alive",actor.isAlive());row.put("removed",actor.isRemoved());row.put("worldOwnerMatches",actor.getWorld().getEntityById(actor.getId())==actor);
        row.put("position",vector(actor.getPos()));row.put("bounds",bounds(actor.getBoundingBox()));row.put("eye",vector(actor.getEyePos()));
        row.put("velocity",vector(actor.getVelocity()));row.put("onGround",actor.isOnGround());row.put("observedPath",path(actor,observed));
        var nav=actor.getNavigation();row.put("currentNativePath",path(actor,nav.getCurrentPath()));row.put("nativeNavigationIdle",nav.isIdle());
        row.put("nativeNavigationTarget",block(nav.getTargetPos()));var target=actor.getTarget();row.put("actualTarget",target==null?null:target.getUuid().toString());
        row.put("actualTargetPosition",target==null?null:vector(target.getPos()));row.put("actualTargetSquaredDistance",target==null?null:actor.squaredDistanceTo(target));
        var motor=actor.getMoveControl();row.put("nativeMotorMoving",motor.isMoving());row.put("nativeMotorSpeed",motor.getSpeed());
        row.put("nativeMotorWanted",List.of(motor.getTargetX(),motor.getTargetY(),motor.getTargetZ()));
        row.put("forwardSpeed",actor.forwardSpeed);row.put("sidewaysSpeed",actor.sidewaysSpeed);row.put("upwardSpeed",actor.upwardSpeed);
        try{row.put("boundedCache",ClimberRequestTrace.state(actor));}
        catch(ReflectiveOperationException failure){throw new IllegalStateException("read-only corner cache ABI mismatch",failure);}return row;
    }
    private static Map<String,Object> path(SpiderEntity actor,Path path){
        if(path==null)return null;var row=new LinkedHashMap<String,Object>();row.put("identity",System.identityHashCode(path));row.put("class",path.getClass().getName());
        row.put("index",path.getCurrentNodeIndex());row.put("length",path.getLength());row.put("finished",path.isFinished());row.put("target",block(path.getTarget()));
        if(path instanceof LocalSurfacePath||!path.isFinished()){var waypoint=path.getNodePosition(actor);row.put("waypoint",vector(waypoint));row.put("feetDistance",actor.getPos().distanceTo(waypoint));}
        return row;
    }
    private static List<Double> vector(Vec3d p){return List.of(p.x,p.y,p.z);}
    private static List<Integer> block(BlockPos p){return p==null?null:List.of(p.getX(),p.getY(),p.getZ());}
    private static List<Double> bounds(Box b){return List.of(b.minX,b.minY,b.minZ,b.maxX,b.maxY,b.maxZ);}
}
