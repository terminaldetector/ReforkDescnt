package com.terminaldetector.drmd.climber;

import com.terminaldetector.drmd.world.access.WorldAccess;
import net.minecraft.entity.Entity;
import net.minecraft.entity.mob.SpiderEntity;
import net.minecraft.registry.Registries;
import net.minecraft.server.world.*;
import net.minecraft.test.TestContext;
import net.minecraft.util.math.*;
import net.minecraft.util.thread.TaskExecutor;
import net.minecraft.world.LightType;
import java.lang.reflect.Field;
import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;

/** Focused-only snapshots of existing fixture reads. No lighting work, waits or admission changes. */
public final class ClimberRoomReadinessTrace {
    public static final boolean ENABLED=Boolean.getBoolean("drmd.gate.climberReadiness");
    private static final int MAX_ROOMS=3,MAX_CALLS=4096,MAX_SHELL_READS=12;
    private static int rooms,shellReads;
    public static final class Room {
        final int id;final TestContext context;final ServerWorld world;final BlockPos min,max;
        final long created=System.nanoTime();long buildStart,buildEnd,firstDark;
        int readyCalls,readyTrue,darkCalls,darkFailures,lightCalls;boolean barrier,closed,overflow;
        final List<Map<String,Object>> firstFailures=new ArrayList<>();
        final ArrayDeque<Map<String,Object>> lastFailures=new ArrayDeque<>();
        final Map<String,Integer> lightCounts=new LinkedHashMap<>();Map<String,Object> current,last;
        Room(TestContext context,ServerWorld world,BlockPos min,BlockPos max){id=++rooms;this.context=context;this.world=world;this.min=min.toImmutable();this.max=max.toImmutable();}
    }
    private ClimberRoomReadinessTrace(){}
    public static Room room(TestContext c,ServerWorld world,BlockPos min,BlockPos max){
        if(!ENABLED)return null;if(rooms>=MAX_ROOMS)throw new IllegalStateException("readiness room cap3 exceeded");
        return new Room(c,world,min,max);
    }
    public static void build(Room r,boolean barrier,boolean built,boolean before){
        if(r==null)return;if(before&&!built){r.barrier=barrier;r.buildStart=System.nanoTime();}
        if(!before&&built&&r.buildEnd==0)r.buildEnd=System.nanoTime();
    }
    public static void ready(Room r,boolean result){if(r!=null){r.readyCalls++;if(result)r.readyTrue++;}}
    public static void darkBefore(Room r,Vec3d eye,boolean built){
        if(r==null)return;r.darkCalls++;if(r.firstDark==0)r.firstDark=System.nanoTime();
        if(r.darkCalls>MAX_CALLS){r.overflow=true;r.current=null;return;}
        var row=clock(r);row.put("eye",vector(eye));row.put("at",block(BlockPos.ofFloored(eye)));
        row.put("built",built);row.put("existingLightReturns",new LinkedHashMap<String,Integer>());r.current=row;
    }
    /** Called after the single original read, preserving its result and short-circuit evaluation. */
    @SuppressWarnings("unchecked") public static void light(Room r,LightType type,BlockPos at,int value){
        if(r==null)return;r.lightCalls++;r.lightCounts.merge(type.toString(),1,Integer::sum);
        if(r.current!=null){((Map<String,Integer>)r.current.get("existingLightReturns")).put(type.toString(),value);r.current.put("actualReadAt",block(at));}
    }
    public static void darkAfter(Room r,boolean result){
        if(r==null)return;if(!result)r.darkFailures++;var row=r.current;r.current=null;if(row==null)return;
        row.put("actualDarkReturn",result);row.put("returnNanos",System.nanoTime());row.put("missingLightTypesAreUnobservedNeverAssumedZero",true);
        r.last=row;if(result)return;row.put("nativeLightSnapshot",lighting(r.world));
        if(r.firstFailures.size()<4)r.firstFailures.add(row);r.lastFailures.addLast(row);while(r.lastFailures.size()>4)r.lastFailures.removeFirst();
    }
    public static void spawned(Room r,Entity entity){if(r!=null&&r.barrier&&entity instanceof SpiderEntity actor)ClimberCornerTrace.arm(actor);}
    public static void close(Room r,List<Entity> actors,boolean built,boolean closed){
        if(r==null||r.closed)return;r.closed=true;
        var row=clock(r);row.put("built",built);row.put("nativeClosedBeforeCleanup",closed);row.put("barrier",r.barrier);
        row.put("buildStartNanos",r.buildStart);row.put("buildEndNanos",r.buildEnd);row.put("firstDarkNanos",r.firstDark);
        row.put("actualReadyCalls",r.readyCalls);row.put("actualReadyTrue",r.readyTrue);row.put("actualDarkCalls",r.darkCalls);
        row.put("actualDarkFailures",r.darkFailures);row.put("actualLightCalls",r.lightCalls);row.put("lightTypeCounts",r.lightCounts);
        row.put("callCap",MAX_CALLS);row.put("overflow",r.overflow);row.put("first4Failures",r.firstFailures);row.put("last4Failures",List.copyOf(r.lastFailures));
        row.put("lastDarkCall",r.last);row.put("spawnedEntities",actors.size());row.put("nativeLightAtClose",lighting(r.world));
        row.put("shellSamples",actors.isEmpty()&&built&&!r.lastFailures.isEmpty()?shell(r):List.of());
        row.put("globalShellReadCount",shellReads);row.put("globalShellReadCap",MAX_SHELL_READS);row.put("sampledCellsDoNotProveEntireShell",true);
        System.out.println("CLIMBER_ROOM_READINESS "+new com.google.gson.Gson().toJson(row));
        for(var entity:actors)if(entity instanceof SpiderEntity actor)ClimberCornerTrace.finish(actor);
    }
    private static Map<String,Object> clock(Room r){
        var row=new LinkedHashMap<String,Object>();long now=System.nanoTime();row.put("room",r.id);row.put("contextTick",r.context.getTick());
        row.put("worldTick",r.world.getTime());row.put("nanos",now);row.put("elapsedSinceRoomNanos",now-r.created);
        row.put("elapsedSinceBuildNanos",r.buildEnd==0?null:now-r.buildEnd);row.put("min",block(r.min));row.put("max",block(r.max));return row;
    }
    private static Map<String,Object> lighting(ServerWorld world){
        try{
            var light=world.getChunkManager().getLightingProvider();var row=new LinkedHashMap<String,Object>();
            row.put("snapshotNanos",System.nanoTime());row.put("hasUpdates",light.hasUpdates());
            row.put("pendingTasksSize",((List<?>)read(ServerLightingProvider.class,light,"pendingTasks")).size());
            row.put("ticking",((AtomicBoolean)read(ServerLightingProvider.class,light,"ticking")).get());
            row.put("processorQueueSize",((TaskExecutor<?>)read(ServerLightingProvider.class,light,"processor")).getQueueSize());
            row.put("notAtomicNotAWorkCompletionBarrier",true);return row;
        }catch(ReflectiveOperationException failure){throw new IllegalStateException("read-only lighting metadata ABI mismatch",failure);}
    }
    /** Root-authorized twelve total loaded-only shell samples; never infer the unobserved entire shell. */
    @SuppressWarnings("unchecked") private static List<Map<String,Object>> shell(Room r){
        var positions=new LinkedHashSet<BlockPos>();
        for(var failure:r.lastFailures){var p=(List<Number>)failure.get("at");int x=p.get(0).intValue(),y=p.get(1).intValue(),z=p.get(2).intValue();
            positions.add(new BlockPos(x,r.max.getY(),z));positions.add(new BlockPos(r.min.getX(),y,z));positions.add(new BlockPos(r.max.getX(),y,z));
            positions.add(new BlockPos(x,y,r.min.getZ()));positions.add(new BlockPos(x,y,r.max.getZ()));}
        var rows=new ArrayList<Map<String,Object>>();var access=WorldAccess.of(r.world);
        for(var at:positions){if(shellReads>=MAX_SHELL_READS)break;shellReads++;var state=access.readIfLoaded(at);var row=new LinkedHashMap<String,Object>();
            row.put("at",block(at));row.put("receipt",state.isPresent()?"LOADED_SAMPLE":"UNOBSERVED_UNLOADED");
            row.put("block",state.map(s->Registries.BLOCK.getId(s.getBlock()).toString()).orElse(null));row.put("globalReadOrdinal",shellReads);rows.add(row);}
        return rows;
    }
    private static Object read(Class<?> type,Object owner,String name)throws ReflectiveOperationException{Field f=type.getDeclaredField(name);f.setAccessible(true);return f.get(owner);}
    private static List<Double> vector(Vec3d p){return List.of(p.x,p.y,p.z);}
    private static List<Integer> block(BlockPos p){return List.of(p.getX(),p.getY(),p.getZ());}
}
