package com.terminaldetector.drmd.climber.mixin;

import com.terminaldetector.drmd.climber.ClimberRoomReadinessTrace;
import net.minecraft.entity.Entity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.test.TestContext;
import net.minecraft.util.math.*;
import net.minecraft.world.LightType;
import org.spongepowered.asm.mixin.*;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.*;
import java.util.List;

@Mixin(targets="com.terminaldetector.drmd.ClimberJumpGravityGameTests$Room",remap=false)
public abstract class NewRoomReadinessProbe {
    @Shadow @Final TestContext c;
    @Shadow @Final ServerWorld world;
    @Shadow @Final BlockPos min,max;
    @Shadow @Final List<Entity> actors;
    @Shadow boolean built,closed;
    @Unique private ClimberRoomReadinessTrace.Room drmd$readiness;
    @Inject(method="<init>",at=@At("RETURN"),remap=false)
    private void created(TestContext c,BlockPos centre,CallbackInfo ci){drmd$readiness=ClimberRoomReadinessTrace.room(c,world,min,max);}
    @Inject(method="ready",at=@At("RETURN"),remap=false)
    private void ready(CallbackInfoReturnable<Boolean> cir){ClimberRoomReadinessTrace.ready(drmd$readiness,cir.getReturnValue());}
    @Inject(method="build",at=@At("HEAD"),remap=false)
    private void beforeBuild(boolean barrier,int plateY,CallbackInfo ci){ClimberRoomReadinessTrace.build(drmd$readiness,barrier,built,true);}
    @Inject(method="build",at=@At("RETURN"),remap=false)
    private void afterBuild(boolean barrier,int plateY,CallbackInfo ci){ClimberRoomReadinessTrace.build(drmd$readiness,barrier,built,false);}
    @Inject(method="dark",at=@At("HEAD"),remap=false)
    private void beforeDark(Vec3d eye,CallbackInfoReturnable<Boolean> cir){ClimberRoomReadinessTrace.darkBefore(drmd$readiness,eye,built);}
    @Redirect(method="dark",at=@At(value="INVOKE",target="Lnet/minecraft/server/world/ServerWorld;getLightLevel(Lnet/minecraft/world/LightType;Lnet/minecraft/util/math/BlockPos;)I",remap=true),remap=false)
    private int existingLight(ServerWorld receiver,LightType type,BlockPos at){
        int value=receiver.getLightLevel(type,at);ClimberRoomReadinessTrace.light(drmd$readiness,type,at,value);return value;
    }
    @Inject(method="dark",at=@At("RETURN"),remap=false)
    private void afterDark(Vec3d eye,CallbackInfoReturnable<Boolean> cir){ClimberRoomReadinessTrace.darkAfter(drmd$readiness,cir.getReturnValue());}
    @Inject(method="spawn",at=@At("RETURN"),remap=false)
    private void spawned(Entity actor,CallbackInfo ci){ClimberRoomReadinessTrace.spawned(drmd$readiness,actor);}
    @Inject(method="close",at=@At("HEAD"),remap=false)
    private void closing(CallbackInfo ci){ClimberRoomReadinessTrace.close(drmd$readiness,actors,built,closed);}
}
