package com.terminaldetector.drmd.climber.mixin;

import com.terminaldetector.drmd.climber.ClimberCornerTrace;
import com.terminaldetector.drmd.world.gravity.*;
import net.minecraft.entity.ai.pathing.Path;
import net.minecraft.entity.mob.*;
import net.minecraft.util.math.BlockPos;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.*;
import java.util.Set;

@Mixin(value=LocalSurfaceNavigation.class,remap=false)
public abstract class SurfaceCornerProbe {
    @Inject(method="follow",at=@At("HEAD"),remap=false)
    private static void before(SpiderEntity actor,LocalSurfacePath path,double speed,CallbackInfoReturnable<Boolean> cir){ClimberCornerTrace.before(actor,path,speed);}
    @Inject(method="follow",at=@At("RETURN"),remap=false)
    private static void after(SpiderEntity actor,LocalSurfacePath path,double speed,CallbackInfoReturnable<Boolean> cir){ClimberCornerTrace.after(actor,path,cir.getReturnValue());}
    @Inject(method="request",at=@At("HEAD"),remap=false)
    private static void requestBefore(SpiderEntity actor,Set<BlockPos> targets,float range,CallbackInfoReturnable<Path> cir){ClimberCornerTrace.transition(actor,"REQUEST_BEFORE",targets,null);}
    @Inject(method="request",at=@At("RETURN"),remap=false)
    private static void requestAfter(SpiderEntity actor,Set<BlockPos> targets,float range,CallbackInfoReturnable<Path> cir){ClimberCornerTrace.transition(actor,"REQUEST_AFTER",targets,cir.getReturnValue());}
    @Inject(method="pending",at=@At("HEAD"),remap=false)
    private static void pendingBefore(SpiderEntity actor,CallbackInfo ci){ClimberCornerTrace.transition(actor,"PENDING_BEFORE",Set.of(),null);}
    @Inject(method="pending",at=@At("RETURN"),remap=false)
    private static void pendingAfter(SpiderEntity actor,CallbackInfo ci){ClimberCornerTrace.transition(actor,"PENDING_AFTER",Set.of(),null);}
    @Inject(method="invalidate",at=@At("HEAD"),remap=false)
    private static void invalidateBefore(SpiderEntity actor,CallbackInfo ci){ClimberCornerTrace.transition(actor,"INVALIDATE_BEFORE",Set.of(),null);}
    @Inject(method="invalidate",at=@At("RETURN"),remap=false)
    private static void invalidateAfter(SpiderEntity actor,CallbackInfo ci){ClimberCornerTrace.transition(actor,"INVALIDATE_AFTER",Set.of(),null);}
    @Inject(method="stop",at=@At("HEAD"),remap=false)
    private static void stopBefore(MobEntity actor,CallbackInfo ci){if(actor instanceof SpiderEntity spider)ClimberCornerTrace.transition(spider,"STOP_BEFORE",Set.of(),null);}
    @Inject(method="stop",at=@At("RETURN"),remap=false)
    private static void stopAfter(MobEntity actor,CallbackInfo ci){if(actor instanceof SpiderEntity spider)ClimberCornerTrace.transition(spider,"STOP_AFTER",Set.of(),null);}
}
