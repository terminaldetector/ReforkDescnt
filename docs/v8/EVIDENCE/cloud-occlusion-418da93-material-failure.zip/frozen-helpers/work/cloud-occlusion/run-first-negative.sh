#!/usr/bin/env bash
set +e
cd /workspace/ungravity-v5/ps1-render
bash scripts/v8/ps1_build.sh
build_code=$?
cp work/ps1/verified-build.log work/cloud-occlusion/first-build.log
echo "$build_code" > work/cloud-occlusion/first-build.exit
if [ "$build_code" -ne 0 ]; then exit "$build_code"; fi
cp work/ps1/verified-build.json work/cloud-occlusion/first-build.json
python3 - <<'PY' > work/cloud-occlusion/first-game-parity.log 2>&1
from pathlib import Path
import hashlib
p=Path('build/libs/drmd-6dof-1.1.35-ufo-dev.1.jar');expected='b6c653a4729e7dd4a8158ba1b8704fc31434c89d0c7cabaefbee4e1266d3df8c';actual=hashlib.sha256(p.read_bytes()).hexdigest();assert actual==expected,(actual,expected);print('Observer-only cloud source retains exact accepted palette game bytes',actual)
PY
parity_code=$?
echo "$parity_code" > work/cloud-occlusion/first-game-parity.exit
if [ "$parity_code" -ne 0 ]; then exit "$parity_code"; fi
bash scripts/v8/ps1_native.sh ps1-cloud-attribution-occlusion-first-418da93-sodium
native_code=$?
echo "$native_code" > work/cloud-occlusion/first-native.exit
exit "$native_code"
