package com.terminaldetector.drmd.world.portal.mirror;

import com.terminaldetector.drmd.diag.DiagProblems;
import com.terminaldetector.drmd.entity.ModBlockEntities;
import com.terminaldetector.drmd.world.portal.PortalTravel;
import net.minecraft.block.BlockState;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.network.listener.ClientPlayPacketListener;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.s2c.play.BlockEntityUpdateS2CPacket;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

import java.util.UUID;

/**
 * Link bookkeeping for {@link PortalPanelBlock} — an exact structural copy of
 * {@link ChargedMirrorBlockEntity}, kept as its own class rather than reused directly because
 * {@link net.minecraft.block.entity.BlockEntity}'s constructor is tied to one fixed
 * {@link net.minecraft.block.entity.BlockEntityType}, the same reason {@code ChargedMirrorBlockEntity}
 * itself isn't just {@code MirrorBlockEntity} with extra fields.
 */
public class PortalPanelBlockEntity extends BlockEntity {
    private static Runnable clientChanged=()->{};
    public static void bindClientInvalidation(Runnable callback){clientChanged=callback;}
    private void notifyClient(){if(world!=null && world.isClient)clientChanged.run();}
    @Override public void markRemoved(){
        if(world instanceof ServerWorld server){
            com.terminaldetector.drmd.world.portal.PortalExitInterest.release(server,pos);
            PortalTravel.cancelSource(server,pos);
        }
        super.markRemoved();notifyClient();
    }
    @Override public void setWorld(World world){
        super.setWorld(world);
        if(projectorOwner!=null && world instanceof ServerWorld server)com.terminaldetector.drmd.world.portal.gun.PortalGunState.get(server);
    }
	private UUID attachedEntityId;
	private boolean linked;
	private BlockPos linkPartnerPos;
	private RegistryKey<World> linkPartnerDim;
	private UUID projectorOwner;
	private int projectorSlot;
	public UUID projectorOwner(){return projectorOwner;}
	public int projectorSlot(){return projectorSlot;}
	public void claimProjector(UUID owner,int slot){
		if(owner==null || slot<1 || slot>2)throw new IllegalArgumentException("projector owner/channel");
		projectorOwner=owner;projectorSlot=slot;markDirty();
	}
	public boolean ownedBy(UUID owner,int slot){return owner.equals(projectorOwner) && slot==projectorSlot;}

	public PortalPanelBlockEntity(BlockPos pos, BlockState state) {
		super(ModBlockEntities.PORTAL_PANEL, pos, state);
	}

	public UUID getAttachedEntityId() { return attachedEntityId; }
	public void setAttachedEntityId(UUID id) { this.attachedEntityId = id; markDirty(); }

	public boolean isLinked() { return linked; }
	@Nullable public BlockPos getLinkPartnerPos() { return linkPartnerPos; }
	@Nullable public RegistryKey<World> getLinkPartnerDim() { return linkPartnerDim; }

	public void setLink(UUID attachedEntityId, BlockPos partnerPos, RegistryKey<World> partnerDim) {
		if(world instanceof ServerWorld server){
			com.terminaldetector.drmd.world.portal.PortalExitInterest.release(server,pos);
			PortalTravel.cancelSource(server,pos);
		}
		this.attachedEntityId = attachedEntityId;
		this.linked = true;
		this.linkPartnerPos = partnerPos;
		this.linkPartnerDim = partnerDim;
		markDirty();
	}

	/**
	 * Forget the link: the far end is gone, so there is nothing left to travel to.
	 *
	 * <p>Without this a survivor keeps {@code LINKED} and a partner position pointing at nothing. The
	 * native tick reads that and does nothing, which is safe but leaves a block that says it is linked
	 * and is not. With ImmPtl it is worse than untidy — the far portal entity outlives its own block.
	 */
	public void clearLink() {
		if(world instanceof ServerWorld server){
			com.terminaldetector.drmd.world.portal.PortalExitInterest.release(server,pos);
			PortalTravel.cancelSource(server,pos);
		}
		this.attachedEntityId = null;
		this.linked = false;
		this.linkPartnerPos = null;
		this.linkPartnerDim = null;
		markDirty();
	}

	@Override
	protected void writeNbt(NbtCompound nbt, RegistryWrapper.WrapperLookup registryLookup) {
		super.writeNbt(nbt, registryLookup);
		if(projectorOwner!=null){nbt.putUuid("projectorOwner",projectorOwner);nbt.putInt("projectorSlot",projectorSlot);}
		if (attachedEntityId != null) nbt.putUuid("attached", attachedEntityId);
		nbt.putBoolean("linked", linked);
		if (linkPartnerPos != null) {
			nbt.putInt("partnerX", linkPartnerPos.getX());
			nbt.putInt("partnerY", linkPartnerPos.getY());
			nbt.putInt("partnerZ", linkPartnerPos.getZ());
		}
		if (linkPartnerDim != null) nbt.putString("partnerDim", linkPartnerDim.getValue().toString());
	}

	@Override
	protected void readNbt(NbtCompound nbt, RegistryWrapper.WrapperLookup registryLookup) {
		super.readNbt(nbt, registryLookup);
		projectorSlot=nbt.getInt("projectorSlot");
		projectorOwner=projectorSlot>=1 && projectorSlot<=2 && nbt.containsUuid("projectorOwner")?nbt.getUuid("projectorOwner"):null;
		if(projectorOwner==null)projectorSlot=0;
		attachedEntityId = nbt.containsUuid("attached") ? nbt.getUuid("attached") : null;
		linked = nbt.getBoolean("linked");
		linkPartnerPos = nbt.contains("partnerX")
				? new BlockPos(nbt.getInt("partnerX"), nbt.getInt("partnerY"), nbt.getInt("partnerZ"))
				: null;
		linkPartnerDim = nbt.contains("partnerDim")
				? RegistryKey.of(RegistryKeys.WORLD, Identifier.of(nbt.getString("partnerDim")))
				: null;
        notifyClient();
        if(projectorOwner!=null && world instanceof ServerWorld server)com.terminaldetector.drmd.world.portal.gun.PortalGunState.get(server);
	}

		/** Retire the saved foreign attachment, then perform native travel across the panel span. */
	public static void tick(World world, BlockPos pos, BlockState state, PortalPanelBlockEntity be) {
		if (!(world instanceof ServerWorld serverWorld)) return;
		LegacyPortalEntities.detach(serverWorld, be.attachedEntityId);
        if (!be.linked || be.linkPartnerPos == null) return;
		// Same dimension only — see PortalTravel for why a cross-dimension hop is not this call.
		if (be.linkPartnerDim != null && !be.linkPartnerDim.equals(world.getRegistryKey())) {
			DiagProblems.record("portal", "panel at " + pos + " links to " + be.linkPartnerDim.getValue()
					+ " — native travel is same-dimension only, so it carries nobody");
			return;
		}
		if (!(state.getBlock() instanceof PortalPanelBlock)) return;
		com.terminaldetector.drmd.world.portal.PortalExitInterest.observe(serverWorld,pos,be.linkPartnerPos,PortalPanelBlock.HALF_SPAN);
		PortalTravel.noteSource(serverWorld,pos,state.get(PortalPanelBlock.FACING),be.linkPartnerPos,PortalPanelBlock.HALF_SPAN);

		// A saved link is not permission to load its destination every server tick.
		// Keep the link while the partner is unavailable and retry once it is loaded.
		if (com.terminaldetector.drmd.world.access.WorldAccess.of(world).readIfLoaded(be.linkPartnerPos).isEmpty()) return;
		BlockState partnerState = world.getBlockState(be.linkPartnerPos);
		if (!(partnerState.getBlock() instanceof PortalPanelBlock)) {
			DiagProblems.record("portal", "panel at " + pos + " points at " + be.linkPartnerPos
					+ " where there is no portal panel — the link is dead");
			return;
		}
		if(be.projectorOwner!=null && (!(world.getBlockEntity(be.linkPartnerPos) instanceof PortalPanelBlockEntity partner)
			|| !partner.ownedBy(be.projectorOwner,3-be.projectorSlot) || !partner.linked || !pos.equals(partner.linkPartnerPos)))return;

		PortalTravel.enqueue(serverWorld, pos, state.get(PortalPanelBlock.FACING),
				be.linkPartnerPos, partnerState.get(PortalPanelBlock.FACING), PortalPanelBlock.HALF_SPAN);
	}

	/**
	 * Send the link to the client, not just the {@code LINKED} bit the blockstate already carries.
	 *
	 * <p>That bit was enough while the client only had to draw a linked block differently. Drawing
	 * <em>through</em> one needs to know where it goes — the partner's position, and whether a live
	 * ImmPtl portal is already doing the job — and none of that is in a blockstate. This is
	 * {@code CarvedBlockEntity}'s existing sync idiom, unchanged, on the data this block already writes.
	 */
	@Override
	public NbtCompound toInitialChunkDataNbt(RegistryWrapper.WrapperLookup registries) {
		return createNbt(registries);
	}

	@Override
	public Packet<ClientPlayPacketListener> toUpdatePacket() {
		return BlockEntityUpdateS2CPacket.create(this);
	}
}
