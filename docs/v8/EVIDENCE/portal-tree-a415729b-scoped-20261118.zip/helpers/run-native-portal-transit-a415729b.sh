#!/usr/bin/env bash
set -euo pipefail
cd /workspace/ungravity-v5/ufo-body-physics
scenario=portal-transit-a415729b-sodium-first
out=work/multi-agent/native-transit-a415729b-first
python3 scripts/v8/ps1_build_stamp.py check
test ! -e build/cubic-client-automation
test ! -e "build/cubic-client-final-${scenario}"
test ! -e "build/cubic-client-failed-${scenario}"
PS1_SCENARIO="$scenario" python3 scripts/v8/ps1_prepare.py --server-runtime /workspace/ungravity-v5/world/build/cubic-seed2-gate --runtime build/cubic-client-automation --drmd build/libs/drmd-6dof-1.1.35-ufo-dev.1.jar --gate build/libs/drmd-6dof-1.1.35-ufo-dev.1-cubiccheck.jar --bcc /workspace/Refork-audit/work/master-v5/upstream/bettercubicchunks-fabric-0.1.1+mc1.21.1.jar --api /workspace/.gradle/caches/modules-2/files-2.1/net.fabricmc.fabric-api/fabric-api/0.116.15+1.21.1/d25c793833a90cc028c9a61bc4546cd578a70ce1/fabric-api-0.116.15+1.21.1.jar --java /workspace/jdk21-complete/bin/java --copy-test-world --sodium /workspace/ungravity-v5/world/work/gate0/upstream/sodium-fabric-0.8.13+mc1.21.1.jar > "$out/prepare-first.log"
python3 - <<'PY'
from pathlib import Path
import json,time
r=Path('build/cubic-client-automation');p=r/'launch.json';a=json.loads(p.read_text())
a=[v for v in a if not v.startswith('-Ddrmd.gate.')]
a.insert(1,'-Ddrmd.gate.portalTransit=true');p.write_text(json.dumps(a,indent=2)+'\n')
assert [v for v in a if v.startswith('-Ddrmd.gate.')]==['-Ddrmd.gate.portalTransit=true']
Path('work/multi-agent/native-transit-a415729b-first/native-start.json').write_text(json.dumps(dict(command=a,startedNs=time.time_ns(),runtime=str(r.resolve()),scope='Actual native BCC/Sodium held-forward6DoF portal transit only; no camera override or repeated gameplay teleport.'),indent=2)+'\n')
PY
display_file="$out/display.txt"
: > "$display_file"
/workspace/xvfb/usr/bin/Xvfb -displayfd 3 -screen 0 1280x1024x24 3> "$display_file" > "$out/xvfb.log" 2>&1 &
display_pid=$!
trap 'kill "$display_pid" 2>/dev/null || true; wait "$display_pid" 2>/dev/null || true' EXIT
for attempt in {1..100}; do kill -0 "$display_pid"; if [ -s "$display_file" ]; then break; fi; sleep .1; done
test -s "$display_file"
read -r display_number < "$display_file"
set +e
DISPLAY=:$display_number LIBGL_ALWAYS_SOFTWARE=1 MESA_GL_VERSION_OVERRIDE=3.3 MESA_GLSL_VERSION_OVERRIDE=330 timeout --kill-after=15 --foreground 240 python3 -c 'import os,json; from pathlib import Path; p=Path("build/cubic-client-automation").resolve(); a=json.loads((p/"launch.json").read_text()); os.chdir(p);os.execv(a[0],a)' < /dev/null > "$out/native-first.log" 2>&1
java_code=$?
set -e
echo "$java_code" > "$out/native.exit"
python3 - "$java_code" <<'PY'
from pathlib import Path
import json,sys,time
r=Path('build/cubic-client-automation');out=Path('work/multi-agent/native-transit-a415729b-first');p=r/'portal-transit-outcome.json'
result=json.loads(p.read_text()) if p.exists() else None
passed=int(sys.argv[1])==0 and result is not None and result['status']=='PASS' and result['observerInitialTeleports']==1 and result['noCameraOverride'] and result['clientJumpWitness'] and len(result['frames'])==2 and all((r/'portal-transit-frames'/(n+'.png')).is_file() for n in ['before','after'])
receipt=dict(javaExit=int(sys.argv[1]),observerStatus=result['status'] if result else 'UNOBSERVED',passed=passed,closedNs=time.time_ns(),newFullSuiteAccepted=False,droneClientInterpolationAccepted=False)
(out/'native-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt),flush=True)
PY
target="build/cubic-client-failed-${scenario}"
if python3 -c 'import json; assert json.load(open("work/multi-agent/native-transit-a415729b-first/native-receipt.json"))["passed"]'; then target="build/cubic-client-final-${scenario}"; fi
mv build/cubic-client-automation "$target"
python3 - "$target" <<'PY'
from pathlib import Path
import json,shutil,sys
r=Path(sys.argv[1]);out=Path('work/multi-agent/native-transit-a415729b-first');p=out/'native-receipt.json';receipt=json.loads(p.read_text());receipt['runtime']=str(r.resolve());p.write_text(json.dumps(receipt,indent=2)+'\n')
for rel in ['inputs.json','launch.json','portal-transit-outcome.json','portal-transit-frames/before.png','portal-transit-frames/after.png']:
 source=r/rel
 if source.exists():
  dest=out/'observed'/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,dest)
raise SystemExit(0 if receipt['passed'] else 1)
PY
