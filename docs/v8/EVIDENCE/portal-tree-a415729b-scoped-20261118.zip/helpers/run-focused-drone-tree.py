"""Focused live drone portal state and paired rounded tree geometry, with affected collapse and thermal regressions."""
from pathlib import Path
import hashlib
import json
import os
import shutil
import signal
import subprocess
import time
import xml.etree.ElementTree as ET

ROOT = Path('/workspace/ungravity-v5/ufo-body-physics')
SOURCE = '0f723c45199dea1cf09196d165285e341e32fc73'
OUT = ROOT / 'work/multi-agent/focused-0f723c45-first'
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == SOURCE
assert not subprocess.check_output(['git', 'status', '--porcelain', '--untracked-files=no'], cwd=ROOT)
assert not OUT.exists()
assert shutil.disk_usage(ROOT).free >= 160 * 1024 * 1024
assert not (ROOT / 'build/gametest/world').exists()
OUT.mkdir()
declared = json.loads((ROOT / 'src/gametest/resources/fabric.mod.json').read_text())
assert len(declared['entrypoints']['fabric-gametest']) == 97
entries = ['com.terminaldetector.drmd.world.portal.DronePortalGameTests', 'com.terminaldetector.drmd.RoundedTreeGameTests', 'com.terminaldetector.drmd.ThermalDrillGameTests', 'com.terminaldetector.drmd.CollapseGameTests']
assert all(x in declared['entrypoints']['fabric-gametest'] for x in entries)
init = OUT / 'focus.init.gradle'
init.write_text('''import groovy.json.JsonSlurper
import groovy.json.JsonOutput
gradle.projectsEvaluated {
  rootProject.tasks.named('test') {
    outputs.upToDateWhen { false }
    filter {
      includeTestsMatching 'com.terminaldetector.drmd.RoundedLogsTest'
      includeTestsMatching 'com.terminaldetector.drmd.HybridMeshTest'
      includeTestsMatching 'com.terminaldetector.drmd.BoundedHybridShapeTest'
      failOnNoMatchingTests = true
    }
  }
  rootProject.tasks.named('processGametestResources') {
    outputs.upToDateWhen { false }
    doLast {
      def p = rootProject.file('build/resources/gametest/fabric.mod.json')
      def m = new JsonSlurper().parse(p)
      m.entrypoints['fabric-gametest'] = ['com.terminaldetector.drmd.world.portal.DronePortalGameTests', 'com.terminaldetector.drmd.RoundedTreeGameTests', 'com.terminaldetector.drmd.ThermalDrillGameTests', 'com.terminaldetector.drmd.CollapseGameTests']
      p.text = JsonOutput.prettyPrint(JsonOutput.toJson(m)) + '\\n'
    }
  }
}
''')
prior = ROOT / 'build/gametest/reports/gametest-results.xml'
if prior.exists():
    shutil.copyfile(prior, OUT / 'prior-full-game-results.xml')
    prior.unlink()
started = time.time_ns()
env = dict(os.environ, JAVA_HOME='/workspace/jdk21-complete', GRADLE_USER_HOME='/workspace/.gradle')
env['PATH'] = env['JAVA_HOME'] + '/bin:' + env['PATH']
command = ['./gradlew', 'test', 'runGametest', 'remapJar', 'remapCubiccheckJar', '--offline', '--no-daemon', '-I', str(init)]
(OUT / 'start.json').write_text(json.dumps(dict(source=SOURCE, command=command, startedNs=started,
    ordinarySourceEntries=97, selectedGameClasses=entries, intendedUnits=13, intendedGames=18,
    scope='Focused new code only; no full-suite or pixel acceptance'), indent=2) + '\n')
timed = False
with (OUT / 'first.log').open('xb') as log:
    process = subprocess.Popen(command, cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
    print(json.dumps(dict(startedGradlePid=process.pid)), flush=True)
    try:
        code = process.wait(timeout=600)
    except subprocess.TimeoutExpired:
        timed = True
        os.killpg(process.pid, signal.SIGTERM)
        try:
            code = process.wait(timeout=15)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGKILL)
            code = process.wait()
(OUT / 'exit.json').write_text(json.dumps(dict(actualGradleExit=code, timedOut=timed, closedNs=time.time_ns())) + '\n')
print(json.dumps(dict(actualGradleExit=code, timedOut=timed)), flush=True)
def count(paths):
    rows = []
    for p in paths:
        if p.stat().st_mtime_ns < started:
            continue
        tree = ET.parse(p).getroot()
        rows.extend(tree.iter('testcase'))
        shutil.copyfile(p, OUT / p.name)
    return dict(tests=len(rows), failures=sum(x.find('failure') is not None for x in rows),
                errors=sum(x.find('error') is not None for x in rows), skipped=sum(x.find('skipped') is not None for x in rows))
result = dict(source=SOURCE, actualGradleExit=code, timedOut=timed,
              unit=count(list((ROOT / 'build/test-results/test').glob('TEST-*.xml'))),
              game=count([prior] if prior.exists() else []), fullSuiteAccepted=False, pixelAccepted=False)
result['passed'] = code == 0 and not timed and result['unit'] == dict(tests=13, failures=0, errors=0, skipped=0) and result['game'] == dict(tests=18, failures=0, errors=0, skipped=0)
if result['passed']:
    jar = ROOT / 'build/libs/drmd-6dof-1.1.35-ufo-dev.1.jar'
    result['jarSHA256'] = hashlib.sha256(jar.read_bytes()).hexdigest()
    shutil.copyfile(jar, OUT / jar.name)
assert json.loads((ROOT / 'src/gametest/resources/fabric.mod.json').read_text()) == declared
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == SOURCE
(OUT / 'outcome.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result), flush=True)
raise SystemExit(0 if result['passed'] else 1)
