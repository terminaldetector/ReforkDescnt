from pathlib import Path
import hashlib,json,struct,tarfile,xml.etree.ElementTree as ET,zipfile,zlib

root=Path.cwd(); source='11513cdd26fe4d3d291858d91efab1b21007c1a8'
out=root/'docs/v8/EVIDENCE/integrated-11513cd.zip'
assert not out.exists()
full=root/'work/multi-agent/integrated-11513cd'
stamp=json.loads((full/'verified-build.json').read_text())
assert stamp['sourceSha']==source
payload={}; sha=lambda b:hashlib.sha256(b).hexdigest()
def add(path,name):
    assert name not in payload;payload[name]=path.read_bytes()
for p in sorted(full.iterdir()):
    if p.is_file():add(p,'full/'+p.name)
counts=json.loads((full/'counts.json').read_text())
assert counts=={'unit':{'tests':824,'failures':0,'errors':0,'skipped':0},'game':{'tests':418,'failures':0,'errors':0,'skipped':0}}
with tarfile.open(full/'unit-results.tar.gz') as t:
    cases=[c for m in t.getmembers() if m.name.endswith('.xml') for c in ET.fromstring(t.extractfile(m).read()).iter('testcase')]
assert len(cases)==824 and all(c.find('failure') is None and c.find('error') is None and c.find('skipped') is None for c in cases)
cases=list(ET.parse(full/'full-game-results.xml').getroot().iter('testcase'))
assert len(cases)==418 and all(c.find('failure') is None and c.find('error') is None and c.find('skipped') is None for c in cases)
assert len(json.loads((full/'processed-full-manifest.json').read_text())['entrypoints']['fabric-gametest'])==66
def png(path):
    raw=path.read_bytes();assert raw.startswith(b'\x89PNG\r\n\x1a\n');at=8;data=b'';size=None
    while at<len(raw):
        n=struct.unpack('>I',raw[at:at+4])[0];kind=raw[at+4:at+8];body=raw[at+8:at+8+n];crc=struct.unpack('>I',raw[at+8+n:at+12+n])[0]
        assert zlib.crc32(kind+body)&0xffffffff==crc
        if kind==b'IHDR':size=struct.unpack('>II',body[:8])
        if kind==b'IDAT':data+=body
        at+=n+12
    assert at==len(raw) and size in [(1280,720),(960,540)] and zlib.decompress(data)
native=[];frames=0
for scenario,marker,folders,prefix in [
    ('ps1-viewmodel-integrated-11513cd-sodium','presentation-ok.json',('presentation-frames','viewmodel-proof'),'work/ps1/')]:
    run=root/'build'/('cubic-client-final-'+scenario)
    info=json.loads((run/'inputs.json').read_text());assert info['sourceSha']==source and info['candidateJars']==stamp['jars']
    for rel,h in stamp['jars'].items():
        jar=run/'mods'/Path(rel).name;assert sha(jar.read_bytes())==h
        with zipfile.ZipFile(jar) as z:assert z.testzip() is None
    for name in ('inputs.json','launch.json',marker):add(run/name,scenario+'/'+name)
    for folder in folders:
        for p in sorted((run/folder).iterdir()):
            if p.is_file():
                if p.suffix=='.png':png(p);frames+=1
                add(p,scenario+'/'+folder+'/'+p.name)
    for suffix in ('.log','.exit','-prepare.log','-xvfb.log','-display.txt'):
        p=root/(prefix+scenario+suffix)
        if p.exists():add(p,scenario+'/'+p.name)
    assert (root/(prefix+scenario+'.exit')).read_text().strip()=='0'
    native.append({'scenario':scenario,'marker':json.loads((run/marker).read_text()),'source':source})
assert frames==23,frames
proof=json.loads((root/'build/cubic-client-final-ps1-viewmodel-integrated-11513cd-sodium/viewmodel-proof/viewmodel-visibility.json').read_text())
viewmodel={k:proof[k] for k in ('nativeObserved','nativePixels','ps1Pixels','requiredPixels','sameCamera','sameModules','maximumProjectedVertexDeltaPixels')}
assert viewmodel==dict(nativeObserved=True,nativePixels=166,ps1Pixels=166,requiredPixels=125,sameCamera=True,sameModules=True,maximumProjectedVertexDeltaPixels=0.0)
for p in [root/'work/combined-final-11513cd/native.sh',root/'work/ufo-body/native/prepare-with-verified-library-links.py',root/'work/ufo-body/native/dedup-staged-libraries.py',root/'work/ufo-body/native/seed-verified-minecraft-remap.py',root/'scripts/v8/ps1_native.sh',root/'scripts/v8/ps1_prepare.py',Path(__file__)]:add(p,'helpers/'+p.name)
for name in ('integrated-11513cd-wrapper.log','native-viewmodel-integrated-11513cd-wrapper.log'):
    add(root/'work/multi-agent'/name,'wrappers/'+name)
summary=dict(source=source,unit=counts['unit'],game=counts['game'],entrypoints=66,jars=stamp['jars'],freshFrames=frames,viewmodel=viewmodel,native=native,
    scope='Exact combined source; complete ordinary stock Fabric server suite; same-JAR real BCC/Sodium GL3.3 software-Mesa clients. Twenty-three saved PNGs include intermediate viewmodel stages. No full specification, physical GPU, performance, full Fabulous or release acceptance.',releaseAccepted=False)
payload['SUMMARY.json']=(json.dumps(summary,indent=2)+'\n').encode()
manifest={n:sha(b) for n,b in sorted(payload.items())}
with zipfile.ZipFile(out,'x',zipfile.ZIP_DEFLATED) as z:
    for name,data in sorted(payload.items()):z.writestr(name,data)
    z.writestr('MANIFEST.json',json.dumps({'source':source,'files':manifest},indent=2)+'\n')
with zipfile.ZipFile(out) as z:
    assert z.testzip() is None
    for name,h in manifest.items():assert sha(z.read(name))==h
receipt=dict(archive=str(out.relative_to(root)),sha256=sha(out.read_bytes()),payloadFiles=len(payload),bytes=out.stat().st_size,allHashesAndCrcVerified=True,**summary)
Path('docs/v8/EVIDENCE/integrated-11513cd.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({k:receipt[k] for k in ('archive','sha256','payloadFiles','bytes','freshFrames')}))
