#!/usr/bin/env python3
"""Read-only preservation of this closed, disposable FIRST19 world. No deletion."""
import datetime,fcntl,gzip,hashlib,json,os,pathlib,zipfile
ROOT=pathlib.Path('/workspace/ungravity-v5/control-core-20261118')
RUN=pathlib.Path(__file__).resolve().parent
WORLD=ROOT/'build/gametest/world'
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def inventory():
 return [{'path':str(p.relative_to(WORLD)),'bytes':p.stat().st_size,'sha256':sha(p),'inode':p.stat().st_ino,'mtime_ns':p.stat().st_mtime_ns} for p in sorted(WORLD.rglob('*')) if p.is_file()]
assert json.loads((RUN/'first-game-outcome.json').read_text())['verified_first19']
exit=json.loads((RUN/'child-exit.json').read_text());assert exit['returncode']==0 and not exit['timed_out'] and not exit['forced_kill']
lock=WORLD/'session.lock';assert lock.is_file()
with lock.open('r+b') as handle:
 fcntl.lockf(handle,fcntl.LOCK_EX|fcntl.LOCK_NB)
 before=inventory();archive=RUN/'closed-first19-world.zip'
 with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
  for row in before:z.write(WORLD/row['path'],row['path'])
  z.writestr('MANIFEST.sha256',''.join(row['sha256']+'  '+row['path']+'\n' for row in before))
 with zipfile.ZipFile(archive) as z:
  assert z.testzip() is None
  for row in before:assert hashlib.sha256(z.read(row['path'])).hexdigest()==row['sha256']
 gzip_rows=[]
 for row in before:
  path=WORLD/row['path']
  with path.open('rb') as f:magic=f.read(2)
  if magic==b'\x1f\x8b':
   with gzip.open(path,'rb') as f:
    while f.read(65536):pass
   gzip_rows.append(row['path'])
 after=inventory();assert before==after,'closed world changed during preservation'
 receipt={'schema':1,'recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'production_source':'d4921ee5fa60048b38fdb328ec3901639dab50e7','observer_source':'0bb280a8d27e4c1a0e75fd09a79ee6a2e05232ce','source_world':str(WORLD),'file_count':len(before),'raw_bytes':sum(row['bytes'] for row in before),'files':before,'archive':str(archive),'archive_bytes':archive.stat().st_size,'archive_sha256':sha(archive),'zip_crc_all_payload_sha256_verified':True,'gzip_full_footer_verified':gzip_rows,'source_same_file_hash_inode_mtime_verified':True,'exclusive_existing_session_lock_held':True,'actual_child_exit':exit,'raw_world_retained':True,'deletion_performed':False}
 with (RUN/'closed-world-preservation.json').open('x') as f:json.dump(receipt,f,indent=2);f.write('\n')
 print(json.dumps({k:v for k,v in receipt.items() if k!='files'}))
