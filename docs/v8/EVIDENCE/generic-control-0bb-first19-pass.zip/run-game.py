#!/usr/bin/env python3
"""ONE first19 after package fix; production d492, observer 0bb; no compilation/remap/client."""
import datetime,hashlib,json,os,pathlib,re,shutil,signal,subprocess,sys,time,xml.etree.ElementTree as ET
ROOT=pathlib.Path('/workspace/ungravity-v5/control-core-20261118')
RUN=pathlib.Path(__file__).resolve().parent
BUILD=ROOT/'work/b2-probe-package-build-0bb280a-first-20261118'
PROD_BUILD=ROOT/'work/b2-assembly-build-d4921ee-forced-first-20261118'
SOURCE='0bb280a8d27e4c1a0e75fd09a79ee6a2e05232ce'
PRODUCTION='d4921ee5fa60048b38fdb328ec3901639dab50e7'
JAVA=pathlib.Path('/workspace/jdk21-complete')
INIT=ROOT/'verification/generic-control/inputs.init.gradle'
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def write(name,value):
 with (RUN/name).open('x') as f:json.dump(value,f,indent=2);f.write('\n')
def classes():
 result={}
 for kind in ['main','gametest']:
  base=ROOT/'build/classes/java'/kind
  actual=[{'path':str(p.relative_to(base)),'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(base.rglob('*')) if p.is_file()]
  assert actual==json.loads(((PROD_BUILD if kind=='main' else BUILD)/(kind+'-classes-output.json')).read_text()),'compiled '+kind+' changed'
  result[kind]=actual
 return result

assert os.environ.get('B2_CORE_JAVA_LEASE')=='granted','No explicit Java lease'
assert shutil.disk_usage(ROOT).free>=160*1024*1024,'160 MiB first-game guard; do not lower'
assert not (RUN/'child-start.json').exists() and not (RUN/'runtime-inputs.json').exists(),'first game already entered'
assert not (ROOT/'build/gametest/world').exists(),'fresh isolated game world required'
prior_xml=ROOT/'build/gametest/reports/gametest-results.xml'
if prior_xml.exists():
 assert sha(prior_xml)=='f0d0b1e650241fb7c05c28a080c67097c75b2bca5675edd5b0a090b3e32249c4','unexpected prior report'
 shutil.move(str(prior_xml),str(RUN/'prior-first14-results.xml'))
write('prior-XML-preserved.json',{'source':'c4b81c4420bca8137e5f6c84baf2fafe95d6bc7b','moved_into_new_run':(RUN/'prior-first14-results.xml').exists(),'original_first_run_copy_unchanged':sha(ROOT/'work/b2-first-game-c4b81c4-20261118/first-game-results.xml')=='f0d0b1e650241fb7c05c28a080c67097c75b2bca5675edd5b0a090b3e32249c4'})
assert json.loads((PROD_BUILD/'first-build-outcome.json').read_text())['verified_compile_and_units']
assert json.loads((BUILD/'first-build-outcome.json').read_text())['verified_observer_only_compile']
assert json.loads((BUILD/'actual-namespace-audit.json').read_text())['outcome']=='PASS'
assert not subprocess.check_output(['git','diff','--name-only',PRODUCTION,SOURCE,'--','src/main/','src/test/','verification/'],cwd=ROOT,text=True).strip()
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
changes=subprocess.check_output(['git','diff','--name-only',SOURCE,head],cwd=ROOT,text=True).splitlines()
assert all(p.startswith('docs/') for p in changes),'only metadata descendants of compiled source allowed'
assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=ROOT,text=True).strip()
source_inputs=json.loads((BUILD/'source-inputs-before.json').read_text())
for row in source_inputs:assert sha(ROOT/row['path'])==row['sha256'],row['path']
before=classes();resources=[{'path':str(p.relative_to(ROOT/'build/resources/main')),'sha256':sha(p)} for p in sorted((ROOT/'build/resources/main').rglob('*')) if p.is_file()]
expected=[]
for name in ['GenericControlCoreGameTests','GenericControlFireGameTests','BodyAssemblyTransactionGameTests']:
 text=(ROOT/('src/gametest/java/com/terminaldetector/drmd/'+name+'.java')).read_text()
 expected.extend((name+'.'+method).lower() for method in re.findall(r'@GameTest\([^)]*\)\s+public void (\w+)\(',text))
assert len(expected)==len(set(expected))==19
started=now();started_ns=time.time_ns();helper_sha=sha(pathlib.Path(__file__))
command=['./gradlew','--offline','--no-daemon','--no-parallel','--max-workers=1',
 '-Dorg.gradle.jvmargs=-Xmx1G -Dfile.encoding=UTF-8','--console=plain','--stacktrace','--init-script',str(INIT),
 '-PgenericCoreStage=game','-PgenericCoreCases=all','-PgenericCoreEvidence='+str(RUN),'runGametest']
env=os.environ.copy();env['JAVA_HOME']=str(JAVA);env['GRADLE_USER_HOME']='/workspace/.gradle';env['PATH']=str(JAVA/'bin')+os.pathsep+env.get('PATH','')
write('compiled-inputs-before.json',{'source':SOURCE,'production_source':PRODUCTION,'metadata_head':head,'metadata_only_changes':changes,'classes':before,'main_resources':resources})
write('runtime-inputs.json',{'source':SOURCE,'production_source':PRODUCTION,'metadata_head':head,'command':command,'started_utc':started,'started_unix_ns':started_ns,
 'runner_sha256':helper_sha,'init_sha256':sha(INIT),'java_sha256':sha(JAVA/'bin/java'),'javac_sha256':sha(JAVA/'bin/javac'),
 'libjvm_sha256':sha(JAVA/'lib/server/libjvm.so'),'java_home':str(JAVA),'gradle_user_home':'/workspace/.gradle','expected_cases':sorted(expected),
 'unit_repeated':False,'compilation_permitted':False,'native_permitted':False,'initial_free_bytes':shutil.disk_usage(ROOT).free})
timeout=False;killed=False
with (RUN/'game-first.log').open('xb') as log:
 child=subprocess.Popen(command,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 write('child-start.json',{'pid':child.pid,'started_utc':now(),'command':command})
 print(json.dumps({'event':'JAVA_STARTED','pid':child.pid,'source':SOURCE,'game_cases':19}),flush=True)
 try:code=child.wait(timeout=420)
 except subprocess.TimeoutExpired:
  timeout=True;os.killpg(child.pid,signal.SIGTERM)
  try:code=child.wait(timeout=10)
  except subprocess.TimeoutExpired:killed=True;os.killpg(child.pid,signal.SIGKILL);code=child.wait()
 write('child-exit.json',{'pid':child.pid,'returncode':code,'closed_utc':now(),'timed_out':timeout,'forced_kill':killed})
 print(json.dumps({'event':'JAVA_CLOSED','returncode':code,'closed_utc':now(),'timed_out':timeout,'forced_kill':killed}),flush=True)

after=classes();new_resources=[{'path':str(p.relative_to(ROOT/'build/resources/main')),'sha256':sha(p)} for p in sorted((ROOT/'build/resources/main').rglob('*')) if p.is_file()]
for row in source_inputs:assert sha(ROOT/row['path'])==row['sha256'],row['path']
write('compiled-inputs-after.json',{'source':SOURCE,'production_source':PRODUCTION,'classes':after,'classes_unchanged':before==after,'main_resources_unchanged':resources==new_resources,
 'helper_unchanged':sha(pathlib.Path(__file__))==helper_sha})
path=ROOT/'build/gametest/reports/gametest-results.xml';cases=[];failures=errors=skips=0;fresh=False
if path.exists():
 shutil.copy2(path,RUN/'first-game-results.xml');tree=ET.parse(path).getroot();nodes=tree.findall('.//testcase')
 cases=[node.attrib['name'] for node in nodes];failures=len(tree.findall('.//failure'));errors=len(tree.findall('.//error'));skips=len(tree.findall('.//skipped'));fresh=path.stat().st_mtime_ns>=started_ns
verified=code==0 and not timeout and not killed and sorted(cases)==sorted(expected) and failures==errors==skips==0 and fresh and resources==new_resources
write('first-game-outcome.json',{'source':SOURCE,'production_source':PRODUCTION,'child_returncode':code,'timed_out':timeout,'forced_kill':killed,'cases':cases,'case_count':len(cases),
 'failures':failures,'errors':errors,'skipped':skips,'fresh_xml':fresh,'classes_unchanged':before==after,'main_resources_unchanged':resources==new_resources,
 'source_unchanged':True,'helper_unchanged':sha(pathlib.Path(__file__))==helper_sha,'verified_first19':verified,'new_compilation':False,'native_run':False,
 'xml_sha256':sha(RUN/'first-game-results.xml') if (RUN/'first-game-results.xml').exists() else None,'final_free_bytes':shutil.disk_usage(ROOT).free})
print(json.dumps({'event':'POSTCHECK','verified_first19':verified,'cases':len(cases),'failures':failures,'errors':errors,'skipped':skips}),flush=True)
sys.exit(0 if verified else code if code else 1)
