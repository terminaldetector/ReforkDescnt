from pathlib import Path
import hashlib,struct,json,zipfile
artifact=Path('/workspace/.gradle/caches/fabric-loom/minecraftMaven/net/minecraft/minecraft-merged/1.21.1-net.fabricmc.yarn.1_21_1.1.21.1+build.3-v2/minecraft-merged-1.21.1-net.fabricmc.yarn.1_21_1.1.21.1+build.3-v2.jar')
class Reader:
 def __init__(self,b):self.b=b;self.i=0
 def take(self,n):v=self.b[self.i:self.i+n];self.i+=n;return v
 def u1(self):return int.from_bytes(self.take(1),'big')
 def u2(self):return int.from_bytes(self.take(2),'big')
 def u4(self):return int.from_bytes(self.take(4),'big')
def parse(b,wanted):
 r=Reader(b);assert r.take(4)==b'\xca\xfe\xba\xbe';r.take(4);n=r.u2();cp=[None]*n;i=1
 while i<n:
  t=r.u1()
  if t==1:cp[i]=(t,r.take(r.u2()).decode('utf-8',errors='replace'))
  elif t in (3,4):cp[i]=(t,struct.unpack('>i' if t==3 else '>f',r.take(4))[0])
  elif t in (5,6):cp[i]=(t,struct.unpack('>q' if t==5 else '>d',r.take(8))[0]);i+=1
  elif t in (7,8,16,19,20):cp[i]=(t,r.u2())
  elif t in (9,10,11,12,17,18):cp[i]=(t,r.u2(),r.u2())
  elif t==15:cp[i]=(t,r.u1(),r.u2())
  else:raise ValueError(t)
  i+=1
 def utf(i):return cp[i][1]
 def cname(i):return utf(cp[i][1])
 def ref(i):
  v=cp[i]
  if v[0] in (9,10,11):
   nt=cp[v[2]];return {'owner':cname(v[1]),'name':utf(nt[1]),'descriptor':utf(nt[2])}
  if v[0]==7:return {'class':cname(i)}
  if v[0]==8:return {'string':utf(v[1])}
  return {'constant':v}
 def attrs():
  return [(utf(r.u2()),r.take(r.u4())) for _ in range(r.u2())]
 access=r.u2();name=cname(r.u2());super_=r.u2();r.take(r.u2()*2);fields=[]
 for _ in range(r.u2()):a=r.u2();fn=utf(r.u2());fd=utf(r.u2());attrs();fields.append({'access':hex(a),'name':fn,'descriptor':fd})
 methods=[]
 for _ in range(r.u2()):
  a=r.u2();mn=utf(r.u2());md=utf(r.u2());items=attrs()
  if mn not in wanted:continue
  m={'access':hex(a),'name':mn,'descriptor':md}
  for an,data in items:
   if an!='Code':continue
   cr=Reader(data);m['maxStack']=cr.u2();m['maxLocals']=cr.u2();code=cr.take(cr.u4());cr.take(cr.u2()*8);extra=[]
   for _ in range(cr.u2()):
    cn=utf(cr.u2());cb=cr.take(cr.u4())
    if cn=='LocalVariableTable':
     lr=Reader(cb);entries=[]
     for _ in range(lr.u2()):
      st=lr.u2();ln=lr.u2();vn=utf(lr.u2());vd=utf(lr.u2());sl=lr.u2();entries.append({'start':st,'length':ln,'name':vn,'descriptor':vd,'slot':sl})
     extra=entries
   m['codeSha256']=hashlib.sha256(code).hexdigest();m['localVariables']=extra;m['instructions']=decode(code,ref)
  methods.append(m)
 return {'class':name,'classSha256':hashlib.sha256(b).hexdigest(),'fields':fields,'methods':methods}
def decode(code,ref):
 sizes=[1]*256
 for o in [0x10,0x12,*range(0x15,0x1a),*range(0x36,0x3b),0xa9,0xbc]:sizes[o]=2
 for o in [0x11,0x13,0x14,0x84,*range(0x99,0xa9),*range(0xb2,0xb9),0xbb,0xbd,0xc0,0xc1,0xc6,0xc7]:sizes[o]=3
 for o in [0xb9,0xba,0xc8,0xc9]:sizes[o]=5
 sizes[0xc5]=4
 names={0x0:'nop',0x1:'aconst_null',0x57:'pop',0x59:'dup',0x60:'iadd',0x62:'fadd',0x63:'dadd',0x66:'fsub',0x67:'dsub',0x6a:'fmul',0x6b:'dmul',0x6e:'fdiv',0x6f:'ddiv',0x76:'fneg',0x77:'dneg',0x85:'i2l',0x86:'i2f',0x87:'i2d',0x8d:'f2d',0x8e:'d2i',0x8f:'d2l',0x90:'d2f',0xb2:'getstatic',0xb3:'putstatic',0xb4:'getfield',0xb5:'putfield',0xb6:'invokevirtual',0xb7:'invokespecial',0xb8:'invokestatic',0xb9:'invokeinterface',0xba:'invokedynamic',0xbb:'new',0xc0:'checkcast',0xc1:'instanceof',0xb0:'areturn',0xb1:'return',0xac:'ireturn',0xaf:'dreturn',0x12:'ldc',0x13:'ldc_w',0x14:'ldc2_w',0x84:'iinc'}
 for start,prefix in [(0x1a,'iload_'),(0x1e,'lload_'),(0x22,'fload_'),(0x26,'dload_'),(0x2a,'aload_'),(0x3b,'istore_'),(0x3f,'lstore_'),(0x43,'fstore_'),(0x47,'dstore_'),(0x4b,'astore_')]:
  for i in range(4):names[start+i]=prefix+str(i)
 for op,n in [(0x15,'iload'),(0x16,'lload'),(0x17,'fload'),(0x18,'dload'),(0x19,'aload'),(0x36,'istore'),(0x37,'lstore'),(0x38,'fstore'),(0x39,'dstore'),(0x3a,'astore')]:names[op]=n
 rows=[];pc=0
 while pc<len(code):
  op=code[pc];size=sizes[op];row={'bci':pc,'opcode':names.get(op,hex(op))}
  if op==0xc4:size=6 if code[pc+1]==0x84 else 4
  if op in (0xaa,0xab):
   pad=(4-(pc+1)%4)%4;off=pc+1+pad;row['switchDefault']=pc+int.from_bytes(code[off:off+4],'big',signed=True)
   if op==0xaa:lo=int.from_bytes(code[off+4:off+8],'big',signed=True);hi=int.from_bytes(code[off+8:off+12],'big',signed=True);size=1+pad+12+(hi-lo+1)*4
   else:size=1+pad+8+int.from_bytes(code[off+4:off+8],'big',signed=True)*8
  if op in range(0xb2,0xbb) or op in [0xbb,0xbd,0xc0,0xc1]:row['member']=ref(int.from_bytes(code[pc+1:pc+3],'big'))
  elif op in (0x12,0x13,0x14):row['value']=ref(code[pc+1] if op==0x12 else int.from_bytes(code[pc+1:pc+3],'big'))
  elif op in [*range(0x15,0x1a),*range(0x36,0x3b)]:row['slot']=code[pc+1]
  if 0x99<=op<=0xa8 or op in (0xc6,0xc7):row['branchTarget']=pc+int.from_bytes(code[pc+1:pc+3],'big',signed=True)
  if size>1:row['operandHex']=code[pc+1:pc+size].hex()
  rows.append(row);pc+=size
 assert pc==len(code);return rows
wanted={'net/minecraft/entity/LivingEntity':{'travel','applyMovementInput','getMovementSpeed','jump'},'net/minecraft/entity/Entity':{'getVelocityAffectingPos','getBlockPos','getSteppingPos'},'net/minecraft/entity/ai/goal/PounceAtTargetGoal':{'canStart','shouldContinue','start'},'net/minecraft/entity/mob/SpiderEntity':{'initGoals'}}
result={'artifact':str(artifact),'artifactSha256':hashlib.sha256(artifact.read_bytes()).hexdigest(),'sourceEvidence':'952286a90463b2b8cf656daf128b5c27e313f312','scope':'source-only exact native hook/operator design; not another runtime result','classes':[]}
with zipfile.ZipFile(artifact) as z:
 for name,methods in wanted.items():result['classes'].append(parse(z.read(name+'.class'),methods))
p=Path(__file__).with_name('native-hook-contract.json');p.write_text(json.dumps(result,indent=2)+'\n');print('nativeAudit',p.stat().st_size,hashlib.sha256(p.read_bytes()).hexdigest())
for c in result['classes']:
 for m in c['methods']:
  if m['name']=='travel':print('TRAVEL_END',json.dumps([r for r in m['instructions'] if r['bci']>=1007]))
  if c['class'].endswith('PounceAtTargetGoal'):print('POUNCE',m['name'],json.dumps(m['instructions']))
