from pathlib import Path
import hashlib,json,os,subprocess,sys,time,xml.etree.ElementTree as ET
root=Path.cwd().resolve();assert root==Path('/workspace/ungravity-v5/mission-runtime-20261117')
source=sys.argv[1];assert len(source)==40 and all(c in '0123456789abcdef' for c in source)
run=root/'work/mission-ledger-first';assert not (run/'started.json').exists()
sha=lambda b:hashlib.sha256(b).hexdigest()
head=lambda:subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert head()==source
paths=sorted(p for base in ('src/main','src/test') for p in (root/base).rglob('*') if p.is_file())
paths += [root/n for n in ('build.gradle','settings.gradle','gradle.properties')]
freeze={str(p.relative_to(root)):sha(p.read_bytes()) for p in paths}
init=run/'fresh-test.init.gradle';init.write_text("allprojects { tasks.withType(Test).configureEach { outputs.upToDateWhen { false } } }\n")
started=time.time_ns();(run/'started.json').write_text(json.dumps(dict(source=source,startNs=started,inputs=freeze,runnerSHA256=sha(Path(__file__).read_bytes())),indent=2)+'\n')
env=dict(os.environ,JAVA_HOME='/workspace/jdk21-complete',GRADLE_USER_HOME='/workspace/.gradle');env['PATH']=env['JAVA_HOME']+'/bin:'+env['PATH']
command=['./gradlew','test','--tests','com.terminaldetector.drmd.world.enclave.EnclaveMissionContractTest','--tests','com.terminaldetector.drmd.world.enclave.EnclaveMissionLedgerTest','--offline','--no-daemon','--max-workers=2','-I',str(init)]
(run/'command.json').write_text(json.dumps(command,indent=2)+'\n')
with (run/'first.log').open('x') as log:
    try:code=subprocess.run(command,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=300).returncode
    except subprocess.TimeoutExpired:code=124
(run/'first.exit').write_text(str(code)+'\n')
unchanged=head()==source and all(p.exists() and sha(p.read_bytes())==freeze[str(p.relative_to(root))] for p in paths)
reports=[];cases=[]
for p in sorted((root/'build/test-results/test').glob('TEST-com.terminaldetector.drmd.world.enclave.EnclaveMission*Test.xml')):
    if p.stat().st_mtime_ns>=started:
        data=p.read_bytes();(run/p.name).write_bytes(data);reports.append(p.name);cases.extend(ET.fromstring(data).iter('testcase'))
result=dict(source=source,processExit=code,sourceInputsUnchanged=unchanged,freshReports=reports,tests=len(cases),failures=sum(c.find('failure') is not None for c in cases),errors=sum(c.find('error') is not None for c in cases),skipped=sum(c.find('skipped') is not None for c in cases),scope='Targeted pure protocol/codec and FactionMemory NBT tests only; no actual owner interaction, cold disk reopen or full mission/spec acceptance')
result['passed']=code==0 and unchanged and len(cases)==18 and all(result[k]==0 for k in ('failures','errors','skipped'))
(run/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2));sys.exit(0 if result['passed'] else 1)
