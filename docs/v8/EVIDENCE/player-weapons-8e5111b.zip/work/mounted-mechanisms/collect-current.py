from pathlib import Path
import hashlib,json,subprocess,sys,zipfile,xml.etree.ElementTree as E

root=Path.cwd();work=root/'work/mounted-mechanisms'
scenario=sys.argv[1]
runtime=root/'build'/('cubic-client-final-'+scenario)
full_source=(work/'current-source.txt').read_text().strip()
source=json.loads((runtime/'inputs.json').read_text())['sourceSha']
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==source
assert not subprocess.check_output(['git','diff',full_source,source,'--','src/main','src/gametest','src/test','build.gradle','settings.gradle','gradle.properties'])
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def cases(p,count):
    r=E.parse(p);tests=list(r.iter('testcase'))
    assert len(tests)==count and not list(r.iter('failure')) and not list(r.iter('error')),p
    return dict(tests=count,failures=0,errors=0)
full=cases(work/'current-full.xml',376);contact=cases(work/'contact-passed.xml',3)
unit=dict(tests=0,failures=0,errors=0,skipped=0)
unitfiles=list((root/'build/test-results/test').glob('TEST-*.xml'))
for p in unitfiles:
    r=E.parse(p).getroot()
    for k in unit:unit[k]+=int(r.get(k,0))
assert unit==dict(tests=758,failures=0,errors=0,skipped=0)
marker=json.loads((runtime/'mounted-mechanisms-ok.json').read_text())
assert marker['actualUseAndSneakKeys'] and not marker['fixtureSuppliedJointOrShots']
assert marker['ordinaryPhysicalGunOwner'] and marker['preservedSpinAfterRelease']
assert marker['lasers']>=3 and marker['rockets']>=1 and marker['stoppedTicks']>=16
assert marker['maxAnchorError']<.03 and marker['maxMuzzleError']<1e-8 and marker['maxLaunchVelocityError']<1e-8
assert marker['frames']==['connected-off','laser-fire','rocket-fire','fire-off-reversed','bearing-detached']
assert not list((runtime/'crash-reports').glob('*.txt'))
assert json.loads((runtime/'inputs.json').read_text())['sourceSha']==source
subprocess.run(['python3','work/ufo-body/native/verify-build-stamp.py','check'],check=True)
game=root/'build/libs/drmd-6dof-1.1.35-ufo-dev.1.jar';observer=root/'build/libs/drmd-6dof-1.1.35-ufo-dev.1-cubiccheck.jar'
assert digest(game)==(work/'current-game.sha256').read_text().split()[0]
summary=dict(nativeSource=source,fullServerSource=full_source,productionSource='4fede1d',base='4913c04',unit=unit,server=full,focusedContacts=contact,
             playerViewFocused=cases(work/'head-yaw-passed.xml',30),exactPlacementFocused=cases(work/'placement-exact-passed.xml',12),
             earlierWeaponFocused=dict(source='87e392e',tests=29,scope='Historical focused run before contact fixes; all cases rerun in current complete suite'),
             gameSha256=digest(game),observerSha256=digest(observer),sameFullAndNativeGameBytes=True,
             nativeScenario=scenario,native=marker,releaseAccepted=False,publication='Local only',
             scope='Generic six-axis physical weapon blocks, lever controls, bounded scheduling/cooldowns, compound contact continuation. Automatic aiming, world anchoring, ammo/power, generic cold restart/multiplayer and full v8 remain open.')
(work/'summary-current.json').write_text(json.dumps(summary,indent=2)+'\n')
(work/'source-series-current.patch').write_text(subprocess.check_output(['git','diff','4913c04..'+source,'--','src'],text=True))
files={}
def add(p):
    assert p.is_file() and not p.is_symlink(),p
    files[str(p.relative_to(root))]=p
for p in work.iterdir():
    if p.is_file() and p.suffix in {'.log','.xml','.json','.txt','.patch','.gradle','.sh','.py'}:add(p)
for p in unitfiles:add(p)
for p in (runtime/'mounted-mechanism-frames').glob('*.png'):add(p)
for name in ['inputs.json','launch.json','options.txt','mounted-mechanisms-ok.json']:add(runtime/name)
for suffix in ['.log','.exit','-prepare.log','-xvfb.log']:
    p=root/'work/ufo-body/native'/('final-'+scenario+suffix)
    if p.is_file():add(p)
for previous in ['cubic-client-failed-mounted-weapons-87e392e','cubic-client-failed-mounted-contact-f7c9b23','cubic-client-failed-mounted-off-e5fa9c6','cubic-client-failed-mounted-use-891df68','cubic-client-failed-mounted-keyboard-06260bd','cubic-client-failed-mounted-release-4fede1d']:
    for p in (root/'build'/previous/'mounted-mechanism-frames').glob('*.png'):add(p)
for p in [game,observer,root/'docs/v8/PLAYER_BUILT_WEAPONS.md']:add(p)
manifest={name:digest(p) for name,p in sorted(files.items())}
dest=root/'docs/v8/EVIDENCE'/('player-weapons-'+source[:7]+'.zip');assert not dest.exists()
with zipfile.ZipFile(dest,'x',zipfile.ZIP_DEFLATED) as z:
    for name,p in sorted(files.items()):z.write(p,name)
    z.writestr('MANIFEST.json',json.dumps(dict(nativeSource=source,fullServerSource=full_source,files=manifest),indent=2))
with zipfile.ZipFile(dest) as z:
    assert z.testzip() is None
    for name,h in manifest.items():assert hashlib.sha256(z.read(name)).hexdigest()==h
summary.update(archive=str(dest.relative_to(root)),archiveSha256=digest(dest),verifiedFiles=len(manifest),crcAndHashesVerified=True)
(work/'summary-current.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
