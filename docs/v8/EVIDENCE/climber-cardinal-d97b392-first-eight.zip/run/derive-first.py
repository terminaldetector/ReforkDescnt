from pathlib import Path
import json,collections,hashlib
out=Path(__file__).resolve().parent;rows=json.loads((out/'first-air-events.json').read_text());actors=[]
for uid in dict.fromkeys(r['uuid']for r in rows):
 events=[r for r in rows if r['uuid']==uid];admit=events[0];obs=[r for r in events if r['phase']=='ORDINARY_OBSERVATION'];after=[r for r in events if r['phase']=='NATIVE_POUNCE_AFTER'];arcs=[];completed=0
 for r in obs:
  if r['completeArcs']>completed:arcs.append({'landingAge':r['actualAge'],'completedArcs':r['completeArcs'],'support':r['support']});completed=r['completeArcs']
 actors.append({'uuid':uid,'type':admit['type'],'wall':admit['wall'],'barrier':admit['barrier'],'events':len(events),
     'phases':dict(collections.Counter(r['phase']for r in events)),'actualAgeRange':[min(r['actualAge']for r in events),max(r['actualAge']for r in events)],
     'actualPounceAges':[r['actualAge']for r in after],'actualImpulseMatchesExpected':[r['actualVelocity']==r['expectedLocalImpulse']for r in after],
     'allObservedBodyVolumesFull':all(r['support']['available']for r in obs),'allObservedBodiesClear':all(r['support']['bodyClear']for r in obs),
     'allObservedUpEyeErrorsWithinTolerance':all(r['support']['upError']<=1e-6 and r['support']['eyeError']<=1e-6 for r in obs),
     'maximumObservedGap':max((r['support'].get('gap')or 0)for r in obs),'reacquisitions':arcs,'lastOrdinaryObservation':obs[-1],
     'finalRows':[r for r in events if r['phase']=='FINAL']})
summary={'source':'d97b3921c1759c4dc7b92bf2c7c53d541696d106','derivedOnly':True,'rawAirExportSha256':hashlib.sha256((out/'first-air-events.json').read_bytes()).hexdigest(),'actualEvents':len(rows),'actualActors':len(actors),'actors':actors,
    'classification':{'floorControl':'Bothspecies PASS120ordinaryticks, actualnaturalpounceage7, exactimpulse match, airpeak1.1531/10ticks/nativeattacksafterlanding',
    'wallAirCase':'Bothspecies120observations but zeroactualnaturalpounces; finalSpiderfailure is jumpADMISSION failure; Cavefinalunreached; do not infer broken local impulse from missing jump',
    'jumpAwareBarrier':'Fouractualcorrectlocalpounces(two/species), firstairarc/reacquisition observed each; Spiderage73 first coarse whole-body sweep assertion; triggering postmove box is not exported because assertion precedes sample emit. Native step-up/chord falsepositive vs penetration UNRESOLVED',
    'oldStrictWall':'Real gap1.53/16invalidsupport afterlegit localup launch conflicts continuoussupport threshold; no assertionwaived',
    'oldStrictBarrier':'Completed120Spider,38invalidsupports/maxgap1.5766, supportedpassageyes/nativePath12index6, crossedfalse/onecoarsesweep; Cavefinalunreached',
    'oldCeiling':'Pre-timeout309says spawnedaliveage57/57samples, realFULLsupport/owners; missing last3ordinaryticks, exact cause notobserved',
    'oldBarrier309':'No callback row because barriercompleted/fails before309; not proof observerbroken',
    'overall':'3PASS5FAIL; stillUNACCEPTED. No mainpatch/retry from these incompletecauses'}}
(out/'first-air-analysis.json').write_text(json.dumps(summary,indent=2)+'\n')
for a in actors:print(a['type'],a['wall'],a['barrier'],a['actualPounceAges'],a['reacquisitions'])
