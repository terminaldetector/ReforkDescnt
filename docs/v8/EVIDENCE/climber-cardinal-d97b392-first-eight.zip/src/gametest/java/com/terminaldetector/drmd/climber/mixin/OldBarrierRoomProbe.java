package com.terminaldetector.drmd.climber.mixin;

import com.terminaldetector.drmd.climber.ClimberBarrierWatch;
import net.minecraft.entity.Entity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.test.TestContext;
import net.minecraft.util.math.BlockPos;
import org.spongepowered.asm.mixin.*;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import java.util.List;

@Mixin(targets="com.terminaldetector.drmd.ClimberFieldGravityGameTests$Room",remap=false)
public abstract class OldBarrierRoomProbe {
    @Shadow @Final TestContext context;
    @Shadow @Final ServerWorld world;
    @Shadow @Final List<Entity> actors;
    @Shadow boolean built;
    @Shadow boolean closed;
    @Unique private boolean drmd$oldBarrier;
    @Shadow abstract boolean loaded();
    @Inject(method="<init>",at=@At("RETURN"),remap=false)
    private void created(TestContext c,BlockPos min,BlockPos max,CallbackInfo ci) {
        if(!ClimberBarrierWatch.owns(c))return;
        drmd$oldBarrier=true;
        c.runAtTick(309,()->{if(!closed)ClimberBarrierWatch.record(context,world,actors,built,closed,loaded());});
    }
    @Inject(method="spawn",at=@At("RETURN"),remap=false)
    private void spawned(Entity actor,CallbackInfo ci){if(drmd$oldBarrier)ClimberBarrierWatch.spawned(actor);}
}
