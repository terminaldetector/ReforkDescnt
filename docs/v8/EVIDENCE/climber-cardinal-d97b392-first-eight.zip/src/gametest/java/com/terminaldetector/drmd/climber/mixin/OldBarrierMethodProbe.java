package com.terminaldetector.drmd.climber.mixin;

import com.terminaldetector.drmd.ClimberFieldGravityGameTests;
import com.terminaldetector.drmd.climber.ClimberBarrierWatch;
import net.minecraft.test.TestContext;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value=ClimberFieldGravityGameTests.class,remap=false)
public abstract class OldBarrierMethodProbe {
    @Inject(method="wallRouteUsesSupportedSidePassageWithoutBarrierPhasing",at=@At("HEAD"),remap=false)
    private void before(TestContext c,CallbackInfo ci){ClimberBarrierWatch.begin(c);}
    @Inject(method="wallRouteUsesSupportedSidePassageWithoutBarrierPhasing",at=@At("RETURN"),remap=false)
    private void after(TestContext c,CallbackInfo ci){ClimberBarrierWatch.end(c);}
}
