package com.terminaldetector.drmd;

import com.terminaldetector.drmd.climber.ClimberAirAcceptance;
import com.terminaldetector.drmd.world.gravity.*;
import net.fabricmc.fabric.api.gametest.v1.FabricGameTest;
import net.minecraft.block.Blocks;
import net.minecraft.entity.*;
import net.minecraft.entity.mob.SpiderEntity;
import net.minecraft.entity.passive.CowEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.test.*;
import net.minecraft.util.math.*;
import net.minecraft.world.LightType;
import java.util.*;

/** Additional jump-aware acceptance. The five original continuous-support fixtures remain unchanged. */
public final class ClimberJumpGravityGameTests implements FabricGameTest {
    private static final EntityType<?>[] TYPES={EntityType.SPIDER,EntityType.CAVE_SPIDER};
    private static final int ADMISSION=80,OBSERVE=120,MAX_FLIGHT=40;

    @GameTest(templateName=EMPTY_STRUCTURE,batchId="climber-native-floor-jump",tickLimit=320)
    public void ordinaryFloorNaturalPounceAdmitsAirArcAndReacquisition(TestContext c){run(c,false,false);}
    @GameTest(templateName=EMPTY_STRUCTURE,batchId="climber-local-wall-jump",tickLimit=320)
    public void wallNaturalPounceUsesLocalImpulseAndReacquiresSupport(TestContext c){run(c,true,false);}
    @GameTest(templateName=EMPTY_STRUCTURE,batchId="climber-jump-aware-wall-route",tickLimit=320)
    public void jumpAwareWallRouteUsesPassageAndReacquiresAfterNativePounces(TestContext c){run(c,true,true);}

    private static final class Trial {
        final SpiderEntity actor;final CowEntity target;final ClimberAirAcceptance.State trace;
        final Object navigation,control;final Vec3d start;final int spawnAge;
        final double initialDistance;int samples,illegalSweeps,maxPathIndex;boolean usedPassage,crossed,nativePath;
        Trial(SpiderEntity actor,CowEntity target,ClimberAirAcceptance.State trace){this.actor=actor;this.target=target;this.trace=trace;
            navigation=actor.getNavigation();control=actor.getMoveControl();start=actor.getPos();spawnAge=actor.age;
            initialDistance=start.distanceTo(target.getPos());}
    }
    private static void run(TestContext c,boolean wall,boolean barrierCase) {
        var centre=c.getAbsolutePos(new BlockPos(6,80,6));var room=new Room(c,centre);
        var up=wall?new Vec3d(1,0,0):new Vec3d(0,1,0);var trials=new ArrayList<Trial>();
        boolean[] spawned={false},finished={false};int plateY=room.min.getY()+5;
        var barrier=new Box(room.min.getX()+1,plateY,centre.getZ()-4,room.max.getX(),plateY+1,centre.getZ()+5);
        for(int tick=1;tick<310;tick++)c.runAtTick(tick,()->{
            if(finished[0])return;
            try {
                if(!spawned[0]) {
                    if(!room.ready()) {c.assertTrue(c.getTick()<ADMISSION,"FIXTURE: actual FULL/entity-ticking admission not reached by80");return;}
                    room.build(barrierCase,plateY);
                    for(int i=0;i<2;i++) {
                        var start=start(room,centre,wall,i);var target=start.add(wall?new Vec3d(0,barrierCase?5:3,0):new Vec3d(0,0,3));
                        if(!room.dark(start.add(up.multiply(.65)))||!room.dark(target.add(up.multiply(1.3)))) {
                            c.assertTrue(c.getTick()<ADMISSION,"FIXTURE: propagated dark eyes not reached by80");return;
                        }
                    }
                    for(int i=0;i<2;i++) {
                        var actor=(SpiderEntity)TYPES[i].create(room.world);var target=EntityType.COW.create(room.world);
                        c.assertTrue(actor!=null&&target!=null,"FIXTURE: actual native registered actor and Cow");
                        actor.setPersistent();target.setAiDisabled(true);target.setNoGravity(true);target.setInvulnerable(true);
                        double eye=actor.getEyeHeight(EntityPose.STANDING);
                        var origin=start(room,centre,wall,i);actor.setPosition(origin);
                        target.setPosition(origin.add(wall?new Vec3d(0,barrierCase?5:3,0):new Vec3d(0,0,3)));
                        if(wall)c.assertTrue(ActorFrames.trySetUp(actor,up)&&ActorFrames.trySetUp(target,up),"FIXTURE: one checked in-place frame before spawn");
                        room.spawn(actor);room.spawn(target);
                        // One initial seed/velocity only; ordinary native goals still decide whether and when to pounce.
                        actor.getRandom().setSeed(0);
                        if(!barrierCase)actor.setVelocity(ActorFrameMath.toWorld(new Vec3d(.02,0,.05),up));
                        var trace=ClimberAirAcceptance.arm(actor,target,up,eye);trials.add(new Trial(actor,target,trace));
                    }
                    if(wall)room.field(centre,up.negate());
                    if(wall)EntityGravitySystem.tick(room.world.getServer()); // sole disclosed fixture entry pass
                    for(var t:trials) {
                        var support=ClimberAirAcceptance.support(room.world,t.actor,up,t.trace.eyeHeight);
                        c.assertTrue(support.valid()&&room.world.shouldTickEntity(t.actor.getBlockPos()),"FIXTURE: real collider support and tick ownership before one target assignment");
                        t.actor.setTarget(t.target);ClimberAirAcceptance.emit(t.trace,t.actor,"ADMITTED",Map.of(
                            "wall",wall,"barrier",barrierCase,"initialSeed",0,"oneInitialVelocity",!barrierCase,"oneInitialTarget",true,"support",support));
                    }
                    spawned[0]=true;return;
                }
                boolean complete=true;
                for(var trial:trials) {
                    var actor=trial.actor;var trace=trial.trace;
                    c.assertTrue(actor.isAlive()&&!actor.isRemoved()&&room.world.getEntityById(actor.getId())==actor
                        &&room.world.shouldTickEntity(actor.getBlockPos()),"FIXTURE: admitted native actor remains alive/world-owned/entity-ticking");
                    c.assertTrue(actor.getTarget()==trial.target&&actor.getNavigation()==trial.navigation&&actor.getMoveControl()==trial.control
                        &&!actor.hasNoGravity()&&!actor.isAiDisabled(),"native goal/target/control/flags retain original ownership");
                    if(actor.age>trace.lastAge) {
                        c.assertTrue(trace.lastAge<0||actor.age==trace.lastAge+1,"FIXTURE: no missed ordinary actor samples");
                        var support=ClimberAirAcceptance.support(room.world,actor,up,trace.eyeHeight);
                        c.assertTrue(support.available()&&support.bodyClear()&&support.eyeError()<=1e-6&&support.upError()<=1e-6
                            &&room.dark(actor.getEyePos()),"actual loaded body/eye/localframe/dark evidence throughout flight");
                        var box=actor.getBoundingBox();
                        c.assertTrue(ClimberAirAcceptance.available(room.world,trace.previousBox.union(box).expand(1)),"actual swept body volume remains FULL without loads");
                        double step=actor.getPos().distanceTo(trace.previousPosition);trace.maximumStep=Math.max(trace.maximumStep,step);
                        c.assertTrue(step<=1,"native actual movement cannot teleport between observations");
                        if(support.gap()!=null)trace.maximumGap=Math.max(trace.maximumGap,support.gap());
                        if(support.valid()) {
                            if(trace.flightStart>=0) {
                                trace.maximumAirTicks=Math.max(trace.maximumAirTicks,actor.age-trace.flightStart);
                                c.assertTrue(actor.age-trace.flightStart<=MAX_FLIGHT,"native air arc reacquires measured support within40ordinaryticks");
                                trace.completedArcs++;trace.flightStart=-1;trace.lastLandingAge=actor.age;
                            }
                            if(trace.lastLandingAge>=0&&actor.age>trace.lastLandingAge&&actor.getNavigation().getCurrentPath()!=null)
                                trace.resumedNativeAfterLanding=true;
                        } else {
                            trace.unsupportedGroundClaim|=actor.isOnGround();
                            c.assertTrue(!actor.isOnGround(),"unsupported airborne state must not claim onGround");
                            if(trace.flightStart<0) {
                                c.assertTrue(trace.pounces>trace.consumedPounces&&actor.age-trace.lastPounceAge<=1,
                                    "support loss must have an actually observed fresh native pounce");
                                trace.flightStart=trace.lastPounceAge;trace.consumedPounces=trace.pounces;
                            }
                            c.assertTrue(actor.age-trace.flightStart<=MAX_FLIGHT,"air arc cannot remain unsupported beyond40ordinaryticks");
                            trace.sawDetached|=support.gap()==null||support.gap()>.16;
                        }
                        c.assertTrue(trace.impulseErrors==0,"actual native pounce preserves local aim/leap and inherited tangent momentum");
                        var path=actor.getNavigation().getCurrentPath();
                        if(path!=null){trial.nativePath=true;trial.maxPathIndex=Math.max(trial.maxPathIndex,path.getCurrentNodeIndex());}
                        if(barrierCase) {
                            var old=trace.previousBox;var expanded=barrier.contract(1e-6).expand(Math.max(old.getLengthX(),box.getLengthX())/2,
                                Math.max(old.getLengthY(),box.getLengthY())/2,Math.max(old.getLengthZ(),box.getLengthZ())/2);
                            if(expanded.contains(old.getCenter())||expanded.contains(box.getCenter())||expanded.raycast(old.getCenter(),box.getCenter()).isPresent())trial.illegalSweeps++;
                            boolean band=box.maxY>plateY+1e-6&&box.minY<plateY+1-1e-6;
                            boolean passage=box.minZ>=room.min.getZ()+1-1e-6&&box.maxZ<=centre.getZ()-4+1e-6
                                ||box.minZ>=centre.getZ()+5-1e-6&&box.maxZ<=room.max.getZ()+1e-6;
                            trial.usedPassage|=band&&passage&&support.valid();trial.crossed|=box.minY>=plateY+1+1e-6;
                            c.assertTrue(trial.illegalSweeps==0,"real whole-body sweep may not phase through plate");
                        }
                        trial.samples++;trace.lastAge=actor.age;trace.previousBox=box;trace.previousPosition=actor.getPos();
                        ClimberAirAcceptance.emit(trace,actor,"ORDINARY_OBSERVATION",Map.of("support",support,"samples",trial.samples,
                            "pounces",trace.pounces,"completeArcs",trace.completedArcs,"nativeAfterLanding",trace.resumedNativeAfterLanding,
                            "airStartAge",trace.flightStart,"usedSupportedPassage",trial.usedPassage,"entireBodyCrossed",trial.crossed));
                    }
                    if(actor.age-trial.spawnAge<OBSERVE)complete=false;
                }
                if(!complete)return;
                for(var trial:trials) {
                    var trace=trial.trace;var actor=trial.actor;
                    var result=new LinkedHashMap<String,Object>();result.put("ordinaryTicks",actor.age-trial.spawnAge);result.put("samples",trial.samples);
                    result.put("pounces",trace.pounces);result.put("impulseErrors",trace.impulseErrors);result.put("completedAirArcs",trace.completedArcs);
                    result.put("maximumGap",trace.maximumGap);result.put("maximumAirTicks",trace.maximumAirTicks);result.put("maximumStep",trace.maximumStep);
                    result.put("nativeAfterLanding",trace.resumedNativeAfterLanding);result.put("usedSupportedPassage",trial.usedPassage);
                    result.put("entireBodyCrossed",trial.crossed);result.put("illegalSweeps",trial.illegalSweeps);result.put("nativePathObserved",trial.nativePath);
                    result.put("maxPathIndex",trial.maxPathIndex);result.put("distanceImprovement",trial.initialDistance-actor.getPos().distanceTo(trial.target.getPos()));
                    ClimberAirAcceptance.emit(trace,actor,"FINAL",result);
                    if(barrierCase)c.assertTrue(trial.samples>=OBSERVE&&trial.nativePath&&trial.maxPathIndex>=1&&trial.usedPassage&&trial.crossed
                        &&trace.flightStart<0&&actor.getY()-trial.start.y>=1&&trial.initialDistance-actor.getPos().distanceTo(trial.target.getPos())>=1,
                        "new explicit jump-aware route requires real supported passage/crossing and progress; oldstrictfixture remains separate");
                    else c.assertTrue(trial.samples>=OBSERVE&&trace.pounces>0&&trace.sawDetached&&trace.completedArcs>0
                        &&trace.flightStart<0&&trace.resumedNativeAfterLanding,
                        "NATIVE_JUMP_ADMISSION: actual natural pounce, detached air arc, support reacquisition and native AI resumption required");
                }
                finished[0]=true;room.close();c.complete();
            } catch(Throwable failure){finished[0]=true;room.close();throw failure;}
        });
        c.runAtTick(310,()->{if(!finished[0]){finished[0]=true;room.close();c.assertTrue(false,"FIXTURE: new air acceptance timed out; no implicit pass");}});
    }
    private static Vec3d start(Room room,BlockPos centre,boolean wall,int index) {
        return wall?new Vec3d(room.min.getX()+1.02,room.min.getY()+2.5,centre.getZ()+(index==0?-2.5:2.5)):
            new Vec3d(centre.getX()+(index==0?-3:3)+.5,room.min.getY()+1.02,centre.getZ()-2.5);
    }
    private static final class Room implements AutoCloseable {
        final ServerWorld world;final TestContext c;final BlockPos min,max;final AiFixtureChunks chunks;
        final List<Entity> actors=new ArrayList<>();final List<UUID> fields=new ArrayList<>();boolean built,closed;
        Room(TestContext c,BlockPos centre){this.c=c;world=c.getWorld();min=centre.add(-8,0,-8);max=centre.add(8,12,8);chunks=new AiFixtureChunks(world,centre,1);}
        boolean ready(){return chunks.entityTicking(min,max)&&ClimberAirAcceptance.available(world,new Box(Vec3d.of(min),Vec3d.of(max.add(1,1,1))).expand(1));}
        boolean dark(Vec3d eye){var at=BlockPos.ofFloored(eye);return world.getLightLevel(LightType.SKY,at)==0&&world.getLightLevel(LightType.BLOCK,at)==0;}
        void build(boolean barrier,int plateY) {
            if(built)return;
            for(var at:BlockPos.iterate(min,max)) {
                boolean shell=at.getX()==min.getX()||at.getX()==max.getX()||at.getY()==min.getY()||at.getY()==max.getY()||at.getZ()==min.getZ()||at.getZ()==max.getZ();
                world.setBlockState(at,(shell?Blocks.OBSIDIAN:Blocks.AIR).getDefaultState(),2);
            }
            if(barrier)for(var at:BlockPos.iterate(new BlockPos(min.getX()+1,plateY,(min.getZ()+max.getZ())/2-4),
                new BlockPos(max.getX()-1,plateY,(min.getZ()+max.getZ())/2+4)))world.setBlockState(at,Blocks.OBSIDIAN.getDefaultState(),2);
            built=true;
        }
        void spawn(Entity actor){actors.add(actor);c.assertTrue(world.spawnEntity(actor),"FIXTURE: actual world registration");}
        void field(BlockPos centre,Vec3d down){UUID id=UUID.randomUUID();fields.add(id);GravityFields.put(new GravityFields.Field(id,world.getRegistryKey(),centre.add(0,6,0),down,32,1,FieldShape.SPHERE,"native jump acceptance"));}
        @Override public void close(){if(closed)return;closed=true;for(UUID id:fields)GravityFields.remove(id);for(var actor:actors)actor.discard();
            EntityGravitySystem.tick(world.getServer());if(built)for(var at:BlockPos.iterate(min,max))world.setBlockState(at,Blocks.AIR.getDefaultState(),2);chunks.close();}
    }
}
