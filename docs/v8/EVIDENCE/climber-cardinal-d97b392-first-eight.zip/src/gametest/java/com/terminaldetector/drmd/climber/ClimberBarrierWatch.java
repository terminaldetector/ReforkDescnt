package com.terminaldetector.drmd.climber;

import net.minecraft.test.TestContext;
import net.minecraft.entity.Entity;
import net.minecraft.entity.mob.SpiderEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.*;
import java.lang.ref.WeakReference;
import java.util.*;

/** One passive309 snapshot of the old untouched barrier fixture, including native tick admission. */
public final class ClimberBarrierWatch {
    public static final boolean ENABLED=Boolean.getBoolean("drmd.gate.climberBarrierWatch");
    private static WeakReference<TestContext> constructing=new WeakReference<>(null);
    private static final Map<UUID,Integer> SPAWN_AGES=new LinkedHashMap<>();
    private ClimberBarrierWatch() {}
    public static void begin(TestContext c){if(ENABLED){constructing=new WeakReference<>(c);SPAWN_AGES.clear();}}
    public static void spawned(Entity actor) {
        if(!(actor instanceof SpiderEntity))return;
        if(SPAWN_AGES.size()>=2)throw new IllegalStateException("oldbarrier spawn observer budget exceeded");
        SPAWN_AGES.put(actor.getUuid(),actor.age);
    }
    public static void end(TestContext c){if(ENABLED&&constructing.get()==c)constructing.clear();}
    public static boolean owns(TestContext c){return ENABLED&&constructing.get()==c;}
    public static void record(TestContext c,ServerWorld world,List<Entity> actors,boolean built,boolean closed,boolean full) {
        var rows=new ArrayList<Map<String,Object>>();
        for(var entity:actors)if(entity instanceof SpiderEntity actor) {
            if(rows.size()>=2)throw new IllegalStateException("oldbarrier309 observer actor budget exceeded");
            var row=new LinkedHashMap<String,Object>();row.put("uuid",actor.getUuid().toString());row.put("type",actor.getType().toString());
            row.put("actualAge",actor.age);row.put("recordedSpawnAge",SPAWN_AGES.get(actor.getUuid()));row.put("alive",actor.isAlive());row.put("health",actor.getHealth());row.put("removed",actor.isRemoved());
            row.put("worldOwnsEntity",world.getEntityById(actor.getId())==actor);row.put("shouldTickEntity",world.shouldTickEntity(actor.getBlockPos()));
            row.put("forcedColumn",world.getForcedChunks().contains(new ChunkPos(actor.getBlockPos()).toLong()));
            row.put("position",ClimberAirAcceptance.vector(actor.getPos()));row.put("eye",ClimberAirAcceptance.vector(actor.getEyePos()));
            var box=actor.getBoundingBox();row.put("bounds",List.of(box.minX,box.minY,box.minZ,box.maxX,box.maxY,box.maxZ));
            row.put("velocity",ClimberAirAcceptance.vector(actor.getVelocity()));row.put("navigationIdle",actor.getNavigation().isIdle());
            row.put("localUp",ClimberAirAcceptance.vector(com.terminaldetector.drmd.world.gravity.ActorFrames.up(actor)));
            var field=com.terminaldetector.drmd.world.gravity.GravityFields.sample(world,actor.getPos());
            row.put("fieldStrength",field==null?null:field.strength());row.put("fieldUp",field==null?null:ClimberAirAcceptance.vector(field.upDir()));
            var path=actor.getNavigation().getCurrentPath();row.put("path",path==null?null:Map.of("identity",System.identityHashCode(path),"index",path.getCurrentNodeIndex(),"length",path.getLength()));
            rows.add(row);
        }
        int idle;
        try {var field=ServerWorld.class.getDeclaredField("idleTimeout");field.setAccessible(true);idle=field.getInt(world);}
        catch(ReflectiveOperationException failure){throw new IllegalStateException("oldbarrier idle observer contract mismatch",failure);}
        System.out.println("CLIMBER_BARRIER_309 "+new com.google.gson.Gson().toJson(Map.of("testTick",c.getTick(),"worldTime",world.getTime(),
            "serverTick",world.getServer().getTicks(),"nativeIdleTimeout",idle,"built",built,"closed",closed,"fixtureFull",full,"actors",rows)));
    }
}
