"""Collect exact candidate proof only after BOTH independent native modes actually pass."""
from pathlib import Path
import hashlib,json,subprocess,sys,xml.etree.ElementTree as E,zipfile

root=Path.cwd();work=root/'work/ps1';scenarios=sys.argv[1:]
assert len(scenarios)==2 and sum('gl32' in s for s in scenarios)==1
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def results(p,expected):
    r=E.parse(p);cases=list(r.iter('testcase'));assert len(cases)==expected and not list(r.iter('failure')) and not list(r.iter('error')),p
    return {'tests':expected,'failures':0,'errors':0}
server=results(work/'full-passed.xml',376)
unit={'tests':0,'failures':0,'errors':0,'skipped':0};unitfiles=list((root/'build/test-results/test').glob('TEST-*.xml'))
for p in unitfiles:
    r=E.parse(p).getroot()
    for k in unit:unit[k]+=int(r.get(k,0))
assert unit==dict(tests=763,failures=0,errors=0,skipped=0)
subprocess.run(['python3','scripts/v8/ps1_build_stamp.py','check'],check=True)
stamp=json.loads((work/'verified-build.json').read_text());full=json.loads((work/'full-passed-build.json').read_text());native_source=stamp['sourceSha'];full_source=(work/'full-source.txt').read_text().strip()
game='build/libs/drmd-6dof-1.1.35-ufo-dev.1.jar';assert stamp['jars'][game]==full['jars'][game]
assert not subprocess.check_output(['git','diff',full_source,native_source,'--','src/main','src/test','src/gametest','build.gradle','settings.gradle','gradle.properties'])
names=['native-baseline','ps1-360','native-restored','debug-wireframe','ps1-180-resized','native-window-restored']
native={};runtimes=[]
for scenario in scenarios:
    runtime=root/'build'/('cubic-client-final-'+scenario);runtimes.append(runtime)
    manifest=json.loads((runtime/'inputs.json').read_text());assert manifest['sourceSha']==native_source and manifest['candidateJars']==stamp['jars']
    assert not list((runtime/'crash-reports').glob('*.txt'))
    marker=json.loads((runtime/'presentation-ok.json').read_text())
    assert marker['runtimeToggleWithoutReload'] and marker['actualWindowResizeAndRestore'] and marker['exceptionTargetsRestored']
    assert marker['blockstoreHashUnchanged'] and marker['independentHybridChoiceUnchanged']
    assert [s['scene'] for s in marker['scenes']]==names
    for scene in marker['scenes']:
        assert scene['nativeHudPixel'] and scene['glError']==0
        if scene['profile']=='PS1_HYBRID':
            assert scene['worldNearestGridRatio']>.97 and scene['deferredOverlayPasses']>=2
            assert scene['sampleEpoch']==scene['frameEpoch']==scene['mirrorEpoch']
            assert scene['mergedMirrorSurfaces']==1 and scene['projectedMirrorPanes']==8
            assert (runtime/'presentation-frames'/(scene['scene']+'-world-before-overlays.png')).is_file()
        if scene['profile']!='RENDER_DEBUG':assert scene['reflectedGoldPixels']>=30 and scene['mirror'].startswith('drawing')
        assert (runtime/'presentation-frames'/(scene['scene']+'.png')).is_file()
    if 'fabulous' in scenario:assert 'graphicsMode:2' in (runtime/'options.txt').read_text()
    assert len(list((runtime/'presentation-frames').glob('*.png')))==8
    sodium=any('sodium' in a['path'].lower() for a in manifest['artifacts'])
    assert sodium==('gl32' not in scenario)
    native[scenario]=marker
summary=dict(nativeSource=native_source,fullSource=full_source,unit=unit,server=server,jars=stamp['jars'],sameFullAndNativeGameBytes=True,native=native,
             verifiedDatesUtc={'full':'2026-11-09','ps1-layer-fixed-sodium':'2026-11-10','ps1-layer-fixed-fabulous-gl32':'2026-11-11'},
             imagesInspected=16,debugKnownNegative='Fabulous wireframe frame is mostly black with a fullscreen diagonal; useful world-edge visualization remains unaccepted.',
             scope='Initial scene target/profile and stable-overlay increment only; front-wall hash and enabled-mode assertion are representative. Full S04/S05/v8 remain open.',releaseAccepted=False,publication='Local only')
(work/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
(work/'source-series.patch').write_text(subprocess.check_output(['git','diff','8e5111b',native_source,'--','src','scripts/v8'],text=True))
files={}
def add(p,name=None):
    assert p.is_file() and not p.is_symlink(),p
    files[name or str(p.relative_to(root))]=p
for p in work.iterdir():
    if p.is_file() and p.suffix in {'.log','.json','.xml','.txt','.patch','.py','.sh','.gradle'}:add(p)
for p in unitfiles:add(p)
for runtime in runtimes:
    for name in ['inputs.json','launch.json','options.txt','presentation-ok.json']:add(runtime/name)
    for p in (runtime/'presentation-frames').glob('*.png'):add(p)
for runtime in (root/'build').glob('cubic-client-failed-ps1-*'):
    for folder in ['presentation-frames','presentation-failure']:
        for p in (runtime/folder).glob('*'):
            if p.is_file():add(p)
# Exact candidate bytes remain locally in build/libs; compact tracked evidence stores hashes only.
for p in (root/'scripts/v8').glob('ps1*'):
    if p.is_file():add(p)
add(root/'docs/v8/PS1_PRESENTATION_WIP.md')
official=Path('/workspace/ungravity-v5/ufo-body-physics/scripts/v5/prepare_cubic_client.py');add(official,'official_stager/prepare_cubic_client.py')
manifest={name:sha(p) for name,p in sorted(files.items())}
dest=root/'docs/v8/EVIDENCE'/('ps1-target-'+native_source[:7]+'.zip');dest.parent.mkdir(parents=True,exist_ok=True);assert not dest.exists()
with zipfile.ZipFile(dest,'x',zipfile.ZIP_DEFLATED) as z:
    for name,p in sorted(files.items()):z.write(p,name)
    z.writestr('MANIFEST.json',json.dumps(dict(nativeSource=native_source,fullSource=full_source,files=manifest),indent=2))
with zipfile.ZipFile(dest) as z:
    assert z.testzip() is None
    for name,digest in manifest.items():assert hashlib.sha256(z.read(name)).hexdigest()==digest,name
receipt=dict(archive=str(dest.relative_to(root)),archiveSha256=sha(dest),verifiedFiles=len(manifest),crcAndHashesVerified=True,nativeSource=native_source,fullSource=full_source,jars=stamp['jars'],unit=unit,server=server,scope=summary['scope'],debugKnownNegative=summary['debugKnownNegative'],releaseAccepted=False)
(dest.with_suffix('.json')).write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
