package com.terminaldetector.drmd.gate;

import com.terminaldetector.drmd.client.flight.BoardingClient;
import com.terminaldetector.drmd.client.flight.UfoControlClient;
import com.terminaldetector.drmd.world.contraption.BlockBodyEntity;
import com.terminaldetector.drmd.world.contraption.boarding.BoardingSystem;
import com.terminaldetector.drmd.world.mega.*;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.ScreenshotRecorder;
import net.minecraft.nbt.*;
import java.nio.file.*;
import java.util.UUID;

/** Two actual client processes and the same saved world; no NBT clone or replacement hull. */
public final class NativeUfoReloadCheck {
    public static final boolean WRITE=Boolean.getBoolean("drmd.gate.ufoReloadWrite");
    public static final boolean READ=Boolean.getBoolean("drmd.gate.ufoReloadRead");
    private static volatile UUID watched;
    private static volatile boolean restored,serverReady;
    private static volatile int restoredEngines,savedUfoSchema;
    private static boolean done;private static int ticks,draws,stable,frames;
    private static final int READY_DELAY=Integer.getInteger("drmd.gate.restoreReadyDelay",0);
    private static final java.util.Map<net.minecraft.server.network.ServerPlayerEntity,Integer> DELAYED=new java.util.HashMap<>();
    private static boolean releasingReady;private static int admissionTicks;
    private static volatile boolean walkRequested,walkObserved;private static int walkTicks;
    private static volatile net.minecraft.util.math.Vec3d walkFrom;private static volatile double walked;
    private static Path file(String name){return MinecraftClient.getInstance().runDirectory.toPath().resolve(name);}
    private static void require(boolean b,String why){if(!b)throw new IllegalStateException(why);}
    private NativeUfoReloadCheck(){}
    private static net.minecraft.entity.Entity entity(BlockBodyEntity body){return body;}
    public static boolean delayReady(net.minecraft.server.network.ServerPlayerEntity p,int version) {
        if(!READ||READY_DELAY<=0||releasingReady||version!=com.terminaldetector.drmd.network.BoardingNetworking.PROTOCOL)return false;
        DELAYED.putIfAbsent(p,-1);return true;
    }
    public static void watch(UUID id) {
        watched=id;try{Files.writeString(file("ufo-reload-target.txt"),id.toString());}catch(Exception e){throw new IllegalStateException(e);}
    }
    public static void saved(SkyUfoEntity body,NbtCompound n) {
        if(!WRITE||entity(body).getWorld().isClient||!entity(body).getUuid().equals(watched))return;
        try{Files.writeString(file("ufo-reload-expected.snbt"),n.toString());}catch(Exception e){throw new IllegalStateException(e);}
    }
    public static void loaded(SkyUfoEntity body,NbtCompound saved) {
        if(!READ||entity(body).getWorld().isClient)return;
        try {
            var id=UUID.fromString(Files.readString(file("ufo-reload-target.txt")).trim());if(!entity(body).getUuid().equals(id))return;
            var expected=StringNbtReader.parse(Files.readString(file("ufo-reload-expected.snbt")));
            var actual=entity(body).writeNbt(new NbtCompound());
            require(expected.getCompound("body").equals(saved.getCompound("body")),"world storage must retain the exact saved physics data");
            var before=expected.getCompound("body");var after=actual.getCompound("body");
            // Rotation is normalized on load; motionPaused is a current-tick render
            // readiness hint, not persisted physical motion. Check actual state explicitly.
            for(String key:new String[]{"qx","qy","qz","qw","vx","vy","vz","lx","ly","lz","passengerGravityx","passengerGravityy","passengerGravityz"})
                require(Double.isFinite(after.getDouble(key))&&Math.abs(before.getDouble(key)-after.getDouble(key))<=1e-10,"restored physical component differs: "+key);
            require(before.getBoolean("gravity")==after.getBoolean("gravity"),"restored gravity mode");
            require(expected.getList("Pos",NbtElement.DOUBLE_TYPE).equals(actual.getList("Pos",NbtElement.DOUBLE_TYPE)),"restored world position");
            require(expected.getCompound("shape").equals(actual.getCompound("shape")),"actual world reload must retain the local block grid");
            require(!body.hasSimulatedPhysics(),"restored engine grid observed before the first physical tick");
            var engineCells=com.terminaldetector.drmd.world.contraption.BodyShapeCodec.read(expected.getCompound("shape"));
            savedUfoSchema=expected.getInt("physicalUfoSchema");boolean legacy=savedUfoSchema==1||expected.getBoolean("legacyThrusters");
            int expectedEngines=(int)engineCells.stream().filter(cell->SkyUfoThrusters.SLOTS.contains(cell.pos())&&(cell.state().isOf(com.terminaldetector.drmd.entity.ModWorldBlocks.SHIP_THRUSTER)||legacy&&cell.state().isOf(net.minecraft.block.Blocks.PRISMARINE_BRICKS))).count();
            restoredEngines=body.activeThrusters();require(restoredEngines==expectedEngines&&actual.getInt("physicalUfoSchema")==2&&actual.getBoolean("legacyThrusters")==legacy,"actual new/legacy engine availability must restore without repairing the saved material");
            require(expected.getBoolean("autopilot")&&body.autopilotEnabled(),"reload restores the pre-capture AI mode");
            require(body.physics().linearVelocity().length()>.1&&body.physics().angularVelocity().length()>.01,"fixture must save a translating and rotating ship");
            watched=id;restored=true;System.out.println("UFO_RELOAD_NBT PASS uuid="+id+" cells="+body.cells().size());
            for(var p:((net.minecraft.server.world.ServerWorld)entity(body).getWorld()).getPlayers())
                System.out.println("UFO_RELOAD_INITIAL_PLAYER local="+body.worldToLocal(p.getPos())+" velocity="+p.getVelocity()+" flying="+p.getAbilities().flying+" suit="+com.terminaldetector.drmd.DescentPlayerData.get(p).isEnabled()+" ready="+BoardingSystem.ready(p));
        }catch(Exception e){throw new IllegalStateException("actual UFO reload verification failed",e);}
    }
    public static void register() {
        require(READ,"reload reader stand only");
        require(MinecraftClient.getInstance().runDirectory.toPath().getFileName().toString().equals("cubic-client-automation"),"disposable native runtime only");
        ServerTickEvents.END_SERVER_TICK.register(s->{
            if(restored)for(var p:java.util.List.copyOf(DELAYED.keySet())) {
                int due=DELAYED.get(p);if(due<0){DELAYED.put(p,s.getTicks()+READY_DELAY);continue;}
                if(s.getTicks()>=due){DELAYED.remove(p);releasingReady=true;try{BoardingSystem.ready(p,com.terminaldetector.drmd.network.BoardingNetworking.PROTOCOL);}finally{releasingReady=false;}}
            }
            if(!restored)return;var w=s.getOverworld();var e=w.getEntity(watched);if(!(e instanceof SkyUfoEntity body))return;
            var players=s.getPlayerManager().getPlayerList();if(players.isEmpty())return;var p=players.getFirst();
            require(!UfoControlSystem.controls(p),"old pilot connection must not survive a process restart");
            var state=BoardingSystem.state(p);
            if(serverReady){
                var local=body.worldToLocal(p.getPos());walked=Math.hypot(local.x-walkFrom.x,local.z-walkFrom.z);
                if(walkRequested&&walked>.3&&BoardingSystem.drives(p)&&state!=null&&state.grounded())walkObserved=true;return;
            }
            if(READY_DELAY>0&&!BoardingSystem.ready(p)) {
                require(com.terminaldetector.drmd.DescentPlayerData.get(p).pendingBoardingResume()!=null&&!body.hasSimulatedPhysics(),"saved passenger and newly loaded hull must wait together for admission");admissionTicks++;
            }
            require(w.getEntitiesByClass(SkyUfoEntity.class,entity(body).getBoundingBox().expand(64),u->true).size()==1,"reload must not duplicate the local UFO");
            if(s.getTicks()%20==0)System.out.println("UFO_RELOAD_CONTACT local="+body.worldToLocal(p.getPos())+" walking="+BoardingSystem.drives(p)+" stable="+stable+" playerWorld="+p.getWorld().getRegistryKey().getValue());
            if(body.containsPos(p.getPos())&&BoardingSystem.drives(p)&&state!=null&&state.grounded())stable++;else stable=0;
            if(stable>=40){require(READY_DELAY<=0||admissionTicks>=20,"delayed native handshake must exercise the load barrier");walkFrom=body.worldToLocal(p.getPos());serverReady=true;}
        });
        ClientTickEvents.END_CLIENT_TICK.register(c->{
            if(done)return;if(++ticks>1800)throw new IllegalStateException("UFO reload timeout: restored="+restored+" contact="+stable+" draws="+draws);
            com.terminaldetector.drmd.client.DescentClient.markUserFlightChoice();
            if(ticks%100==0)System.out.println("UFO_RELOAD_CLIENT restored="+restored+" ready="+serverReady+" stable="+stable+" draws="+draws+" screen="+(c.currentScreen==null?null:c.currentScreen.getClass().getName()));
            if(c.currentScreen instanceof net.minecraft.client.gui.screen.world.BackupPromptScreen prompt)for(var child:prompt.children())
                if(child instanceof net.minecraft.client.gui.widget.ButtonWidget b&&b.getMessage().getString().equals("I know what I'm doing!"))b.onPress();
            if(c.player!=null&&c.world!=null&&serverReady){
                require(!UfoControlClient.active(),"client cannot retain a previous process's pilot input");require(BoardingClient.drives(c.player),"saved player must resume physical walking on the saved UFO");
                if(!walkRequested){walkRequested=true;walkTicks=0;c.options.leftKey.setPressed(true);}
                else if(++walkTicks>=14)c.options.leftKey.setPressed(false);
                require(walkTicks<80||walkObserved,"ordinary keys must walk after the actual world restart");
            }
        });
    }
    public static void drew(BlockBodyEntity body){if(READ&&entity(body).getUuid().equals(watched))draws++;}
    public static void rendered() {
        var c=MinecraftClient.getInstance();if(done||!serverReady||!walkObserved||walkTicks<14||draws<20||c.currentScreen!=null||++frames<3)return;
        try(var image=ScreenshotRecorder.takeScreenshot(c.getFramebuffer())) {
            image.writeTo(file("ufo-reloaded.png"));
            Files.writeString(file("ufo-reload-ok.json"),"{\"restoredEngines\":"+restoredEngines+",\"sourceUfoSchema\":"+savedUfoSchema+",\"postLoadWalking\":true,\"postLoadDistance\":"+walked+",\"admissionTicks\":"+admissionTicks+",\"actualProcessRestart\":true,\"serializedDataExact\":true,\"restoredPhysicsTolerance\":1e-10,\"sameUuid\":\""+watched+"\",\"noDuplicateHull\":true,\"restoredWalkingTicks\":"+stable+",\"renderedFrames\":"+draws+",\"stalePilotAbsent\":true}\n");
            done=true;c.scheduleStop();
        }catch(Exception e){throw new IllegalStateException(e);}
    }
}
