from pathlib import Path
import hashlib,json,subprocess,zipfile,xml.etree.ElementTree as E,re
subprocess.run(['python3','work/ufo-body/native/verify-build-stamp.py','check'],check=True)
source=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();files=set()
def add(p):
 p=Path(p);assert p.is_file(),p;files.add(p)
for name in subprocess.check_output(['git','diff','--name-only','d6e2b47',source],text=True).splitlines():
 if name.startswith('src/'):add(name)
for name in ['build.gradle','gradle.properties','src/gametest/resources/fabric.mod.json','build/resources/gametest/fabric.mod.json','build/gametest/reports/gametest-results.xml','work/ufo-body/engine-focus.init.gradle','work/ufo-body/engine-final-force-test.init.gradle','work/ufo-body/engines-focused-fixed-20261107.xml','work/ufo-body/native/verified-build.json','work/ufo-body/native/run-engines.sh','work/ufo-body/native/run-engine-reload-pair.sh','work/ufo-body/native/run-engine-reload-read.sh','work/ufo-body/native/run-engine-legacy-read.sh','work/ufo-body/native/engines-final-checks-20261107.sh','work/ufo-body/native/engines-final-checks-20261107.log','work/ufo-body/collect-engines-evidence-20261107.py']:add(name)
for glob in ['engines-*.log','engines-*failure*.zip']:
 for p in Path('work/ufo-body').glob(glob):add(p)
for p in Path('build/test-results/test').glob('TEST-*.xml'):add(p)
stamp=json.loads(Path('work/ufo-body/native/verified-build.json').read_text())
for p,h in stamp['jars'].items():assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==h;add(p)
markers={}
for profile in ['gl32','sodium']:
 scenario='flight-body-control-engines-final4-'+profile;r=Path('build/cubic-client-final-'+scenario)
 info=json.loads((r/'inputs.json').read_text());assert info['sourceSha']==source and not info['uncommittedDiff']
 for suffix in ['.log','.exit','-prepare.log']:add('work/ufo-body/native/final-'+scenario+suffix)
 assert Path('work/ufo-body/native/final-'+scenario+'.exit').read_text().strip()=='0'
 for f in ['inputs.json','launch.json','ufo-control-ok.json']:add(r/f)
 m=json.loads((r/'ufo-control-ok.json').read_text());assert m['engineOffSamples']>=12 and m['engineOnSamples']>=12 and m['engineOffSixAxisInputs']>=8 and m['engineOnSixAxisInputs']>=8 and m['engineOffMaxVelocityDelta']<.2 and m['engineOnVelocityDelta']>.8 and m['materialPointError']<1e-8 and m['inertialTravel']>.2 and m['inertialTurn']>.01 and m['restoredEngines']==4 and m['newEngineItemObserved'] and m['maxPredictionError']<.8 and m['bayResumed'] and m['pauseResumed']
 assert len(m['independentAxisSamples'])==6 and min(m['independentAxisSamples'])>=4 and m['maxEngineVelocityLawError']<1e-8 and m['maxEngineMomentumLawError']<1e-6
 for key in ['localVelocityDelta','localMomentumDelta']:assert all(abs(m[key][a])>.1 for a in ['x','y','z'])
 assert len(m['scenes'])==11
 png=list((r/'flight-body-frames').glob('*.png'));assert len(png)==11
 for f in png:add(f)
 markers[profile]=m
reads={}
for name,schema in [('flight-body-control-engines-20261107-sodium',2),('flight-body-control-engine-legacy-20261107-sodium',1)]:
 r=Path('build/cubic-client-final-'+name);proof=r/'reload-proof'
 info=json.loads((r/'inputs.json').read_text());assert info['sourceSha']==source and not info['uncommittedDiff']
 for f in ['inputs.json','launch.json','ufo-reload-target.txt','ufo-reload-expected.snbt','ufo-reload-ok.json','ufo-reloaded.png']:add(r/f)
 for p in proof.iterdir():
  if p.is_file():add(p)
 for p in (r/'flight-body-frames').glob('*.png'):add(p)
 for ext in ['.log','.exit']:add('work/ufo-body/native/final-'+name+ext)
 assert Path('work/ufo-body/native/final-'+name+'.exit').read_text().strip()=='0'
 m=json.loads((r/'ufo-reload-ok.json').read_text());assert m['sourceUfoSchema']==schema and m['restoredEngines']==4 and m['actualProcessRestart'] and m['serializedDataExact'] and m['noDuplicateHull'] and m['stalePilotAbsent'] and m['postLoadWalking'] and m['postLoadDistance']>.3 and m['restoredWalkingTicks']>=40 and m['admissionTicks']>=20
 meta=json.loads((proof/'first-process-world.json').read_text());p=proof/'first-process-world.zip';assert hashlib.sha256(p.read_bytes()).hexdigest()==meta['sha256']
 with zipfile.ZipFile(p) as z:
  assert z.testzip() is None
  for n,h in meta['files'].items():assert hashlib.sha256(z.read(n)).hexdigest()==h
 if schema==2:assert json.loads((proof/'write-inputs.json').read_text())['sourceSha']==source
 else:assert json.loads((proof/'write-inputs.json').read_text())['sourceSha']=='08d61c3a2bdc758924252ed1e7d28e8f9c3ff826'
 reads[str(schema)]=dict(marker=m,snapshotSha256=meta['sha256'],originalWriter=json.loads((proof/'write-inputs.json').read_text()).get('sourceSha'))
for ext in ['.log','.exit']:add('work/ufo-body/native/final-flight-body-control-save-engines-20261107-sodium'+ext)
assert Path('work/ufo-body/native/final-flight-body-control-save-engines-20261107-sodium.exit').read_text().strip()=='0'
rs=[E.parse(p).getroot() for p in Path('build/test-results/test').glob('TEST-*.xml')];u={k:sum(int(r.get(k,0)) for r in rs) for k in ['tests','failures','errors','skipped']};cs=list(E.parse('build/gametest/reports/gametest-results.xml').iter('testcase'));g={'tests':len(cs),'failures':sum(c.find('failure') is not None for c in cs),'errors':sum(c.find('error') is not None for c in cs),'skipped':sum(c.find('skipped') is not None for c in cs)}
assert u==dict(tests=728,failures=0,errors=0,skipped=0) and g==dict(tests=298,failures=0,errors=0,skipped=0)
assert json.loads(Path('build/resources/gametest/fabric.mod.json').read_text())['entrypoints']==json.loads(Path('src/gametest/resources/fabric.mod.json').read_text())['entrypoints']
assert 'BUILD SUCCESSFUL' in Path('work/ufo-body/engines-final-regressions-20261107.log').read_text()
s=dict(source=source,productionSource=subprocess.check_output(['git','rev-parse','cfbedc9'],text=True).strip(),jars=stamp['jars'],unit=u,server=g,native=markers,reload=reads,files={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(files)},releaseAccepted=False,publication='Local only',scope='Reference rigid UFO with four actual destructible vector-engine blocks, fixed capacity, mounted impulses, independent six-axis native inertia response, repair, schema2 and real schema1 saved-world restore. Full v8/G2/Dynamic Boarding are not closed.')
p=Path('docs/v8/EVIDENCE/engines-'+source[:7]+'.zip')
with zipfile.ZipFile(p,'x',zipfile.ZIP_DEFLATED) as z:
 for f in sorted(files):z.write(f,str(f))
 z.writestr('MANIFEST.json',json.dumps(s,indent=2))
with zipfile.ZipFile(p) as z:
 assert z.testzip() is None
 for n,h in s['files'].items():assert hashlib.sha256(z.read(n)).hexdigest()==h
s['archive']=str(p);s['archiveSha256']=hashlib.sha256(p.read_bytes()).hexdigest();Path('work/ufo-body/engines-summary-20261107.json').write_text(json.dumps(s,indent=2)+'\n');print(json.dumps({k:v for k,v in s.items() if k!='files'},indent=2))
