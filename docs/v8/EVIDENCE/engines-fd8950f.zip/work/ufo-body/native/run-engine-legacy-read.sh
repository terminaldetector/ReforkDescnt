#!/usr/bin/env bash
set -euo pipefail
cd /workspace/ungravity-v5/ufo-body-physics
scenario="$1"
python3 work/ufo-body/native/verify-build-stamp.py check
test ! -e "build/cubic-client-final-${scenario}"
if [ -e build/cubic-client-automation ]; then
  mv build/cubic-client-automation "build/cubic-client-before-${scenario}"
fi
args=()
if [[ "$scenario" != *gl32* ]]; then
  args+=(--sodium /workspace/ungravity-v5/world/work/gate0/upstream/sodium-fabric-0.8.13+mc1.21.1.jar)
fi
python3 work/ufo-body/native/prepare-with-verified-library-links.py --server-runtime /workspace/ungravity-v5/world/build/cubic-seed2-gate --runtime build/cubic-client-automation --drmd build/libs/drmd-6dof-1.1.35-ufo-dev.1.jar --gate build/libs/drmd-6dof-1.1.35-ufo-dev.1-cubiccheck.jar --bcc /workspace/Refork-audit/work/master-v5/upstream/bettercubicchunks-fabric-0.1.1+mc1.21.1.jar --api /workspace/.gradle/caches/modules-2/files-2.1/net.fabricmc.fabric-api/fabric-api/0.116.15+1.21.1/d25c793833a90cc028c9a61bc4546cd578a70ce1/fabric-api-0.116.15+1.21.1.jar --java /workspace/jdk21-complete/bin/java "${args[@]}" > "work/ufo-body/native/final-${scenario}-prepare.log"
python3 work/ufo-body/native/dedup-staged-libraries.py "$scenario"
python3 work/ufo-body/native/seed-verified-minecraft-remap.py
python3 - "$scenario" <<'PY'
import sys,json,pathlib,subprocess
scenario=sys.argv[1];root=pathlib.Path('build/cubic-client-automation')
p=root/'launch.json';a=json.loads(p.read_text());a.insert(1,'-Ddrmd.gate.flightBody=true' if 'flight-body' in scenario else '-Ddrmd.gate.joints=true' if 'joints' in scenario else '-Ddrmd.gate.bodyIndex=true' if 'body-index' in scenario or 'body-scale' in scenario else '-Ddrmd.gate.bodyEdit=true' if 'body-edit' in scenario else '-Ddrmd.gate.shipGravity=true' if 'ship' in scenario else '-Ddrmd.gate.boarding=true' if 'boarding' in scenario else '-Ddrmd.gate.snapshot=true' if 'snapshot' in scenario else '-Ddrmd.gate.contacts=true' if 'contacts' in scenario or 'fracture' in scenario else '-Ddrmd.gate.gun=true' if 'gun' in scenario else '-Ddrmd.gate.actors=true' if 'actors' in scenario else '-Ddrmd.gate.terrain=true' if 'baseline' in scenario else '-Ddrmd.gate.mirrors=true');
if 'control' in scenario:a.insert(1,'-Ddrmd.gate.ufoControl=true')
if 'control-save' in scenario:a.insert(1,'-Ddrmd.gate.ufoReloadWrite=true')
if 'lifecycle' in scenario:a.insert(1,'-Ddrmd.gate.ufoControlLifecycle=true')
if 'ufo' in scenario:a.insert(1,'-Ddrmd.gate.ufo=true')
if 'fragment-boarding' in scenario:a.insert(1,'-Ddrmd.gate.fragmentBoarding=true')
if 'fracture' in scenario:a.insert(1,'-Ddrmd.gate.fracture=true')
if 'body-scale' in scenario:a.insert(1,'-Ddrmd.gate.bodyScale=true');a.insert(1,'-Ddrmd.gate.shapeDelayTicks=30')
p.write_text(json.dumps(a,indent=2))

if 'fabulous' in scenario:
    opts=root/'options.txt'; content=opts.read_text(); import re; content=re.sub(r'(?m)^graphicsMode:.*$', 'graphicsMode:2', content) if re.search(r'(?m)^graphicsMode:',content) else content+'\ngraphicsMode:2\n';opts.write_text(content)
p=root/'inputs.json';a=json.loads(p.read_text());a['sourceSha']=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();a['scenario']=scenario;a['glOverride']='3.2/150' if 'gl32' in scenario else '3.3/330';a['uncommittedDiff']=subprocess.check_output(['git','diff','--stat'],text=True);p.write_text(json.dumps(a,indent=2))
PY
mkdir -p build/cubic-client-automation/reload-proof
python3 - <<'RESTORE'
from pathlib import Path
import json,hashlib,zipfile,shutil,subprocess
r=Path('build/cubic-client-automation');old=Path('build/cubic-client-final-flight-body-control-reload-walking-sodium');proof=old/'reload-proof';p=proof/'first-process-world.zip';meta=json.loads((proof/'first-process-world.json').read_text());assert hashlib.sha256(p.read_bytes()).hexdigest()==meta['sha256']
assert not (r/'saves').exists(), 'Legacy read must begin without an injected seed world'
with zipfile.ZipFile(p) as z:
 assert z.testzip() is None
 assert set(z.namelist())==set(meta['files'])
 for name,h in meta['files'].items():
  assert hashlib.sha256(z.read(name)).hexdigest()==h
  target=r/'saves'/name;assert target.resolve().is_relative_to((r/'saves').resolve());target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(z.read(name))
for name in ['first-process-world.zip','first-process-world.json','write-inputs.json','write-launch.json']:shutil.copy2(proof/name,r/'reload-proof'/name)
for name in ['ufo-reload-expected.snbt','ufo-reload-target.txt']:shutil.copy2(old/name,r/name)
p=r/'launch.json';args=json.loads(p.read_text());args=[a for a in args if not a.startswith(('-Ddrmd.gate.flightBody=','-Ddrmd.gate.ufoControl=','-Ddrmd.gate.ufoReloadWrite='))];args.insert(1,'-Ddrmd.gate.ufoReloadRead=true');args.insert(1,'-Ddrmd.gate.restoreReadyDelay=30');args.extend(['--quickPlaySingleplayer','Cubic-Gate']);p.write_text(json.dumps(args,indent=2))
p=r/'inputs.json';data=json.loads(p.read_text());data['regressionWorldSource']='Actual closed schema1 world previously verified on08d61c3; read by current engine code without seed replacement or NBT insertion';data['regressionWorldSha256']=meta['sha256'];data['reloadExpectedSha256']=hashlib.sha256((r/'ufo-reload-expected.snbt').read_bytes()).hexdigest();p.write_text(json.dumps(data,indent=2))
RESTORE
cp work/ufo-body/native/run-engine-reload-read.sh "work/ufo-body/native/run-${scenario}.sh"
bash "work/ufo-body/native/run-${scenario}.sh" "$scenario"
