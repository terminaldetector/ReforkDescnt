package com.terminaldetector.drmd.gate.cloud;

import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import org.joml.Vector4f;
import java.util.*;

/** Independent true-ray diagnostic. Its triangles never enter a renderer or physics world. */
public final class CloudOcclusionGeometry {
    public record Triangle(Vec3d a,Vec3d b,Vec3d c,int colour) {}
    public record Hit(double distance,Triangle triangle) {}
    private CloudOcclusionGeometry() {}
    public static Vec3d point(Matrix4f transform,Vec3d value){var p=new Vector4f((float)value.x,(float)value.y,(float)value.z,1).mul(transform);return new Vec3d(p.x/p.w,p.y/p.w,p.z/p.w);}
    public static Vec3d ray(Matrix4f inverseProjection,int x,int y,int width,int height){var p=new Vector4f((float)((x+.5)*2/width-1),(float)(1-(y+.5)*2/height),-1,1).mul(inverseProjection);return new Vec3d(p.x/p.w,p.y/p.w,p.z/p.w).normalize();}
    public static double distance(Vec3d ray,Triangle triangle,double margin){
        var e1=triangle.b.subtract(triangle.a);var e2=triangle.c.subtract(triangle.a);var p=ray.crossProduct(e2);double determinant=e1.dotProduct(p);if(Math.abs(determinant)<1e-9)return Double.POSITIVE_INFINITY;
        var offset=triangle.a.negate();double u=offset.dotProduct(p)/determinant;var q=offset.crossProduct(e1);double v=ray.dotProduct(q)/determinant,t=e2.dotProduct(q)/determinant;
        return t>0&&u>=margin&&v>=margin&&u+v<=1-margin?t:Double.POSITIVE_INFINITY;
    }
    public static Hit nearest(Vec3d ray,List<Triangle> triangles,double margin){double best=Double.POSITIVE_INFINITY;Triangle selected=null;for(var t:triangles){double distance=distance(ray,t,margin);if(distance<best){best=distance;selected=t;}}return new Hit(best,selected);}
    public static double depth(Matrix4f projection,Vec3d ray,double distance){var p=new Vector4f((float)(ray.x*distance),(float)(ray.y*distance),(float)(ray.z*distance),1).mul(projection);return p.z/p.w*.5+.5;}
    public static List<Triangle> box(Vec3d[] corners,Matrix4f view){
        int[][] faces={{0,1,3,2},{4,6,7,5},{0,4,5,1},{2,3,7,6},{0,2,6,4},{1,5,7,3}};var result=new ArrayList<Triangle>();var eye=new Vec3d[8];for(int i=0;i<8;i++)eye[i]=point(view,corners[i]);
        for(var f:faces){result.add(new Triangle(eye[f[0]],eye[f[1]],eye[f[2]],0));result.add(new Triangle(eye[f[0]],eye[f[2]],eye[f[3]],0));}return result;
    }
    public static int[] bounds(List<Triangle> triangles,Matrix4f projection,int width,int height){
        double x0=width,y0=height,x1=0,y1=0;boolean positive=false;
        for(var t:triangles)for(var p:List.of(t.a,t.b,t.c)){var q=new Vector4f((float)p.x,(float)p.y,(float)p.z,1).mul(projection);if(q.w<=0)continue;positive=true;double x=(q.x/q.w*.5+.5)*width,y=(.5-q.y/q.w*.5)*height;x0=Math.min(x0,x);y0=Math.min(y0,y);x1=Math.max(x1,x);y1=Math.max(y1,y);}
        if(!positive)return new int[]{0,0,0,0};int left=Math.max(0,(int)Math.floor(x0)),top=Math.max(0,(int)Math.floor(y0)),right=Math.min(width,(int)Math.ceil(x1)),bottom=Math.min(height,(int)Math.ceil(y1));return new int[]{left,top,Math.max(0,right-left),Math.max(0,bottom-top)};
    }
    public static List<Triangle> cloud(CloudFootprint.Mesh mesh,Matrix4f view){
        var result=new ArrayList<Triangle>();int step="QUADS".equals(mesh.mode())?4:3;var positions=mesh.positions();
        for(int i=0;i+step<=mesh.vertices();i+=step){var points=new Vec3d[step];for(int j=0;j<step;j++){int k=(i+j)*3;points[j]=point(view,new Vec3d(positions[k],positions[k+1],positions[k+2]));}result.add(new Triangle(points[0],points[1],points[2],mesh.colours()[i]));if(step==4)result.add(new Triangle(points[0],points[2],points[3],mesh.colours()[i]));}return result;
    }
}
