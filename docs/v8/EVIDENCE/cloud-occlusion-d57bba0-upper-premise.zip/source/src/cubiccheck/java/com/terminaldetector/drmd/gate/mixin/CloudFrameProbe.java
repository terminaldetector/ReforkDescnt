package com.terminaldetector.drmd.gate.mixin;
import com.terminaldetector.drmd.gate.NativeCloudAltitudeCheck;
import net.minecraft.client.render.GameRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(GameRenderer.class)
public class CloudFrameProbe {
    @Inject(method="render",at=@At("HEAD"))
    private void before(CallbackInfo ci){if(NativeCloudAltitudeCheck.ENABLED)NativeCloudAltitudeCheck.beforeFrame();}
    @Inject(method="render",at=@At("RETURN"))
    private void after(CallbackInfo ci){if(NativeCloudAltitudeCheck.ENABLED)NativeCloudAltitudeCheck.rendered();}
}
