package com.terminaldetector.drmd.gate.mixin;
import com.terminaldetector.drmd.gate.NativeCloudOcclusionCheck;
import com.terminaldetector.drmd.gate.cloud.CloudOcclusionFixture;
import com.terminaldetector.drmd.client.planet.*;
import java.util.List;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(value=PlanetClientState.class,remap=false)
public class CloudOcclusionPacketProbe {
    @Inject(method="apply",at=@At("RETURN"),remap=false)
    private void accepted(long seed,List<Long> scars,List<HorizonLandmark> marks,CallbackInfo ci){if(NativeCloudOcclusionCheck.ENABLED)CloudOcclusionFixture.acceptedPacket(seed,marks);}
}
