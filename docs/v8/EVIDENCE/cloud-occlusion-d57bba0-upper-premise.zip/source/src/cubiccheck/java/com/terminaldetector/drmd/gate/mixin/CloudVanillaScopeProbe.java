package com.terminaldetector.drmd.gate.mixin;
import com.terminaldetector.drmd.gate.NativeCloudAltitudeCheck;
import net.minecraft.client.render.WorldRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(WorldRenderer.class)
public class CloudVanillaScopeProbe {
    @Inject(method="renderClouds",at=@At("HEAD"))
    private void before(CallbackInfo ci){if(NativeCloudAltitudeCheck.ENABLED)NativeCloudAltitudeCheck.scope("vanilla-wrapper",true);}
    @Inject(method="renderClouds",at=@At("RETURN"))
    private void after(CallbackInfo ci){if(NativeCloudAltitudeCheck.ENABLED)NativeCloudAltitudeCheck.scope("vanilla-wrapper",false);}
}
