package com.terminaldetector.drmd.gate.cloud;

import net.minecraft.client.texture.NativeImage;
import org.joml.Matrix4f;
import org.joml.Vector4f;
import java.util.BitSet;

/** CPU diagnostic of the actual uploaded cloud triangles. It never supplies a GPU cloud. */
public final class CloudFootprint {
    public record Mesh(int upload, float[] positions, float[] uv, int[] colours, String mode) {
        public int vertices() { return colours.length; }
    }
    public record Fog(boolean sodium, float start, float end, float alpha, String shape, float shaderAlpha) {}
    public record Result(BitSet opaque, BitSet insideDepthClip, BitSet outsideFarClip,
                         BitSet fogZero, BitSet fogNonzero, BitSet fullyFogMixed,
                         int triangles, int backFacing, int nonpositiveW) {}
    private CloudFootprint() {}

    public static Result project(Mesh mesh, Matrix4f view, Matrix4f projection, Fog fog,
            NativeImage texture, int width, int height, int stride, boolean cull, int cullMode, int frontFace) {
        int n=mesh.vertices();double[] sx=new double[n],sy=new double[n],iw=new double[n],z=new double[n],distance=new double[n];
        var transform=new Matrix4f(projection).mul(view);int invalid=0;
        for(int i=0;i<n;i++) {
            int j=i*3;var p=new Vector4f(mesh.positions[j],mesh.positions[j+1],mesh.positions[j+2],1);
            var clip=new Vector4f(p).mul(transform);iw[i]=clip.w>1e-5?1.0/clip.w:0;if(iw[i]==0)invalid++;
            sx[i]=(clip.x*iw[i]*.5+.5)*width;sy[i]=(.5-clip.y*iw[i]*.5)*height;z[i]=clip.z*iw[i];
            if(fog.sodium)p.y=0;
            p.mul(view);distance[i]="CYLINDER".equals(fog.shape)?Math.max(Math.hypot(p.x,p.z),Math.abs(p.y)):Math.sqrt(p.x*p.x+p.y*p.y+p.z*p.z);
        }
        BitSet opaque=new BitSet(),inside=new BitSet(),far=new BitSet(),fogZero=new BitSet(),fogNonzero=new BitSet(),fogMixed=new BitSet();
        int step="QUADS".equals(mesh.mode)?4:3,triangles=0,back=0;
        if(!"QUADS".equals(mesh.mode)&&!"TRIANGLES".equals(mesh.mode))throw new IllegalArgumentException("Unsupported actual cloud draw mode "+mesh.mode);
        for(int base=0;base+step<=n;base+=step)for(int tri=0;tri<(step==4?2:1);tri++) {
            int a=base,b=base+(tri==0?1:2),c=base+(tri==0?2:3);triangles++;
            if(iw[a]==0||iw[b]==0||iw[c]==0)continue;
            double area=edge(sx[a],sy[a],sx[b],sy[b],sx[c],sy[c]);if(Math.abs(area)<1e-9)continue;
            boolean front=frontFace==2305?area<0:area>0; // GL_CCW; framebuffer image Y points down.
            if(!front)back++;
            if(cull&&(cullMode==1032||cullMode==1029&&!front||cullMode==1028&&front))continue;
            int x0=Math.max(0,(int)Math.floor(Math.min(sx[a],Math.min(sx[b],sx[c]))/stride)*stride);
            int x1=Math.min(width-1,(int)Math.ceil(Math.max(sx[a],Math.max(sx[b],sx[c]))));
            int y0=Math.max(0,(int)Math.floor(Math.min(sy[a],Math.min(sy[b],sy[c]))/stride)*stride);
            int y1=Math.min(height-1,(int)Math.ceil(Math.max(sy[a],Math.max(sy[b],sy[c]))));
            for(int y=y0;y<=y1;y+=stride)for(int x=x0;x<=x1;x+=stride) {
                double l0=edge(sx[b],sy[b],sx[c],sy[c],x+.5,y+.5)/area;
                double l1=edge(sx[c],sy[c],sx[a],sy[a],x+.5,y+.5)/area,l2=1-l0-l1;
                if(l0< -1e-7||l1< -1e-7||l2< -1e-7)continue;
                double denominator=l0*iw[a]+l1*iw[b]+l2*iw[c];if(denominator<=0)continue;
                double alpha=(l0*iw[a]*(mesh.colours[a]>>>24)+l1*iw[b]*(mesh.colours[b]>>>24)+l2*iw[c]*(mesh.colours[c]>>>24))/denominator/255*fog.shaderAlpha;
                if(mesh.uv.length>0) {
                    double u=(l0*iw[a]*mesh.uv[a*2]+l1*iw[b]*mesh.uv[b*2]+l2*iw[c]*mesh.uv[c*2])/denominator;
                    double v=(l0*iw[a]*mesh.uv[a*2+1]+l1*iw[b]*mesh.uv[b*2+1]+l2*iw[c]*mesh.uv[c*2+1])/denominator;
                    int tx=Math.floorMod((int)Math.floor(u*texture.getWidth()),texture.getWidth()),ty=Math.floorMod((int)Math.floor(v*texture.getHeight()),texture.getHeight());
                    alpha*=((texture.getColor(tx,ty)>>>24)&255)/255.0;
                }
                if(alpha<.1)continue;
                int index=(y/stride)*((width+stride-1)/stride)+x/stride;opaque.set(index);
                double depth=l0*z[a]+l1*z[b]+l2*z[c];if(depth>=-1&&depth<=1)inside.set(index);if(depth>1)far.set(index);
                double d=(l0*iw[a]*distance[a]+l1*iw[b]*distance[b]+l2*iw[c]*distance[c])/denominator;
                if(fog.sodium) {
                    double end=fog.start+(fog.end-fog.start)*4;double fade=d<=fog.start?1:d>=end?0:(end-d)/(end-fog.start);
                    if(alpha*fade*fog.alpha<.01)fogZero.set(index);else fogNonzero.set(index);
                }else if(d>=fog.end)fogMixed.set(index);
            }
        }
        far.andNot(inside);fogZero.andNot(fogNonzero);
        return new Result(opaque,inside,far,fogZero,fogNonzero,fogMixed,triangles,back,invalid);
    }
    private static double edge(double ax,double ay,double bx,double by,double x,double y) {return (bx-ax)*(y-ay)-(by-ay)*(x-ax);}
}
