package com.terminaldetector.drmd.gate.mixin;
import com.terminaldetector.drmd.gate.NativeCloudOcclusionCheck;
import com.terminaldetector.drmd.client.planet.*;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.*;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(value=HorizonVertexBuffer.class,remap=false)
public class CloudOcclusionHorizonProbe {
    @Shadow private static PlanetSurfaceMesh uploaded;
    @Inject(method="draw",at=@At("HEAD"),remap=false)
    private static void before(Matrix4f view,CallbackInfo ci){if(NativeCloudOcclusionCheck.ENABLED)NativeCloudOcclusionCheck.horizon(uploaded,view,true);}
    @Inject(method="draw",at=@At("RETURN"),remap=false)
    private static void after(Matrix4f view,CallbackInfo ci){if(NativeCloudOcclusionCheck.ENABLED)NativeCloudOcclusionCheck.horizon(uploaded,view,false);}
}
