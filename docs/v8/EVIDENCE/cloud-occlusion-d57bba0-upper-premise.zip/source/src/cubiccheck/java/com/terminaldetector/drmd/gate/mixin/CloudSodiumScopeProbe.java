package com.terminaldetector.drmd.gate.mixin;
import com.terminaldetector.drmd.gate.NativeCloudAltitudeCheck;
import org.spongepowered.asm.mixin.*;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/** Optional observer only. No Sodium class or dependency is linked into the game JAR. */
@Pseudo
@Mixin(targets="net.caffeinemc.mods.sodium.client.render.immediate.CloudRenderer",remap=false)
public class CloudSodiumScopeProbe {
    @Inject(method="render",at=@At("HEAD"),remap=false)
    private void before(CallbackInfo ci){if(NativeCloudAltitudeCheck.ENABLED)NativeCloudAltitudeCheck.scope("sodium",true);}
    @Inject(method="render",at=@At("RETURN"),remap=false)
    private void after(CallbackInfo ci){if(NativeCloudAltitudeCheck.ENABLED)NativeCloudAltitudeCheck.scope("sodium",false);}
}
