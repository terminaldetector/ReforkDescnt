from pathlib import Path
import math,json
code=Path('work/cloud-occlusion/analyse-upper-visible-rays.py').read_text().split('pre=Image.open')[0];scope={};exec(compile(code,'actual-input-reader','exec'),scope)
ray,hit,point,P,V,camera,cloudtris=(scope[n] for n in ['ray','hit','point','P','V','camera','triangles']);width,height=1536,864

def box(cx,cz,base,tall,half):
 x0,x1=cx-half,cx+half;z0,z1=cz-half,cz+half;y0,y1=base,base+tall
 return [[(x0,y1,z0),(x1,y1,z0),(x1,y1,z1),(x0,y1,z1)],[(x0,y0,z0),(x1,y0,z0),(x1,y1,z0),(x0,y1,z0)],[(x0,y0,z1),(x1,y0,z1),(x1,y1,z1),(x0,y1,z1)],[(x0,y0,z0),(x0,y0,z1),(x0,y1,z1),(x0,y1,z0)],[(x1,y0,z0),(x1,y0,z1),(x1,y1,z1),(x1,y1,z0)]]
def forecast(name,cx,cz,base,tall,half):
 quads=[[point(V,tuple(p[i]-camera[i] for i in range(3))) for p in q] for q in box(cx,cz,base,tall,half)];screens=[scope['screen'](p) for q in quads for p in q];roi=[max(0,math.floor(min(p[0] for p in screens))),max(0,math.floor(min(p[1] for p in screens))),min(width,math.ceil(max(p[0] for p in screens))),min(height,math.ceil(max(p[1] for p in screens)))];rows=[]
 for y in range(roi[1],roi[3]):
  for x in range(roi[0],roi[2]):
   direction=ray(x,y);hits=[min(hit(direction,(q[0],q[1],q[2]),.015),hit(direction,(q[0],q[2],q[3]),.015)) for q in quads];hits=[d for d in hits if math.isfinite(d)]
   if not hits:continue
   c=min((hit(direction,t) for t in cloudtris),default=math.inf)
   if not math.isfinite(c):continue
   near=min(hits);clear=all(abs(d-c)>8 and (d<c)==(near<c) for d in hits)
   if clear:rows.append({'pixel':[x,y],'markerDistance':near,'actualStockCloudDistance':c,'nearer':near<c})
 return {'name':name,'hypotheticalRealWorldBounds':{'centerXZ':[cx,cz],'baseY':base,'proxyHeight':tall,'proxyHalfWidth':half},'projectedBox':[roi[0],roi[1],roi[2]-roi[0],roi[3]-roi[1]],'projectedCloudOverlappingNearerPixels':sum(p['nearer'] for p in rows),'projectedCloudOverlappingBehindPixels':sum(not p['nearer'] for p in rows),'rows':rows}
results=[forecast('above-cloud64arch',738,1074,63,170,9.6),forecast('below-cloud48beam',690,1074,63,8,7.2)]
out={'classification':'READ-ONLY PLACEMENT FORECAST using actual d57 camera/projection and actual stock uploaded cloud triangles; proposed proxy boxes are CPU-only forecasts, NOT a new GPU/native pass or altered domain','cameraUnchanged':camera,'source':'d57bba007597b8d42f0dad994da482fdfd76e132','proposedActualAuthoring':'Two real normal-synced objects, high64wide arch with170bounding height and separate48long ground beam; actual new native must verify normal writes/accepted packets/visibility independently','projected':results};p=Path('work/cloud-occlusion/abi-two-landmark-placement-forecast.json');assert not p.exists();p.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({**{k:v for k,v in out.items() if k!='projected'},'projected':[{k:v for k,v in x.items() if k!='rows'} for x in results]},indent=2))
