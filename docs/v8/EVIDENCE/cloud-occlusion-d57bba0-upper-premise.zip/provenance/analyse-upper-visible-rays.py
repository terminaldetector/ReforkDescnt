from pathlib import Path
import json,struct,math
from PIL import Image
r=Path('build/cubic-client-failed-cloud-upper-lod-d57bba0');folder=r/'cloud-occlusion-frames/pose-3';j=json.loads((r/'cloud-attribution-frames/orbit2200/attribution.json').read_text());s=j['occlusion']['actualHorizonState'];width,height=1536,864
P=s['horizonProjection'];V=s['horizonView'];delta=s['fieldOriginDelta'];camera=j['actualCloudDraws'][0]['camera'];cloud=j['actualCloudDraws'][0]
def mv(m,p):return tuple(sum(m[c*4+row]*p[c] for c in range(4)) for row in range(4))
def add(a,b):return tuple(x+y for x,y in zip(a,b))
def sub(a,b):return tuple(x-y for x,y in zip(a,b))
def mul(a,b):return tuple(x*b for x in a)
def dot(a,b):return sum(x*y for x,y in zip(a,b))
def cross(a,b):return (a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0])
def point(m,p):q=mv(m,(*p,1));return tuple(x/q[3] for x in q[:3])
def ray(x,y):
 a=((x+.5)*2/width-1,(1-(y+.5)*2/height));v=(a[0]/P[0],a[1]/P[5],-1);return mul(v,1/math.sqrt(dot(v,v)))
def hit(direction,tri,margin=0):
 a,b,c=tri;e1=sub(b,a);e2=sub(c,a);p=cross(direction,e2);det=dot(e1,p)
 if abs(det)<1e-9:return math.inf
 offset=mul(a,-1);u=dot(offset,p)/det;q=cross(offset,e1);v=dot(direction,q)/det;t=dot(e2,q)/det
 return t if t>0 and u>=margin and v>=margin and u+v<=1-margin else math.inf
def screen(p):q=mv(P,(*p,1));return ((q[0]/q[3]*.5+.5)*width,(.5-q[1]/q[3]*.5)*height)
def nearest(direction,quads):
 hits=[(min(hit(direction,(a,b,c)),hit(direction,(a,c,d))),colour,index) for index,(a,b,c,d,colour) in enumerate(quads)];return min(hits,default=(math.inf,0,-1))
raw=(folder/'actual-horizon-source.bin').read_bytes();count=struct.unpack_from('<I',raw)[0];marker=[];colours={0xD83EC7,0x9B2C8F,0x76226D}
for i in range(count):
 c,*p=struct.unpack_from('<I12f',raw,4+i*52)
 if c&0xffffff not in colours:continue
 points=[point(V,add(p[k:k+3],delta)) for k in range(0,12,3)];marker.append((*points,c))
assert len(marker)==5,(len(marker),[hex(q[-1]) for q in marker])
source=r/cloud['sourceFile'];meta=json.loads(source.with_suffix('.json').read_text());data=source.read_bytes();n=meta['vertexCount'];stride=meta['stride'];po=meta['positionOffset'];co=meta['colourOffset'];cv=cloud['view'];cp=cloud['projection'];triangles=[]
for i in range(0,n,4):
 points=[point(cv,struct.unpack_from('<fff',data,(i+k)*stride+po)) for k in range(4)];a=(data[i*stride+co+3]/255)*cloud['shaderColour'][3]
 if a<.1:continue
 for inds in [(0,1,2),(0,2,3)]:
  tri=tuple(points[k] for k in inds);scr=[]
  for p in tri:
   q=mv(cp,(*p,1));scr.append(((q[0]/q[3]*.5+.5)*width,(.5-q[1]/q[3]*.5)*height))
  a2=(scr[1][0]-scr[0][0])*(scr[2][1]-scr[0][1])-(scr[1][1]-scr[0][1])*(scr[2][0]-scr[0][0]);front=a2<0 if cloud['frontFace']==2305 else a2>0
  if cloud['cull'] and ((cloud['cullMode']==1029 and not front) or (cloud['cullMode']==1028 and front) or cloud['cullMode']==1032):continue
  triangles.append(tri)
pre=Image.open(folder/'horizon-before.png').convert('RGB');after=Image.open(folder/'horizon-after.png').convert('RGB');roi=j['occlusion']['landmark']['roi'];rows=[]
for y in range(roi[1],roi[1]+roi[3]):
 for x in range(roi[0],roi[0]+roi[2]):
  direction=ray(x,y);hits=[(min(hit(direction,(a,b,c)),hit(direction,(a,c,d))),index,colour) for index,(a,b,c,d,colour) in enumerate(marker) if math.isfinite(min(hit(direction,(a,b,c)),hit(direction,(a,c,d))))]
  if not hits:continue
  t,index,colour=hits[-1];rgb=((colour>>16)&255,(colour>>8)&255,colour&255);actual=after.getpixel((x,y));visible=max(abs(a-b) for a,b in zip(actual,rgb))<=8 and max(abs(a-b) for a,b in zip(actual,pre.getpixel((x,y))))>8
  cloudT=min((hit(direction,t) for t in triangles),default=math.inf);nearestT=min(h[0] for h in hits)
  # View is a recorded pure orthogonal rotation. R transpose recovers true world-relative Y.
  eye=mul(direction,t);world_y=camera[1]+sum(V[4+row]*eye[row] for row in range(3))
  rows.append({'pixel':[x,y],'visibleGpuMarker':visible,'actualAfterRgb':actual,'sourceOwnerRgb':rgb,'lastContributingSourceQuad':index,'ownerTrueWorldY':world_y,'trueVisibleOwnerDistance':t,'nearestLandmarkDistance':nearestT,'actualOpaqueCloudRay':math.isfinite(cloudT),'trueCloudDistance':cloudT if math.isfinite(cloudT) else None,'visibleOwnerBehindCloud':math.isfinite(cloudT) and t>cloudT+8})
summary={'source':'d57bba007597b8d42f0dad994da482fdfd76e132','scope':'Read-only actual uploaded5face proxy and recorded7x7GPU ROI; no camera/geometry/pixel mutation, no JVM','roi':roi,'actualSourceQuads':len(marker),'candidatePixels':len(rows),'visibleGpuMarkerPixels':sum(x['visibleGpuMarker'] for x in rows),'visibleGpuMarkerAndOpaqueCloudPixels':sum(x['visibleGpuMarker'] and x['actualOpaqueCloudRay'] for x in rows),'visibleBehindCloudPixels':sum(x['visibleGpuMarker'] and x['visibleOwnerBehindCloud'] for x in rows),'visibleOwnerWorldYRange':[min(x['ownerTrueWorldY'] for x in rows if x['visibleGpuMarker']),max(x['ownerTrueWorldY'] for x in rows if x['visibleGpuMarker'])],'rows':rows}
out=Path('work/cloud-occlusion/abi-upper-visible-ray-analysis.json');assert not out.exists();out.write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps({k:v for k,v in summary.items() if k!='rows'},indent=2))
