from pathlib import Path
import json,hashlib,subprocess,zipfile,xml.etree.ElementTree as E
subprocess.run(['python3','work/ufo-body/native/verify-build-stamp.py','check'],check=True)
source=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();stamp=json.loads(Path('work/ufo-body/native/verified-build.json').read_text());files=set()
def add(p):
 p=Path(p);assert p.is_file(),p;files.add(p)
for n in subprocess.check_output(['git','diff','--name-only','f984556',source],text=True).splitlines():
 if n.startswith('src/'):add(n)
for n in ['build.gradle','gradle.properties','src/gametest/resources/fabric.mod.json','build/resources/gametest/fabric.mod.json','build/gametest/reports/gametest-results.xml','work/ufo-body/native/verified-build.json','work/ufo-body/native/build-verified.sh','work/ufo-body/native/verify-build-stamp.py','work/ufo-body/native/run-turret-restart-pair.sh','work/ufo-body/native/run-turret-restart-write.sh','work/ufo-body/native/run-turret-restart-read.sh','work/ufo-body/native/prepare-with-verified-library-links.py','work/ufo-body/native/dedup-staged-libraries.py','work/ufo-body/native/seed-verified-minecraft-remap.py','scripts/v5/prepare_cubic_client.py','work/ufo-body/collect-turret-restart-evidence.py','work/ufo-body/engine-final-force-test.init.gradle','work/ufo-body/turret-restart-full-regressions.log','work/ufo-body/preserve-old-boarding-gametest.py','work/preserved-disposable-worlds/boarding-closed-gametest-turret-restart-20261107.zip.json']:add(n)
for p,h in stamp['jars'].items():assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==h;add(p)
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in stamp['inputs'].items())
full=json.loads(Path('work/ufo-body/turret-restart-full-server-build.json').read_text());add('work/ufo-body/turret-restart-full-server-build.json')
fullDelta=subprocess.check_output(['git','diff','--name-only',full['source'],source],text=True).splitlines();assert all(p.startswith('src/cubiccheck/') for p in fullDelta)
for p,h in full['inputs'].items():
 if not p.startswith('src/cubiccheck/'):assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==h,p
assert full['jars']['build/libs/drmd-6dof-1.1.35-ufo-dev.1.jar']==stamp['jars']['build/libs/drmd-6dof-1.1.35-ufo-dev.1.jar']
profiles={};nativeSource=None
for profile in ['sodium','gl32']:
 name='flight-body-control-turret-restart-read-clean10-'+profile;r=Path('build/cubic-client-final-'+name)
 wi=json.loads((r/'reload-proof/write-inputs.json').read_text());ri=json.loads((r/'inputs.json').read_text());assert wi['sourceSha']==ri['sourceSha'] and not wi['uncommittedDiff'] and not ri['uncommittedDiff']
 if nativeSource is None:nativeSource=ri['sourceSha']
 assert nativeSource==ri['sourceSha']
 delta=subprocess.check_output(['git','diff','--name-only',nativeSource,source],text=True).splitlines();assert all(p.startswith('src/gametest/') for p in delta)
 assert not list((r/'crash-reports').glob('*.txt'))
 for info in [wi,ri]:
  seen=set()
  for a in info['artifacts']:
   if a.get('source') in stamp['jars']:
    assert a['sha256']==stamp['jars'][a['source']]==hashlib.sha256((r/a['path']).read_bytes()).hexdigest();seen.add(a['source'])
  assert seen==set(stamp['jars'])
 for suffix in ['write','read']:
  n='flight-body-control-turret-restart-'+suffix+'-clean10-'+profile
  for ext in ['.log','.exit']:add('work/ufo-body/native/final-'+n+ext)
  assert Path('work/ufo-body/native/final-'+n+'.exit').read_text().strip()=='0'
  log=Path('work/ufo-body/native/final-'+n+'.log').read_text();assert 'All dimensions are saved' in log and 'Encountered an unexpected exception' not in log and 'Unreported exception thrown' not in log
 for f in ['inputs.json','launch.json','process-pid.txt','turret-restart-ids.json','turret-restart-root.snbt','turret-restart-child.snbt','turret-restart-registry.snbt','ufo-reload-expected.snbt','ufo-reload-target.txt','turret-restart-write-ok.json','ufo-reload-ok.json','turret-restart-ok.json','ufo-reloaded.png','turret-restart-module.png']:add(r/f)
 for f in (r/'reload-proof').glob('*'):add(f)
 proof=json.loads((r/'reload-proof/first-process-world.json').read_text());archive=r/'reload-proof/first-process-world.zip';assert hashlib.sha256(archive.read_bytes()).hexdigest()==proof['sha256']
 with zipfile.ZipFile(archive) as z:
  assert z.testzip() is None
  for f,h in proof['files'].items():assert hashlib.sha256(z.read(f)).hexdigest()==h
 pids=json.loads((r/'reload-proof/processes.json').read_text());assert pids['distinctProcesses'] and pids['writerPid']!=pids['readerPid']
 w=json.loads((r/'turret-restart-write-ok.json').read_text());u=json.loads((r/'ufo-reload-ok.json').read_text());m=json.loads((r/'turret-restart-ok.json').read_text())
 assert 0<w['laserCooldown']<=8 and 0<w['rocketCooldown']<=24 and w['lasers']>=4 and w['rockets']>=2
 for k in ['actualHeadProjectionVerified','observerPositionVerified','actualTwoProcessRestart','rootExact','headExact','registryExact','noDuplicates','postLoadControlRelease']:assert m[k],(k,m)
 for k,n in [('barrierCooldownSamples',20),('restoredCarrierOwnerSamples',40),('postLoadSamples',32),('lasers',3),('rockets',1),('aimPackets',8),('firePackets',8),('exteriorRenderedFrames',6),('subjectPixels',256)]:assert m[k]>=n,(k,m)
 assert 0<=m['consoleApproachTicks']<=80 and m['initialConsoleDistance']>0
 assert m['observerPositionError']<.5
 assert abs(m['headNdcX'])<=.08 and abs(m['headNdcY'])<=.08
 assert m['idleLocalDrift']<.4
 assert m['maxAnchorError']<.03 and m['muzzleError']<1e-8 and m['launchVelocityError']<1e-8 and m['relativeAngle']>.25 and m['brakedRelativeSpeed']<.08
 assert u['postLoadWalking'] and u['postLoadDistance']>.3 and u['restoredWalkingTicks']>=40 and u['admissionTicks']>=20 and u['stalePilotAbsent']
 images=[*list((r/'flight-body-frames').glob('*.png')),*list((r/'turret-restart-frames').glob('*.png')),r/'ufo-reloaded.png',r/'turret-restart-module.png'];assert len(images)>=10
 for p in images:add(p)
 profiles[profile]=dict(writer=w,walking=u,reader=m,processes=pids,frames=len(images),closedWorldSha256=proof['sha256'])
for p in Path('work/ufo-body/native').glob('*turret-restart*'):
 if p.is_file() and p.suffix in ['.log','.exit','.json','.sh']:add(p)
for root in [*Path('build').glob('cubic-client-before-flight-body-control-turret-restart-write-clean4-*'),*Path('build').glob('cubic-client-before-flight-body-control-turret-restart-write-clean5-*'),*Path('build').glob('cubic-client-final-flight-body-control-turret-restart-read-restart1-*'),*Path('build').glob('cubic-client-before-flight-body-control-turret-restart-write-clean3-*'),*Path('build').glob('cubic-client-final-flight-body-control-turret-restart-write-clean3-gl32')]:
 for p in root.glob('*.json'):add(p)
 for p in root.glob('*.snbt'):add(p)
 for p in root.glob('turret-restart-module.png'):add(p)
 for folder in ['crash-reports','flight-body-frames']:
  for p in (root/folder).glob('*'):
   if p.is_file():add(p)
for n in ['work/ufo-body/turret-restart-source.patch','work/ufo-body/turret-restart-source-series.patch','work/ufo-body/turret-restart-source.json','work/ufo-body/native/verified-build.log']:add(n)
for p in [*Path('work/ufo-body').glob('turret-restart-owner-*'),*Path('work/ufo-body').glob('turret-restart-world-contact-*')]:
 if p.is_file() and p.suffix in ['.xml','.log','.zip']:add(p)
for n in ['work/ufo-body/turret-restart-full-regressions.sh','work/ufo-body/boarding-restore-focus.init.gradle','work/ufo-body/turret-restart-restore-full-manifest.log','work/ufo-body/turret-restart-low-disk-reader.png','work/ufo-body/turret-restart-mesa-live.png','work/preserved-disposable-worlds/world-seed2-closed-native-turret-restart.zip.json','work/preserved-disposable-worlds/world-access-nonblocking-closed-native-turret-restart.zip.json','work/preserved-disposable-worlds/ufo-closed-full-gametest-turret-restart.zip.json','work/preserved-disposable-worlds/ufo-closed-full-320-gametest-turret-restart.zip.json','work/preserved-disposable-worlds/world-closed-gametest-turret-restart.zip.json']:add(n)
for root in [*Path('build').glob('cubic-client-final-flight-body-control-turret-restart-read-clean5-*'),*Path('build').glob('cubic-client-final-flight-body-control-turret-restart-read-clean6-*')]:
 for p in root.glob('*.json'):add(p)
 for p in root.glob('*.snbt'):add(p)
 for folder in ['reload-proof','turret-restart-frames','flight-body-frames']:
  for p in (root/folder).glob('*'):
   if p.is_file():add(p)
 add(root/'turret-restart-module.png')
for root in Path('build').glob('cubic-client-rejected-turret-restart-*'):
 for pattern in ['*.snbt','*.json','crash-reports/*.txt','turret-restart-frames/*.png','reload-proof/*']:
  for p in root.glob(pattern):add(p)
for p in Path('build/test-results/test').glob('TEST-*.xml'):add(p)
rs=[E.parse(p).getroot() for p in Path('build/test-results/test').glob('TEST-*.xml')];unit={k:sum(int(r.get(k,0)) for r in rs) for k in ['tests','failures','errors','skipped']};cs=list(E.parse('build/gametest/reports/gametest-results.xml').iter('testcase'));server=dict(tests=len(cs),failures=sum(c.find('failure') is not None for c in cs),errors=sum(c.find('error') is not None for c in cs),skipped=sum(c.find('skipped') is not None for c in cs))
assert unit==dict(tests=736,failures=0,errors=0,skipped=0) and server==dict(tests=320,failures=0,errors=0,skipped=0),(unit,server)
focused=list(E.parse('work/ufo-body/turret-restart-world-contact-fixed.xml').iter('testcase'));assert len(focused)==14 and not any(c.find('failure') is not None or c.find('error') is not None for c in focused)
for name,total,failed in [('turret-restart-owner-negative.xml',12,2),('turret-restart-world-contact-negative.xml',14,1)]:
 cases=list(E.parse(Path('work/ufo-body')/name).iter('testcase'));assert len(cases)==total and sum(c.find('failure') is not None for c in cases)==failed
assert json.loads(Path('src/gametest/resources/fabric.mod.json').read_text())['entrypoints']==json.loads(Path('build/resources/gametest/fabric.mod.json').read_text())['entrypoints']
assert 'BUILD SUCCESSFUL' in Path('work/ufo-body/turret-restart-full-regressions.log').read_text()
s=dict(source=source,fullServerSource=full['source'],fullServerObserverOnlyDelta=fullDelta,nativeSource=nativeSource,nativeTestOnlyDelta=delta,productionJarUnchangedFromTurretMilestone=False,productionSource="aa5d79660e735785f4a7a1a72cbb6f0449aad416",productionFix="Bounded saved-UUID admission rejects earlier loaded module fields while retaining immediate real world-gravity deck contacts",jars=stamp['jars'],unit=unit,server=server,focusedBoarding=dict(tests=14,failures=0,errors=0,skipped=0),native=profiles,releaseAccepted=False,publication='Local only',scope='Actual hot connected turret save/load and post-load walking/capture/yaw/fire/braking/release. AI, compound modules, damaged/absent endpoints and full master v8 remain open.',files={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(files)})
p=Path('docs/v8/EVIDENCE/turret-restart-'+source[:7]+'.zip')
with zipfile.ZipFile(p,'x',zipfile.ZIP_DEFLATED) as z:
 for f in sorted(files):z.write(f,str(f))
 z.writestr('MANIFEST.json',json.dumps(s,indent=2))
with zipfile.ZipFile(p) as z:
 assert z.testzip() is None
 for f,h in s['files'].items():assert hashlib.sha256(z.read(f)).hexdigest()==h
s.update(archive=str(p),archiveSha256=hashlib.sha256(p.read_bytes()).hexdigest());Path('work/ufo-body/turret-restart-summary.json').write_text(json.dumps(s,indent=2)+'\n');print(json.dumps({k:v for k,v in s.items() if k!='files'},indent=2))
