package com.terminaldetector.drmd;

import com.terminaldetector.drmd.ai.AiCommands;
import com.terminaldetector.drmd.command.DescentCommands;
import com.terminaldetector.drmd.entity.ModBlocks;
import com.terminaldetector.drmd.entity.ModEntities;
import com.terminaldetector.drmd.energy.EnergySystem;
import com.terminaldetector.drmd.flight.FlightSystem;
import com.terminaldetector.drmd.network.ModNetworking;
import com.terminaldetector.drmd.shield.ShieldSystem;
import com.terminaldetector.drmd.weapon.items.ModItems;
import com.terminaldetector.drmd.weapon.registry.WeaponRegistry;
import com.terminaldetector.drmd.workshop.ClusterModule;
import com.terminaldetector.drmd.workshop.ConstructionRegistry;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.server.world.ServerWorld;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * DRMD 6DOF — Minecraft Fabric port of the Garry's Mod Descent addon.
 * Preserves: 6DOF flight, energy presets, shields, weapon core, AI roles,
 * map entities, HUD, and Weapon Workshop.
 */
public class DescentMod implements ModInitializer {
	public static final String MOD_ID = "drmd";
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

	/** Source-engine units → Minecraft blocks (tuned for playable feel). */
	public static final double UNIT_SCALE = 1.0 / 80.0;

	@Override
	public void onInitialize() {
		LOGGER.info("DRMD 6DOF initializing — 6DoF world mode (volume-first)");
		// First, so these facts are in the log even if something below this line takes the game down.
		com.terminaldetector.drmd.diag.DiagStartup.logBanner();
		// Registered before any other DRMD tick handler, so the tick it closes is a whole one. The
		// distances are sampled a second apart rather than every tick: they change when a slider moves,
		// and reading them 20 times a second to prove that would be its own small cost.
		ServerTickEvents.END_SERVER_TICK.register(server -> {
            for(var p:server.getPlayerManager().getPlayerList())com.terminaldetector.drmd.inventory.DroneArsenal.tick(p);
			com.terminaldetector.drmd.diag.DiagServerTick.rollTick(System.nanoTime());
			if (com.terminaldetector.drmd.diag.DiagServerTick.ticks() % 20 == 0) {
				int chunks = 0;
				for (net.minecraft.server.world.ServerWorld world : server.getWorlds()) {
					chunks += world.getChunkManager().getLoadedChunkCount();
				}
				com.terminaldetector.drmd.diag.DiagServerTick.sample(
						server.getPlayerManager().getViewDistance(),
						server.getPlayerManager().getSimulationDistance(),
						chunks);
			}
		});

		ServerTickEvents.START_SERVER_TICK.register(com.terminaldetector.drmd.world.level.LowerWorldRecovery::tick);
        com.terminaldetector.drmd.world.DrmdServerConfig.load();
		com.terminaldetector.drmd.world.DrmdBuiltinPacks.register();
		ModNetworking.register();
        com.terminaldetector.drmd.world.contraption.BodyContactSystem.register();
        com.terminaldetector.drmd.world.contraption.boarding.LooseItemBodySystem.register();
        com.terminaldetector.drmd.world.contraption.boarding.FlightBodySystem.register();
        com.terminaldetector.drmd.world.contraption.boarding.BoardingSystem.register();
        com.terminaldetector.drmd.world.portal.PortalTravel.register();
        com.terminaldetector.drmd.world.portal.PortalExitInterest.register();
        com.terminaldetector.drmd.world.mega.SkyUfoCombat.register();
        com.terminaldetector.drmd.inventory.DroneInventoryHandler.register();
		ModEntities.register();
		ModBlocks.register();
		ModItems.register();
		com.terminaldetector.drmd.entity.ModWorldBlocks.register();
		com.terminaldetector.drmd.world.trap.PointDefenseInterception.register();
		com.terminaldetector.drmd.world.geometry.OrganicMaterials.register();
		com.terminaldetector.drmd.entity.ModBlockEntities.register();
		com.terminaldetector.drmd.world.gen.ModWorldgen.register();
		com.terminaldetector.drmd.world.gen2.ModWorldgen2.register();
		com.terminaldetector.drmd.world.surface.MegacityBiomeWorldgen.register();
		com.terminaldetector.drmd.world.surface.TechnogenicSeaBiomeWorldgen.register();
		com.terminaldetector.drmd.world.surface.ScorchedLandsBiomeWorldgen.register();
		com.terminaldetector.drmd.world.surface.IronGuildBiomeWorldgen.register();
		com.terminaldetector.drmd.world.surface.SurfaceEventWorldgen.register();
		com.terminaldetector.drmd.world.surface.InfiniteMegacityWorldgen.register();
		com.terminaldetector.drmd.world.end.space.EndSpaceWorldgen.register();
		com.terminaldetector.drmd.world.orbit.OrbitJunkWorldgen.register();
		com.terminaldetector.drmd.world.level.LevelBuilder.register();
		com.terminaldetector.drmd.world.portal.PortalComplexity.register();
		com.terminaldetector.drmd.aeris.AerisMirai.register();
		WeaponRegistry.bootstrap();
		DescentCommands.register();
		com.terminaldetector.drmd.world.enclave.EnclaveMissionSystem.register();
		com.terminaldetector.drmd.world.fixture.city.CityAuthoringSystem.register();
		com.terminaldetector.drmd.world.contraption.BlockBodyCommands.register();
        com.terminaldetector.drmd.world.contraption.BodySpatialIndex.registerServer();
        com.terminaldetector.drmd.world.contraption.BodyVolumeLeases.register();
        com.terminaldetector.drmd.world.contraption.BodyBlockInteraction.register();
        com.terminaldetector.drmd.world.contraption.mechanism.MechanicalBearingSystem.register();
        com.terminaldetector.drmd.world.contraption.mechanism.BodyMountedWeapons.register();
        // Ability authority follows actual contacts, boarding and mounted damage in the same END phase.
        com.terminaldetector.drmd.ai.TeleportAbilityRelay.register();
        com.terminaldetector.drmd.world.compat.NativeDeferredFluids.register();
		com.terminaldetector.drmd.world.geometry.HybridTerrainCommands.register();
		AiCommands.register();
        com.terminaldetector.drmd.world.threat.SurvivalThreatDirector.register();

		// Player state is keyed by UUID in a process-wide map, so it outlives the world unless it is
		// cleared. Leaving it behind meant a new world inherited the previous one's data — and since
		// a fresh world has no player file to read over it, the stale copy won. 6DoF ended up off in
		// every world after the first, because the flag saying the first-join branch had already run
		// was part of what carried over. Cleared at both ends: on stop for the ordinary case, on
		// start in case a stop never happened.
		ServerLifecycleEvents.SERVER_STOPPED.register(server -> {
            com.terminaldetector.drmd.world.gravity.EntityGravitySystem.clear();
            com.terminaldetector.drmd.world.build.ConstructionMode.clearAll();
			com.terminaldetector.drmd.world.store.SurfaceIngest.close();
			com.terminaldetector.drmd.world.cubic.CubicWorldSystem.close();
			com.terminaldetector.drmd.world.access.CubeLifecycle.closeServer(server);
			com.terminaldetector.drmd.world.compat.NativeCubicSkylight.close();
			com.terminaldetector.drmd.world.portal.PortalTravel.clear();
			com.terminaldetector.drmd.physics.GravyPhysics.clear();
			com.terminaldetector.drmd.ai.DroneSwarmAi.clear();
			com.terminaldetector.drmd.world.gravity.TransientGravityFields.clear();
			DescentPlayerData.clear();
            com.terminaldetector.drmd.inventory.DroneArsenal.clear();
            com.terminaldetector.drmd.world.gravity.FootGravitySystem.clearAll();
            com.terminaldetector.drmd.world.level.LowerWorldRecovery.clearAll();
			com.terminaldetector.drmd.world.layer.LayerBridge.clearAll();
		});

		ServerLifecycleEvents.SERVER_STARTED.register(server -> {
            com.terminaldetector.drmd.physics.PhysicsProfileState.get(server.getOverworld());
            com.terminaldetector.drmd.world.build.ConstructionMode.clearAll();
			// Column height is authoritative once a world is loaded — reconcile the WorldFeatures
			// forced-off-in-Vanilla state against what actually loaded, in case it differs from the
			// config-time guess (e.g. loading an existing Advanced save after the config was flipped
			// to Vanilla for the *next* world, or vice versa).
			if (server.getOverworld() != null) {
				com.terminaldetector.drmd.world.DrmdServerConfig.forceFeaturesFor(
						com.terminaldetector.drmd.world.level.WorldLevels.isAdvancedColumn(server.getOverworld()));
			}
			DescentPlayerData.clear();
            com.terminaldetector.drmd.inventory.DroneArsenal.clear();
            com.terminaldetector.drmd.world.gravity.FootGravitySystem.clearAll();
            com.terminaldetector.drmd.world.level.LowerWorldRecovery.clearAll();
			com.terminaldetector.drmd.world.layer.LayerBridge.clearAll();
			com.terminaldetector.drmd.physics.GravyPhysics.clear();
			com.terminaldetector.drmd.ai.DroneSwarmAi.clear();
			com.terminaldetector.drmd.world.gravity.TransientGravityFields.clear();
			ConstructionRegistry.bootstrap(server);
			com.terminaldetector.drmd.world.gen2.MacroWorld.clear();
			com.terminaldetector.drmd.world.gravity.GravityFields.clear();
			com.terminaldetector.drmd.world.trap.ShieldProjectors.clear();
			com.terminaldetector.drmd.world.smoke.SmokeSystem.clear();
			com.terminaldetector.drmd.world.fire.FireSystem.clear();
			com.terminaldetector.drmd.world.base.DescentSession.clearSeedQueue();
			// Queue is RAM-only; persisted "seeded" marks must reset or distant plates stay empty.
			ServerWorld ow = server.getOverworld();
			if (ow != null) {
				com.terminaldetector.drmd.world.DescentWorldState.get(ow).clearLandmarkSeedMarks();
			}
			com.terminaldetector.drmd.world.build.ConstructScaffold.clearAll();
			com.terminaldetector.drmd.world.dungeon.FacilityReactorFight.clear();
			com.terminaldetector.drmd.world.dungeon.ReactorAftermath.clear();
			com.terminaldetector.drmd.world.gravity.EntityGravitySystem.clear();
			com.terminaldetector.drmd.world.trap.MagneticAnomalySystem.clear();
			com.terminaldetector.drmd.world.sync.DimensionSync.load(server);
			com.terminaldetector.drmd.world.planet.PlanetSync.reset();
			com.terminaldetector.drmd.world.store.SurfaceIngest.onServerStarted(server);
			com.terminaldetector.drmd.world.store.SurfaceStreamer.clear();
			// Both halves of worldgen are kept off the join path. Seeding only queues the landmarks
			// and spends one per tick; the CHUNK_LOAD generators stay idle until that hand-off is
			// done, so nothing of the mod's runs while the server is still preparing spawn.
			server.execute(() -> {
				try {
					com.terminaldetector.drmd.world.base.DescentSession.seedWorld(server);
				} catch (Exception e) {
					LOGGER.error("Descent stock seed failed — world is still playable", e);
				}
				com.terminaldetector.drmd.world.gen.ModWorldgen.enableLiveGeneration();
				com.terminaldetector.drmd.world.gen2.ModWorldgen2.enableLiveGeneration();
			});
			if(!com.terminaldetector.drmd.world.LegacyGeneration.retired())com.terminaldetector.drmd.world.end.EndReactorSession.onServerStarted(server);
		});

		ServerTickEvents.END_SERVER_TICK.register(server -> {
			com.terminaldetector.drmd.world.access.CubeLifecycle.tick(server);
			int tick = server.getTicks();
			// Two buckets rather than one: the world-wide systems and the per-player ones scale with
			// different things — loaded chunks and entities on one side, player count on the other — so a
			// single figure for "the mod" could not say which to look at. See DiagServerTick.
			long worldStart = com.terminaldetector.drmd.diag.DiagServerTick.begin();
			com.terminaldetector.drmd.world.smoke.SmokeSystem.tick();
			com.terminaldetector.drmd.world.gravity.TransientGravityFields.tick(server);
			com.terminaldetector.drmd.world.gravity.EntityGravitySystem.tick(server);
			com.terminaldetector.drmd.world.trap.MagneticAnomalySystem.tick(server);
			com.terminaldetector.drmd.world.base.DescentSession.drainSeedQueue(server);
			com.terminaldetector.drmd.world.dungeon.FacilityReactorFight.tick(server);
			com.terminaldetector.drmd.world.dungeon.ReactorAftermath.tick(server);
			com.terminaldetector.drmd.world.sync.DimensionSync.tick(server);
			com.terminaldetector.drmd.world.planet.PlanetSync.tick(server);
			com.terminaldetector.drmd.world.store.SurfaceIngest.tick(server);
			com.terminaldetector.drmd.world.cubic.CubicWorldSystem.tick(server);
			com.terminaldetector.drmd.world.compat.NativeCubicSkylight.tick(server);
			com.terminaldetector.drmd.world.store.SurfaceStreamer.tick(server);
			if(!com.terminaldetector.drmd.world.LegacyGeneration.retired())com.terminaldetector.drmd.world.fate.WorldEndings.tick(server);
			if(!com.terminaldetector.drmd.world.LegacyGeneration.retired())com.terminaldetector.drmd.world.event.WorldEventSystem.tick(server);
			if (tick % 40 == 0) {
				if(!com.terminaldetector.drmd.world.LegacyGeneration.retired())com.terminaldetector.drmd.world.end.EndReactorSession.onServerTick(server);
			}
			if(!com.terminaldetector.drmd.world.LegacyGeneration.retired())com.terminaldetector.drmd.world.end.OblivionSeekerSpawner.onServerTick(server);
			server.getWorlds().forEach(world -> {
				if (tick % 5 == 0) {
					com.terminaldetector.drmd.world.fire.FireSystem.tick(world);
				}
			});
			com.terminaldetector.drmd.diag.DiagServerTick.end("systems.world", worldStart);

			long playerStart = com.terminaldetector.drmd.diag.DiagServerTick.begin();
			server.getPlayerManager().getPlayerList().forEach(player -> {
				DescentPlayerData data = DescentPlayerData.get(player);
				com.terminaldetector.drmd.world.layer.LayerBridge.tick(player);
				// Background Nether/End warm before ±10 of the parallelepiped faces.
				if(!com.terminaldetector.drmd.world.LegacyGeneration.retired())com.terminaldetector.drmd.world.layer.SeamWarmup.tick(player);
				if (data.isEnabled()) {
					FlightSystem.tick(player, data);
					EnergySystem.regenTick(player, data);
					ShieldSystem.regenTick(player, data);
					com.terminaldetector.drmd.pickup.LootField.tick(player, data);
				} else {
					com.terminaldetector.drmd.world.gravity.FootGravitySystem.tick(player);
				}
				// Gravity tools are hand-held physical manipulators, not a 6DoF-flight subsystem.
				// Keeping this outside the flight branch makes a landed pilot retain the captured body.
				EnergySystem.regenGravityTick(data);
				com.terminaldetector.drmd.physics.GravyPhysics.tick(player);
				if (tick % 20 == player.getId() % 20) {
					var pos = player.getBlockPos();
					com.terminaldetector.drmd.world.atmosphere.AtmosphereRules.tickWaterSuppression(
							player.getServerWorld(), pos, 2);
					com.terminaldetector.drmd.world.atmosphere.AtmosphereRules.tickDeepPressure(
							player.getServerWorld(), pos);
				}
			});
			com.terminaldetector.drmd.diag.DiagServerTick.end("systems.players", playerStart);
		});

		net.fabricmc.fabric.api.event.lifecycle.v1.ServerChunkEvents.CHUNK_LOAD.register(
				(world, chunk) -> {
					com.terminaldetector.drmd.world.scar.ScarApplier.onChunkLoad(world, chunk);
					com.terminaldetector.drmd.world.compat.NativeCubicSkylight.loaded(chunk);
					com.terminaldetector.drmd.world.store.SurfaceIngest.onChunkLoad(world, chunk);
				});

		ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
			DescentPlayerData.get(handler.player).resetPortalEpoch();
			com.terminaldetector.drmd.world.layer.LayerBridge.clear(handler.player.getUuid());
			ConstructionRegistry.allOverrides().forEach((id, mods) -> {
				ServerPlayNetworking.send(handler.player,
						new ModNetworking.ConstructionPayload(id, ClusterModule.listToNbt(mods)));
			});
			server.execute(() -> {
				com.terminaldetector.drmd.world.base.DescentSession.onPlayerJoin(handler.player);
				ModNetworking.syncPlayer(handler.player, DescentPlayerData.get(handler.player));
				com.terminaldetector.drmd.world.sync.DimensionSync.pushTo(handler.player);
				com.terminaldetector.drmd.world.fate.WorldEndings.pushTo(handler.player);
				com.terminaldetector.drmd.world.planet.PlanetSync.pushTo(handler.player);
				com.terminaldetector.drmd.physics.PhysicsProfileState.sync(handler.player);
				com.terminaldetector.drmd.world.build.ConstructScaffold.sync(handler.player);
				unlockDrmdRecipes(handler.player);
			});
		});

        net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents.AFTER_DEATH.register((entity, source) -> {
            if(entity instanceof net.minecraft.server.network.ServerPlayerEntity player) {
                com.terminaldetector.drmd.world.build.ConstructionMode.clear(player.getUuid());
                FlightSystem.disable(player,DescentPlayerData.get(player));
                com.terminaldetector.drmd.physics.GravyPhysics.release(player);
            }
        });
        net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents.AFTER_RESPAWN.register((oldPlayer, newPlayer, alive) -> {
            com.terminaldetector.drmd.world.build.ConstructionMode.clear(newPlayer.getUuid());
            com.terminaldetector.drmd.world.build.ConstructScaffold.sync(newPlayer);
            // A new player entity must not inherit a dead entity's thrust, roll or mount intent.
            var data=DescentPlayerData.get(newPlayer);
            boolean resume=alive&&data.isEnabled();
            FlightSystem.disable(newPlayer,data);
            if(resume) FlightSystem.enableWithoutMount(newPlayer,data);
        });

        net.fabricmc.fabric.api.entity.event.v1.ServerEntityWorldChangeEvents.AFTER_PLAYER_CHANGE_WORLD.register((player,origin,destination)->{
            com.terminaldetector.drmd.world.build.ConstructionMode.clear(player.getUuid());
            com.terminaldetector.drmd.world.build.ConstructScaffold.sync(player);
            com.terminaldetector.drmd.world.level.LowerWorldRecovery.clear(player.getUuid());
            com.terminaldetector.drmd.world.gravity.FootGravitySystem.forget(player.getUuid());
            com.terminaldetector.drmd.world.LocalOrientation.clear(player.getUuid());
            FlightSystem.clearInput(player.getUuid());
            com.terminaldetector.drmd.inventory.DroneArsenal.clear(player.getUuid());
            player.calculateDimensions();
        });

		ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> {
            com.terminaldetector.drmd.world.build.ConstructionMode.clear(handler.player.getUuid());
            FlightSystem.disable(handler.player,DescentPlayerData.get(handler.player));
            com.terminaldetector.drmd.world.gravity.FootGravitySystem.forget(handler.player.getUuid());
            com.terminaldetector.drmd.world.level.LowerWorldRecovery.clear(handler.player.getUuid());
            com.terminaldetector.drmd.world.LocalOrientation.clear(handler.player.getUuid());
			com.terminaldetector.drmd.physics.GravyPhysics.release(handler.player);
			com.terminaldetector.drmd.world.layer.LayerBridge.clear(handler.player.getUuid());
			com.terminaldetector.drmd.world.store.SurfaceStreamer.forget(handler.player.getUuid());
		});

		com.terminaldetector.drmd.world.compat.DistantHorizonsCompat.logStatus();
		LOGGER.info("DRMD 6DOF ready — cubic body prototype + native portal frames + surface store");
	}

	/**
	 * Put the whole DRMD tree in the recipe book on join.
	 *
	 * <p>Survival crafting works either way, but without this the recipes never surface: none of
	 * them is gated behind an advancement, so the book would stay empty and players would have to
	 * look the patterns up externally.
	 */
	private static void unlockDrmdRecipes(net.minecraft.server.network.ServerPlayerEntity player) {
		var server = player.getServer();
		if (server == null) return;
		var recipes = server.getRecipeManager().values().stream()
				.filter(entry -> entry.id().getNamespace().equals(MOD_ID))
				.toList();
		if (!recipes.isEmpty()) {
			player.unlockRecipes(recipes);
		}
	}

	public static double su(double sourceUnits) {
		return sourceUnits * UNIT_SCALE;
	}

	/**
	 * Ticks per second — the divisor between the flight model's blocks-per-second domain and the
	 * blocks-per-tick that {@code Entity.setVelocity} expects. Mixing the two is what made the ship
	 * top out at 19.4 blocks/tick: 388 m/s, faster than chunks can stream.
	 */
	public static final double TICKS_PER_SECOND = 20.0;
}
