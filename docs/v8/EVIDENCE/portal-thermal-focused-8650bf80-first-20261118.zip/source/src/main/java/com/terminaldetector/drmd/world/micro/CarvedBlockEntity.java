package com.terminaldetector.drmd.world.micro;

import com.terminaldetector.drmd.entity.ModBlockEntities;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtHelper;
import net.minecraft.network.listener.ClientPlayPacketListener;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.s2c.play.BlockEntityUpdateS2CPacket;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.util.math.BlockPos;

/**
 * What a block that has been shot at is now: the block it used to be, and which of its sixty-four
 * cells survive.
 *
 * <p>The source state is kept rather than a material name, so a carved oak plank is still oak
 * planks — it drops the right thing, sounds right, and can be put back. The mask is one long.
 *
 * <p>Both are sent to clients, because the shape has to be the same on both sides: the server
 * decides what a player can fly through, and a client drawing something else is a wall you bounce
 * off that is not there.
 */
public class CarvedBlockEntity extends BlockEntity {
	private BlockState source = Blocks.STONE.getDefaultState();
	private long mask = MicroGrid.FULL;
	private boolean organic;
	private ThermalDrillCell thermal;
	private net.minecraft.nbt.NbtElement opaqueThermal;
	private com.terminaldetector.drmd.world.geometry.HybridMesh.Neighbourhood shapeKey;
	private net.minecraft.util.shape.VoxelShape cachedOrganicShape;

	public boolean organic() { return organic || thermal!=null&&!thermal.bores().isEmpty(); }
	public ThermalDrillCell thermal(){return thermal;}
	public boolean thermalReadOnly(){return opaqueThermal!=null;}
	public void setThermal(ThermalDrillCell value){
		if(opaqueThermal!=null)throw new IllegalStateException("opaque thermal metadata cannot be replaced");
		thermal=value;markDirty();sync();
		if(world instanceof net.minecraft.server.world.ServerWorld server&&value!=null&&value.heat()>0)
			server.scheduleBlockTick(pos,getCachedState().getBlock(),Math.max(1,(int)Math.min(ThermalDrillCell.COOL_TICKS,value.coolAt()-server.getTime())));
	}

	public void setOrganic(boolean value) {
		if (organic == value) return;
		organic = value;
		markDirty();
		sync();
	}

	@Override
	public com.terminaldetector.drmd.world.geometry.HybridTerrain.Data getRenderData() {
		return new com.terminaldetector.drmd.world.geometry.HybridTerrain.Data(source, mask, organic(),thermal==null?java.util.List.of():thermal.bores(),thermal==null?0:thermal.heat());
	}

	public net.minecraft.util.shape.VoxelShape organicShape(net.minecraft.world.BlockView view) {
		var key = com.terminaldetector.drmd.world.geometry.HybridTerrain.snapshot(view, pos, getRenderData());
		if (!key.equals(shapeKey)) {
			cachedOrganicShape = com.terminaldetector.drmd.world.geometry.NaturalGeometry.shape(key);
			shapeKey = key;
		}
		return cachedOrganicShape;
	}
	private long cachedMask;
	private java.util.List<MicroGrid.Box> cachedBoxes;

	/** Geometry is rebuilt on damage, not once per block per rendered frame. */
	public java.util.List<MicroGrid.Box> boxes() {
		if (cachedBoxes == null || cachedMask != mask) {
			cachedMask = mask;
			cachedBoxes = java.util.List.copyOf(MicroGrid.boxes(mask));
		}
		return cachedBoxes;
	}

	public CarvedBlockEntity(BlockPos pos, BlockState state) {
		super(ModBlockEntities.CARVED, pos, state);
	}

	public BlockState source() {
		return source;
	}

	public long mask() {
		return mask;
	}

	public void init(BlockState source, long mask) {
		this.source = source;
		this.mask = mask;
		markDirty();
		sync();
	}

	public void setMask(long mask) {
		if (this.mask == mask) return;
		this.mask = mask;
		markDirty();
		sync();
	}

	private void sync() {
		if (world != null && !world.isClient) {
			world.updateListeners(pos, getCachedState(), getCachedState(), 3);
		}
	}

	@Override
	protected void writeNbt(NbtCompound nbt, RegistryWrapper.WrapperLookup registries) {
		super.writeNbt(nbt, registries);
		nbt.put("source", NbtHelper.fromBlockState(source));
		nbt.putLong("mask", mask);
		nbt.putBoolean("organic", organic);
		if(opaqueThermal!=null)nbt.put("thermalDrill",opaqueThermal.copy());
		else if(thermal!=null)nbt.put("thermalDrill",thermal.write());
	}

	@Override
	protected void readNbt(NbtCompound nbt, RegistryWrapper.WrapperLookup registries) {
		super.readNbt(nbt, registries);
		if (nbt.contains("source")) {
			source = NbtHelper.toBlockState(
					registries.getWrapperOrThrow(net.minecraft.registry.RegistryKeys.BLOCK),
					nbt.getCompound("source"));
		}
		if (nbt.contains("mask")) mask = nbt.getLong("mask");
		organic = nbt.getBoolean("organic"); // Existing saves stay rigid.
		thermal=null;opaqueThermal=null;
		if(nbt.contains("thermalDrill")){
			var raw=nbt.get("thermalDrill");var decoded=ThermalDrillCell.read(raw);
			if(decoded.isPresent())thermal=decoded.get();else opaqueThermal=raw.copy();
		}
		if (source.getBlock() instanceof CarvedBlock || source.isAir()) source = Blocks.STONE.getDefaultState();
		// BE packets change geometry without replacing block state. ClientWorld schedules a one-block halo.
		if (world != null && world.isClient) world.updateListeners(pos, getCachedState(), getCachedState(), 3);
	}

	@Override
	public NbtCompound toInitialChunkDataNbt(RegistryWrapper.WrapperLookup registries) {
		return createNbt(registries);
	}

	@Override
	public Packet<ClientPlayPacketListener> toUpdatePacket() {
		return BlockEntityUpdateS2CPacket.create(this);
	}
}
