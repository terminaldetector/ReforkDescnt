#!/usr/bin/env bash
set -euo pipefail
cd /workspace/ungravity-v5/ufo-body-physics
python3 work/ufo-body/native/verify-build-stamp.py check
bash work/ufo-body/native/run-joint-state-pair.sh sodium islandmeta2
python3 work/ufo-body/native/verify-build-stamp.py check
JAVA_HOME=/workspace/jdk21-complete PATH=/workspace/jdk21-complete/bin:$PATH GRADLE_USER_HOME=/workspace/.gradle ./gradlew test runGametest remapJar remapCubiccheckJar --no-daemon --offline > work/ufo-body/island-render-final-regressions.log 2>&1
python3 work/ufo-body/native/verify-build-stamp.py check
