from pathlib import Path
import json,hashlib,zipfile,subprocess,xml.etree.ElementTree as E
subprocess.run(['python3','work/ufo-body/native/verify-build-stamp.py','check'],check=True)
source=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
stamp=json.loads(Path('work/ufo-body/native/verified-build.json').read_text());files=set()
def add(p):
 p=Path(p);assert p.is_file(),p;files.add(p)
for f,h in stamp['jars'].items():
 assert hashlib.sha256(Path(f).read_bytes()).hexdigest()==h
 add(f)
for p in ['src/main/java/com/terminaldetector/drmd/client/flight/BoardingClient.java','src/main/java/com/terminaldetector/drmd/world/contraption/BlockBodyEntity.java','src/main/java/com/terminaldetector/drmd/world/contraption/BodyJointRegistry.java','src/main/java/com/terminaldetector/drmd/world/contraption/BodyJointSystem.java','src/main/java/com/terminaldetector/drmd/world/contraption/BodyVolumeLeases.java','src/main/java/com/terminaldetector/drmd/mixin/VanillaChunkUnloadBudgetMixin.java','src/main/resources/drmd.mixins.json','src/gametest/java/com/terminaldetector/drmd/BodyVolumeGameTests.java','src/gametest/java/com/terminaldetector/drmd/BodyJointRegistryGameTests.java','src/cubiccheck/java/com/terminaldetector/drmd/gate/NativeIslandLoadCheck.java','src/cubiccheck/java/com/terminaldetector/drmd/gate/CubicClientGate.java','src/cubiccheck/java/com/terminaldetector/drmd/gate/mixin/CubicFrameProbe.java','src/cubiccheck/java/com/terminaldetector/drmd/gate/mixin/BodyRenderProbe.java','src/cubiccheck/java/com/terminaldetector/drmd/gate/mixin/JointBodyPersistenceProbe.java','build.gradle','gradle.properties','work/ufo-body/native/verified-build.json','work/ufo-body/collect-island-evidence.py','work/ufo-body/native/run-island.sh','work/ufo-body/native/run-joint-state-pair.sh','work/ufo-body/native/island-final-milestone-checks.sh','work/ufo-body/native/island-final-milestone-checks.log','build/gametest/reports/gametest-results.xml']:
 add(p)
for p in Path('build/test-results/test').glob('TEST-*.xml'):add(p)
for pattern in ['island-*.log','island-*repro.xml','island-*failure.zip','island-*threads.txt']:
 for p in Path('work/ufo-body').glob(pattern):add(p)
for scenario in ['island-cold1-sodium','island-view1-sodium','island-final3-sodium']:
 r=Path('build/cubic-client-final-'+scenario)
 for f in ['inputs.json','island-load-ok.json']:
  if (r/f).is_file():add(r/f)
 add('work/ufo-body/native/final-'+scenario+'.log')
markers={}
for scenario in ['island-final4-sodium','island-final4-gl32']:
 r=Path('build/cubic-client-final-'+scenario)
 info=json.loads((r/'inputs.json').read_text());assert info['sourceSha']==source and not info['uncommittedDiff']
 for suffix in ['.log','.exit','-prepare.log']:add('work/ufo-body/native/final-'+scenario+suffix)
 assert Path('work/ufo-body/native/final-'+scenario+'.exit').read_text().strip()=='0'
 for f in ['inputs.json','launch.json','island-ids.json','island-load-ok.json','island-occupied.png','island-restored.png','island-view-occupied.json','island-view-restored.json']:add(r/f)
 for p in (r/'island-nbt').glob('*.snbt'):add(p)
 marker=json.loads((r/'island-load-ok.json').read_text());assert marker['actualUnload'] and marker['actualColdRestore']==3 and marker['savedBodies']==3 and marker['unloadedTicks']>=20 and marker['stableContactTicks']>=20 and marker['postLoadWalkDistance']>.3 and marker['maxFarColumns']>0 and marker['maxAnchorError']<.02
 marker['renderViews']={}
 for name in ['occupied','restored']:
  view=json.loads((r/('island-view-'+name+'.json')).read_text());v=view['renderedLocalFeet'];assert abs(v['y']-1)<.2 and 0<v['x']<128 and 0<v['z']<3
  marker['renderViews'][name]=view
 markers[scenario]=marker
read=Path('build/cubic-client-final-joint-state-read-islandmeta2-sodium');proof=read/'reload-proof'
info=json.loads((read/'inputs.json').read_text());assert info['sourceSha']==source and not info['uncommittedDiff']
info=json.loads((proof/'write-inputs.json').read_text());assert info['sourceSha']==source and not info['uncommittedDiff']
module=json.loads((read/'joint-state-reload-ok.json').read_text());assert module['beforeFirstTickBodies']==8 and module['survivingJoints']==3 and module['exactJointRegistry'] and module['brokenJointAbsent'] and module['ordinaryKeyboardWalkDistance']>.3
for f in ['inputs.json','joints-ok.json','joint-state-reload-ok.json','joint-state-registry.snbt','joint-state-ids.json','joint-state-reloaded.png']:add(read/f)
for p in (read/'joint-state-nbt').glob('*.snbt'):add(p)
for p in (read/'joint-frames').glob('*.png'):add(p)
for p in proof.iterdir():
 if p.is_file():add(p)
for scenario in ['joints-state-write-islandmeta2-sodium','joint-state-read-islandmeta2-sodium']:
 for suffix in ['.log','.exit']:add('work/ufo-body/native/final-'+scenario+suffix)
 assert Path('work/ufo-body/native/final-'+scenario+'.exit').read_text().strip()=='0'
world=json.loads((proof/'first-process-world.json').read_text());archive=proof/'first-process-world.zip'
assert hashlib.sha256(archive.read_bytes()).hexdigest()==world['sha256']
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for p,h in world['files'].items():assert hashlib.sha256(z.read(p)).hexdigest()==h
units=[E.parse(p).getroot() for p in Path('build/test-results/test').glob('TEST-*.xml')];u={k:sum(int(r.get(k,0)) for r in units) for k in ['tests','failures','errors','skipped']}
cases=list(E.parse('build/gametest/reports/gametest-results.xml').iter('testcase'));g=dict(tests=len(cases),failures=sum(c.find('failure') is not None for c in cases),errors=sum(c.find('error') is not None for c in cases),skipped=sum(c.find('skipped') is not None for c in cases))
assert u==dict(tests=722,failures=0,errors=0,skipped=0) and g==dict(tests=291,failures=0,errors=0,skipped=0)
m={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(files)}
s=dict(source=source,jars=stamp['jars'],unit=u,server=g,native=markers,moduleRestart=module,restartSnapshotSha256=world['sha256'],files=m,publication='Local only',releaseAccepted=False,scope='Occupied constraint-island loading, true cold return, saved-volume schema2, damaged entity pivot, world-gravity predicted support rendering and bounded vanilla unload retries; full v8 and Dynamic Boarding remain open')
p=Path('docs/v8/EVIDENCE/island-load-'+source[:7]+'.zip')
with zipfile.ZipFile(p,'x',zipfile.ZIP_DEFLATED) as z:
 for f in sorted(files):z.write(f,str(f))
 z.writestr('MANIFEST.json',json.dumps(s,indent=2))
with zipfile.ZipFile(p) as z:
 assert z.testzip() is None
 for f,h in m.items():assert hashlib.sha256(z.read(f)).hexdigest()==h
s['archive']=str(p);s['archiveSha256']=hashlib.sha256(p.read_bytes()).hexdigest();Path('work/ufo-body/island-load-summary.json').write_text(json.dumps(s,indent=2)+'\n')
print(json.dumps({k:v for k,v in s.items() if k!='files'},indent=2))
