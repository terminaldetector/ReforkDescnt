from pathlib import Path
import hashlib,json,os,shutil,subprocess,time,xml.etree.ElementTree as ET
root=Path('/workspace/ungravity-v5/ufo-body-physics');os.chdir(root)
source='cb3a8da'
assert subprocess.check_output(['git','rev-parse','--short','HEAD'],text=True).strip()==source
assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'])
out=root/'work/multi-agent/planet-order-negative-cb3a8da';out.mkdir(exist_ok=False)
shutil.copyfile(__file__,out/'executing-runner.py')
shutil.copyfile(root/'work/ufo-body/engine-final-force-test.init.gradle',out/'executing-force.init.gradle')
paths=['src/main/java/com/terminaldetector/drmd/client/planet/PlanetClientState.java','src/main/java/com/terminaldetector/drmd/client/DescentClient.java','src/test/java/com/terminaldetector/drmd/PlanetWorldBoundaryTest.java']
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
before={name:sha(root/name) for name in paths}
(out/'before.json').write_text(json.dumps({'source':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'files':before,'startNs':time.time_ns()},indent=2)+'\n')
env=os.environ.copy();env.update(JAVA_HOME='/workspace/jdk21-complete',GRADLE_USER_HOME='/workspace/.gradle');env['PATH']=env['JAVA_HOME']+'/bin:'+env['PATH']
command=['./gradlew','test','--tests','com.terminaldetector.drmd.PlanetWorldBoundaryTest','--no-daemon','--offline','-I',str(out/'executing-force.init.gradle')]
start=time.time_ns()
with (out/'first.log').open('xb') as log:child=subprocess.run(command,env=env,stdout=log,stderr=subprocess.STDOUT)
(out/'child.exit').write_text(str(child.returncode)+'\n')
path=root/'build/test-results/test/TEST-com.terminaldetector.drmd.PlanetWorldBoundaryTest.xml'
if path.is_file():shutil.copyfile(path,out/path.name)
after={name:sha(root/name) for name in paths};assert before==after
cases=list(ET.parse(path).getroot().iter('testcase')) if path.is_file() else []
result={'source':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'childExit':child.returncode,'command':command,'startNs':start,'endNs':time.time_ns(),'sourceUnchanged':before==after,'freshXml':path.is_file() and path.stat().st_mtime_ns>=start,'cases':[{'name':c.attrib['name'],'failure':c.find('failure').attrib.get('message') if c.find('failure') is not None else None} for c in cases]}
(out/'receipt.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
assert result['freshXml'] and child.returncode==1 and len(cases)==3 and sum(c.find('failure') is not None for c in cases)==2
