"""Collect the actual closed full regression and two same-JAR native clients."""
from pathlib import Path
import hashlib
import json
import subprocess
import tarfile
import xml.etree.ElementTree as ET
import zipfile

ROOT = Path('/workspace/ungravity-v5/ufo-body-physics')
SOURCE = '65370f7266cea705ebf2f9e86217031370fa2a3d'
BASE = '5057931efce99156ffdc8a195e90b1a926907ed8'
RUN = ROOT / 'work/multi-agent/integrated-65370f7'
ZIP = ROOT / 'docs/v8/EVIDENCE/integrated-65370f7.zip'
assert not ZIP.exists()
sha = lambda data: hashlib.sha256(data).hexdigest()
counts = json.loads((RUN / 'counts.json').read_text())
assert counts == {k: dict(tests=n, failures=0, errors=0, skipped=0) for k, n in [('unit', 998), ('game', 502)]}
pair = json.loads((RUN / 'native-pair-first/receipt.json').read_text())
assert pair['gatePassed'] and pair['source'] == pair['endSource'] == SOURCE
assert all(r['javaExit'] == r['helperExit'] == 0 and r['gatePassed'] for r in pair['results'])
stamp = json.loads((RUN / 'verified-build.json').read_text())
assert stamp['sourceSha'] == SOURCE
assert stamp['jars'] == pair['jars']
manifest = json.loads((RUN / 'processed-full-manifest.json').read_text())
assert len(manifest['entrypoints']['fabric-gametest']) == 84
payload = {}

def add(path, name=None):
    path = Path(path)
    assert path.is_file() and not path.is_symlink()
    name = name or str(path.relative_to(ROOT))
    assert not name.startswith('/') and '..' not in Path(name).parts
    data = path.read_bytes()
    if name in payload:
        assert payload[name] == data
    else:
        payload[name] = data

for path in sorted(RUN.rglob('*')):
    if path.is_file():
        add(path)
for suffix in ('first-full-wrapper.log', 'outer-executed.sh', 'full-executed.sh', 'outer.exit', 'arrival-inputs-before.json'):
    add(ROOT / ('work/multi-agent/integrated-65370f7-' + suffix))
for name in ('run-full.sh', 'run-final-full-with-arrival.sh', 'run-integrated-native-pair.py', 'preserve-current-full-world.py', 'collect-65370f7.py'):
    add(ROOT / 'work/multi-agent' / name)
for name in ('integrated-65370f7-preserved.json',):
    add(ROOT / 'work/ufo-body' / name)

source_rows = []
changed = subprocess.check_output(['git', 'diff', '--name-only', BASE, SOURCE, '--', 'src/main', 'src/test', 'src/gametest'], cwd=ROOT, text=True).splitlines()
assert len(changed) == 46
for rel in changed:
    data = subprocess.check_output(['git', 'show', SOURCE + ':' + rel], cwd=ROOT)
    assert (ROOT / rel).read_bytes() == data
    payload['source/' + rel] = data
    old = subprocess.run(['git', 'show', BASE + ':' + rel], cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
    source_rows.append(dict(path=rel, oldSHA256=sha(old.stdout) if old.returncode == 0 else None, newSHA256=sha(data)))
payload['SOURCE-DELTA.json'] = (json.dumps(source_rows, indent=2) + '\n').encode()

for result in pair['results']:
    runtime = Path(result['runtime'])
    for name in ('inputs.json', 'launch.json', 'options.txt', 'logs/latest.log', 'actual-negative-fixture-inputs.json', 'surface-arrival-outcome.json', 'presentation-ok.json', 'ps1-color-ok.json'):
        if (runtime / name).is_file():
            add(runtime / name)
    for name in ('surface-arrival-frames', 'surface-arrival-packets', 'presentation-frames', 'ps1-color-reference', 'viewmodel-proof'):
        for path in sorted((runtime / name).rglob('*')):
            if path.is_file():
                add(path)
    inputs = json.loads((runtime / 'inputs.json').read_text())
    for rel, expected in stamp['jars'].items():
        actual = runtime / 'mods' / Path(rel).name
        assert sha(actual.read_bytes()) == expected

header = dict(schema='ungravity.current-full-and-native-evidence.v1', source=SOURCE, base=BASE,
              counts=counts, entries=84, jars=stamp['jars'], sameJarNativePair=True,
              changedSourcePaths=len(source_rows), oldTestsRemoved=0, addedUnits=47, addedGames=22,
              externalComponentNativeNotRelabelled=True,
              worldArchive='work/ufo-body/integrated-65370f7.zip',
              worldArchiveSHA256='f05dbe195f09e49904e8c46c0bdf6699ff7abb4a1e84ad17b15166b3ca3ef739',
              files={name: dict(bytes=len(data), sha256=sha(data)) for name, data in sorted(payload.items())})
with zipfile.ZipFile(ZIP, 'x', zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
    for name, data in sorted(payload.items()):
        archive.writestr(name, data)
    archive.writestr('MANIFEST.json', json.dumps(header, indent=2) + '\n')
with zipfile.ZipFile(ZIP) as archive:
    assert archive.testzip() is None and set(archive.namelist()) == set(payload) | {'MANIFEST.json'}
    for name, expected in header['files'].items():
        data = archive.read(name)
        assert len(data) == expected['bytes'] and sha(data) == expected['sha256']
receipt = dict(source=SOURCE, archive=str(ZIP.relative_to(ROOT)), bytes=ZIP.stat().st_size,
               sha256=sha(ZIP.read_bytes()), payloads=len(payload), allCRCAndSHA256=True,
               units=998, games=502, entries=84, sameJarClients=2, frames=40,
               sourcePaths=46, actualNewUnitCases=47, actualNewGameCases=22, removedOldCases=0,
               fullSpecAccepted=False, wholePacketsAccepted=0)
(ROOT / 'docs/v8/EVIDENCE/integrated-65370f7.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt, indent=2))
