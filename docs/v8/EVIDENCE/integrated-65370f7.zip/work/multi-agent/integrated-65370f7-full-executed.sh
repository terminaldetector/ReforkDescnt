#!/usr/bin/env bash
set -euo pipefail
cd /workspace/ungravity-v5/ufo-body-physics
run="$1"
expected_source="$2"
expected_units="$3"
expected_games="$4"
[[ "$run" =~ ^[a-z0-9-]+$ ]]
test "$(git rev-parse HEAD)" = "$expected_source"
test -z "$(git status --porcelain --untracked-files=no)"
out="work/multi-agent/$run"
test ! -e "$out"
mkdir -p "$out"
export JAVA_HOME=/workspace/jdk21-complete
export PATH="$JAVA_HOME/bin:$PATH"
export GRADLE_USER_HOME=/workspace/.gradle
git rev-parse HEAD > "$out/source.txt"
cp work/ufo-body/engine-final-force-test.init.gradle "$out/force-test.init.gradle"
cp "$0" "$out/runner.sh"
# Material/ownership tests retain CREATE_NEW receipts. Bind the ordinary full
# suite to its own fresh directory without changing any declared entrypoint.
python3 - "$out" <<'PY'
from pathlib import Path
import sys
out=Path(sys.argv[1]).resolve()
proof=out/'player-aa-proof'
assert not proof.exists()
assert "'" not in str(proof) and '\\' not in str(proof)
properties=('drmd.test.playerAaProofDir','drmd.test.playerAaOpaqueProofDir','drmd.test.playerAaMaterialProofDir')
with (out/'force-test.init.gradle').open('a') as f:
    f.write("\ngradle.projectsEvaluated {\n    rootProject.extensions.getByName('loom').runs.named('gametest') {\n")
    for name in properties:
        f.write("        vmArg '-D"+name+"="+str(proof)+"'\n")
    f.write('    }\n}\n')
PY
python3 scripts/v8/ps1_build_stamp.py before
cp work/ps1/verified-build.inputs.json "$out/build-inputs-before.json"
# Focused fixtures may add generated dimension/mixin resources. Start this ordinary
# resource stage from its own source tree, keeping every world and test log intact.
python3 - <<'PY'
from pathlib import Path
import shutil
p=Path('build/resources/gametest')
if p.exists():
    assert p.is_dir() and not p.is_symlink()
    shutil.rmtree(p)
PY
set +e
./gradlew processGametestResources --rerun-tasks --no-daemon --offline > "$out/full-manifest.log" 2>&1
stage_code=$?
set -e
echo "$stage_code" > "$out/full-manifest.exit"
test "$stage_code" -eq 0
python3 - "$out" <<'PY'
import json,sys
from pathlib import Path
src=Path('src/gametest/resources/fabric.mod.json').read_bytes()
actual=Path('build/resources/gametest/fabric.mod.json').read_bytes()
assert json.loads(src)==json.loads(actual),'Processed GameTest manifest differs from committed full manifest'
declared={p.relative_to('src/gametest/resources') for p in Path('src/gametest/resources').rglob('*') if p.is_file()}
generated={p.relative_to('build/resources/gametest') for p in Path('build/resources/gametest').rglob('*') if p.is_file()}
assert declared==generated,('Unexpected or missing ordinary GameTest resources',declared^generated)
Path(sys.argv[1],'processed-full-manifest.json').write_bytes(actual)
print('Full manifest:',len(json.loads(actual)['entrypoints']['fabric-gametest']),'entrypoints')
PY
# Preserve any preceding report, then require this invocation to create its own.
# A failure before the GameTest server starts must never inherit an older XML.
python3 - "$out" <<'PY'
import json,sys,time
from pathlib import Path
out=Path(sys.argv[1]);old=Path('build/gametest/reports/gametest-results.xml')
if old.exists():
    with (out/'prior-game-results.xml').open('xb') as saved:saved.write(old.read_bytes())
    old.unlink()
(out/'test-start.json').write_text(json.dumps({'startNs':time.time_ns()})+'\n')
PY
set +e
./gradlew test runGametest remapJar remapCubiccheckJar --no-daemon --offline -I "$out/force-test.init.gradle" > "$out/full-regressions.log" 2>&1
stage_code=$?
set -e
echo "$stage_code" > "$out/full-regressions.exit"
cp build/gametest/reports/gametest-results.xml "$out/full-game-results.xml" || true
python3 - "$out" "$expected_units" "$expected_games" "$stage_code" <<'PY'
import json,sys,tarfile,xml.etree.ElementTree as ET
from pathlib import Path
out=Path(sys.argv[1]); counts={}
start=json.loads((out/'test-start.json').read_text())['startNs']
fresh=Path('build/gametest/reports/gametest-results.xml')
freshness={'gameReportExists':fresh.is_file(),'startNs':start,
           'gameReportMtimeNs':fresh.stat().st_mtime_ns if fresh.is_file() else None}
(out/'report-freshness.json').write_text(json.dumps(freshness,indent=2)+'\n')
assert freshness['gameReportExists'],'No GameTest XML produced; preceding report preserved separately'
assert freshness['gameReportMtimeNs']>=start,'GameTest XML predates this invocation'
with tarfile.open(out/'unit-results.tar.gz','x:gz') as archive:
    for p in sorted(Path('build/test-results/test').glob('TEST-*.xml')):
        archive.add(p,arcname=p.name)
for label,paths in [('unit',list(Path('build/test-results/test').glob('TEST-*.xml'))),('game',[out/'full-game-results.xml'])]:
    cases=[c for p in paths for c in ET.parse(p).getroot().iter('testcase')]
    counts[label]={'tests':len(cases),'failures':sum(c.find('failure') is not None for c in cases),'errors':sum(c.find('error') is not None for c in cases),'skipped':sum(c.find('skipped') is not None for c in cases)}
(out/'counts.json').write_text(json.dumps(counts,indent=2)+'\n');print(json.dumps(counts))
assert int(sys.argv[4])==0,'Full Gradle run failed; original logs/XML retained'
for label,expected in [('unit',int(sys.argv[2])),('game',int(sys.argv[3]))]:
    assert counts[label]==dict(tests=expected,failures=0,errors=0,skipped=0),(label,counts[label],expected)
PY
python3 scripts/v8/ps1_build_stamp.py record
python3 scripts/v8/ps1_build_stamp.py check
cp work/ps1/verified-build.json "$out/verified-build.json"
test "$(git rev-parse HEAD)" = "$expected_source"
test -z "$(git status --porcelain --untracked-files=no)"
