"""Archive one completed canonical full-suite world; retain all other build evidence."""
from pathlib import Path
import fcntl
import gzip
import hashlib
import json
import os
import re
import shutil
import stat
import subprocess
import sys
import zipfile

root = Path('/workspace/ungravity-v5/ufo-body-physics')
os.chdir(root)
run, source = sys.argv[1:]
assert re.fullmatch(r'integrated-[0-9a-f]{7}', run)
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip() == source
result = json.loads((root / 'work/multi-agent' / run / 'counts.json').read_text())
assert all(v['failures'] == v['errors'] == v['skipped'] == 0 for v in result.values())
world = root / 'build/gametest/world'
assert world.is_dir() and world.resolve() == world
archive = root / 'work/ufo-body' / (run + '.zip')
receipt = archive.with_name(run + '-preserved.json')
assert not archive.exists() and not receipt.exists()

def sha(p):
    h = hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda: f.read(1048576), b''):
            h.update(b)
    return h.hexdigest()

def closed():
    for p in Path('/proc').glob('[0-9]*'):
        try:
            s = (p / 'stat').read_text()
            state = s[s.rfind(')') + 2:].split()[0]
            if state not in ('Z', 'X'):
                assert Path(os.readlink(p / 'exe')).name != 'java', p
        except (FileNotFoundError, ProcessLookupError, PermissionError):
            continue

def inventory():
    rows = {}
    for p in sorted(world.rglob('*')):
        assert not p.is_symlink()
        if not p.is_file():
            continue
        s = p.lstat()
        assert stat.S_ISREG(s.st_mode) and s.st_nlink == 1
        rows[str(p.relative_to(world))] = dict(bytes=s.st_size, sha256=sha(p), dev=s.st_dev,
            inode=s.st_ino, mtimeNs=s.st_mtime_ns, mode=stat.S_IMODE(s.st_mode), blocks=s.st_blocks * 512)
    return rows

closed()
before = shutil.disk_usage(root).free
with (world / 'session.lock').open('r+b') as lock:
    fcntl.lockf(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    rows = inventory()
    assert 'level.dat' in rows and 'session.lock' in rows
    manifest = dict(source=source, original=str(world), counts=result, files=rows,
                    scope='Completed disposable ordinary full-suite world only; all other build evidence retained.')
    with zipfile.ZipFile(archive, 'x', zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for rel in rows:
            z.write(world / rel, rel)
        z.writestr('PRESERVATION.json', json.dumps(manifest, indent=2) + '\n')
    gzip_count = 0
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None and set(z.namelist()) == set(rows) | {'PRESERVATION.json'}
        for rel, row in rows.items():
            h = hashlib.sha256()
            n = 0
            with z.open(rel) as f:
                for b in iter(lambda: f.read(1048576), b''):
                    h.update(b)
                    n += len(b)
            assert n == row['bytes'] and h.hexdigest() == row['sha256']
            with z.open(rel) as f:
                is_gzip = f.read(2) == b'\x1f\x8b'
            if is_gzip:
                with z.open(rel) as f, gzip.GzipFile(fileobj=f) as g:
                    while g.read(1048576):
                        pass
                gzip_count += 1
    closed()
    assert inventory() == rows
    data = dict(source=source, archive=str(archive), archiveSHA256=sha(archive),
                archiveBytes=archive.stat().st_size, files=len(rows),
                originalBytes=sum(v['bytes'] for v in rows.values()),
                allocatedBytes=sum(v['blocks'] for v in rows.values()),
                fullZIPCRCAndEverySHA256=True, gzipFooters=gzip_count,
                freshInodeMtimeHashInventory=True, exclusivePosixAndFlock=True,
                beforeFreeBytes=before, rawWorldReclaimed=False)
    receipt.write_text(json.dumps(data, indent=2) + '\n')
    shutil.rmtree(world)
    data.update(rawWorldReclaimed=True, afterFreeBytes=shutil.disk_usage(root).free)
    receipt.write_text(json.dumps(data, indent=2) + '\n')
print(json.dumps(data, indent=2))
