"""Read-only derived diagnostics; raw log/XML remain authoritative for pass/fail."""
from pathlib import Path
import collections, hashlib, json, sys

raw=Path(sys.argv[1]); out=Path(sys.argv[2]); out.mkdir(parents=True, exist_ok=True)
rows=[]
for line in raw.read_text(errors="replace").splitlines():
    if "CLIMBER_MOTION_TRACE " in line:
        rows.append(json.loads(line.split("CLIMBER_MOTION_TRACE ",1)[1]))
(out/"first-events.json").write_text(json.dumps(rows,indent=2)+"\n")
def delta(a,b,key="velocityBlocksPerTick"):
    return [y-x for x,y in zip(a[key],b[key])]
def ratio(a,b):
    return [y/x if abs(x)>1e-9 else None for x,y in zip(a,b)]
def pairs(tick,first,last,context=None):
    result=[]; pending=[]
    for r in tick:
        if context is not None and r["context"]!=context: continue
        if r["phase"]==first: pending.append(r)
        elif r["phase"]==last and pending: result.append((pending.pop(),r))
    return result
actors=[]
for uid in dict.fromkeys(r["uuid"] for r in rows):
    events=[r for r in rows if r["uuid"]==uid]; ticks=[]
    for age in sorted(set(r["actualAge"] for r in events)):
        tick=[r for r in events if r["actualAge"]==age]
        part={"actualAge":age,"observerRelativeTicks":sorted(set(r["ordinaryEntityTicks"] for r in tick)),
              "phases":dict(collections.Counter(r["phase"] for r in tick)),"nativeInputs":[],"nativeTravel":[],"pounces":[],"follows":[],"fields":[]}
        for a,b in pairs(tick,"INPUT_BEFORE","INPUT_AFTER"):
            part["nativeInputs"].append({"beforeSequence":a["sequence"],"afterSequence":b["sequence"],
                 "input":a.get("nativeInput"),"inputSpeed":a.get("nativeInputSpeed"),
                 "beforeVelocity":a["velocityBlocksPerTick"],"afterVelocity":b["velocityBlocksPerTick"],
                 "actualLocomotorDelta":delta(a,b),"addedNormalVelocity":b["normalVelocityBlocksPerTick"]-a["normalVelocityBlocksPerTick"]})
        for a,b in pairs(tick,"TRAVEL_BEFORE","TRAVEL_AFTER"):
            moves=[r for r in tick if a["sequence"]<r["sequence"]<b["sequence"] and r["phase"]=="MOVE_AFTER" and r["context"]=="NATIVE"]
            entry={"beforeSequence":a["sequence"],"afterSequence":b["sequence"],"input":a.get("nativeTravelInput"),
                   "beforeVelocity":a["velocityBlocksPerTick"],"afterVelocity":b["velocityBlocksPerTick"],
                   "actualDisplacement":delta(a,b,"position"),"nativeMoveAfterCount":len(moves)}
            if moves:
                m=moves[-1];entry.update({"lastMoveAfterSequence":m["sequence"],"lastMoveAfterVelocity":m["velocityBlocksPerTick"],
                    "afterTravelOverAfterMoveWorldXyz":ratio(m["velocityBlocksPerTick"],b["velocityBlocksPerTick"]),
                    "velocityChangeAfterLastNativeMove":delta(m,b),"groundBefore":a["onGround"],"groundAfter":b["onGround"],
                    "horizontalCollision":m["horizontalCollision"],"verticalCollision":m["verticalCollision"]})
            part["nativeTravel"].append(entry)
        for a,b in pairs(tick,"POUNCE_BEFORE","POUNCE_AFTER"):
            part["pounces"].append({"beforeSequence":a["sequence"],"afterSequence":b["sequence"],
                  "nativeLeapVelocity":a.get("nativePounceVelocity"),"beforeVelocity":a["velocityBlocksPerTick"],
                  "afterVelocity":b["velocityBlocksPerTick"],"actualDirectDelta":delta(a,b)})
        for a,b in pairs(tick,"FIELD_BEFORE","FIELD_AFTER"):
            part["fields"].append({"beforeSequence":a["sequence"],"afterSequence":b["sequence"],
                "beforeVelocity":a["velocityBlocksPerTick"],"afterVelocity":b["velocityBlocksPerTick"],"delta":delta(a,b),
                "beforeGap":a["support"].get("feetGap"),"afterGap":b["support"].get("feetGap"),"onGroundAfter":b["onGround"]})
        for r in tick:
            if r["phase"].startswith("FOLLOW_"):
                part["follows"].append({k:r.get(k) for k in ["phase","sequence","nativePath","waypoint","followSpeed","followResult","firstFollowActualAge","autoArmedAtFirstFollow","boundedCacheSnapshot"]})
        ticks.append(part)
    support=[r["support"] for r in events]
    actors.append({"uuid":uid,"type":events[0]["type"],"fixture":events[0]["fixture"],"eventCount":len(events),
        "actualAgeRange":[min(r["actualAge"] for r in events),max(r["actualAge"] for r in events)],
        "observerBaselineAges":sorted(set(r["spawnAge"] for r in events)),"localUp":events[0]["localUp"],
        "phases":dict(collections.Counter(r["phase"] for r in events)),"hitEventBudget":len(events)==256,
        "allSupportQueriesAvailable":all(s.get("queryAvailable",False) for s in support),
        "allMeasuredBodiesClear":all(s.get("actualBodyClear",False) for s in support),
        "allMeasuredSupportsNormalAligned":all(s.get("normalDotLocalUp",0)>=.95 for s in support),
        "ticks":ticks})
result={"rawLogSha256":hashlib.sha256(raw.read_bytes()).hexdigest(),"derivedOnly":True,"eventCount":len(rows),
    "units":"ordinary Entity blocks/tick, input dimensionless, displacement blocks",
    "ratioSemantics":"World XYZ component afterTravel / last actual native MOVE_AFTER within that travel; null if denominator nearly zero; collision/climbing/impulse branches must be interpreted from raw phases",
    "pounceScope":"Only actual start invocations within finite armed windows; missing rows cannot establish no later invocation",
    "actorCount":len(actors),"actors":actors}
(out/"first-phase-analysis.json").write_text(json.dumps(result,indent=2)+"\n")
for a in actors:
    print(json.dumps({k:v for k,v in a.items() if k!="ticks"}))
