from pathlib import Path
import hashlib,json,subprocess,zipfile,datetime
root=Path.cwd();out=root/'work/climber-follow-phases-20261117';source='06286166866ada74f014559749aaa67475eeaed0'
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==source
assert not subprocess.check_output(['git','diff','HEAD','--','src'],text=True)
start=json.loads((out/'first-inputs.json').read_text())['startedUnix']
world=root/'build/gametest/world';assert world.is_dir()
# Do not archive a live own world. Other lanes can hold the independent Java slot now.
for proc in Path('/proc').iterdir():
 if not proc.name.isdigit():continue
 try:
  cmd=(proc/'comm').read_text().strip()
  if cmd=='java' and (proc/'cwd').resolve()==root:raise RuntimeError('Own Java is still running: '+proc.name)
 except (FileNotFoundError,ProcessLookupError,PermissionError):pass
base='b51bed2fbc5da7ccd677cfeccc3bdcdea8851f33'
(out/'source-changes.patch').write_bytes(subprocess.check_output(['git','diff',base,source,'--','src']))
(out/'source-commit.txt').write_bytes(subprocess.check_output(['git','show','--format=fuller','--stat',source]))
files={}
def add(p,name=None):
 p=Path(p);name=name or str(p.relative_to(root));assert p.is_file(),p
 assert name not in files,name;files[name]=p
changed=subprocess.check_output(['git','diff','--name-only',base,source,'--','src/main'],text=True).splitlines()
for name in changed:add(root/name)
for p in (root/'src/gametest/java/com/terminaldetector/drmd/climber').rglob('*.java'):add(p)
add(root/'src/gametest/java/com/terminaldetector/drmd/ClimberFieldGravityGameTests.java')
for p in (root/'src/gametest/resources').glob('drmd.climber*.json'):add(p)
for name in ['build.gradle','settings.gradle','gradle.properties','src/gametest/resources/fabric.mod.json','src/main/resources/fabric.mod.json','build/resources/gametest/fabric.mod.json','build/resources/main/drmd.mixins.json','build/resources/main/fabric.mod.json']:
 p=root/name
 if p.is_file() and name not in files:add(p)
for p in (root/'build/resources/gametest').glob('drmd.climber*.json'):add(p)
classes=[]
for p in (root/'build/classes/java/gametest/com/terminaldetector/drmd/climber').rglob('*.class'):classes.append(p)
classes.extend((root/'build/classes/java/gametest/com/terminaldetector/drmd').glob('ClimberFieldGravityGameTests*.class'))
for name in changed:
 if not name.endswith('.java'):continue
 p=root/('build/classes/java/main/'+name[len('src/main/java/'):]);classes.extend(p.parent.glob(p.stem+'*.class'))
class_rows=[]
for p in sorted(set(classes)):
 add(p);class_rows.append({'path':str(p.relative_to(root)),'bytes':p.stat().st_size,'mtime':p.stat().st_mtime,'reusedUpToDateFromBeforeStart':p.stat().st_mtime<start,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
(out/'compiled-inputs.json').write_text(json.dumps({'classes':class_rows,'note':'Exact launch input class files; up-to-date main classes may predate this test-only gate. No stale build/libs JAR is represented as new.'},indent=2)+'\n')
for name in ['CONTRACT.md','focus.init.gradle','executing-focus.init.gradle','source-contract.json','source-receipt.json','first-inputs.json','first-source.txt','first-summary.json','first.log','first.xml','first.exit','first-markers.json','first-events.json','first-phase-analysis.json','derive.py','compiled-inputs.json','source-changes.patch','source-commit.txt','seal.py']:
 add(out/name,'run/'+name)
add(root/'work/climber-local-request-boundary-20261117/native-leap-contract.json','native/native-leap-contract.json')
worlds=[]
for p in sorted(world.rglob('*')):
 if p.is_file():
  name='world/'+str(p.relative_to(world));add(p,name)
  worlds.append({'path':str(p.relative_to(world)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
(out/'world-inventory.json').write_text(json.dumps(worlds,indent=2)+'\n');add(out/'world-inventory.json','run/world-inventory.json')
payloads=[{'path':name,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for name,p in sorted(files.items())]
manifest={'source':source,'baselineForSourcePatch':base,'productionSource':'341b5b961d2b68eb76bb0f137296ad914679e42d','payloads':payloads,'worldFiles':len(worlds),'worldBytes':sum(r['bytes'] for r in worlds),'classification':json.loads((out/'first-summary.json').read_text())['classification']}
archive=root/'docs/v8/EVIDENCE/climber-follow-phases-0628616-first-diagnostic.zip';archive.parent.mkdir(parents=True,exist_ok=True);assert not archive.exists()
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,p in sorted(files.items()):z.write(p,name)
 z.writestr('MANIFEST.json',json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for row in payloads:
  data=z.read(row['path']);assert len(data)==row['bytes'];assert hashlib.sha256(data).hexdigest()==row['sha256']
receipt={'source':source,'archive':str(archive.relative_to(root)),'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'bytes':archive.stat().st_size,'payloadFiles':len(payloads),'worldFiles':len(worlds),'worldBytes':manifest['worldBytes'],'allSha256AndZipCrcVerified':True,'closedDisposableWorldReclaimed':False,'classification':manifest['classification']}
(out/'first-archive.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
