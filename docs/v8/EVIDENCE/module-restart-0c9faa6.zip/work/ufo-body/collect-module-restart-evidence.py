from pathlib import Path
import json,hashlib,zipfile,subprocess,xml.etree.ElementTree as E
source='0c9faa642643e601db8b75248090cf5a6d2076eb'
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==source
stamp=json.loads(Path('work/ufo-body/native/verified-build.json').read_text());files=set()
def add(p):
 p=Path(p);assert p.is_file(),p;files.add(p)
for f,h in stamp['jars'].items():assert hashlib.sha256(Path(f).read_bytes()).hexdigest()==h
for f in ['build.gradle','gradle.properties','settings.gradle','src/main/resources/drmd.mixins.json',
 'src/main/java/com/terminaldetector/drmd/client/flight/BoardingClient.java',
 'src/main/java/com/terminaldetector/drmd/world/contraption/boarding/BoardingEpochBarrier.java',
 'src/main/java/com/terminaldetector/drmd/world/contraption/boarding/BoardingSystem.java',
 'src/main/java/com/terminaldetector/drmd/mixin/BoardingServerMovementMixin.java',
 'src/main/java/com/terminaldetector/drmd/mixin/client/BoardingClientTeleportMixin.java',
 'src/test/java/com/terminaldetector/drmd/BoardingEpochBarrierTest.java',
 'src/gametest/java/com/terminaldetector/drmd/BoardingGameTests.java',
 'src/cubiccheck/java/com/terminaldetector/drmd/gate/CubicClientGate.java',
 'src/cubiccheck/java/com/terminaldetector/drmd/gate/NativeJointCheck.java',
 'src/cubiccheck/java/com/terminaldetector/drmd/gate/NativeJointReloadCheck.java',
 'src/cubiccheck/java/com/terminaldetector/drmd/gate/mixin/JointBodyPersistenceProbe.java',
 'src/cubiccheck/java/com/terminaldetector/drmd/gate/mixin/BodyRenderProbe.java',
 'src/cubiccheck/java/com/terminaldetector/drmd/gate/mixin/CubicFrameProbe.java',
 'src/cubiccheck/resources/drmd.cubiccheck.mixins.json',
 'work/ufo-body/native/verified-build.json',
 'work/ufo-body/collect-module-restart-evidence.py',
 'work/ufo-body/native/run-joint-state-pair.sh','work/ufo-body/native/resume-joint-state-pair.sh',
 'work/ufo-body/native/run-joint-state-write.sh','work/ufo-body/native/run-joint-state-read.sh',
 'work/ufo-body/joint-modules3-writer-runner-correction.json',
 'build/gametest/reports/gametest-results.xml']:
 add(f)
for p in Path('build/test-results/test').glob('TEST-*.xml'):add(p)
for pattern in ['boarding-teleport-*.log','boarding-teleport-*.xml','joint-reload-*.log','joint-reload-*.json']:
 for p in Path('work/ufo-body').glob(pattern):add(p)
for name in ['modules1','modules2']:
 for p in Path('work/ufo-body/native').glob('final-joints-state-write-'+name+'-sodium.*'):
  if p.is_file():add(p)
for stand in ['build/cubic-client-before-joints-state-write-modules2-sodium','build/cubic-client-failed-joints-state-write-modules2-sodium']:
 r=Path(stand)
 for f in ['inputs.json','launch.json']:add(r/f)
 for f in (r/'crash-reports').glob('*.txt'):add(f)
 for f in (r/'joint-frames').glob('*.png'):add(f)
 for f in [Path('work/preserved-disposable-worlds')/(r.name+'-saves.zip')]:add(f)
pairs={}
for round,renderer in [('modules3','sodium'),('modules4','gl32')]:
 write='joints-state-write-'+round+'-'+renderer;read='joint-state-read-'+round+'-'+renderer
 r=Path('build/cubic-client-final-'+read);proof=r/'reload-proof'
 writer=json.loads((r/'joints-ok.json').read_text());reader=json.loads((r/'joint-state-reload-ok.json').read_text())
 assert len(writer['scenes'])==5 and all(v['frames']>=90 for v in writer['scenes']) and writer['seamSupportChanges']==1
 assert reader['actualProcessRestart'] and reader['beforeFirstTickBodies']==8 and reader['exactJointRegistry'] and reader['survivingJoints']==3 and reader['brokenJointAbsent'] and reader['noReplacementBodies']
 assert reader['stableContactTicks']>=30 and reader['ordinaryKeyboardWalkDistance']>.3 and reader['freshFrames']>=6 and reader['maxAnchorError']<.02
 assert json.loads((r/'joint-state-saved.json').read_text())['actualSerializedBodies']==8
 assert json.loads((r/'inputs.json').read_text())['sourceSha']==source
 assert json.loads((proof/'write-inputs.json').read_text())['sourceSha']==source
 for scenario in [write,read]:
  for suffix in ['.log','.exit']:add('work/ufo-body/native/final-'+scenario+suffix)
  assert Path('work/ufo-body/native/final-'+scenario+'.exit').read_text().strip()=='0'
 for f in ['inputs.json','launch.json','options.txt','joints-ok.json','joint-state-reload-ok.json','joint-state-ids.json','joint-state-saved.json','joint-state-registry.snbt','joint-state-reloaded.png']:add(r/f)
 for f in (r/'joint-state-nbt').glob('*.snbt'):add(f)
 for f in (r/'joint-frames').glob('*.png'):add(f)
 for f in proof.iterdir():
  if f.is_file():add(f)
 world=json.loads((proof/'first-process-world.json').read_text());archive=proof/'first-process-world.zip'
 assert hashlib.sha256(archive.read_bytes()).hexdigest()==world['sha256']
 with zipfile.ZipFile(archive) as z:
  assert z.testzip() is None
  for f,h in world['files'].items():assert hashlib.sha256(z.read(f)).hexdigest()==h
 pairs[renderer]=dict(writer=writer,reader=reader,worldSnapshotSha256=world['sha256'])
units=[E.parse(p).getroot() for p in Path('build/test-results/test').glob('TEST-*.xml')]
u={k:sum(int(r.get(k,0)) for r in units) for k in ['tests','failures','errors','skipped']}
cases=list(E.parse('build/gametest/reports/gametest-results.xml').iter('testcase'))
g=dict(tests=len(cases),failures=sum(c.find('failure') is not None for c in cases),errors=sum(c.find('error') is not None for c in cases),skipped=sum(c.find('skipped') is not None for c in cases))
assert u==dict(tests=722,failures=0,errors=0,skipped=0) and g==dict(tests=285,failures=0,errors=0,skipped=0)
manifest={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(files)}
s=dict(source=source,jars=stamp['jars'],unit=u,server=g,pairs=pairs,files=manifest,releaseAccepted=False,publication='Local only; no GitHub publication',scope='External vanilla transfer authority and actual generic physical module restart; full master v8, UFO modules/control and Dynamic Boarding remain open')
p=Path('docs/v8/EVIDENCE/module-restart-'+source[:7]+'.zip')
with zipfile.ZipFile(p,'x',zipfile.ZIP_DEFLATED) as z:
 for f in sorted(files):z.write(f,str(f))
 z.writestr('MANIFEST.json',json.dumps(s,indent=2))
with zipfile.ZipFile(p) as z:
 assert z.testzip() is None
 for f,h in manifest.items():assert hashlib.sha256(z.read(f)).hexdigest()==h
s['archive']=str(p);s['archiveSha256']=hashlib.sha256(p.read_bytes()).hexdigest()
Path('work/ufo-body/module-restart-summary.json').write_text(json.dumps(s,indent=2)+'\n')
print(json.dumps({k:v for k,v in s.items() if k!='files'},indent=2))
