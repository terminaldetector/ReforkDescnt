#!/usr/bin/env bash
set -euo pipefail
cd /workspace/ungravity-v5/ufo-body-physics
renderer="$1"
round="$2"
write_scenario="joints-state-write-${round}-${renderer}"
read_scenario="joint-state-read-${round}-${renderer}"
cp work/ufo-body/native/run-joint-state-write.sh "work/ufo-body/native/run-${write_scenario}.sh"
bash "work/ufo-body/native/run-${write_scenario}.sh" "$write_scenario"
mv "build/cubic-client-final-${write_scenario}" build/cubic-client-automation
mkdir build/cubic-client-automation/reload-proof
cp build/cubic-client-automation/inputs.json build/cubic-client-automation/reload-proof/write-inputs.json
cp build/cubic-client-automation/launch.json build/cubic-client-automation/reload-proof/write-launch.json
cp work/ufo-body/native/verified-build.json build/cubic-client-automation/reload-proof/verified-build.json
python3 - "$read_scenario" <<'PY'
from pathlib import Path
import json,hashlib,zipfile,sys,subprocess,re
r=Path('build/cubic-client-automation');files=sorted(p for p in (r/'saves').rglob('*') if p.is_file());hashes={str(p.relative_to(r/'saves')):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
p=r/'reload-proof/first-process-world.zip'
with zipfile.ZipFile(p,'x',zipfile.ZIP_DEFLATED) as z:
 for f in files:z.write(f,str(f.relative_to(r/'saves')))
with zipfile.ZipFile(p) as z:
 assert z.testzip() is None
 for name,h in hashes.items():assert hashlib.sha256(z.read(name)).hexdigest()==h
(r/'reload-proof/first-process-world.json').write_text(json.dumps(dict(scope='Closed actual writer world; no NBT insertion or replacement seed',files=hashes,sha256=hashlib.sha256(p.read_bytes()).hexdigest()),indent=2))
assert json.loads((r/'joint-state-saved.json').read_text())['actualSerializedBodies']==8
assert len(json.loads((r/'joint-state-ids.json').read_text()))==8
assert (r/'joint-state-registry.snbt').is_file()
p=r/'launch.json';a=json.loads(p.read_text());a=[v for v in a if not v.startswith(('-Ddrmd.gate.joints=','-Ddrmd.gate.jointsStateWrite=','-Ddrmd.gate.droneStateWrite='))];a.insert(1,'-Ddrmd.gate.jointsStateRead=true');p.write_text(json.dumps(a,indent=2))
p=r/'options.txt';s=p.read_text();s=re.sub(r'(?m)^renderDistance:.*$', 'renderDistance:6',s);p.write_text(s)
p=r/'inputs.json';a=json.loads(p.read_text());a['scenario']=sys.argv[1];a['sourceSha']=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();a['worldSource']='Exact closed writer world, full per-file hash and ZIP CRC verification before this reader; no replacement or NBT injection';p.write_text(json.dumps(a,indent=2))
PY
cp work/ufo-body/native/run-joint-state-read.sh "work/ufo-body/native/run-${read_scenario}.sh"
bash "work/ufo-body/native/run-${read_scenario}.sh" "$read_scenario"
