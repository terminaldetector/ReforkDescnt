from pathlib import Path
import json,hashlib,zipfile
root=Path.cwd();baseline=root/'work/cloud-production/internal-first-artifacts/drmd-6dof-1.1.35-ufo-dev.1.jar';candidate=root/'build/libs/drmd-6dof-1.1.35-ufo-dev.1.jar'
assert hashlib.sha256(baseline.read_bytes()).hexdigest()=='26b8d5538eb95db8d7ba7f70086a99c7dc7c240d00b6f89ad751c220c97b7f06'
def entries(path):
 with zipfile.ZipFile(path) as z:return {n:hashlib.sha256(z.read(n)).hexdigest() for n in z.namelist()}
a=entries(baseline);b=entries(candidate);changed=[n for n in sorted(set(a)|set(b)) if a.get(n)!=b.get(n)]
allowed={'assets/drmd/shaders/core/altitude_clouds.fsh','assets/drmd/shaders/core/altitude_clouds.json'}
def intended(n):return n in allowed or n.startswith('com/terminaldetector/drmd/client/cloud/AltitudeCloudPolicy') or n.startswith('com/terminaldetector/drmd/client/cloud/AltitudeCloudRenderer')
unexpected=[n for n in changed if not intended(n)];report={'scope':'Conditional strict-LESS ceiling differs from preserved26b8 only in policy/renderer record/uniform FSH+JSON; all other world/physics/HUD/LOD entries identical','baselineSha256':hashlib.sha256(baseline.read_bytes()).hexdigest(),'actualCandidateSha256':hashlib.sha256(candidate.read_bytes()).hexdigest(),'changedEntries':changed,'unexpectedChangedEntries':unexpected,'pass':bool(changed) and not unexpected}
Path('work/cloud-depth-ceiling/first-artifact-control.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2));assert report['pass']
