from pathlib import Path
import json,xml.etree.ElementTree as E
rows=[]
for p in Path('work/cloud-depth-ceiling/first-unit-xml').glob('*.xml'):
 r=E.parse(p).getroot();rows.append({'suite':r.attrib['name'],'tests':int(r.attrib['tests']),'failures':int(r.attrib['failures']),'errors':int(r.attrib['errors']),'skipped':int(r.attrib.get('skipped','0'))})
print(json.dumps(rows,indent=2));assert len(rows)==3 and sum(r['tests'] for r in rows)==18 and all(r['failures']==r['errors']==r['skipped']==0 for r in rows)
