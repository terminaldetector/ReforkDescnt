# Proposed bounded altitude-cloud correction after the valid49e9 prerequisite

This is a source-first implementation contract for review, not an implemented fix. `5ea9f1d` seals the actual complete Sodium occluder/depth prerequisite: all five controls pass, but clouds have zero contribution at512/2200/2200-roll90. Existing native cloud source geometry exists at those poses; the256far clip and vertical contribution to stock fog remove it. The main Horizon pass supplies no useful main-depth witness. The earlier e447 first-near geometry absence remains a separate unexplained result.

## Scope and ownership

Extend the current renderer with the original native cloud VBO/texture-derived geometry and cached Horizon VBO. Do not change generation, SurfaceIngest, colliders, physics, viewmodel/HUD, the selected presentation profile, main LOD colour/projection/depth ownership, intentional orbital/End layers or native cloud tessellation. No CPU copy/rebuild of either mesh and no synthetic cloud plane/background fill. The narrow production increment belongs in the isolated render tree; canonical integration remains root-owned.

Proposed files:

- New `client/cloud/AltitudeCloudPolicy.java`: pure bounded settings, altitude weight and original-depth mapping.
- New `client/cloud/AltitudeCloudRenderer.java` and `AltitudeCloudShaders.java`: copied main-view frame context, cloud scope and guarded existing-VBO dispatch.
- New `client/cloud/FarFieldOcclusionTarget.java`: one bounded private semantic target and a complete GL-state guard.
- `PlanetFloorRenderer`: register the cloud extension and submit the **already prepared** Horizon VBO to its semantic pass after the unchanged main colour draw. `HorizonVertexBuffer`: a separate shader-parameterized draw method over the same private buffer; the existing main draw stays unchanged.
- New GLSL150 `horizon_cloud_occlusion` and `altitude_clouds` programs/resources. Do not alter the current `horizon_world` colour shaders.
- New own main mixins for vanilla cloud scope, optional `@Pseudo` Sodium cloud scope and guarded `VertexBuffer.draw` dispatch; own entries in `drmd.mixins.json`. No Sodium imports/dependency or private Sodium fields.
- `DescentConfig`: additive serialized cloud settings with explicit missing-field defaults; new pure policy tests. Do not rewrite existing user values or Native/PS1 settings.

## Near path and continuous range/fog policy

Default extension enabled, transition start384and full512, maximum cloud ray distance4096blocks. Validate finite settings; bound range512–16384and require a nonempty transition. At cameraY≤384use the **original draw call, shader, projection and fog state without replacement or auxiliary work**. Thus224/384remain the existing native path. The presentation profile stays Native by default; the same world effect can operate inside the existing PS1 target.

Above384use smoothstep altitude weight through512. Change only the cloud draw's projection far coefficients, preserving its original X/Y/W and near-plane mapping. The new far limit continuously grows from the actual original far distance to configured reach. Keep the original source geometry, winding, alpha and cull policy. Derive camera-relative world coordinates from the actual cloud ModelView and copied inverse main-world view; this handles roll and actual cloud-model translation without assuming worldYis viewY.

At full weight, fog uses true horizontal distance rather than treating observer height as horizontal fog distance. Bound horizontal fog to the configured range and fade true radial contribution to zero from0.85×range to range. Blend fog behaviour continuously across384–512; retain the actual source colour/modulator/weather policy. The supported vanilla and Sodium cloud paths use POSITION_COLOR; maintain explicit stock fog-policy selection for their transition instead of assuming their fragment algorithms match. An unsupported shader/format uses a recorded original-path fallback, never a fabricated cloud; acceptance cases must report zero fallback.

Near-world depth remains in its current projection. The extended cloud fragment therefore writes **the original-projection depth**, computed from its actual view-space point and clamped to[0,1], while rasterizing with the extended far matrix. Far cloud pixels use depth1and still undergo the existing depth test/function/write-mask. Real foreground opaque world/hull depth stays smaller. This avoids comparing ordinary geometry against incompatible new-far depth and never disables the depth test.

## True far-LOD ray witness in the existing renderer

The main LOD pass remains exactly as measured: current compressed XY, colour/alpha, depth0.999999and depth writes disabled. Its separate semantic pass uses the **same cached VBO**, same actual FieldOriginDelta/InnerRadius/FieldReach, same world/projection matrices and source-opacity cutoff. It writes a private RG32Fattachment: true positive camera-ray distance and actual fragment opacity. A private24bitdepth attachment selects the nearest true source plane, with linearly normalized ray distance and depth writes enabled **only in that private FBO**.

Radial vertex compression preserves each vertex's bearing but can change interpolation weights. Do not call `length(interpolatedTrueEyeVector)` an exact pixel ray distance. Interpolated true source positions still lie on their source triangle plane. Reconstruct its normal from GLSL150derivatives, form the actual pixel-centre camera ray from inverse projection, and intersect that ray with the source plane:

```text
n = cross(dFdx(trueViewPosition), dFdy(trueViewPosition))
ray = normalize(unproject(actualPixelCentre))
t = dot(n, trueViewPosition) / dot(n, ray)
```

Reject degenerate/nonfinite/behind-camera values; use a bounded linear t/maxRayDistance hardware-depth encoding. Record both t and actual sourceOpacity×ColorModulator.a. The witness is generated by actual GPU source fragments, not inflated descriptor boxes or CPU forecast geometry.

At cloud time, sample the same pixel with nearest texel fetch. If a genuine visible far-source fragment is nearer than the cloud, discard that cloud fragment; otherwise retain its normal bounded fogged contribution. Preserve the existing ≥0.01visible-source cutoff. This is a conservative nearest-surface occlusion policy for the current fading LOD representation: even a partially faded foreground silhouette keeps its original pre-cloud colour, as required by the unchanged512control. It is not order-independent transparent-atmosphere integration. Behind-cloud landmarks must show actual cloud contribution, while nearer landmarks and physical world/body pixels keep the original RGB/depth bounds.

## Lifetime, targets and cleanup

Create at most one auxiliary target per main view, maximum8,388,608pixels and one additional draw of at most the existing160,000cached Horizon quads per frame. RG32F+depth storage is bounded to96MiB; no per-frame CPU mesh allocation/readback. At an oversized/unsupported target, record an explicit original-path fallback; do not silently shrink coverage. Release old storage on resize, resource reload, world switch and client stop.

Tag the witness with current main-frame epoch, world identity, camera/view/projection, owning Minecraft framebuffer and dimensions. Clear validity at every main-world frame start; publish only after successful semantic draw. Never consume a prior frame, prior resize, prior world or different-eye witness. If no Horizon was drawn this frame, represent it as a valid empty witness for that frame rather than reuse an old silhouette. A failed target creation is an explicit fallback.

Use the current Minecraft framebuffer dimensions, which already refer to the low-resolution scene during PS1 rendering. Fabulous may draw clouds into its own associated cloud FBO: allow that current view's actual cloud target with matching dimensions, while keeping the witness associated with its parent main/scene framebuffer. Do not resize/delete borrowed vanilla, Fabulous or outline targets. Preserve the accepted outline/overlay ordering.

Skip extension scope and semantic target updates while `OffscreenWorldView.busy()`; nested mirrors/portals retain their original cloud path and cannot overwrite or consume the outer eye's witness. Copy numeric context values only; retain no live Fabric context, matrix stack or frustum beyond its callback.

Guard auxiliary drawing and cloud dispatch with `try/finally`. Restore draw/read framebuffer, viewport/scissor, depth enable/function/mask, blend enable/functions, cull state, polygon mode, actual shader/program and RenderSystem shader/modulator, active texture unit, touched texture/sampler bindings and matrix state. Use fill rasterization only inside the private semantic target and restore the actual Debug polygon state. Keep a recursion guard around the one delegated VBO draw and restore it on exceptions; world-start cleanup clears stale scope metadata. Shader reload/partial allocation failure closes every owned object. No forced visibility, double main cloud draw or GL-state repair by drawing a background.

## Verification without changing the existing gates

First production compile/remap and pure policy tests, then the same actual five-pose/native gate:449real prefab cells, both FULL/readbacks/normal catalogue tuples, original camera/resolution/VBO/texture, stride4/domain≥500, near≥500changed, high≥5%, world/body≥9, LOD≥4eachorder, originalRGB/depth tolerances and192MiBreadback cap. Add bounded semantic ROI reads of the actual auxiliary distance/opacity to compare its true ray ordering with the retained source-triangle reference; no full auxiliary-image readback. Keep all original first negatives.

Require original shader/projection path at224/384; actual high cloud contribution at512/2200/roll90; correct near and far occlusion; restored FBO/viewport/pack/program/sampler state; no unsupported fallback. Preserve the first failure at every build/native boundary.

Repeat the same cloud gate on real vanilla/FabulousGL3.2/GLSL150and Sodium sequentially. Run the unchanged six-scene Native→PS1→Debug→resize→return presentation/mirror/outlined-mob/native-HUD/viewmodel regression and palette reference, on both backends with the same built artifacts. Those existing scenes are atY2200, so they exercise the new target lifetime through real profile changes. Root's current complete integration suite is separate and must be rerun after integration. No full atmosphere, hardware performance, volumetric weather, PS1 geometry/UV or overall-v8 completion is claimed by this increment.

## One pre-compile boundary clarification: focused-view reference altitude

The transition anchor is `MinecraftClient.gameRenderer.getCamera().getFocusedEntity().getY()`, invoked through the actual Minecraft `Entity`owner. This is the focused view entity's world-coordinate base/reference Y, not an assumed eye-height subtraction, player/fixture ID or forced camera follow. The actual384fixture has eyeY385.62; anchoring to its eye would accidentally alter the explicitly preserved384path. All ray/depth/fog/projection work still uses the actual camera eye and real matrices. Receipts record focused entity identity, referenceY, eyeY and selected weight. Missing/removed/wrong-world focus or nonfinite coordinates use an explicitly recorded original-renderer fallback.

In third person, the focus still supplies altitude while the actual offset camera supplies the rays. This is defined behaviour, not a new third-person acceptance claim; the first five-pose gate remains first person. Under local gravity the anchor remains worldYrather than silently becoming ship-local up; actual roll/pitch and camera displacement remain in matrices. No gravity/attachment changes or universal local-altitude interpretation are claimed. A pure reference-versus-eye boundary regression accompanies this clarification. The224/384poses, thresholds and original near shader/projection stay unchanged.

Before the first production gate, pin two added observer checks: actual auxiliary ray distance must agree with the nearest accepted source plane within0.5metre and opacity within0.01at the existing valid landmark masks; at least4behind-cloud landmark pixels must receive actual cloud contribution. These strengthen the existing criteria. Read only the existing semantic ROIs and charge8bytes/pixel to the unchanged8MiB/192MiBcaps. Record referenceY/eyeY/weight/focus status and require zero fallback plus original224/384shader and high512/2200/roll extension. Native colour readback is omitted only for an **actually observed all-false RGBA write mask** (e.g. a vanilla depth-only cloud pass); its actual geometry/state/draw/depth receipt remains. This removes an impossible-colour-change screenshot without dropping any colour-enabled pass or changing a pixel threshold, keeping vanilla multi-pass work inside the same readback budget.

After the separately sealed e2first control failure, observe private `VertexBuffer.drawInternal(Matrix4f,Matrix4f,ShaderProgram)`execution rather than its cancellable public request. [Actual named/runtime bytecode proof](CLOUD_DRAW_INTERNAL_API_2026-11-17.json) pins private29-byte named codeSHA256`36a8163a56eb2f5c4d330279d7f039565b1109a7d197af1dbc336e76a09ce18e`and actual runtime input`net.minecraft.class_291.method_34431(Matrix4f,Matrix4f,class_5944)`codeSHA256`5a9df21680e96a2ab938ce3741397c8304322e4c1e058644de6f5f79b46bbbfa`. Upload source is unchanged. Require matched actual buffer/shader/frame HEAD→RETURN; exceptions, pending calls at frame end/next frame or missing return never count as accepted draws. Retain the same high-shader assertion, so executing the original shader still rejects. Production remains byte-identical to game`26b8d5538eb95db8d7ba7f70086a99c7dc7c240d00b6f89ad751c220c97b7f06`; its17unit results remain the prior fresh proof, not a claimed new run. The next gate requires whole-game parity after the observer-only rebuild.

After the separately sealed f6actual strictLESSnegative (`f01e14d`), the high shader receives one `DepthCeiling`uniform selected from the **actual existing depth function**: greatest float below1forGL_LESS, exactly1otherwise (includingLEQUAL). Retain original-projection depth below that ceiling and change neither depth enable/function/write mask nor the224/384original path. Record the selected value with actual draw state. A new pure regression proves that old1failsLESSagainstsky1, the predecessor passes in float and24bitdepth, nearer opaque geometry still rejects the cloud, and LEQUAL/original near mapping remain unchanged. Rebuild this narrow production change with a fresh18case targeted suite and actual artifact diff against26b8before the unchanged native gate. The sameGPUwitness, masks,5%/500/4+4and pixel/depth tolerances apply.
