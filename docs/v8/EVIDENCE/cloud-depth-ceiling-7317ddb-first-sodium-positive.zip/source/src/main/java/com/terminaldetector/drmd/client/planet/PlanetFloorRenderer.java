package com.terminaldetector.drmd.client.planet;

import com.mojang.blaze3d.systems.RenderSystem;
import com.terminaldetector.drmd.client.config.DescentConfig;
import com.terminaldetector.drmd.world.level.WorldLevels;
import com.terminaldetector.drmd.world.planet.PlanetMap;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import org.joml.Matrix4f;

/**
 * The distant world, drawn as voxels: terrain past the chunk edge, and the things built on it.
 *
 * <p>Vanilla stops at the render distance and the projection stops at four times that, so from
 * altitude almost everything worth looking at is in neither. This draws it anyway, compressed
 * toward the eye by {@link HorizonProjection} — every point on its own sight line, so a coastline
 * lies in the direction the coastline really lies and a locator two kilometres out leaves the
 * silhouette it really would. Only depth is lost.
 *
 * <p>Height matters for when it runs. At sea level the map would sit next to real vanilla terrain
 * it does not match, hill for hill, right in front of the player. From the sky band up there is
 * nothing to compare it against and everything to gain: the ground reads as a map, which is what
 * it is. So it fades in across the climb out of the surface band and is fully on by the orbital.
 */
public final class PlanetFloorRenderer {
	/** Below this the real terrain owns the view; the map would only argue with it. */
	private static final double FADE_START = WorldLevels.SURFACE_TOP;
	/** Fully on by the top of the sky band. */
	private static final double FADE_FULL = WorldLevels.SKY_TOP;

	/** In the End there is no shared vertical, so the planet is placed at a chosen depth. */
	private static final double END_VIRTUAL_DROP = 900.0;

	private PlanetFloorRenderer() {}

	public static void register() {
		HorizonShader.register();
        com.terminaldetector.drmd.client.cloud.AltitudeCloudRenderer.register();
        WorldRenderEvents.BEFORE_ENTITIES.register(PlanetFloorRenderer::render);
	}

	private static void render(WorldRenderContext ctx) {
		if (!DescentConfig.hybridRender || !DescentConfig.planetFloor) return;
		// Not inside a mirror or portal view. That nested render moves the camera, and this callback
		// fires again within it — so the field was being rebuilt around the reflected eye and then drawn
		// from there, which is exactly the "horizon stuck to the camera" the second live session found.
		// The far world does not belong in a mirror anyway: it is the one thing a mirror cannot show
		// correctly, since the field is built for one eye.
		if (com.terminaldetector.drmd.client.portal.OffscreenWorldView.busy()) return;
		MinecraftClient mc = MinecraftClient.getInstance();
		if (mc.player == null || mc.world == null) return;
		if (!PlanetClientState.INSTANCE.hasSeed()) return;

		boolean endDim = mc.world.getRegistryKey() == World.END;
		boolean overworld = mc.world.getRegistryKey() == World.OVERWORLD;
		if (!endDim && !overworld) return;
		// DH owns actual distant Overworld terrain. The procedural map is an explicit fallback,
		// not another terrain layer to composite over the real LOD at altitude.
		if (overworld && !DescentConfig.planetFloorWithDistantHorizons && com.terminaldetector.drmd.world.compat.DistantHorizonsCompat.isPresent()) return;

		Vec3d cam = ctx.camera().getPos();
		float alpha = 1f;
		if (overworld) {
			double into = cam.y - FADE_START;
			if (into <= 0) return;
			alpha = (float) MathHelper.clamp(into / (FADE_FULL - FADE_START), 0.0, 1.0);
		}

		long seed = PlanetClientState.INSTANCE.seed();
		// In the column the eye is where it is and the map keeps the world's own heights. In the
		// End nothing ties the two verticals together, so the field is built for an eye hanging a
		// fixed distance above sea level and then hung under the camera wherever it is.
		double eyeY = endDim ? PlanetMap.SEA_LEVEL + END_VIRTUAL_DROP : cam.y;

		double viewBlocks = mc.options.getClampedViewDistance() * 16.0;
		double clip = viewBlocks * 4.0;
		// Blend toward the orbit-band share by the same alpha the map itself faded in by, so the
		// reach boost has no seam of its own — it grows in exactly as the map becomes visible.
		double clipUse = HorizonProjection.CLIP_USE
				+ (HorizonProjection.CLIP_USE_ORBIT - HorizonProjection.CLIP_USE) * alpha;
		double reach = clip * clipUse;
		double inner = innerRadius(endDim, viewBlocks, clip, eyeY, seed, cam);

		PlanetSurfaceMesh mesh = PlanetClientState.INSTANCE.mesh(cam.x, eyeY, cam.z, inner, reach);
		// Null for the first frames of a world: the field is built on drmd-horizon now, and this asks
		// for it rather than waiting. Drawing nothing for a frame or two is what buys never spending
		// 26ms of one — see PlanetClientState.mesh.
		if (mesh == null || mesh.quads == 0) return;

		// In 1.21 the object stack is local; positionMatrix is the terrain view, including camera rotation.
		Matrix4f mat = new Matrix4f(ctx.positionMatrix());
        // The shader receives source-space parallax and compresses around this frame's eye.
        // Translating already-compressed vertices was not the same projection and made the
        // terrain swing/crawl between rebuilds, especially during fast lateral flight.
        if(HorizonShader.program()==null) return;
        HorizonShader.position((float)(mesh.originX-cam.x),endDim?0f:(float)(mesh.originY-cam.y),
                (float)(mesh.originZ-cam.z),(float)inner,(float)reach);

		boolean write=org.lwjgl.opengl.GL11.glGetBoolean(org.lwjgl.opengl.GL11.GL_DEPTH_WRITEMASK);
        var previous=RenderSystem.getShader();
        RenderSystem.depthMask(false);
        RenderSystem.enableBlend();
		RenderSystem.defaultBlendFunc();
		RenderSystem.disableCull(); // skirts are single quads seen from either side
		RenderSystem.enableDepthTest();
        RenderSystem.setShader(HorizonShader::program);
		// The climb's fade as a uniform rather than per-vertex alpha, which is what lets the geometry
		// stay on the GPU across frames — see HorizonVertexBuffer. Each quad's own alpha is already
		// baked in there; this multiplies the whole field by how far the map has faded in.
		RenderSystem.setShaderColor(1f, 1f, 1f, alpha);

		if (HorizonVertexBuffer.prepare(mesh)) {
			HorizonVertexBuffer.draw(mat);
            com.terminaldetector.drmd.client.cloud.AltitudeCloudRenderer.captureFar(mesh,mat,
                    (float)(mesh.originX-cam.x),endDim?0f:(float)(mesh.originY-cam.y),
                    (float)(mesh.originZ-cam.z),(float)inner,(float)reach);
		}

		RenderSystem.setShaderColor(1f, 1f, 1f, 1f);
		RenderSystem.enableCull();
		RenderSystem.disableBlend();
        RenderSystem.depthMask(write);
        RenderSystem.setShader(()->previous);
	}

	/**
	 * Horizontal radius out to which the game is still drawing the real ground.
	 *
	 * <p>Two limits, whichever bites first: chunks are only sent within the view distance, and
	 * nothing is drawn past the far plane at all. From the band the ground is usually past the far
	 * plane already, which gives zero — the map owns the whole view down. From lower, or with a very
	 * long view distance, real terrain reaches further and the map starts outside it.
	 *
	 * <p>Whatever it comes to, the compression is the identity inside it, so the map's first cells
	 * are drawn at their true distance and continue the real ground rather than stepping off it.
	 */
	private static double innerRadius(boolean endDim, double viewBlocks, double clip,
									  double eyeY, long seed, Vec3d cam) {
		if (endDim) return 0.0; // no Overworld ground below the End to collide with
		double drop = eyeY - PlanetMap.height(seed, cam.x, cam.z);
		double byClip = clip * clip - drop * drop;
		if (byClip <= 0) return 0.0;
		return Math.min(viewBlocks, Math.sqrt(byClip));
	}
}
