package com.terminaldetector.drmd.gate;

import com.mojang.blaze3d.systems.RenderSystem;
import com.terminaldetector.drmd.client.planet.*;
import com.terminaldetector.drmd.client.portal.OffscreenWorldView;
import com.terminaldetector.drmd.gate.cloud.*;
import com.terminaldetector.drmd.gate.cloud.CloudOcclusionGeometry.Triangle;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.texture.NativeImage;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import org.lwjgl.opengl.*;
import java.nio.*;
import java.nio.file.*;
import java.util.*;

/** No world shader/state mutation: semantic true rays and real GPU before/after pixels only. */
public final class NativeCloudOcclusionCheck {
    public static final boolean ENABLED=Boolean.getBoolean("drmd.gate.cloudOcclusion");
    private static final int WIDTH=1536,HEIGHT=864,MAX_DEPTH_PIXELS=65536,MAX_RAY_TESTS=8_000_000;
    private record Depth(int[] roi,float[] values){float at(int x,int y){return values[(roi[3]-1-(y-roi[1]))*roi[2]+x-roi[0]];}}
    private record Quad(Triangle a,Triangle b,int colour,boolean marker){}
    private record ColourReference(int withMarker,int withoutMarker){}
    private record FarWitness(int[] roi,float[] values){float at(int x,int y,int channel){return values[((roi[3]-1-(y-roi[1]))*roi[2]+x-roi[0])*2+channel];}}
    private static final List<Triangle> CLOUDS=new ArrayList<>(),LANDMARK=new ArrayList<>();
    private static final Map<Integer,List<Triangle>> CLOUD_BINS=new HashMap<>();
    private static final Map<Integer,List<Quad>> HORIZON_BINS=new HashMap<>();
    private static final Map<String,Depth> DEPTHS=new LinkedHashMap<>();
    private static final Map<String,NativeImage> IMAGES=new LinkedHashMap<>();
    private static final Map<String,Object> STATE=new LinkedHashMap<>();
    private static BitSet cloudOpaque=new BitSet();
    private static List<Triangle> worldCube=List.of(),bodyCube=List.of();
    private static Matrix4f projection,view;
    private static float dx,dy,dz,inner,reach;
    private static PlanetSurfaceMesh lastMesh;
    private static boolean meshHasLandmark;
    private static int[] actualLandmarkSourceQuads=new int[2];
    private static int horizonDraws,rayTests,binReferences;
    private static float[] horizonColour;
    private static long witnessSourceBytes,witnessDepthBytes;
    private NativeCloudOcclusionCheck(){}
    private static boolean live(){return ENABLED&&NativeCloudAltitudeCheck.witnessActive()&&!OffscreenWorldView.busy();}
    private static boolean lodDiagnostic(){int p=NativeCloudAltitudeCheck.witnessPose();return p==2||p==3;}
    private static void require(boolean value,String reason){NativeCloudAltitudeCheck.witnessControl(value,reason);}
    public static void uniforms(float x,float y,float z,float radius,float fieldReach){if(ENABLED&&!OffscreenWorldView.busy()){dx=x;dy=y;dz=z;inner=radius;reach=fieldReach;}}
    public static boolean diagnosticActive(){return live();}
    public static int diagnosticEpoch(){return NativeCloudAltitudeCheck.witnessEpoch();}
    public static Path diagnosticFolder(){return folder();}
    public static void register(){if(ENABLED){WorldRenderEvents.BEFORE_ENTITIES.register(ctx->{if(live()){context(ctx.positionMatrix());diagnosticStage("BEFORE_ENTITIES",ctx);}});WorldRenderEvents.AFTER_ENTITIES.register(ctx->{if(live())diagnosticStage("AFTER_ENTITIES",ctx);});}}
    private static Map<String,Object> depthSummary(Depth data){int invalid=0,nonclear=0;float minimum=Float.POSITIVE_INFINITY,maximum=Float.NEGATIVE_INFINITY;for(float z:data.values){if(!Float.isFinite(z)){invalid++;continue;}minimum=Math.min(minimum,z);maximum=Math.max(maximum,z);if(z<.999995f)nonclear++;}return Map.of("roi",data.roi.clone(),"actualMinimum",Float.isFinite(minimum)?minimum:"UNOBSERVED finite depth","actualMaximum",Float.isFinite(maximum)?maximum:"UNOBSERVED finite depth","actualNonclearPixels",nonclear,"actualInvalidDepthPixels",invalid);}
    private static void diagnosticStage(String name,WorldRenderContext ctx){
        var before=CloudOcclusionDrawTrace.glState();var summary=new LinkedHashMap<String,Object>();
        for(String owner:List.of("world","body")){int[] roi=bounds(owner.equals("world")?worldCube:bodyCube);require((long)roi[2]*roi[3]<=4096,"bounded additional draw-diagnostic semantic ROI");var actual=depth(roi);DEPTHS.put("diagnostic-"+name+"-"+owner,actual);summary.put(owner,depthSummary(actual));}
        CloudOcclusionDrawTrace.stage(name,ctx,ctx.positionMatrix(),RenderSystem.getProjectionMatrix(),summary,before,CloudOcclusionDrawTrace.glState());
    }
    private static void context(Matrix4f actualView){
        view=new Matrix4f(actualView);projection=new Matrix4f(RenderSystem.getProjectionMatrix());var c=MinecraftClient.getInstance();var camera=c.gameRenderer.getCamera().getPos();
        worldCube=CloudOcclusionGeometry.box(eyeCorners(CloudOcclusionFixture.worldCorners(),camera),view);bodyCube=CloudOcclusionGeometry.box(eyeCorners(CloudOcclusionFixture.bodyCorners(c),camera),view);
    }
    public static boolean meshReady(){return meshHasLandmark;}
    private static boolean markerColour(int colour){int rgb=colour&0xFFFFFF;for(float shade:new float[]{1,.72f,.55f}){int expected=0;for(int shift:new int[]{16,8,0})expected|=(int)(((CloudOcclusionFixture.COLOUR>>shift)&255)*shade)<<shift;if(rgb==expected)return true;}return false;}
    public static void horizon(PlanetSurfaceMesh mesh,Matrix4f actualView,boolean before){
        if(!ENABLED||OffscreenWorldView.busy())return;
        if(before&&mesh!=lastMesh){lastMesh=mesh;actualLandmarkSourceQuads=new int[2];if(mesh!=null)for(int q=0;q<mesh.quads;q++)if((mesh.colours[q]>>>24)>2&&markerColour(mesh.colours[q])){double x=0,z=0;for(int v=0;v<4;v++){x+=mesh.positions[q*12+v*3];z+=mesh.positions[q*12+v*3+2];}int owner=CloudOcclusionFixture.landmarkSourceOwner(mesh.originX+x/4,mesh.originZ+z/4);if(owner>=0)actualLandmarkSourceQuads[owner]++;}meshHasLandmark=actualLandmarkSourceQuads[0]>=5&&actualLandmarkSourceQuads[1]>=5;}
        if(!live())return;
        if(before){
            horizonDraws++;require(horizonDraws==1,"one actual main-world Horizon draw per admitted frame");context(actualView);horizonColour=RenderSystem.getShaderColor().clone();
            LANDMARK.clear();HORIZON_BINS.clear();int references=0;
            for(int q=0;q<mesh.quads;q++){var points=new Vec3d[4];for(int j=0;j<4;j++){int at=q*12+j*3;points[j]=CloudOcclusionGeometry.point(view,new Vec3d(mesh.positions[at]+dx,mesh.positions[at+1]+dy,mesh.positions[at+2]+dz));}var a=new Triangle(points[0],points[1],points[2],mesh.colours[q]);var b=new Triangle(points[0],points[2],points[3],mesh.colours[q]);boolean marker=markerColour(mesh.colours[q]);if(marker){LANDMARK.add(a);LANDMARK.add(b);}if(lodDiagnostic()&&(mesh.colours[q]>>>24)>2){int[] roi=bounds(List.of(a,b));if(roi[2]==0||roi[3]==0)continue;var quad=new Quad(a,b,mesh.colours[q],marker);for(int y=roi[1]/32;y<=(roi[1]+roi[3]-1)/32;y++)for(int x=roi[0]/32;x<=(roi[0]+roi[2]-1)/32;x++){require(++references<=2_000_000,"bounded actual Horizon source spatial index");HORIZON_BINS.computeIfAbsent(y*(WIDTH/32)+x,k->new ArrayList<>()).add(quad);}}}
            STATE.put("horizonBefore",state());STATE.put("horizonProjection",projection.get(new float[16]));STATE.put("horizonView",view.get(new float[16]));STATE.put("fieldOriginDelta",List.of(dx,dy,dz));STATE.put("innerRadius",inner);STATE.put("fieldReach",reach);STATE.put("actualSourceQuads",mesh.quads);STATE.put("actualLandmarkTriangles",LANDMARK.size());STATE.put("actualMarkerSourceQuadsByRealObject",actualLandmarkSourceQuads.clone());STATE.put("sourceColourModulator",horizonColour);STATE.put("sourceQuadBinReferences",references);
            if(lodDiagnostic()){source(mesh);IMAGES.put("horizon-before",NativeCloudAltitudeCheck.witnessScreenshot());DEPTHS.put("landmark-before",depth(bounds(LANDMARK)));}
        }else if(lodDiagnostic()){
            STATE.put("horizonAfter",state());IMAGES.put("horizon-after",NativeCloudAltitudeCheck.witnessScreenshot());DEPTHS.put("landmark-after",depth(bounds(LANDMARK)));
        }
    }
    private static Vec3d[] eyeCorners(Vec3d[] corners,Vec3d camera){var result=new Vec3d[corners.length];for(int i=0;i<corners.length;i++)result[i]=corners[i].subtract(camera);return result;}
    public static void cloud(CloudFootprint.Mesh mesh,Matrix4f actualView,Matrix4f actualProjection,CloudFootprint.Fog fog,NativeImage texture,boolean cull,int mode,int front,boolean before){
        if(!live())return;require(projection!=null&&(!lodDiagnostic()||horizonDraws==1),"actual main-world view/required Horizon readiness before cloud");
        if(before){var triangles=CloudOcclusionGeometry.cloud(mesh,actualView);CLOUDS.addAll(triangles);for(var triangle:triangles){int[] roi=CloudOcclusionGeometry.bounds(List.of(triangle),actualProjection,WIDTH,HEIGHT);if(roi[2]==0||roi[3]==0)continue;for(int y=roi[1]/32;y<=(roi[1]+roi[3]-1)/32;y++)for(int x=roi[0]/32;x<=(roi[0]+roi[2]-1)/32;x++){require(++binReferences<=262144,"bounded actual source spatial index");CLOUD_BINS.computeIfAbsent(y*(WIDTH/32)+x,k->new ArrayList<>()).add(triangle);}}var projected=CloudFootprint.project(mesh,actualView,actualProjection,fog,texture,WIDTH,HEIGHT,1,cull,mode,front);cloudOpaque.or(projected.opaque());if(!DEPTHS.containsKey("world-before")){var stateBefore=CloudOcclusionDrawTrace.glState();DEPTHS.put("world-before",depth(bounds(worldCube)));DEPTHS.put("body-before",depth(bounds(bodyCube)));CloudOcclusionDrawTrace.stage("PRE_CLOUD",null,view,projection,Map.of("world",depthSummary(DEPTHS.get("world-before")),"body",depthSummary(DEPTHS.get("body-before"))),stateBefore,CloudOcclusionDrawTrace.glState());}}
        else{DEPTHS.put("world-after",depth(bounds(worldCube)));DEPTHS.put("body-after",depth(bounds(bodyCube)));}
    }
    private static int[] bounds(List<Triangle> triangles){return CloudOcclusionGeometry.bounds(triangles,projection,WIDTH,HEIGHT);}
    private static void source(PlanetSurfaceMesh mesh){
        require(mesh.quads<=131072,"bounded actual Horizon source quads");long bytes=4L+mesh.quads*52L;witnessSourceBytes+=bytes;require(witnessSourceBytes<=16L*1024*1024,"bounded actual Horizon source copy bytes");
        var data=ByteBuffer.allocate((int)bytes).order(ByteOrder.LITTLE_ENDIAN);data.putInt(mesh.quads);for(int q=0;q<mesh.quads;q++){data.putInt(mesh.colours[q]);for(int i=0;i<12;i++)data.putFloat(mesh.positions[q*12+i]);}
        try{Files.createDirectories(folder());Files.write(folder().resolve("actual-horizon-source.bin"),data.array());STATE.put("actualHorizonSourceSha256",HexFormat.of().formatHex(java.security.MessageDigest.getInstance("SHA-256").digest(data.array())));STATE.put("sourceCopyBytesTotal",witnessSourceBytes);STATE.put("sourceEncoding","Little-endian int quad count, then ARGB int +12float source positions per quad. Actual uploaded mesh; alpha<=.01quads omitted by production VertexBuffer.prepare.");}catch(java.io.IOException|java.security.NoSuchAlgorithmException failure){throw new IllegalStateException(failure);}
    }
    private static Map<String,Object> state(){int[] viewport=new int[4];GL11.glGetIntegerv(GL11.GL_VIEWPORT,viewport);return Map.of("framebuffer",GL11.glGetInteger(GL30.GL_DRAW_FRAMEBUFFER_BINDING),"viewport",viewport,"depthWrite",GL11.glGetBoolean(GL11.GL_DEPTH_WRITEMASK),"depthTest",GL11.glIsEnabled(GL11.GL_DEPTH_TEST),"depthFunction",GL11.glGetInteger(GL11.GL_DEPTH_FUNC),"scissor",GL11.glIsEnabled(GL11.GL_SCISSOR_TEST),"blend",GL11.glIsEnabled(GL11.GL_BLEND),"sourceRgbBlend",GL11.glGetInteger(GL14.GL_BLEND_SRC_RGB),"destinationRgbBlend",GL11.glGetInteger(GL14.GL_BLEND_DST_RGB),"framebufferSrgb",GL11.glIsEnabled(GL30.GL_FRAMEBUFFER_SRGB));}
    private static Depth depth(int[] roi){
        require(roi[2]>0&&roi[3]>0&&(long)roi[2]*roi[3]<=MAX_DEPTH_PIXELS,"bounded nonempty semantic depth ROI");int count=roi[2]*roi[3];witnessDepthBytes+=count*4L;require(witnessDepthBytes<=8L*1024*1024,"bounded cumulative semantic depth readback");NativeCloudAltitudeCheck.witnessReadback(count*4L);float[] values=new float[count];
        int prior=GL11.glGetInteger(GL30.GL_READ_FRAMEBUFFER_BINDING),packBuffer=GL11.glGetInteger(GL21.GL_PIXEL_PACK_BUFFER_BINDING);int[] packNames={GL11.GL_PACK_ALIGNMENT,GL11.GL_PACK_ROW_LENGTH,GL11.GL_PACK_SKIP_ROWS,GL11.GL_PACK_SKIP_PIXELS};int[] saved=new int[4];for(int i=0;i<4;i++){saved[i]=GL11.glGetInteger(packNames[i]);GL11.glPixelStorei(packNames[i],i==0?4:0);}
        try{GL15.glBindBuffer(GL21.GL_PIXEL_PACK_BUFFER,0);GL30.glBindFramebuffer(GL30.GL_READ_FRAMEBUFFER,MinecraftClient.getInstance().getFramebuffer().fbo);GL11.glReadPixels(roi[0],HEIGHT-roi[1]-roi[3],roi[2],roi[3],GL11.GL_DEPTH_COMPONENT,GL11.GL_FLOAT,values);return new Depth(roi.clone(),values);}finally{GL30.glBindFramebuffer(GL30.GL_READ_FRAMEBUFFER,prior);GL15.glBindBuffer(GL21.GL_PIXEL_PACK_BUFFER,packBuffer);for(int i=0;i<4;i++)GL11.glPixelStorei(packNames[i],saved[i]);}
    }
    private static FarWitness farWitness(int[] roi){
        var actual=com.terminaldetector.drmd.client.cloud.AltitudeCloudRenderer.stats();require(actual.valid()&&actual.hasFarSource()&&actual.width()==WIDTH&&actual.height()==HEIGHT&&actual.ownerMainFbo()==MinecraftClient.getInstance().getFramebuffer().fbo&&actual.fallbacks()==0,"actual same-view far witness available");
        int count=roi[2]*roi[3];require(count>0&&count<=MAX_DEPTH_PIXELS,"bounded actual far-witness ROI");witnessDepthBytes+=count*8L;require(witnessDepthBytes<=8L*1024*1024,"shared semantic ray/depth readback cap");NativeCloudAltitudeCheck.witnessReadback(count*8L);float[] values=new float[count*2];
        int read=GL11.glGetInteger(GL30.GL_READ_FRAMEBUFFER_BINDING),packBuffer=GL11.glGetInteger(GL21.GL_PIXEL_PACK_BUFFER_BINDING);int[] names={GL11.GL_PACK_ALIGNMENT,GL11.GL_PACK_ROW_LENGTH,GL11.GL_PACK_SKIP_ROWS,GL11.GL_PACK_SKIP_PIXELS},saved=new int[4];for(int i=0;i<4;i++){saved[i]=GL11.glGetInteger(names[i]);GL11.glPixelStorei(names[i],i==0?4:0);}
        try{GL15.glBindBuffer(GL21.GL_PIXEL_PACK_BUFFER,0);GL30.glBindFramebuffer(GL30.GL_READ_FRAMEBUFFER,actual.witnessFbo());GL11.glReadPixels(roi[0],HEIGHT-roi[1]-roi[3],roi[2],roi[3],GL30.GL_RG,GL11.GL_FLOAT,values);}finally{GL30.glBindFramebuffer(GL30.GL_READ_FRAMEBUFFER,read);GL15.glBindBuffer(GL21.GL_PIXEL_PACK_BUFFER,packBuffer);for(int i=0;i<4;i++)GL11.glPixelStorei(names[i],saved[i]);}
        var bytes=ByteBuffer.allocate(values.length*4).order(ByteOrder.LITTLE_ENDIAN);for(float value:values)bytes.putFloat(value);try{Files.write(folder().resolve("actual-far-ray-opacity.f32"),bytes.array());}catch(java.io.IOException failure){throw new IllegalStateException(failure);}STATE.put("actualFarWitnessAtRead",actual);return new FarWitness(roi,values);
    }
    private static double[] expectedFarWitness(Vec3d ray,int x,int y){double distance=Double.POSITIVE_INFINITY,opacity=0;for(var q:HORIZON_BINS.getOrDefault((y/32)*(WIDTH/32)+x/32,List.of())){double alpha=(q.colour>>>24)/255.0*horizonColour[3];if(alpha<.01)continue;budget(2);double hit=Math.min(CloudOcclusionGeometry.distance(ray,q.a,0),CloudOcclusionGeometry.distance(ray,q.b,0));if(hit<distance){distance=hit;opacity=alpha;}}return new double[]{distance,opacity};}
    private static int difference(int a,int b){int maximum=0;for(int s:new int[]{0,8,16})maximum=Math.max(maximum,Math.abs(((a>>s)&255)-((b>>s)&255)));return maximum;}
    private static void budget(int amount){require((long)rayTests+amount<=MAX_RAY_TESTS,"bounded actual source ray test budget");rayTests+=amount;}
    private static CloudOcclusionGeometry.Hit nearest(Vec3d ray,List<Triangle> triangles,double margin){budget(triangles.size());return CloudOcclusionGeometry.nearest(ray,triangles,margin);}
    private static CloudOcclusionGeometry.Hit cloudHit(Vec3d ray,int x,int y){return nearest(ray,CLOUD_BINS.getOrDefault((y/32)*(WIDTH/32)+x/32,List.of()),0);}
    private static int blend(int background,int argb){double alpha=(argb>>>24)/255.0*horizonColour[3];int out=0;for(int channel=0;channel<3;channel++){int sourceShift=16-channel*8,targetShift=channel*8;double source=((argb>>>sourceShift)&255)*horizonColour[channel],previous=(background>>>targetShift)&255;out|=((int)Math.round(source*alpha+previous*(1-alpha)))<<targetShift;}return out;}
    private static ColourReference colourReference(Vec3d ray,int x,int y,int background){
        int with=background,without=background;var quads=HORIZON_BINS.getOrDefault((y/32)*(WIDTH/32)+x/32,List.of());budget(quads.size()*2);
        for(var q:quads)if(Double.isFinite(CloudOcclusionGeometry.distance(ray,q.a,0))||Double.isFinite(CloudOcclusionGeometry.distance(ray,q.b,0))){with=blend(with,q.colour);if(!q.marker)without=blend(without,q.colour);}return new ColourReference(with,without);
    }
    private static boolean unambiguousOrder(Vec3d ray,int x,int y,double cloudDistance,boolean nearer){for(var q:HORIZON_BINS.getOrDefault((y/32)*(WIDTH/32)+x/32,List.of()))if(q.marker){budget(2);double distance=Math.min(CloudOcclusionGeometry.distance(ray,q.a,0),CloudOcclusionGeometry.distance(ray,q.b,0));if(!Double.isFinite(distance))continue;if(Math.abs(distance-cloudDistance)<=8||(distance<cloudDistance)!=nearer)return false;}return true;}
    private static Map<String,Object> foreground(String name,List<Triangle> triangles,NativeImage before,NativeImage after){
        var pre=DEPTHS.get(name+"-before");var post=DEPTHS.get(name+"-after");require(pre!=null&&post!=null,"actual near depth snapshots");int visible=0,changed=0,badDepth=0;var inv=new Matrix4f(projection).invert();int[] roi=bounds(triangles);var mask=new BitSet();var samples=new ArrayList<Map<String,Object>>();
        for(int y=roi[1];y<roi[1]+roi[3];y++)for(int x=roi[0];x<roi[0]+roi[2];x++){if(!cloudOpaque.get(y*WIDTH+x))continue;var ray=CloudOcclusionGeometry.ray(inv,x,y,WIDTH,HEIGHT);var hit=nearest(ray,triangles,.02);if(!Double.isFinite(hit.distance()))continue;var cloud=cloudHit(ray,x,y);if(!Double.isFinite(cloud.distance())||hit.distance()+8>=cloud.distance())continue;double expected=CloudOcclusionGeometry.depth(projection,ray,hit.distance());float actual=pre.at(x,y);if(!Float.isFinite(actual)||Math.abs(actual-expected)>.00001||actual>=.999995)continue;visible++;mask.set(y*WIDTH+x);if(difference(before.getColor(x,y),after.getColor(x,y))>4)changed++;if(!Float.isFinite(post.at(x,y))||Math.abs(post.at(x,y)-actual)>.00001)badDepth++;if(samples.size()<32)samples.add(Map.of("pixel",List.of(x,y),"trueOccluderDistance",hit.distance(),"trueCloudDistance",cloud.distance(),"expectedPhysicalDepth",expected,"actualBeforeDepth",actual,"actualAfterDepth",Float.isFinite(post.at(x,y))?post.at(x,y):"nonfinite","beforeAbgr",before.getColor(x,y),"afterAbgr",after.getColor(x,y)));}
        saveMask(name+"-visible.bits",mask);return Map.of("independentlyVisibleNativePixels",visible,"changedColourPixels",changed,"changedDepthPixels",badDepth,"minimumVisiblePixels",9,"pass",visible>=9&&changed==0&&badDepth==0,"roi",roi,"representativeActualSamples",samples);
    }
    private static Map<String,Object> landmark(NativeImage before,NativeImage after){
        var pre=IMAGES.get("horizon-before");var shown=IMAGES.get("horizon-after");var z0=DEPTHS.get("landmark-before");var z1=DEPTHS.get("landmark-after");require(pre!=null&&shown!=null&&z0!=null&&z1!=null,"actual Horizon before/after witness");
        int nearer=0,behind=0,nearerPainted=0,depthWrites=0,referenceMismatch=0,invalidDepth=0,behindChanged=0,witnessCompared=0,witnessMismatch=0;var nearMask=new BitSet();var behindMask=new BitSet();var inv=new Matrix4f(projection).invert();int[] roi=bounds(LANDMARK);var samples=new ArrayList<Map<String,Object>>();boolean production=Boolean.getBoolean("drmd.gate.cloudProduction");var witness=production?farWitness(roi):null;var witnessSamples=new ArrayList<Map<String,Object>>();
        for(int y=roi[1];y<roi[1]+roi[3];y++)for(int x=roi[0];x<roi[0]+roi[2];x++){if(!cloudOpaque.get(y*WIDTH+x))continue;var ray=CloudOcclusionGeometry.ray(inv,x,y,WIDTH,HEIGHT);var hit=nearest(ray,LANDMARK,.015);if(!Double.isFinite(hit.distance())||difference(pre.getColor(x,y),shown.getColor(x,y))<=8)continue;
            if(!Float.isFinite(z0.at(x,y))||!Float.isFinite(z1.at(x,y))){invalidDepth++;continue;}if(z0.at(x,y)<=.999999f)continue;var reference=colourReference(ray,x,y,pre.getColor(x,y));if(difference(reference.withMarker,shown.getColor(x,y))>8){referenceMismatch++;continue;}if(difference(reference.withMarker,reference.withoutMarker)<=8)continue;
            var cloud=cloudHit(ray,x,y);if(!Double.isFinite(cloud.distance())||Math.abs(hit.distance()-cloud.distance())<=8)continue;
            if(!unambiguousOrder(ray,x,y,cloud.distance(),hit.distance()<cloud.distance()))continue;
            if(witness!=null){var expected=expectedFarWitness(ray,x,y);float actualDistance=witness.at(x,y,0),actualOpacity=witness.at(x,y,1);witnessCompared++;boolean matches=Float.isFinite(actualDistance)&&Float.isFinite(actualOpacity)&&Math.abs(actualDistance-expected[0])<=.5&&Math.abs(actualOpacity-expected[1])<=.01;if(!matches)witnessMismatch++;if(witnessSamples.size()<64)witnessSamples.add(Map.of("pixel",List.of(x,y),"actualDistance",Float.isFinite(actualDistance)?actualDistance:"nonfinite","actualOpacity",Float.isFinite(actualOpacity)?actualOpacity:"nonfinite","expectedNearestSourceDistance",Double.isFinite(expected[0])?expected[0]:"unobserved","expectedSourceOpacity",expected[1],"agreement",matches));}
            if(Math.abs(z0.at(x,y)-z1.at(x,y))>.000001)depthWrites++;
            if(hit.distance()<cloud.distance()){nearer++;nearMask.set(y*WIDTH+x);if(difference(before.getColor(x,y),after.getColor(x,y))>4)nearerPainted++;}else{behind++;behindMask.set(y*WIDTH+x);if(difference(before.getColor(x,y),after.getColor(x,y))>4)behindChanged++;}
            if(samples.size()<64)samples.add(Map.of("pixel",List.of(x,y),"trueLandmarkDistance",hit.distance(),"trueCloudDistance",cloud.distance(),"landmarkNearer",hit.distance()<cloud.distance(),"mainDepthBeforeHorizon",z0.at(x,y),"mainDepthAfterHorizon",z1.at(x,y),"actualAfterHorizonAbgr",shown.getColor(x,y),"sourceReferenceWithMarkerAbgr",reference.withMarker,"sourceReferenceWithoutMarkerAbgr",reference.withoutMarker));
        }
        saveMask("landmark-nearer-cloud.bits",nearMask);saveMask("landmark-behind-cloud.bits",behindMask);var result=new LinkedHashMap<String,Object>();result.put("actualVisibleNearerPixels",nearer);result.put("actualVisibleBehindPixels",behind);result.put("nearerPaintedByCloud",nearerPainted);result.put("actualMainDepthChangedPixels",depthWrites);result.put("invalidDepthPixels",invalidDepth);result.put("minimumPixelsPerRayOrder",4);result.put("pass",nearer>=4&&behind>=4&&nearerPainted==0&&invalidDepth==0&&(!production||behindChanged>=4&&witnessCompared>=8&&witnessMismatch==0));result.put("mainDepthWitnessExists",depthWrites>0);result.put("roi",roi);result.put("sourceColourReferenceMismatches",referenceMismatch);result.put("representativeActualSamples",samples);if(production)result.put("actualAuxiliaryWitness",Map.of("comparedPixels",witnessCompared,"mismatches",witnessMismatch,"distanceToleranceMetres",.5,"opacityTolerance",.01,"behindCloudContributionPixels",behindChanged,"representativeActualSamples",witnessSamples));return result;
    }
    public static Map<String,Object> evaluate(NativeImage before,NativeImage after){
        require(live()&&before!=null&&after!=null&&projection!=null&&(!lodDiagnostic()||horizonDraws==1)&&!CLOUDS.isEmpty(),"real world/cloud witnesses ready");var result=new LinkedHashMap<String,Object>();result.put("fixture",CloudOcclusionFixture.status());result.put("world",foreground("world",worldCube,before,after));result.put("body",foreground("body",bodyCube,before,after));if(lodDiagnostic())result.put("landmark",landmark(before,after));result.put("actualHorizonState",new LinkedHashMap<>(STATE));result.put("denseOccluderStride",1);result.put("originalCloudStride",4);result.put("scheduledRayTriangleTestUpperBound",rayTests);result.put("maximumRayTriangleTests",MAX_RAY_TESTS);result.put("semanticDepthReadbackBytesTotal",witnessDepthBytes);result.put("horizonSourceBytesTotal",witnessSourceBytes);result.put("maskEncoding",Map.of("bitset","Java BitSet little-endian bytes, dense pixel row order","width",WIDTH,"height",HEIGHT,"depth","float32LE, GL bottom-to-top rows within each recorded top-left ROI","colours","NativeImage ABGR integers"));
        result.put("actualDrawStageDiagnostic",CloudOcclusionDrawTrace.summary());boolean pass=Boolean.TRUE.equals(((Map<?,?>)result.get("world")).get("pass"))&&Boolean.TRUE.equals(((Map<?,?>)result.get("body")).get("pass"))&&(!lodDiagnostic()||Boolean.TRUE.equals(((Map<?,?>)result.get("landmark")).get("pass")));result.put("occlusionControlPass",pass);if(!pass)result.put("diagnostic","Unknown/insufficient genuine occluder visibility or occlusion rejection; never inferred pass from zero cloud pixels");
        try{Files.createDirectories(folder());for(var e:IMAGES.entrySet())e.getValue().writeTo(folder().resolve(e.getKey()+".png"));for(var e:DEPTHS.entrySet()){var data=ByteBuffer.allocate(e.getValue().values.length*4).order(ByteOrder.LITTLE_ENDIAN);for(float value:e.getValue().values)data.putFloat(value);Files.write(folder().resolve(e.getKey()+"-depth.f32"),data.array());}Files.writeString(folder().resolve("occlusion.json"),new com.google.gson.Gson().toJson(result));}catch(java.io.IOException failure){throw new IllegalStateException(failure);}return result;
    }
    private static Path folder(){return MinecraftClient.getInstance().runDirectory.toPath().resolve("cloud-occlusion-frames/pose-"+NativeCloudAltitudeCheck.witnessPose());}
    private static void saveMask(String name,BitSet mask){try{Files.createDirectories(folder());Files.write(folder().resolve(name),mask.toByteArray());}catch(java.io.IOException failure){throw new IllegalStateException(failure);}}
    public static void savePartial(String reason){if(!ENABLED)return;try{Files.createDirectories(folder());for(var e:IMAGES.entrySet())e.getValue().writeTo(folder().resolve(e.getKey()+".png"));Files.writeString(folder().resolve("control-failure.json"),new com.google.gson.Gson().toJson(Map.of("reason",reason,"fixture",CloudOcclusionFixture.status(),"state",new LinkedHashMap<>(STATE),"rayTests",rayTests,"cloudBinReferences",binReferences,"actualDrawStageDiagnostic",CloudOcclusionDrawTrace.summary())));}catch(java.io.IOException failure){throw new IllegalStateException(failure);}}
    public static void clearFrame(){for(var image:IMAGES.values())image.close();IMAGES.clear();DEPTHS.clear();STATE.clear();LANDMARK.clear();CLOUDS.clear();CLOUD_BINS.clear();HORIZON_BINS.clear();cloudOpaque.clear();horizonDraws=rayTests=binReferences=0;projection=view=null;CloudOcclusionDrawTrace.clear();}
    public static void cleanup(){clearFrame();lastMesh=null;meshHasLandmark=false;actualLandmarkSourceQuads=new int[2];witnessSourceBytes=witnessDepthBytes=0;CloudOcclusionFixture.releaseWorldReference();}
}
