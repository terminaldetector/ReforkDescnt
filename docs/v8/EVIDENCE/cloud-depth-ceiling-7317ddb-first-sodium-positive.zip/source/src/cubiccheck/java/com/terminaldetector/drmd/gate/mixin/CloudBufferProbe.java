package com.terminaldetector.drmd.gate.mixin;
import com.terminaldetector.drmd.gate.NativeCloudAltitudeCheck;
import net.minecraft.client.gl.*;
import net.minecraft.client.render.BuiltBuffer;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(VertexBuffer.class)
public class CloudBufferProbe {
    @Inject(method="upload",at=@At("HEAD"))
    private void upload(BuiltBuffer source,CallbackInfo ci){if(NativeCloudAltitudeCheck.ENABLED)NativeCloudAltitudeCheck.upload((VertexBuffer)(Object)this,source);}
    @Inject(method="drawInternal(Lorg/joml/Matrix4f;Lorg/joml/Matrix4f;Lnet/minecraft/client/gl/ShaderProgram;)V",at=@At("HEAD"))
    private void before(Matrix4f view,Matrix4f projection,ShaderProgram shader,CallbackInfo ci){if(NativeCloudAltitudeCheck.ENABLED)NativeCloudAltitudeCheck.draw((VertexBuffer)(Object)this,view,projection,shader,true);}
    @Inject(method="drawInternal(Lorg/joml/Matrix4f;Lorg/joml/Matrix4f;Lnet/minecraft/client/gl/ShaderProgram;)V",at=@At("RETURN"))
    private void after(Matrix4f view,Matrix4f projection,ShaderProgram shader,CallbackInfo ci){if(NativeCloudAltitudeCheck.ENABLED)NativeCloudAltitudeCheck.draw((VertexBuffer)(Object)this,view,projection,shader,false);}
}
