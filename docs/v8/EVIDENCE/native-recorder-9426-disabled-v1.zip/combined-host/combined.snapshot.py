"""One separately leased historical9426 DISABLED control; never retries or runs capacity16."""
from datetime import datetime,timezone
import hashlib,json,os
from pathlib import Path
import shutil,subprocess,sys,time

ROOT=Path('/workspace/ungravity-v5/audit-next-20261109')
WORK=ROOT/'work/native-benchmark-recorder'
WRAPPER=WORK/'disabled-combined-v1'
RUN=WORK/'9426-disabled-v1'
STAGE=WORK/'9426-disabled-v1-stage'
RUNTIME=ROOT/'build/native-benchmark-9426/9426-disabled-v1/cubic-client-automation'
OBS=RUN/'closed-output-observer-v2'
HEAD='4d997e509f81b9cc3bf51853ee59bda8b2aa85eb'
SOURCE='9426a6549fc91abc8c7e060a2eef9f184742dc3d'
MIB=1024*1024
SEED=Path('/workspace/ungravity-v5/world/build/cubic-seed2-gate/gate-v5-cubic-fixed')
DONOR=Path('/workspace/ungravity-v5/ufo-body-physics/build/cubic-client-final-flight-body-current-phase-sodium/.fabric/remappedJars/minecraft-1.21.1-0.19.5/client-intermediary.jar')
FROZEN={
 str(WORK/'immutable_native_runner.py'):'1946e64f61de6d676f1cf4e09e519e59174fad3356de3eea56e13ed5ab56fc64',
 str(WORK/'control_contracts.py'):'870c65d6d708c77fceb5a432dd2dc56eb2448b187b2874380e5ab1f876d48dbb',
 str(WORK/'native_control_plan.py'):'8c3393d6be31c7d151260f2a28b577235b59fd937ac3ad6bd84d696639e06a04',
 str(WORK/'verify_candidate.py'):'eb0076d8bde37523a97345ff21b8842deafdaa1a182b96716a60c045532cc072',
 str(ROOT/'docs/v8/recorder-controls/observe_control.py'):'6352a0991733890e35dbd6c51985cd3601887778649d6fd4a47972b938032fc9',
 str(ROOT/'scripts/v5/prepare_cubic_client.py'):'8a0967489aedaa127c4f479b17aa19006607a26fe43c99ad9d3256a9a9e2e274',
 '/workspace/ungravity-v5/ufo-body-physics/work/ufo-body/native/prepare-with-verified-library-links.py':'d0e12e732e5f5270aea81c27032d7f6e8e4b2cdd57fecb2c7e9a98bc621204ce',
 str(ROOT/'build/libs/drmd-6dof-1.1.35-ufo-dev.1.jar'):'cf3701b529b21633a8a3e910e6755d006d97d6349e8938d7701c82671027138d',
 str(ROOT/'build/libs/drmd-6dof-1.1.35-ufo-dev.1-cubiccheck.jar'):'cb1056d89d1435a5211c5a1c1728934fde2caf92c3c85e28016e2c5ff4bce70a',
}

def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def require(value,message):
 if not value:raise ValueError(message)
def write(path,value):
 with path.open('x') as stream:
  json.dump(value,stream,indent=2);stream.write('\n');stream.flush();os.fsync(stream.fileno())
def seed_receipt():
 files={str(p.relative_to(SEED)):digest(p) for p in sorted(SEED.rglob('*')) if p.is_file() and p.name!='session.lock'}
 return dict(files=files,count=len(files),bytes=sum((SEED/p).stat().st_size for p in files),
             sha256=hashlib.sha256(json.dumps(files,sort_keys=True,separators=(',',':')).encode()).hexdigest())
def frozen():
 require(subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT).decode().strip()==HEAD,'Own docs-only HEAD changed')
 require(not subprocess.check_output(['git','diff','--name-only','HEAD'],cwd=ROOT),'Tracked source changed')
 for name,wanted in FROZEN.items():require(digest(Path(name))==wanted,'Frozen input changed: '+name)
 require(DONOR.is_file(),'Original closed-runtime derivative unavailable; do not reconstruct silently')
def usage():
 if not RUNTIME.exists():return dict(files=0,logical_bytes=0,private_allocated_bytes=0)
 rows=[p.stat() for p in RUNTIME.rglob('*') if p.is_file() and not p.is_symlink()]
 return dict(files=len(rows),logical_bytes=sum(s.st_size for s in rows),private_allocated_bytes=sum(s.st_blocks*512 for s in rows if s.st_nlink==1))
def run_helper(label,args):
 with (WRAPPER/(label+'.log')).open('x') as stream:
  result=subprocess.run(args,cwd=ROOT,stdout=stream,stderr=subprocess.STDOUT,env=os.environ.copy())
 write(WRAPPER/(label+'-exit.json'),dict(returncode=result.returncode,observed_at=datetime.now(timezone.utc).isoformat()))
 require(result.returncode==0,label+' failed; no retry')

def snapshot():
 require(not WRAPPER.exists(),'Fresh combined-wrapper snapshot required')
 frozen();seed=seed_receipt();WRAPPER.mkdir()
 path=WRAPPER/'combined.snapshot.py';path.write_bytes(Path(__file__).read_bytes());path.chmod(0o444)
 write(WRAPPER/'manifest.json',dict(wrapper_sha256=digest(path),host_head=HEAD,tested_java_source=SOURCE,
   frozen=FROZEN,seed=seed,donor_sha256=digest(DONOR),preflight_free_min_bytes=256*MIB,
   pre_java_free_min_bytes=160*MIB,pre_java_private_max_bytes=160*MIB,
   scope='ONE DISABLED historical recorder-component control; not latest canonical-game/performance/fullS16 acceptance'))
 (WRAPPER/'manifest.json').chmod(0o444)
 print(json.dumps({'wrapper':str(path),'sha256':digest(path),'manifest':str(WRAPPER/'manifest.json'),'source_only_snapshot':True}),flush=True)

def execute():
 require(os.environ.get('S16_JAVA_LEASE')=='granted','Separate root Java/native lease required')
 require(Path(__file__).resolve()==WRAPPER/'combined.snapshot.py','Execute exact copied host wrapper')
 manifest_path=WRAPPER/'manifest.json';manifest_raw=manifest_path.read_bytes();m=json.loads(manifest_raw)
 require(digest(Path(__file__))==m['wrapper_sha256'],'Actual host-wrapper bytes changed')
 require(not (WRAPPER/'preflight.json').exists(),'One attempt only; no automatic retries')
 observer=None;native_started=False;native_closed=False
 try:
  frozen();seed=seed_receipt();require(seed==m['seed'],'Seed bytes changed')
  require(digest(DONOR)==m['donor_sha256'],'Derivative donor bytes changed')
  require(not STAGE.exists() and not RUN.exists() and not RUNTIME.exists(),'Control is not fresh')
  free=shutil.disk_usage(ROOT).free;require(free>=m['preflight_free_min_bytes'],'Preflight free disk below256MiB; do not delete or stop anything')
  write(WRAPPER/'preflight.json',dict(free_bytes=free,seed_sha256=seed['sha256'],seed_bytes=seed['bytes'],frozen=FROZEN))
  run_helper('prepare-disabled',[sys.executable,str(WORK/'native_control_plan.py'),'prepare','disabled'])
  require(seed_receipt()==seed,'Seed changed during copying')
  frozen();private=usage();free=shutil.disk_usage(ROOT).free
  write(WRAPPER/'pre-java-disk.json',dict(free_bytes=free,**private))
  require(free>=m['pre_java_free_min_bytes'] and private['private_allocated_bytes']<=m['pre_java_private_max_bytes'],'PreJava disk cap failed; retain partial staging, no Java')
  run_helper('prepare-observer',[sys.executable,str(ROOT/'docs/v8/recorder-controls/observe_control.py'),'prepare',
      '--runner-manifest',str(RUN/'manifest.json'),'--case','disabled','--out',str(OBS)])
  with (WRAPPER/'observer-host.log').open('x') as observer_log:
   observer=subprocess.Popen([sys.executable,str(OBS/'observer.snapshot.py'),'watch','--config',str(OBS/'observer-inputs.json')],cwd=ROOT,stdout=observer_log,stderr=subprocess.STDOUT)
   deadline=time.monotonic()+10
   while not (OBS/'ready.json').exists():
    require(observer.poll() is None and time.monotonic()<deadline,'Observer not ready before native start')
    time.sleep(.1)
   ready=json.loads((OBS/'ready.json').read_text());require(ready['observer_sha256']==FROZEN[str(ROOT/'docs/v8/recorder-controls/observe_control.py')],'Wrong copied observer')
   require(shutil.disk_usage(ROOT).free>=m['pre_java_free_min_bytes'],'Free disk fell before native start')
   native_started=True
   with (WRAPPER/'native-host.log').open('x') as log:
    native=subprocess.Popen([sys.executable,str(RUN/'runner.snapshot.py'),'execute','--manifest',str(RUN/'manifest.json')],cwd=ROOT,stdout=log,stderr=subprocess.STDOUT)
    native_code=native.wait();native_closed=True
   write(WRAPPER/'native-host-exit.json',dict(returncode=native_code,observed_at=datetime.now(timezone.utc).isoformat()))
   child_path=RUN/'child-exit.json';child=json.loads(child_path.read_text()) if child_path.exists() else None
   write(WRAPPER/'first-native-close.json',dict(host_returncode=native_code,actual_child_exit=child,native_exit_unknown=child is None,
       observed_at=datetime.now(timezone.utc).isoformat()))
   print('FIRST_DISABLED_NATIVE_CLOSE '+json.dumps(dict(host_returncode=native_code,child=child)),flush=True)
   require(native_code==0 and child is not None and child['returncode']==0 and not child['timed_out'] and not child['forced_kill'],'First native control failed/exit unknown; no retry')
   observer_code=observer.wait(timeout=15)
   write(WRAPPER/'observer-host-exit.json',dict(returncode=observer_code,observed_at=datetime.now(timezone.utc).isoformat()))
   require(observer_code==0,'External observer failed; preserve native result separately')
  run_helper('verify-disabled',[sys.executable,str(WORK/'native_control_plan.py'),'verify','disabled'])
  outcome=json.loads((OBS/'observer-outcome.json').read_text())
  require(outcome['status']=='PASS_DISABLED_ZERO_EMISSION','No actual zero-emission observer result')
  frozen();require(digest(Path(__file__))==m['wrapper_sha256'] and manifest_path.read_bytes()==manifest_raw,'Host execution inputs changed')
  write(WRAPPER/'outcome.json',dict(status='PASS_DISABLED_COMPONENT_CONTROL',tested_java_source=SOURCE,host_head=HEAD,
      child_exit=child,zero_emission=outcome,post_close_disk=dict(free_bytes=shutil.disk_usage(ROOT).free,**usage()),
      performance_accepted=False,full_s16_accepted=False,release_accepted=False,capacity_control_run=False))
 except Exception as error:
  write(WRAPPER/'first-failure.json',dict(error=repr(error),native_started=native_started,native_host_closed=native_closed,
      actual_child_exit_path=str(RUN/'child-exit.json'),observed_at=datetime.now(timezone.utc).isoformat(),retry_performed=False))
  raise
 finally:
  # This may stop the Python observer only. Never terminate the native runner or Java.
  if observer is not None and observer.poll() is None and (not native_started or native_closed):
   observer.terminate()
   try:observer.wait(timeout=5)
   except subprocess.TimeoutExpired:observer.kill();observer.wait()

if __name__=='__main__':
 os.chdir(ROOT);require(sys.argv[1:] in (['snapshot'],['execute']),'Unsupported action')
 if sys.argv[1]=='snapshot':snapshot()
 else:execute()
