# Cloud attribution: stable viewer admission

This observer-only refinement follows the preserved actual `1704bad` control failure in [CLOUD_ATTRIBUTION_CONTROL_2026-11-17.md](CLOUD_ATTRIBUTION_CONTROL_2026-11-17.md). That run did not admit even the first pose: genuine lower-layer 6DoF idle sinking moved the player from requested Y224 to Y170.48570809126176. It provides no cloud-visibility or fog attribution verdict.

The next first actual cloud attribution keeps the original five player heights, fixed texture-derived X/Z, downward view, original stock texture/cloud wind, FANCY clouds, Native presentation and all enabled sky/LOD layers. Only viewer admission changes:

- At Y224, Y384 and Y512, the server uses the existing `FlightSystem.disable` path and ordinary Creative flight abilities. The real abilities packet and flight-state sync must reach the client. Both sides must report 6DoF off, flight permission on and Creative hovering on; client yaw0/pitch90 is required.
- At Y2200 and Y2200+roll90, the existing genuine 6DoF path stays enabled in the END layer. Both sides must report 6DoF on and Creative flight/permission off. The real attitude must agree with the requested forward/up vectors to the existing dot threshold0.999.
- Each pose receives one ordinary server teleport and one initial velocity reset. There is no repeated teleport, per-tick velocity override, changed world gravity or direct camera-follow. After admission, stability comes from the ordinary Creative or existing END flight path.
- Client and server X/Y/Z must independently stay within the original0.02 tolerance of the requested pose. The existing minimum8client ticks, actual client/server cubic volume readiness and closed-screen prerequisites remain required.

Every admitted pose, and any later admission timeout, records actual client/server coordinates, velocities, yaw/pitch, 6DoF state, flight abilities and gravity flags. Cloud draw records retain their actual camera position, view/projection matrices, FBO/viewport, clipping/fog/depth state and original VBO source. The original contract and prior failures stay immutable.

No production renderer, cloud shader, physics, configuration or geometry changes accompany this fixture refinement. The actual build must reproduce the accepted palette game JAR `b6c653a4729e7dd4a8158ba1b8704fc31434c89d0c7cabaefbee4e1266d3df8c`. The source/readback/event budgets, five-pose preservation and fixed visibility criteria remain unchanged: at least500valid source-footprint samples per pose, at least500actual changed-cloud samples near, at least5%actual changed-cloud samples at each higher/rolled pose, GL0 and the actual full main target. Missing draw/source/readiness is a diagnostic failure, not evidence that clouds are absent.

This document records the next observer contract before its first compilation/native attempt. It records no new passing or cloud-negative result.
