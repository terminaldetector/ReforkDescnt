#!/usr/bin/env python3
import hashlib,json,os,shutil,subprocess,sys,time
from pathlib import Path

root=Path('/workspace/ungravity-v5/ufo-body-physics');os.chdir(root)
source='ed458a8b0ceaaa06b6ec153d2c051e7dcb1b6c5c'
head=lambda:subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert head()==source and not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'])
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
out=root/'work/multi-agent/integrated-ed458a8/native-first';out.mkdir(exist_ok=False)
helpers=['scripts/v8/ps1_native.sh','scripts/v8/ps1_prepare.py','scripts/v8/ps1_build_stamp.py','scripts/v5/prepare_cubic_client.py']
before={p:sha(root/p) for p in helpers}
for name in helpers:
 p=out/'helpers'/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(root/name,p)
shutil.copyfile(__file__,out/'executing-runner.py')
stamp=json.loads((root/'work/ps1/verified-build.json').read_text());assert stamp['sourceSha']==source
assert all(sha(root/p)==h for p,h in stamp['jars'].items())
scenario='ps1-color-integrated-ed458a8-sodium'
cmd=['bash','scripts/v8/ps1_native.sh',scenario]
(out/'before.json').write_text(json.dumps({'source':source,'startNs':time.time_ns(),'command':cmd,'helperHashes':before,'jars':stamp['jars']},indent=2)+'\n')
with (out/'native.log').open('xb') as log:child=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
(out/'child.exit').write_text(str(child.returncode)+'\n')
(out/'early-close.json').write_text(json.dumps({'childExit':child.returncode,'endNs':time.time_ns()})+'\n')
runtime=root/f'build/cubic-client-final-{scenario}'
if not runtime.is_dir():runtime=root/'build/cubic-client-automation'
markers={}
for name in ['inputs.json','launch.json','presentation-ok.json','ps1-color-ok.json','viewmodel-proof/viewmodel-visibility.json']:
 p=runtime/name
 if p.is_file():
  target=out/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,target)
  markers[name]=json.loads(p.read_text())
receipt={'source':source,'endSource':head(),'childExit':child.returncode,'runtime':str(runtime),'helpersUnchanged':all(sha(root/p)==h for p,h in before.items()),'jarsUnchanged':all(sha(root/p)==h for p,h in stamp['jars'].items()),'pngCount':len(list(runtime.rglob('*.png'))),'markers':list(markers)}
receipt['gatePassed']=child.returncode==0 and receipt['endSource']==source and receipt['helpersUnchanged'] and receipt['jarsUnchanged'] and all(k in markers for k in ('presentation-ok.json','ps1-color-ok.json','viewmodel-proof/viewmodel-visibility.json'))
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
code=0 if receipt['gatePassed'] else child.returncode or 1
(out/'wrapper.exit').write_text(str(code)+'\n');print(json.dumps(receipt,indent=2),flush=True);sys.exit(code)
