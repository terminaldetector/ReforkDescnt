#!/usr/bin/env bash
set -euo pipefail
cd /workspace/ungravity-v5/ufo-body-physics
export JAVA_HOME=/workspace/jdk21-complete PATH=/workspace/jdk21-complete/bin:$PATH GRADLE_USER_HOME=/workspace/.gradle
python3 work/ufo-body/native/verify-build-stamp.py check
./gradlew processGametestResources --rerun-tasks --no-daemon --offline > work/ufo-ai/restore-full-manifest.log 2>&1
python3 - <<'PY'
import json,pathlib
assert json.loads(pathlib.Path('build/resources/gametest/fabric.mod.json').read_text())['entrypoints']==json.loads(pathlib.Path('src/gametest/resources/fabric.mod.json').read_text())['entrypoints']
PY
./gradlew test runGametest --no-daemon --offline -I work/ufo-body/engine-final-force-test.init.gradle > work/ufo-ai/full-regressions.log 2>&1
python3 work/ufo-body/native/verify-build-stamp.py check
