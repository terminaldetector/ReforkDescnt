from pathlib import Path
import hashlib,json,subprocess,zipfile,xml.etree.ElementTree as E

root=Path.cwd();base='19bb10f';source=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
subprocess.run(['python3','work/ufo-body/native/verify-build-stamp.py','check'],check=True)
stamp=json.loads(Path('work/ufo-body/native/verified-build.json').read_text());files=set()
def add(p):
 p=Path(p);assert p.is_file(),p;files.add(p)
def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def results(path):
 c=list(E.parse(path).iter('testcase'));return dict(tests=len(c),failures=sum(t.find('failure') is not None for t in c),errors=sum(t.find('error') is not None for t in c),skipped=sum(t.find('skipped') is not None for t in c))
assert not subprocess.check_output(['git','diff','--name-only','HEAD','--','src','build.gradle','gradle.properties','settings.gradle'],text=True).strip()
for n in subprocess.check_output(['git','diff','--name-only',base,source,'--','src'],text=True).splitlines():add(n)
for n,h in stamp['jars'].items():assert digest(n)==h;add(n)
for n in ['build.gradle','gradle.properties','settings.gradle','src/gametest/resources/fabric.mod.json','build/resources/gametest/fabric.mod.json','build/gametest/reports/gametest-results.xml','work/ufo-body/native/verified-build.json','work/ufo-body/native/verified-build.log','work/ufo-body/native/build-verified.sh','work/ufo-body/native/verify-build-stamp.py','work/ufo-body/native/prepare-with-verified-library-links.py','work/ufo-body/native/dedup-staged-libraries.py','work/ufo-body/native/seed-verified-minecraft-remap.py','work/ufo-body/engine-final-force-test.init.gradle','scripts/v5/prepare_cubic_client.py']:add(n)
for p in Path('work/ufo-ai').glob('*'):
 if p.is_file() and p.suffix in ['.py','.sh','.log','.xml','.json','.gradle','.txt']:add(p)
for n in ['source.patch','source-series.patch','source.json']:add(Path('work/ufo-ai')/n)
rs=[E.parse(p).getroot() for p in Path('build/test-results/test').glob('TEST-*.xml')]
unit={k:sum(int(r.get(k,0)) for r in rs) for k in ['tests','failures','errors','skipped']}
server=results('build/gametest/reports/gametest-results.xml');focus=results('work/ufo-ai/mount-choice-fixed-focus.xml')
assert unit==dict(tests=743,failures=0,errors=0,skipped=0),unit
assert server==dict(tests=335,failures=0,errors=0,skipped=0),server
assert focus==dict(tests=15,failures=0,errors=0,skipped=0),focus
assert results('work/ufo-ai/grounded-lead-direction-negative.xml')==dict(tests=13,failures=1,errors=0,skipped=0)
assert 'BUILD SUCCESSFUL' in Path('work/ufo-ai/full-regressions.log').read_text()
full=json.loads(Path('work/ufo-ai/full-server-build.json').read_text());assert full['source']==source and full['inputs']==stamp['inputs'] and full['jars']==stamp['jars']
assert results('work/ufo-ai/mount-choice-negative.xml')==dict(tests=15,failures=1,errors=0,skipped=0)
src=json.loads(Path('src/gametest/resources/fabric.mod.json').read_text())['entrypoints'];built=json.loads(Path('build/resources/gametest/fabric.mod.json').read_text())['entrypoints'];assert src==built and len(src['fabric-gametest'])==56
for p in Path('build/test-results/test').glob('TEST-*.xml'):add(p)
native={}
for renderer in ['sodium','gl32']:
 name='autonomous-ufo-visible-'+renderer;r=Path('build/cubic-client-final-'+name);i=json.loads((r/'inputs.json').read_text());assert i['sourceSha']==source and not i['uncommittedDiff']
 assert not list((r/'crash-reports').glob('*.txt'))
 for n in ['inputs.json','launch.json','ufo-ai-ok.json']:add(r/n)
 seen=set()
 for a in i['artifacts']:
  if a.get('source') in stamp['jars']:assert a['sha256']==stamp['jars'][a['source']]==digest(r/a['path']);seen.add(a['source'])
 assert seen==set(stamp['jars'])
 for ext in ['.log','.exit']:add('work/ufo-body/native/final-'+name+ext)
 assert Path('work/ufo-body/native/final-'+name+'.exit').read_text().strip()=='0'
 log=Path('work/ufo-body/native/final-'+name+'.log').read_text();assert 'All dimensions are saved' in log and 'UFO autonomous:' not in log
 m=json.loads((r/'ufo-ai-ok.json').read_text())
 for k in ['actualDefaultHull','naturalSurvivalTarget','noAssignedTarget','noScriptedShots','realPhysicalOwner']:assert m[k],(renderer,k)
 assert m['lasers']>=3 and m['rockets']>=1 and m['actualDamagingHits']>0 and m['bestAimDot']>m['initialAimDot']+.1
 assert m['muzzleError']<1e-8 and m['launchVelocityError']<1e-8 and m['disabledTicks']>=24 and m['disabledInertialTravel']>.01
 assert m['actualProjectedShotPixels']>=3 and m['ownedShotRenderCalls']>0 and m['height']==2156 and m['targetFixtureMaxHealth']==200
 images=list((r/'ufo-ai-frames').glob('*.png'));assert len(images)==4 and len(m['scenes'])==4
 for p in images:add(p)
 native[renderer]=m
# Rejected live rounds and their exact staged game/observer bytes remain distinct.
for r in Path('build').glob('cubic-client-rejected-autonomous-ufo-*'):
 for pattern in ['inputs.json','launch.json','crash-reports/*.txt','ufo-ai-frames/*.png','mods/drmd-*.jar']:
  for p in r.glob(pattern):add(p)
for p in Path('work/ufo-body/native').glob('final-autonomous-ufo-*'):
 if p.is_file() and p.suffix in ['.log','.exit']:add(p)
for p in Path('work/ufo-body').glob('ufo-ai-*-world.zip'):add(p)
for p in Path('work/preserved-disposable-worlds').glob('*ufo-ai*.zip.json'):add(p)
for p in Path('work/preserved-disposable-worlds').glob('cubic-client-rejected-autonomous-ufo-*-saves.zip*'):add(p)
# The living-pilot path also gets a fresh actual-world writer/reader regression.
name='flight-body-control-turret-restart-read-ufo-ai-sodium';r=Path('build/cubic-client-final-'+name)
writer=json.loads((r/'reload-proof/write-inputs.json').read_text());reader=json.loads((r/'inputs.json').read_text());assert writer['sourceSha']==reader['sourceSha']==source
for info in [writer,reader]:
 assert not info['uncommittedDiff']
 seen=set()
 for a in info['artifacts']:
  if a.get('source') in stamp['jars']:assert a['sha256']==stamp['jars'][a['source']]==digest(r/a['path']);seen.add(a['source'])
 assert seen==set(stamp['jars'])
for suffix in ['write','read']:
 name='flight-body-control-turret-restart-'+suffix+'-ufo-ai-sodium'
 for ext in ['.log','.exit']:add('work/ufo-body/native/final-'+name+ext)
 assert Path('work/ufo-body/native/final-'+name+'.exit').read_text().strip()=='0'
 assert 'All dimensions are saved' in Path('work/ufo-body/native/final-'+name+'.log').read_text()
for pattern in ['*.json','*.snbt','*.png','process-pid.txt','reload-proof/*','flight-body-frames/*.png','turret-restart-frames/*.png']:
 for p in r.glob(pattern):
  if p.is_file():add(p)
pids=json.loads((r/'reload-proof/processes.json').read_text());m=json.loads((r/'turret-restart-ok.json').read_text());walking=json.loads((r/'ufo-reload-ok.json').read_text());w=json.loads((r/'turret-restart-write-ok.json').read_text())
assert pids['distinctProcesses'] and pids['writerPid']!=pids['readerPid']
assert 0<w['laserCooldown']<=8 and 0<w['rocketCooldown']<=24
for k in ['actualTwoProcessRestart','rootExact','headExact','registryExact','noDuplicates','postLoadControlRelease','actualHeadProjectionVerified']:assert m[k],k
assert m['lasers']>=3 and m['rockets']>=1 and m['restoredCarrierOwnerSamples']>=40 and m['maxAnchorError']<.03 and m['muzzleError']<1e-8 and m['launchVelocityError']<1e-8 and m['brakedRelativeSpeed']<.08 and m['relativeAngle']>.25
assert walking['postLoadWalking'] and walking['restoredWalkingTicks']>=40 and walking['postLoadDistance']>.3
snap=json.loads((r/'reload-proof/first-process-world.json').read_text());archive=r/'reload-proof/first-process-world.zip';assert digest(archive)==snap['sha256']
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for n,h in snap['files'].items():assert hashlib.sha256(z.read(n)).hexdigest()==h
for n in ['run-turret-restart-pair.sh','run-turret-restart-write.sh','run-turret-restart-read.sh']:add('work/ufo-body/native/'+n)
summary=dict(source=source,productionSource=source,base=base,jars=stamp['jars'],unit=unit,server=server,focused=focus,native=native,pilotRestart=dict(writer=w,reader=m,walking=walking,processes=pids),releaseAccepted=False,publication='Local only',scope='Reference-UFO autonomous rigid batteries and actual nonliving weapon ownership. Full 3D AI, child-turret AI, pitch/compound modules, energy/ammunition economy and full master v8 remain open.',files={str(p):digest(p) for p in sorted(files)})
out=Path('docs/v8/EVIDENCE/ufo-autonomous-'+source[:7]+'.zip')
with zipfile.ZipFile(out,'x',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(files):z.write(p,str(p))
 z.writestr('MANIFEST.json',json.dumps(summary,indent=2))
with zipfile.ZipFile(out) as z:
 assert z.testzip() is None
 for n,h in summary['files'].items():assert hashlib.sha256(z.read(n)).hexdigest()==h
summary.update(archive=str(out),archiveSha256=digest(out));Path('work/ufo-ai/summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps({k:v for k,v in summary.items() if k!='files'},indent=2))
