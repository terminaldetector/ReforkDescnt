from pathlib import Path
import zipfile,zlib,struct,json,io
class Nbt:
 def __init__(self,b):self.f=io.BytesIO(b)
 def num(self,t):return struct.unpack('>'+t,self.f.read(struct.calcsize('>'+t)))[0]
 def string(self):return self.f.read(self.num('H')).decode('utf-8')
 def tag(self,t):
  if t in [1,2,3,4,5,6]:return self.num({1:'b',2:'h',3:'i',4:'q',5:'f',6:'d'}[t])
  if t==7:return list(self.f.read(self.num('i')))
  if t==8:return self.string()
  if t==9:
   kind=self.num('b');n=self.num('i');return [self.tag(kind) for _ in range(n)]
  if t==10:
   d={}
   while True:
    kind=self.num('b')
    if kind==0:return d
    name=self.string();d[name]=self.tag(kind)
  if t in [11,12]:return [self.num('i' if t==11 else 'q') for _ in range(self.num('i'))]
  raise ValueError(t)
 def root(self):t=self.num('b');self.string();return self.tag(t)
root=Path('work/preserved-disposable-worlds/cubic-client-rejected-autonomous-ufo-durable-sodium-saves.zip');out=[]
with zipfile.ZipFile(root) as z:
 for name in z.namelist():
  if '/entities/' not in name or not name.endswith('.mca'):continue
  b=z.read(name)
  for i in range(1024):
   offset=int.from_bytes(b[i*4:i*4+3],'big')*4096
   if not offset:continue
   size=int.from_bytes(b[offset:offset+4],'big');kind=b[offset+4];data=b[offset+5:offset+4+size]
   raw=zlib.decompress(data) if kind==2 else data
   n=Nbt(raw).root();out.extend(n.get('Entities',[]))
Path('work/ufo-ai/durable-saved-entities.json').write_text(json.dumps(out,indent=2)+'\n')
for e in out:
 if 'ufo' in e.get('id',''):
  print('ROOT',e['id'],e['Pos'], 'CD',e.get('laserCooldown'),e.get('rocketCooldown'));print('shape keys',e['shape'].keys());print('weapons',[(c) for c in e['shape'].get('cells',[]) if any('ship_laser' in str(c) or 'ship_rocket' in str(c) for _ in [0])]);print('physical',e['body']);print('shape first',str(e['shape'])[:1400])
