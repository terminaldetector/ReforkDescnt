import importlib.util,sys,os,hashlib
from pathlib import Path
source=Path('scripts/v5/prepare_cubic_client.py');spec=importlib.util.spec_from_file_location('official_stager',source);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
original=module.verified_copy;donor=Path('/workspace/ungravity-v5/boarding-attachment/build/cubic-client-final-body-scale-volumes-final-gl32/libraries')
def copy(source,target,sha1=None):
    parts=target.parts
    if 'libraries' in parts:
        prior=donor.joinpath(*parts[parts.index('libraries')+1:])
        if prior.is_file() and module.digest(prior)==module.digest(source) and (not sha1 or module.digest(prior,'sha1')==sha1):
            target.parent.mkdir(parents=True,exist_ok=True);os.link(prior,target);return target
    return original(source,target,sha1)
module.verified_copy=copy
module.main()
