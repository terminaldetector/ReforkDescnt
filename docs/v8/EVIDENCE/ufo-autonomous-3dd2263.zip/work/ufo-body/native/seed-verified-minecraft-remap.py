from pathlib import Path
import json,hashlib,zipfile,os
root=Path.cwd();target=root/'build/cubic-client-automation';donor=root/'build/cubic-client-final-flight-body-current-phase-sodium'
a=json.loads((target/'inputs.json').read_text());b=json.loads((donor/'inputs.json').read_text());name='libraries/com/mojang/minecraft/1.21.1/minecraft-1.21.1-client.jar'
assert next(x['sha256'] for x in a['artifacts'] if x['path']==name)==next(x['sha256'] for x in b['artifacts'] if x['path']==name)
p=donor/'.fabric/remappedJars/minecraft-1.21.1-0.19.5/client-intermediary.jar';q=target/p.relative_to(donor)
with zipfile.ZipFile(p) as z:
 assert z.testzip() is None
 assert not any(n.startswith('com/terminaldetector/') for n in z.namelist())
q.parent.mkdir(parents=True,exist_ok=True);os.link(p,q)
a['derivedMinecraftCache']=dict(source=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest(),scope='Minecraft1.21.1/Fabric0.19.5 intermediary remap only; original official input SHA checked; no DRMD code, save or test marker copied')
(target/'inputs.json').write_text(json.dumps(a,indent=2)+'\n')
