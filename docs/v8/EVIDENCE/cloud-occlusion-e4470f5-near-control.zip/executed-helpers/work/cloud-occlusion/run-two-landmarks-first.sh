#!/usr/bin/env bash
set +e
cd /workspace/ungravity-v5/ps1-render
bash scripts/v8/ps1_build.sh
build_code=$?
cp work/ps1/verified-build.log work/cloud-occlusion/two-first-build.log
echo "$build_code" > work/cloud-occlusion/two-first-build.exit
if [ "$build_code" -ne 0 ]; then exit "$build_code"; fi
cp work/ps1/verified-build.json work/cloud-occlusion/two-first-build.json
python3 - <<'PY' > work/cloud-occlusion/two-first-game-parity.log 2>&1
from pathlib import Path
import hashlib
p=Path('build/libs/drmd-6dof-1.1.35-ufo-dev.1.jar');expected='b6c653a4729e7dd4a8158ba1b8704fc31434c89d0c7cabaefbee4e1266d3df8c';actual=hashlib.sha256(p.read_bytes()).hexdigest();assert actual==expected,(actual,expected);print('Observer-only cloud source retains exact accepted palette game bytes',actual)
PY
parity_code=$?
echo "$parity_code" > work/cloud-occlusion/two-first-game-parity.exit
if [ "$parity_code" -ne 0 ]; then exit "$parity_code"; fi
python3 - work/cloud-occlusion/two-remapped-owner-audit.json <<'OWNER_AUDIT' > work/cloud-occlusion/two-owner-audit.log 2>&1
from pathlib import Path
import hashlib,json,struct,sys,zipfile
root=Path.cwd();game=root/'build/libs/drmd-6dof-1.1.35-ufo-dev.1.jar';observer=root/'build/libs/drmd-6dof-1.1.35-ufo-dev.1-cubiccheck.jar'
class Reader:
 def __init__(self,b):self.b=b;self.p=0
 def u(self,n):v=int.from_bytes(self.b[self.p:self.p+n],'big');self.p+=n;return v
 def skip(self,n):self.p+=n
 def utf(self,i):return self.cp[i][1]
 def cls(self,i):return self.utf(self.cp[i][1]) if i else ''
 def parse(self):
  assert self.u(4)==0xCAFEBABE;self.skip(4);n=self.u(2);self.cp=[None]*n;i=1
  while i<n:
   tag=self.u(1)
   if tag==1:
    length=self.u(2);self.cp[i]=(tag,self.b[self.p:self.p+length].decode('utf8',errors='replace'));self.skip(length)
   elif tag in (7,8,16,19,20):self.cp[i]=(tag,self.u(2))
   elif tag in (9,10,11,12,17,18):self.cp[i]=(tag,self.u(2),self.u(2))
   elif tag in (3,4):self.skip(4)
   elif tag in (5,6):self.skip(8);i+=1
   elif tag==15:self.skip(3)
   else:raise ValueError(tag)
   i+=1
  self.skip(2);name=self.cls(self.u(2));parent=self.cls(self.u(2));interfaces=[self.cls(self.u(2)) for _ in range(self.u(2))]
  def members():
   result=set()
   for _ in range(self.u(2)):
    self.skip(2);result.add((self.utf(self.u(2)),self.utf(self.u(2))))
    for _ in range(self.u(2)):self.skip(2);self.skip(self.u(4))
   return result
  members();methods=members();refs=[]
  for c in self.cp:
   if c and c[0] in (10,11):
    nt=self.cp[c[2]];refs.append((self.cls(c[1]),self.utf(nt[1]),self.utf(nt[2])))
  return dict(name=name,parent=parent,interfaces=interfaces,methods=methods,refs=refs)
classes={}
for jar in [game,observer]:
 with zipfile.ZipFile(jar) as z:
  for name in z.namelist():
   if name.startswith('com/terminaldetector/') and name.endswith('.class'):
    c=Reader(z.read(name)).parse();classes[c['name']]=c
prefix='com/terminaldetector/drmd/gate/'
new=[n for n in classes if n.startswith(prefix+'NativeCloudOcclusionCheck') or n.startswith(prefix+'NativeCloudAltitudeCheck') or n.startswith(prefix+'cloud/CloudOcclusion') or n.startswith(prefix+'mixin/CloudOcclusion')]
def ancestors(name,seen=None):
 seen=set() if seen is None else seen
 if name in seen:return set(),False
 seen.add(name)
 if name.startswith('net/minecraft/'):return set(),True
 if name.startswith('com/terminaldetector/'):
  assert name in classes,'Unknown project call-owner hierarchy '+name
  c=classes[name];methods=set(c['methods']);minecraft=False
  for parent in [c['parent'],*c['interfaces']]:
   inherited,is_mc=ancestors(parent,seen);methods|=inherited;minecraft|=is_mc
  return methods,minecraft
 return set(),False
checked=[];forbidden=[]
for n in sorted(new):
 for owner,name,descriptor in classes[n]['refs']:
  if owner.startswith('com/terminaldetector/'):
   declared,minecraft=ancestors(owner)
   if minecraft:
    row=dict(caller=n,owner=owner,method=name,descriptor=descriptor,declaredProjectMethod=(name,descriptor) in declared);checked.append(row)
    if not row['declaredProjectMethod']:forbidden.append(row)
report={'classification':'Read-only actual remapped bytecode method-owner audit; no JVM executed','gameSha256':hashlib.sha256(game.read_bytes()).hexdigest(),'observerSha256':hashlib.sha256(observer.read_bytes()).hexdigest(),'newClasses':sorted(new),'allProjectCallOwnersWithMinecraftAncestor':checked,'forbiddenInheritedMethodOwners':forbidden,'pass':not forbidden}
path=Path(sys.argv[1]);assert not path.exists(),path;path.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'classes':len(new),'checkedMethodRefs':len(checked),'forbidden':forbidden,'pass':not forbidden},indent=2));raise SystemExit(0 if not forbidden else 1)
OWNER_AUDIT
audit_code=$?
echo "$audit_code" > work/cloud-occlusion/two-owner-audit.exit
if [ "$audit_code" -ne 0 ]; then exit "$audit_code"; fi
python3 - <<'CAPACITY' > work/cloud-occlusion/two-capacity-admission.log 2>&1
from pathlib import Path
import hashlib,json,shutil,subprocess,time
r=Path.cwd();m=json.loads(Path('work/cloud-occlusion/two-executed-inputs.json').read_text());source=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert source==m['source'];assert all(hashlib.sha256((r/p).read_bytes()).hexdigest()==h for p,h in m['files'].items());e=m['externalOfficialStager'];assert hashlib.sha256(Path(e['path']).read_bytes()).hexdigest()==e['sha256'];free=shutil.disk_usage(r).free
j={'source':source,'utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'actualFreeBeforeNativeBytes':free,'minimumBytes':140*1024*1024,'nativeCapacityPermitted':free>=140*1024*1024,'actualNativeCommand':['bash','scripts/v8/ps1_native.sh','ps1-cloud-attribution-occlusion-two-e4470f5-sodium'],'allEightHelpersUnchanged':True,'externalOfficialStagerUnchanged':True}
Path('work/cloud-occlusion/two-native-admission.json').write_text(json.dumps(j,indent=2)+'\n');print(json.dumps(j,indent=2));raise SystemExit(0 if j['nativeCapacityPermitted'] else 78)
CAPACITY
capacity_code=$?
echo "$capacity_code" > work/cloud-occlusion/two-capacity.exit
if [ "$capacity_code" -ne 0 ]; then exit "$capacity_code"; fi
bash scripts/v8/ps1_native.sh ps1-cloud-attribution-occlusion-two-e4470f5-sodium
native_code=$?
echo "$native_code" > work/cloud-occlusion/two-first-native.exit
exit "$native_code"
