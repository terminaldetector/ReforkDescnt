#!/usr/bin/env bash
set +e
cd /workspace/ungravity-v5/ps1-render
bash scripts/v8/ps1_build.sh
build_code=$?
cp work/ps1/verified-build.log work/ps1-color/first-build.log
echo "$build_code" > work/ps1-color/first-build.exit
if [ "$build_code" -ne 0 ]; then exit "$build_code"; fi
cp work/ps1/verified-build.json work/ps1-color/first-build.json
python3 - <<'PY' > work/ps1-color/first-artifact-parity.log 2>&1
from pathlib import Path
import json,hashlib
p=Path('build/libs/drmd-6dof-1.1.35-ufo-dev.1.jar');expected='1dbb11d34293889fc04bc6a49b421b00caac18ff02cfae53f242cba78d4a6e71';actual=hashlib.sha256(p.read_bytes()).hexdigest();assert actual==expected,(actual,expected);print('Observer-only source preserves exact accepted sky game bytes',actual)
PY
parity_code=$?
echo "$parity_code" > work/ps1-color/first-artifact-parity.exit
if [ "$parity_code" -ne 0 ]; then exit "$parity_code"; fi
bash scripts/v8/ps1_native.sh ps1-color-reference-negative-sodium
native_code=$?
echo "$native_code" > work/ps1-color/first-native.exit
exit "$native_code"
