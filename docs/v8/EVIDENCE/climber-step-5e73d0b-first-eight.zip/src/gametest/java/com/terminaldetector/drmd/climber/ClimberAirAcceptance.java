package com.terminaldetector.drmd.climber;

import com.terminaldetector.drmd.d6.D6ChunkPos;
import com.terminaldetector.drmd.world.access.WorldAccess;
import com.terminaldetector.drmd.world.gravity.ActorFrames;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.SpiderEntity;
import net.minecraft.entity.passive.CowEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.*;
import net.minecraft.world.RaycastContext;
import java.lang.ref.WeakReference;
import java.util.*;

/** Test-only acceptance state. Native goals/movement are observed, never invoked or commanded. */
public final class ClimberAirAcceptance {
    public static final boolean ENABLED=Boolean.getBoolean("drmd.gate.climberAirAcceptance");
    private static final int MAX_SEEN=6,MAX_ACTIVE=4,MAX_EVENTS=256;
    private static final Map<UUID,State> STATES=new LinkedHashMap<>();
    public static final class State {
        public final WeakReference<SpiderEntity> actor;
        final WeakReference<CowEntity> target;
        public final Vec3d up;public final double eyeHeight;
        public int events,pounces,impulseErrors,completedArcs,lastPounceAge=-10000,lastLandingAge=-1;
        public int flightStart=-1,consumedPounces,lastAge=-1,maximumAirTicks;
        public double maximumGap,maximumStep;
        public boolean resumedNativeAfterLanding,sawDetached,unsupportedGroundClaim;
        public Vec3d expected;public Vec3d previousPosition;public Box previousBox;
        State(SpiderEntity actor,CowEntity target,Vec3d up,double eyeHeight) {
            this.actor=new WeakReference<>(actor);this.target=new WeakReference<>(target);this.up=up;this.eyeHeight=eyeHeight;
            previousPosition=actor.getPos();previousBox=actor.getBoundingBox();lastAge=actor.age;
        }
    }
    public record Support(boolean available,boolean hit,Double gap,double normal,boolean bodyClear,double eyeError,double upError) {
        public boolean valid(){return available&&hit&&gap!=null&&gap>=-1e-6&&gap<=.08&&normal>=.95&&bodyClear&&eyeError<=1e-6&&upError<=1e-6;}
    }
    private ClimberAirAcceptance() {}
    public static State arm(SpiderEntity actor,CowEntity target,Vec3d up,double eyeHeight) {
        if(!ENABLED)throw new IllegalStateException("air acceptance requires its actual focused observer helper");
        long active=STATES.values().stream().map(s->s.actor.get()).filter(a->a!=null&&!a.isRemoved()).count();
        if(STATES.size()>=MAX_SEEN||active>=MAX_ACTIVE)throw new IllegalStateException("air observer actor budget exceeded");
        var state=new State(actor,target,up,eyeHeight);STATES.put(actor.getUuid(),state);return state;
    }
    public static State state(SpiderEntity actor) {
        if(!ENABLED)return null;var state=STATES.get(actor.getUuid());
        return state!=null&&state.actor.get()==actor?state:null;
    }
    public static void pounce(SpiderEntity actor,LivingEntity nativeTarget,float leap,boolean before) {
        var state=state(actor);if(state==null)return;
        if(before) {
            var delta=nativeTarget.getPos().subtract(actor.getPos());var tangent=delta.subtract(state.up.multiply(delta.dotProduct(state.up)));
            var v=actor.getVelocity();var inherited=v.subtract(state.up.multiply(v.dotProduct(state.up)));
            if(tangent.lengthSquared()>1e-7)tangent=tangent.normalize().multiply(.4).add(inherited.multiply(.2));
            state.expected=tangent.add(state.up.multiply((double)leap));state.pounces++;state.lastPounceAge=actor.age;
            if(nativeTarget!=state.target.get())state.impulseErrors++;
        } else if(state.expected==null||actor.getVelocity().distanceTo(state.expected)>1e-6)state.impulseErrors++;
        emit(state,actor,before?"NATIVE_POUNCE_BEFORE":"NATIVE_POUNCE_AFTER",Map.of(
            "nativeLeapFloat",leap,"expectedLocalImpulse",vector(state.expected),"actualVelocity",vector(actor.getVelocity()),
            "actualNativeTarget",nativeTarget.getUuid().toString(),"pounces",state.pounces,"impulseErrors",state.impulseErrors));
    }
    public static void attack(SpiderEntity actor,net.minecraft.entity.Entity target) {
        var state=state(actor);if(state==null||target!=state.target.get())return;
        if(state.lastLandingAge>=0&&actor.age>state.lastLandingAge)state.resumedNativeAfterLanding=true;
        emit(state,actor,"NATIVE_ATTACK_ATTEMPT",Map.of("target",target.getUuid().toString()));
    }
    public static Support support(ServerWorld world,LivingEntity actor,Vec3d up,double eyeHeight) {
        var from=actor.getPos().add(up.multiply(.04));var to=actor.getPos().subtract(up.multiply(1.6));
        var query=actor.getBoundingBox().union(new Box(from,to)).expand(1);
        if(!available(world,query))return new Support(false,false,null,0,false,Double.MAX_VALUE,Double.MAX_VALUE);
        var hit=world.raycast(new RaycastContext(from,to,RaycastContext.ShapeType.COLLIDER,RaycastContext.FluidHandling.NONE,actor));
        boolean block=hit.getType()==HitResult.Type.BLOCK;
        var actualUp=ActorFrames.active(actor)?ActorFrames.up(actor):new Vec3d(0,1,0);
        return new Support(true,block,block?actor.getPos().subtract(hit.getPos()).dotProduct(up):null,
            block?Vec3d.of(hit.getSide().getVector()).dotProduct(up):0,
            world.isSpaceEmpty(actor,actor.getBoundingBox().contract(1e-6)),
            actor.getEyePos().distanceTo(actor.getPos().add(up.multiply(eyeHeight))),actualUp.distanceTo(up));
    }
    public static boolean available(ServerWorld world,Box query) {
        if(!Double.isFinite(query.minX)||!Double.isFinite(query.maxX)||!Double.isFinite(query.minY)||!Double.isFinite(query.maxY)
            ||!Double.isFinite(query.minZ)||!Double.isFinite(query.maxZ)||query.minY<world.getBottomY()||query.maxY>world.getTopY()
            ||!world.getWorldBorder().contains(query))return false;
        int x0=MathHelper.floor(query.minX)>>4,x1=MathHelper.floor(query.maxX)>>4,y0=MathHelper.floor(query.minY)>>4,y1=MathHelper.floor(query.maxY)>>4,z0=MathHelper.floor(query.minZ)>>4,z1=MathHelper.floor(query.maxZ)>>4;
        if((long)(x1-x0+1)*(y1-y0+1)*(z1-z0+1)>64)return false;
        var access=WorldAccess.of(world);for(int x=x0;x<=x1;x++)for(int y=y0;y<=y1;y++)for(int z=z0;z<=z1;z++)
            if(!access.isVolumeAvailable(new D6ChunkPos(x,y,z)))return false;
        return true;
    }
    public static void emit(State state,SpiderEntity actor,String phase,Map<String,Object> details) {
        if(++state.events>MAX_EVENTS)throw new IllegalStateException("air observer event budget exceeded");
        var row=new LinkedHashMap<String,Object>();row.put("phase",phase);row.put("sequence",state.events);row.put("uuid",actor.getUuid().toString());
        row.put("type",actor.getType().toString());row.put("actualAge",actor.age);row.put("worldTime",actor.getWorld().getTime());
        var box=actor.getBoundingBox();row.put("bounds",List.of(box.minX,box.minY,box.minZ,box.maxX,box.maxY,box.maxZ));row.put("eye",vector(actor.getEyePos()));
        row.put("position",vector(actor.getPos()));row.put("velocity",vector(actor.getVelocity()));row.put("onGround",actor.isOnGround());row.put("localUp",vector(state.up));row.putAll(details);
        System.out.println("CLIMBER_AIR_ACCEPTANCE "+new com.google.gson.Gson().toJson(row));
    }
    public static List<Double> vector(Vec3d v){return v==null?List.of():List.of(v.x,v.y,v.z);}
}
