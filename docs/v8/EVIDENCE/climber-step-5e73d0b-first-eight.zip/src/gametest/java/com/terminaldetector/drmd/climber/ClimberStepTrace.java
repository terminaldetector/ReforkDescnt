package com.terminaldetector.drmd.climber;

import net.minecraft.entity.Entity;
import net.minecraft.entity.MovementType;
import net.minecraft.entity.mob.SpiderEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.*;
import java.lang.ref.WeakReference;
import java.util.*;

/** Passive finite rolling call provenance, not a replacement collision algorithm or synthetic trajectory. */
public final class ClimberStepTrace {
    public static final boolean ENABLED=Boolean.getBoolean("drmd.gate.climberStepTrace");
    private static final int ACTORS=2,MOVES=4,CANDIDATES=8,DEPTH=2;
    private static final Map<UUID,Arm> ARMS=new LinkedHashMap<>();
    private static final ThreadLocal<ArrayDeque<Move>> ACTIVE=new ThreadLocal<>();
    private static final ThreadLocal<Integer> OVERFLOW=ThreadLocal.withInitial(()->0);
    private static final class Arm {
        final WeakReference<SpiderEntity> actor;final Box barrier;final ArrayDeque<Move> history=new ArrayDeque<>();
        int moves,reentrantOverflows;boolean dumped;
        Arm(SpiderEntity actor,Box barrier){this.actor=new WeakReference<>(actor);this.barrier=barrier;}
    }
    private static final class Move {
        final Arm arm;final UUID uuid;final int ordinal,age;final long worldTime;final Map<String,Object> row=new LinkedHashMap<>();
        final List<Map<String,Object>> candidates=new ArrayList<>();Map<String,Object> pending;int calls,sequence;
        Move(Arm arm,Entity actor,MovementType type,Vec3d requested) {
            this.arm=arm;uuid=actor.getUuid();ordinal=++arm.moves;age=actor.age;worldTime=actor.getWorld().getTime();
            row.put("ordinal",ordinal);row.put("actualAge",age);row.put("worldTime",worldTime);row.put("type",type.toString());
            row.put("requested",vector(requested));row.put("before",snapshot(actor));row.put("MOVE_HEAD_sequence",++sequence);
        }
        Map<String,Object> export(){var result=new LinkedHashMap<>(row);result.put("candidateCalls",calls);result.put("candidatesTruncated",Math.max(0,calls-CANDIDATES));result.put("candidateSnapshots",candidates);return result;}
    }
    private ClimberStepTrace() {}
    public static void arm(SpiderEntity actor,Box barrier) {
        if(!ENABLED)return;if(ARMS.size()>=ACTORS)throw new IllegalStateException("step observer actor cap exceeded");
        ARMS.put(actor.getUuid(),new Arm(actor,barrier));
    }
    private static Arm arm(Entity actor) {
        if(!ENABLED)return null;var arm=ARMS.get(actor.getUuid());
        return arm!=null&&arm.actor.get()==actor&&!actor.isRemoved()&&actor.getWorld()instanceof ServerWorld world
            &&world.getServer().isOnThread()&&world.getEntityById(actor.getId())==actor?arm:null;
    }
    private static Move current(Entity actor) {
        if(!ENABLED||OVERFLOW.get()>0)return null;var stack=ACTIVE.get();var move=stack==null?null:stack.peekLast();
        return move!=null&&move.uuid.equals(actor.getUuid())?move:null;
    }
    public static void beginMove(Entity actor,MovementType type,Vec3d requested) {
        var arm=arm(actor);if(arm==null)return;
        var stack=ACTIVE.get();if(stack==null){stack=new ArrayDeque<>();ACTIVE.set(stack);}if(OVERFLOW.get()>0||stack.size()>=DEPTH){OVERFLOW.set(OVERFLOW.get()+1);arm.reentrantOverflows++;return;}
        var move=new Move(arm,actor,type,requested);stack.addLast(move);arm.history.addLast(move);
        while(arm.history.size()>MOVES)arm.history.removeFirst();
    }
    public static void endMove(Entity actor) {
        if(arm(actor)==null)return;
        if(OVERFLOW.get()>0){OVERFLOW.set(OVERFLOW.get()-1);return;}
        var move=current(actor);if(move==null)return;move.row.put("after",snapshot(actor));move.row.put("MOVE_RETURN_sequence",++move.sequence);ACTIVE.get().removeLast();
    }
    public static void adjustBegin(Entity actor,Vec3d requested) {
        if(arm(actor)==null)return;var move=current(actor);if(move==null)return;
        move.row.put("ADJUST_HEAD_sequence",++move.sequence);move.row.put("adjustRequested",vector(requested));move.row.put("adjustStartBox",bounds(actor.getBoundingBox()));
    }
    public static void adjustEnd(Entity actor,Vec3d result,boolean selectedStep) {
        if(arm(actor)==null)return;var move=current(actor);if(move==null)return;
        move.row.put("ADJUST_RETURN_sequence",++move.sequence);move.row.put("actualSelectedBranch",selectedStep?"SELECTED_STEP_RETURN_341":"BASE_RETURN_350");
        move.row.put("actualReturnedMovement",vector(result));
    }
    public static void candidateBegin(Vec3d requested,Box box,int shapes) {
        if(!ENABLED)return;var stack=ACTIVE.get();if(stack==null||OVERFLOW.get()>0)return;var move=stack.peekLast();if(move==null)return;
        move.calls++;int order=++move.sequence;move.pending=null;if(move.calls>CANDIDATES)return;
        var row=new LinkedHashMap<String,Object>();row.put("classification","CANDIDATE_ONLY_NOT_AN_EXECUTED_SEGMENT");
        row.put("call",move.calls);row.put("headSequence",order);row.put("requested",vector(requested));row.put("box",bounds(box));row.put("shapeCount",shapes);
        move.candidates.add(row);move.pending=row;
    }
    public static void candidateEnd(Vec3d result) {
        if(!ENABLED)return;var stack=ACTIVE.get();if(stack==null||OVERFLOW.get()>0)return;var move=stack.peekLast();if(move==null)return;
        int order=++move.sequence;if(move.pending!=null){move.pending.put("returnSequence",order);move.pending.put("result",vector(result));move.pending=null;}
    }
    public static void beforeAssertion(SpiderEntity actor,Box before,Box after,Box expanded,ClimberAirAcceptance.Support support,int violations) {
        var arm=arm(actor);if(arm==null||arm.dumped)return;arm.dumped=true;
        var row=new LinkedHashMap<String,Object>();row.put("uuid",actor.getUuid().toString());row.put("type",actor.getType().toString());row.put("actualAge",actor.age);
        row.put("worldTime",actor.getWorld().getTime());row.put("existingIllegalSweeps",violations);row.put("beforeOrdinaryBox",bounds(before));row.put("currentOrdinaryBox",bounds(after));
        row.put("barrier",bounds(arm.barrier));row.put("existingExpandedMinkowskiBox",bounds(expanded));row.put("existingSupport",support);
        row.put("movesObserved",arm.moves);row.put("rollingMovesCap",MOVES);row.put("candidateCapPerMove",CANDIDATES);row.put("reentrantOverflows",arm.reentrantOverflows);
        row.put("actualNativeCallHistory",arm.history.stream().map(Move::export).toList());row.put("candidateSnapshotsAreNotExecutedSegments",true);
        System.out.println("CLIMBER_STEP_PREASSERT "+new com.google.gson.Gson().toJson(row));
    }
    private static Map<String,Object> snapshot(Entity actor) {
        return Map.of("position",vector(actor.getPos()),"bounds",bounds(actor.getBoundingBox()),"velocity",vector(actor.getVelocity()),
            "onGround",actor.isOnGround(),"horizontalCollision",actor.horizontalCollision,"verticalCollision",actor.verticalCollision,
            "nativeStepHeight",actor.getStepHeight());
    }
    private static List<Double> vector(Vec3d v){return List.of(v.x,v.y,v.z);}
    private static List<Double> bounds(Box b){return List.of(b.minX,b.minY,b.minZ,b.maxX,b.maxY,b.maxZ);}
}
