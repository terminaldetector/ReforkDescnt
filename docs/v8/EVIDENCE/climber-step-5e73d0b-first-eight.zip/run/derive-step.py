from pathlib import Path
import json,hashlib,math
out=Path(__file__).resolve().parent;raw=out/'first-step-dumps.json';rows=json.loads(raw.read_text());assert len(rows)==1
s=rows[0];move=s['actualNativeCallHistory'][-1];before=move['before']['bounds'];delta=move['actualReturnedMovement'];plate=s['barrier'];eps=1e-6
assert move['actualSelectedBranch']=='SELECTED_STEP_RETURN_341';assert move['candidatesTruncated']==0 and s['reentrantOverflows']==0
assert move['candidateSnapshots'][-1]['result']==delta
# Derived reconstruction of the audited native collision resolver's axis order; these are NOT sampled intermediate entity poses.
axisOrder=[1]+([2,0]if abs(delta[0])<abs(delta[2])else[0,2])
def offset(b,d):return[b[i]+d[i%3]for i in range(6)]
def union(a,b):return[min(a[i],b[i])for i in range(3)]+[max(a[i],b[i])for i in range(3,6)]
def intersects(a,b):return all(a[i]<b[i+3]and a[i+3]>b[i]for i in range(3))
contract=[plate[i]+(eps if i<3 else-eps)for i in range(6)];parts=[];box=before
for axis in axisOrder:
 d=[0.,0.,0.];d[axis]=delta[axis];after=offset(box,d);parts.append({'axis':'XYZ'[axis],'derivedOnlyNotSampledPose':True,'fromBox':box,'toBox':after,'axisSweepIntersectsContractedPlate':intersects(union(box,after),contract)});box=after
beforeCenter=[(s['beforeOrdinaryBox'][i]+s['beforeOrdinaryBox'][i+3])/2 for i in range(3)];afterCenter=[(s['currentOrdinaryBox'][i]+s['currentOrdinaryBox'][i+3])/2 for i in range(3)];expanded=s['existingExpandedMinkowskiBox'];lo=0.;hi=1.
for i in range(3):
 d=afterCenter[i]-beforeCenter[i]
 if abs(d)<1e-15:
  if not expanded[i]<=beforeCenter[i]<=expanded[i+3]:lo,hi=1.,0.;break
 else:
  a=(expanded[i]-beforeCenter[i])/d;b=(expanded[i+3]-beforeCenter[i])/d;lo=max(lo,min(a,b));hi=min(hi,max(a,b))
actualDelta=[y-x for x,y in zip(move['before']['position'],move['after']['position'])]
result={'source':'5e73d0b979f1b5fba92db803d3143d3cbe2b9749','derivedOnly':True,'rawStepDumpSha256':hashlib.sha256(raw.read_bytes()).hexdigest(),'actualNativeSelectedBranch':move['actualSelectedBranch'],'actualCandidateCalls':move['candidateCalls'],'actualSelectedCandidateMatchesReturnedMovement':True,'actualMoveRequested':move['requested'],'actualNativeReturnedMovement':delta,'actualPositionDelta':actualDelta,'returnedVsActualDeltaMaxError':max(abs(a-b)for a,b in zip(delta,actualDelta)),'observedEndBodyClear':s['existingSupport']['bodyClear'],'observedEndBox':move['after']['bounds'],'derivedEndBoxMaxError':max(abs(a-b)for a,b in zip(box,move['after']['bounds'])),'originalStraightChordIntersectsExpandedPlate':lo<=hi,'chordParameterInterval':[lo,hi],'auditedNativeAxisOrder':''.join('XYZ'[i]for i in axisOrder),'derivedNativeAxisSweeps':parts,'everyDerivedNativeAxisSweepClearOfContractedPlate':all(not r['axisSweepIntersectsContractedPlate']for r in parts),'classification':'Real selected native step + actual end-body clear; original ordinary-sample chord false-positive for this native collision-resolved step. Reconstructed axis boxes are derived from selected native algorithm, not separate actual Entity positions. No arbitrary CCD or local-UP step-height acceptance.'}
(out/'first-step-analysis.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items()if k!='derivedNativeAxisSweeps'},indent=2))
