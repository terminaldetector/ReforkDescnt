#!/usr/bin/env bash
set -euo pipefail
cd /workspace/ungravity-v5/ufo-body-physics
bash work/ufo-body/native/build-verified.sh > work/ufo-body/weapons-build-after-fixture-20261107.log 2>&1
python3 - <<'PY'
import json,subprocess
from pathlib import Path
stamp=json.loads(Path('work/ufo-body/native/verified-build.json').read_text())
for renderer in ['gl32','sodium']:
 inputs=json.loads(Path('build/cubic-client-final-flight-body-control-weapons-final5-'+renderer+'/inputs.json').read_text())
 changes=subprocess.check_output(['git','diff','--name-only',inputs['sourceSha'],'HEAD'],text=True).splitlines()
 assert changes and all(p.startswith('src/gametest/') for p in changes),changes
 for artifact in inputs['artifacts']:
  if artifact.get('source') in stamp['jars']:assert artifact['sha256']==stamp['jars'][artifact['source']]
print('Verified current production/observer JAR bytes equal both fresh native rounds; intervening source changes are GameTest-only')
PY
JAVA_HOME=/workspace/jdk21-complete PATH=/workspace/jdk21-complete/bin:$PATH GRADLE_USER_HOME=/workspace/.gradle ./gradlew processGametestResources --rerun-tasks --no-daemon --offline > work/ufo-body/weapons-restore-resources-second-20261107.log 2>&1
python3 - <<'PY'
from pathlib import Path
import json
assert json.loads(Path('build/resources/gametest/fabric.mod.json').read_text())['entrypoints']==json.loads(Path('src/gametest/resources/fabric.mod.json').read_text())['entrypoints']
PY
JAVA_HOME=/workspace/jdk21-complete PATH=/workspace/jdk21-complete/bin:$PATH GRADLE_USER_HOME=/workspace/.gradle ./gradlew test runGametest remapJar remapCubiccheckJar --no-daemon --offline -I work/ufo-body/engine-final-force-test.init.gradle > work/ufo-body/weapons-final-regressions-fourth-20261107.log 2>&1
python3 work/ufo-body/native/verify-build-stamp.py check
