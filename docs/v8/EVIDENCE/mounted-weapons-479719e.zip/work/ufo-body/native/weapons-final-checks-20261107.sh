#!/usr/bin/env bash
set -euo pipefail
cd /workspace/ungravity-v5/ufo-body-physics
python3 work/ufo-body/native/verify-build-stamp.py check
bash work/ufo-body/native/run-weapons.sh flight-body-control-weapons-final5-gl32
python3 /workspace/ungravity-v5/boarding-attachment/work/body-scale/preserve-finished-native-worlds.py
JAVA_HOME=/workspace/jdk21-complete PATH=/workspace/jdk21-complete/bin:$PATH GRADLE_USER_HOME=/workspace/.gradle ./gradlew processGametestResources --rerun-tasks --no-daemon --offline > work/ufo-body/weapons-restore-resources-20261107.log 2>&1
python3 - <<'PY'
import json
from pathlib import Path
assert json.loads(Path('build/resources/gametest/fabric.mod.json').read_text())['entrypoints']==json.loads(Path('src/gametest/resources/fabric.mod.json').read_text())['entrypoints']
print('Verified complete GameTest entrypoint manifest')
PY
JAVA_HOME=/workspace/jdk21-complete PATH=/workspace/jdk21-complete/bin:$PATH GRADLE_USER_HOME=/workspace/.gradle ./gradlew test runGametest remapJar remapCubiccheckJar --no-daemon --offline -I work/ufo-body/engine-final-force-test.init.gradle > work/ufo-body/weapons-final-regressions-20261107.log 2>&1
python3 work/ufo-body/native/verify-build-stamp.py check
