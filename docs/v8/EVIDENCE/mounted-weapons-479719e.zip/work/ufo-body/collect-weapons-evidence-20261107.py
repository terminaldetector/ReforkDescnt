from pathlib import Path
import hashlib,json,subprocess,zipfile,xml.etree.ElementTree as E
subprocess.run(['python3','work/ufo-body/native/verify-build-stamp.py','check'],check=True)
source=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();files=set()
def add(p):
 p=Path(p);assert p.is_file(),p;files.add(p)
for n in subprocess.check_output(['git','diff','--name-only','73a0987',source],text=True).splitlines():
 if n.startswith('src/'):add(n)
for n in ['build.gradle','gradle.properties','src/gametest/resources/fabric.mod.json','build/resources/gametest/fabric.mod.json','build/gametest/reports/gametest-results.xml','work/ufo-body/native/verified-build.json','work/ufo-body/native/run-weapons.sh','work/ufo-body/native/build-verified.sh','work/ufo-body/native/verify-build-stamp.py','work/ufo-body/native/prepare-with-verified-library-links.py','work/ufo-body/native/dedup-staged-libraries.py','work/ufo-body/native/seed-verified-minecraft-remap.py','scripts/v5/prepare_cubic_client.py','src/gametest/java/com/terminaldetector/drmd/AiFixtureChunks.java','work/ufo-body/native/weapons-final-regression-checks-20261107.sh','work/ufo-body/weapons-focused-38-admitted-20261107.xml','work/ufo-body/weapon-focus.init.gradle','work/ufo-body/engine-final-force-test.init.gradle','work/ufo-body/collect-weapons-evidence-20261107.py','work/ufo-body/native/weapons-final-checks-20261107.sh','work/ufo-body/preserve-old-portal-gametest.py','work/preserved-disposable-worlds/portal-gun-closed-gametest-20261107.zip.json']:add(n)
for glob in ['weapons-*.log','weapons-*.xml','weapons-*failure*.zip','weapons-first-repro-20261107.zip','weapons-focused-*.xml']:
 for p in Path('work/ufo-body').glob(glob):add(p)
for p in Path('build/test-results/test').glob('TEST-*.xml'):add(p)
stamp=json.loads(Path('work/ufo-body/native/verified-build.json').read_text())
for p,h in stamp['jars'].items():assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==h;add(p)
markers={};nativeSource=None;nativeDelta=[]
for profile in ['gl32','sodium']:
 name='flight-body-control-weapons-final5-'+profile;r=Path('build/cubic-client-final-'+name)
 info=json.loads((r/'inputs.json').read_text());assert not info['uncommittedDiff']
 if nativeSource is None:nativeSource=info['sourceSha']
 assert nativeSource==info['sourceSha']
 nativeDelta=subprocess.check_output(['git','diff','--name-only',nativeSource,source],text=True).splitlines()
 assert all(p.startswith('src/gametest/') for p in nativeDelta),nativeDelta
 for artifact in info['artifacts']:
  if artifact.get('source') in stamp['jars']:assert artifact['sha256']==stamp['jars'][artifact['source']]
 for suffix in ['.log','.exit','-prepare.log']:add('work/ufo-body/native/final-'+name+suffix)
 assert Path('work/ufo-body/native/final-'+name+'.exit').read_text().strip()=='0'
 for f in ['inputs.json','launch.json','ufo-control-ok.json','native-weapon-repair-diagnostic.json','native-weapon-repaired-body.snbt']:add(r/f)
 diagnostic=json.loads((r/'native-weapon-repair-diagnostic.json').read_text());assert not diagnostic['changed'] and diagnostic['materialError']<1e-8 and diagnostic['expectedCells']==diagnostic['actualCells']==1046
 hitlog=r/'native-weapon-hits.jsonl'
 if hitlog.is_file():
  add(hitlog)
  for line in hitlog.read_text().splitlines():
   h=json.loads(line);assert not ('SkyUfoEntity' in h['target'] and 'CubicGate' in h['owner']),h
 log=Path('work/ufo-body/native/final-'+name+'.log').read_text();assert not any('SkyUfoEntity' in line and 'CubicGate' in line for line in log.splitlines() if 'UFO_WEAPON_ACTUAL_HIT' in line)
 m=json.loads((r/'ufo-control-ok.json').read_text())
 for k,n in [('mountedLaserShots',6),('mountedRocketShots',2),('repairedLaserShots',4),('repairedRocketShots',2),('destroyedBankTicks',28),('acceptedFireSnapshots',24),('synchronizedMountedShots',4)]:assert m[k]>=n,(k,m)
 for k in ['maxMuzzleError','maxLaunchVelocityError','maxPointVelocityError','weaponMaterialContinuityError']:assert m[k]<1e-8
 assert m['weaponRotationTravel']>.3 and m['actualWeaponItemsObserved'] and m['maxPredictionError']<.8 and m['bayResumed'] and m['pauseResumed'] and not m['teleportFollow']
 assert m['renderedMountedShots']>0
 assert len(m['scenes'])==11
 ps=list((r/'flight-body-frames').glob('*.png'));assert len(ps)==11
 for p in ps:add(p)
 markers[profile]=m
for p in Path('work/ufo-body/native').glob('*weapons*.log'):add(p)
rs=[E.parse(p).getroot() for p in Path('build/test-results/test').glob('TEST-*.xml')];u={k:sum(int(r.get(k,0)) for r in rs) for k in ['tests','failures','errors','skipped']};cs=list(E.parse('build/gametest/reports/gametest-results.xml').iter('testcase'));g={'tests':len(cs),'failures':sum(c.find('failure') is not None for c in cs),'errors':sum(c.find('error') is not None for c in cs),'skipped':sum(c.find('skipped') is not None for c in cs)}
assert u==dict(tests=732,failures=0,errors=0,skipped=0) and g==dict(tests=308,failures=0,errors=0,skipped=0),(u,g)
assert json.loads(Path('build/resources/gametest/fabric.mod.json').read_text())['entrypoints']==json.loads(Path('src/gametest/resources/fabric.mod.json').read_text())['entrypoints']
assert 'BUILD SUCCESSFUL' in Path('work/ufo-body/weapons-final-regressions-fourth-20261107.log').read_text()
focus=list(E.parse('work/ufo-body/weapons-focused-38-admitted-20261107.xml').iter('testcase'));assert len(focus)==38 and all(c.find('failure') is None and c.find('error') is None and c.find('skipped') is None for c in focus)
s=dict(source=source,nativeSource=nativeSource,nativeTestOnlyDelta=nativeDelta,identicalNativeArtifactBytesVerified=True,productionSource=subprocess.check_output(['git','rev-parse','b33247b'],text=True).strip(),jars=stamp['jars'],unit=u,server=g,native=markers,releaseAccepted=False,publication='Local only',scope='Partial S09-T03: authored rigid hull-mounted laser/rocket banks, physical muzzle and material-point launch velocity/recoil, real pilot buttons and damage/repair. Hinged weapon assemblies, complete module restart/AI and full v8/Dynamic Boarding remain open.',files={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(files)})
p=Path('docs/v8/EVIDENCE/mounted-weapons-'+source[:7]+'.zip')
with zipfile.ZipFile(p,'x',zipfile.ZIP_DEFLATED) as z:
 for f in sorted(files):
  if f.suffix=='.zip':
   with zipfile.ZipFile(f) as nested:assert nested.testzip() is None,f
  z.write(f,str(f))
 z.writestr('MANIFEST.json',json.dumps(s,indent=2))
with zipfile.ZipFile(p) as z:
 assert z.testzip() is None
 for n,h in s['files'].items():assert hashlib.sha256(z.read(n)).hexdigest()==h,n
s['archive']=str(p);s['archiveSha256']=hashlib.sha256(p.read_bytes()).hexdigest();Path('work/ufo-body/weapons-summary-20261107.json').write_text(json.dumps(s,indent=2)+'\n');print(json.dumps({k:v for k,v in s.items() if k!='files'},indent=2))
