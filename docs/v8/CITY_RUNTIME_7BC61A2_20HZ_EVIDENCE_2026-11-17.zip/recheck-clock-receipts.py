"""Post-close evidence oracle only; no Java/game/source mutation."""
import collections
import json
from pathlib import Path

directory = Path(__file__).resolve().parent
grouped = collections.defaultdict(list)
for receipt in json.loads((directory / "clock-receipts.json").read_text()):
    grouped[receipt["fixture"]].append(receipt)
assert len(grouped) == 2
for fixture, rows in grouped.items():
    ticks = [r for r in rows if r["event"] == "CITY_CLOCK20_TICK"]
    anchors = [r for r in rows if r["event"] == "CITY_CLOCK20_ANCHOR"]
    ends = [r for r in rows if r["event"] == "CITY_CLOCK20_END"]
    assert 0 < len(ticks) <= 1024 and len(anchors) == len(ends) == 1
    assert not any(r["event"] == "CITY_CLOCK20_ERROR" for r in rows)
    for index, tick in enumerate(ticks):
        assert tick["sequence"] == index + 1
        assert tick["receiptNanos"] >= tick["targetNanos"]
        assert tick["intervalNanos"] == 50_000_000
    for previous, current in zip(ticks, ticks[1:]):
        assert current["gameTick"] == previous["gameTick"] + 1
        assert current["serverTick"] == previous["serverTick"] + 1
        assert current["receiptNanos"] - previous["receiptNanos"] >= 50_000_000
        assert current["targetNanos"] >= previous["receiptNanos"] + 50_000_000
    anchor, end = anchors[0], ends[0]
    boundary = next(r for r in ticks if r["gameTick"] == anchor["gameTick"])
    assert boundary["serverTick"] == anchor["serverTick"]
    assert anchor["actualRuntimeStartNanos"] >= boundary["receiptNanos"]
    assert anchor["nextTargetNanos"] == anchor["actualRuntimeStartNanos"] + 50_000_000
    assert end["receipts"] == len(ticks) and end["enabled"] and end["finished"] and not end["failed"]
    watchdogs = [r for r in rows if r["event"] == "CITY_CLOCK20_WATCHDOG"]
    for watchdog in watchdogs:
        assert watchdog["runtimeGameTicks"] == watchdog["runtimeServerTicks"] == 300
        assert watchdog["actualRuntimeNanos"] >= watchdog["minimumRuntimeNanos"] == 15_000_000_000
    print(fixture, "PASS", len(ticks), "actual receipts", len(watchdogs), "runtime300 watchdogs")
