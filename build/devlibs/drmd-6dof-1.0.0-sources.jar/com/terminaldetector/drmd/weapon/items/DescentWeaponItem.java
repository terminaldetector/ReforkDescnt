package com.terminaldetector.drmd.weapon.items;

import com.terminaldetector.drmd.DescentPlayerData;
import com.terminaldetector.drmd.energy.EnergySystem;
import com.terminaldetector.drmd.weapon.core.DamageClass;
import com.terminaldetector.drmd.weapon.core.WeaponCore;
import com.terminaldetector.drmd.weapon.registry.WeaponDef;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

/**
 * Base DRMD weapon item — consumes shared energy and fires via WeaponCore.
 */
public class DescentWeaponItem extends Item {
	private final WeaponDef def;

	public DescentWeaponItem(WeaponDef def, Settings settings) {
		super(settings.maxCount(1));
		this.def = def;
	}

	public WeaponDef getDef() { return def; }

	@Override
	public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
		ItemStack stack = user.getStackInHand(hand);
		if (world.isClient) return TypedActionResult.pass(stack);

		DescentPlayerData data = DescentPlayerData.get(user);
		long now = world.getTime();
		long last = 0L;
		var custom = stack.get(net.minecraft.component.DataComponentTypes.CUSTOM_DATA);
		if (custom != null) last = custom.copyNbt().getLong("lastFire");
		int cdTicks = Math.max(1, (int) (def.fireRate * 20));
		if (now - last < cdTicks) return TypedActionResult.fail(stack);

		if (!fire(world, user, data, stack)) {
			return TypedActionResult.fail(stack);
		}

		NbtWrite.lastFire(stack, now);
		user.getItemCooldownManager().set(this, cdTicks);
		world.playSound(null, user.getX(), user.getY(), user.getZ(),
				SoundEvents.ENTITY_FIREWORK_ROCKET_LAUNCH, SoundCategory.PLAYERS, 0.6f, 1.2f);
		return TypedActionResult.success(stack);
	}

	protected boolean fire(World world, PlayerEntity user, DescentPlayerData data, ItemStack stack) {
		return switch (def.behavior) {
			case "laser" -> fireLaser(user, data);
			case "quad_laser" -> fireQuadLaser(user, data);
			case "rockets" -> fireRockets(user, data);
			case "plasma" -> firePlasma(user, data);
			case "flak" -> fireFlak(user, data);
			case "frag" -> fireFrag(user, data);
			case "beam" -> fireBeam(user, data);
			case "shockwave" -> fireShockwave(user, data);
			case "warp" -> fireWarp(user, data);
			case "telefrag" -> fireTelefrag(user, data);
			case "reactor" -> fireReactor(user, data);
			case "gravy" -> fireGravy(user, data);
			case "whiplash" -> fireWhiplash(user, data);
			case "darklance" -> fireDarklance(user, data);
			case "deploy" -> fireDeploy(user, data);
			case "bfg" -> fireBfg(user, data);
			case "rail" -> fireRail(user, data);
			case "homing" -> fireHoming(user, data);
			case "vulcan", "mg", "heavy", "basic" -> fireBasic(user, data);
			default -> fireBasic(user, data);
		};
	}

	protected boolean consumeEnergy(DescentPlayerData data, float cost) {
		if (cost <= 0) return true;
		return EnergySystem.tryConsume(data, "weapons", cost);
	}

	protected boolean fireBasic(PlayerEntity user, DescentPlayerData data) {
		if (!consumeEnergy(data, def.energyCost)) return false;
		WeaponCore.FireConfig cfg = baseCfg(user);
		cfg.directDamage = def.damage;
		cfg.splashDamage = def.splashDamage;
		cfg.splashRadius = def.splashRadius;
		cfg.speed = def.speed;
		cfg.recoil = def.recoil;
		cfg.dmgClass = def.dmgClass;
		WeaponCore.fireProjectile(cfg);
		return true;
	}

	protected boolean firePlasma(PlayerEntity user, DescentPlayerData data) {
		if (!consumeEnergy(data, def.energyCost)) return false;
		for (float side : new float[]{-0.25f, 0.25f}) {
			WeaponCore.FireConfig cfg = baseCfg(user);
			cfg.pos = WeaponCore.muzzle(user, 0.8f, side, -0.1f);
			cfg.directDamage = def.damage;
			cfg.splashDamage = def.splashDamage;
			cfg.splashRadius = def.splashRadius;
			cfg.speed = def.speed;
			cfg.recoil = def.recoil * 0.5f;
			cfg.dmgClass = DamageClass.EXOTIC;
			WeaponCore.fireProjectile(cfg);
		}
		return true;
	}

	protected boolean fireFlak(PlayerEntity user, DescentPlayerData data) {
		if (!consumeEnergy(data, def.energyCost)) return false;
		Vec3d aim = WeaponCore.aimDir(user);
		for (int i = 0; i < 12; i++) {
			Vec3d dir = spread(aim, 7f, user.getRandom());
			WeaponCore.FireConfig cfg = baseCfg(user);
			cfg.dir = dir;
			cfg.directDamage = def.damage;
			cfg.splashDamage = def.splashDamage;
			cfg.splashRadius = def.splashRadius;
			cfg.speed = def.speed;
			cfg.recoil = i == 0 ? def.recoil : 0;
			cfg.life = 1.2f;
			cfg.dmgClass = DamageClass.EXPLOSIVE;
			WeaponCore.fireProjectile(cfg);
		}
		return true;
	}

	protected boolean fireFrag(PlayerEntity user, DescentPlayerData data) {
		if (!consumeEnergy(data, def.energyCost)) return false;
		WeaponCore.FireConfig cfg = baseCfg(user);
		cfg.directDamage = def.damage;
		cfg.splashDamage = def.splashDamage;
		cfg.splashRadius = def.splashRadius;
		cfg.speed = def.speed;
		cfg.recoil = def.recoil;
		cfg.dmgClass = DamageClass.EXPLOSIVE;
		cfg.onHit = ctx -> {
			if (user.getWorld().isClient) return;
			for (int i = 0; i < 8; i++) {
				WeaponCore.FireConfig frag = new WeaponCore.FireConfig();
				frag.owner = user;
				frag.pos = ctx.hitPos();
				frag.dir = spread(new Vec3d(0, 1, 0), 180f, user.getRandom());
				frag.speed = 1200;
				frag.directDamage = 20;
				frag.life = 1.5f;
				frag.dmgClass = DamageClass.KINETIC;
				frag.inherit = 0;
				WeaponCore.fireProjectile(frag);
			}
		};
		WeaponCore.fireProjectile(cfg);
		return true;
	}

	protected boolean fireRockets(PlayerEntity user, DescentPlayerData data) {
		if (!consumeEnergy(data, def.energyCost)) return false;
		int sub = data.getRocketSubmode();
		int count = switch (sub) { case 1 -> 3; case 2 -> 6; default -> 1; };
		float speed = switch (sub) { case 1 -> 2600f; case 2 -> 2200f; case 3 -> 2000f; default -> 2800f; };
		boolean homing = sub == 2;
		boolean atomic = sub == 3;
		for (int i = 0; i < count; i++) {
			WeaponCore.FireConfig cfg = baseCfg(user);
			cfg.dir = count > 1 ? spread(WeaponCore.aimDir(user), 5f, user.getRandom()) : WeaponCore.aimDir(user);
			cfg.speed = speed;
			cfg.homing = homing;
			cfg.turnRate = 120f;
			cfg.directDamage = atomic ? 350 : 80;
			cfg.splashDamage = atomic ? 350 : 50;
			cfg.splashRadius = atomic ? 650 : 200;
			cfg.recoil = i == 0 ? (atomic ? 220 : 120) : 0;
			cfg.dmgClass = DamageClass.EXPLOSIVE;
			cfg.life = 6f;
			WeaponCore.fireProjectile(cfg);
		}
		return true;
	}

	protected boolean fireLaser(PlayerEntity user, DescentPlayerData data) {
		// Charge-style: spend up to 22 energy for scaled damage 40-150
		float spend = Math.min(22f, data.getEnergy());
		if (spend < 4f) return false;
		EnergySystem.tryConsume(data, "weapons", spend);
		float charge = spend / 22f;
		float dmg = 40f + 110f * charge;
		WeaponCore.hitscan(user, user.getEyePos(), WeaponCore.aimDir(user), 8000f, dmg, DamageClass.ENERGY, null);
		WeaponCore.applyRecoil(user, WeaponCore.aimDir(user), 30f * charge);
		return true;
	}

	protected boolean fireQuadLaser(PlayerEntity user, DescentPlayerData data) {
		if (!consumeEnergy(data, def.energyCost)) return false;
		for (float[] off : new float[][]{{-0.2f,0.1f},{0.2f,0.1f},{-0.2f,-0.1f},{0.2f,-0.1f}}) {
			Vec3d start = WeaponCore.muzzle(user, 0.5f, off[0], off[1]);
			WeaponCore.hitscan(user, start, WeaponCore.aimDir(user), 8000f, def.damage, DamageClass.ENERGY, null);
		}
		WeaponCore.applyRecoil(user, WeaponCore.aimDir(user), def.recoil);
		return true;
	}

	protected boolean fireBeam(PlayerEntity user, DescentPlayerData data) {
		if (!consumeEnergy(data, def.energyCost)) return false;
		WeaponCore.hitscan(user, user.getEyePos(), WeaponCore.aimDir(user), 4000f, def.damage, DamageClass.ENERGY, ctx -> {
			if (ctx.hitEntity() instanceof PlayerEntity ply) {
				DescentPlayerData td = DescentPlayerData.get(ply);
				td.setShield(Math.max(0, td.getShield() - 12f));
			}
		});
		return true;
	}

	protected boolean fireShockwave(PlayerEntity user, DescentPlayerData data) {
		if (!consumeEnergy(data, def.energyCost)) return false;
		if (user.getWorld() instanceof net.minecraft.server.world.ServerWorld sw) {
			WeaponCore.splashDamage(user, sw, user.getPos(), def.splashDamage, def.splashRadius > 20 ? (float)com.terminaldetector.drmd.DescentMod.su(def.splashRadius) : def.splashRadius, DamageClass.ENERGY);
		}
		return true;
	}

	protected boolean fireWarp(PlayerEntity user, DescentPlayerData data) {
		if (!consumeEnergy(data, def.energyCost)) return false;
		Vec3d dest = user.getPos().add(WeaponCore.aimDir(user).multiply(com.terminaldetector.drmd.DescentMod.su(700)));
		user.requestTeleport(dest.x, dest.y, dest.z);
		if (user.getWorld() instanceof net.minecraft.server.world.ServerWorld sw) {
			WeaponCore.splashDamage(user, sw, dest, def.damage, (float)com.terminaldetector.drmd.DescentMod.su(200), DamageClass.EXOTIC);
		}
		return true;
	}

	protected boolean fireTelefrag(PlayerEntity user, DescentPlayerData data) {
		if (!consumeEnergy(data, def.energyCost)) return false;
		LivingEntity target = findLookTarget(user, com.terminaldetector.drmd.DescentMod.su(4000));
		if (target == null) return false;
		user.requestTeleport(target.getX(), target.getY(), target.getZ());
		if (user.getWorld() instanceof net.minecraft.server.world.ServerWorld sw) {
			WeaponCore.splashDamage(user, sw, target.getPos(), def.damage, (float)com.terminaldetector.drmd.DescentMod.su(140), DamageClass.EXOTIC);
		}
		return true;
	}

	protected boolean fireReactor(PlayerEntity user, DescentPlayerData data) {
		float spend = Math.max(30f, data.getEnergy());
		if (!EnergySystem.tryConsume(data, "weapons", spend)) return false;
		float frac = spend / data.getEnergyMax();
		float dmg = 150f + 450f * frac;
		float rad = 300f + 600f * frac;
		if (user.getWorld() instanceof net.minecraft.server.world.ServerWorld sw) {
			WeaponCore.splashDamage(user, sw, user.getPos(), dmg, (float)com.terminaldetector.drmd.DescentMod.su(rad), DamageClass.EXPLOSIVE);
		}
		return true;
	}

	protected boolean fireGravy(PlayerEntity user, DescentPlayerData data) {
		// Simplified: spend gravy energy to launch a hypersonic kinetic bolt (prop rail analogue)
		if (data.getGravyEnergy() < 20f) return false;
		data.setGravyEnergy(data.getGravyEnergy() - 20f);
		WeaponCore.FireConfig cfg = baseCfg(user);
		cfg.speed = 18000;
		cfg.directDamage = 80;
		cfg.pierceCount = 3;
		cfg.dmgClass = DamageClass.EXOTIC;
		cfg.recoil = 40;
		cfg.life = 2f;
		WeaponCore.fireProjectile(cfg);
		return true;
	}

	protected boolean fireWhiplash(PlayerEntity user, DescentPlayerData data) {
		if (!consumeEnergy(data, def.energyCost)) return false;
		LivingEntity target = findLookTarget(user, com.terminaldetector.drmd.DescentMod.su(1500));
		if (target == null) {
			// Zip forward
			Vec3d dest = user.getPos().add(WeaponCore.aimDir(user).multiply(com.terminaldetector.drmd.DescentMod.su(800)));
			data.setFlightVelocity(WeaponCore.aimDir(user).multiply(com.terminaldetector.drmd.DescentMod.su(3200)));
			user.requestTeleport(dest.x, dest.y, dest.z);
			return true;
		}
		Vec3d mid = target.getPos();
		user.requestTeleport(mid.x, mid.y, mid.z);
		if (user.getWorld() instanceof net.minecraft.server.world.ServerWorld sw) {
			WeaponCore.splashDamage(user, sw, mid, def.damage, (float)com.terminaldetector.drmd.DescentMod.su(160), DamageClass.KINETIC);
		}
		return true;
	}

	protected boolean fireDarklance(PlayerEntity user, DescentPlayerData data) {
		if (!consumeEnergy(data, def.energyCost)) return false;
		Vec3d start = user.getEyePos();
		Vec3d dir = WeaponCore.aimDir(user);
		int hits = 0;
		for (int i = 0; i < 16 && hits < 8; i++) {
			WeaponCore.hitscan(user, start, dir, 2000f, def.damage, DamageClass.EXOTIC, ctx -> {});
			start = start.add(dir.multiply(com.terminaldetector.drmd.DescentMod.su(500)));
			hits++;
		}
		return true;
	}

	protected boolean fireDeploy(PlayerEntity user, DescentPlayerData data) {
		if (!consumeEnergy(data, def.energyCost)) return false;
		WeaponCore.FireConfig cfg = baseCfg(user);
		cfg.speed = def.speed > 0 ? def.speed : 900;
		cfg.directDamage = def.damage;
		cfg.splashDamage = def.splashDamage;
		cfg.splashRadius = def.splashRadius;
		cfg.gravity = 0.2f;
		cfg.life = 8f;
		cfg.dmgClass = def.dmgClass;
		cfg.recoil = 10;
		WeaponCore.fireProjectile(cfg);
		return true;
	}

	protected boolean fireBfg(PlayerEntity user, DescentPlayerData data) {
		if (!consumeEnergy(data, def.energyCost)) return false;
		WeaponCore.FireConfig cfg = baseCfg(user);
		cfg.speed = def.speed;
		cfg.directDamage = def.damage;
		cfg.splashDamage = def.splashDamage;
		cfg.splashRadius = def.splashRadius;
		cfg.dmgClass = DamageClass.EXOTIC;
		cfg.recoil = def.recoil;
		cfg.scale = 2.5f;
		cfg.life = 8f;
		cfg.onHit = ctx -> {
			if (!(user.getWorld() instanceof net.minecraft.server.world.ServerWorld sw)) return;
			int beams = 0;
			for (LivingEntity e : sw.getEntitiesByClass(LivingEntity.class, user.getBoundingBox().expand(24),
					ent -> ent != user && ent.isAlive())) {
				if (beams++ >= 16) break;
				WeaponCore.directDamage(user, e, 30f, DamageClass.EXOTIC);
			}
		};
		WeaponCore.fireProjectile(cfg);
		return true;
	}

	protected boolean fireRail(PlayerEntity user, DescentPlayerData data) {
		if (!consumeEnergy(data, def.energyCost)) return false;
		WeaponCore.FireConfig cfg = baseCfg(user);
		cfg.speed = def.speed;
		cfg.directDamage = def.damage;
		cfg.pierceCount = 5;
		cfg.dmgClass = DamageClass.KINETIC;
		cfg.recoil = def.recoil;
		cfg.life = 2f;
		WeaponCore.fireProjectile(cfg);
		return true;
	}

	protected boolean fireHoming(PlayerEntity user, DescentPlayerData data) {
		if (def.energyCost > 0 && !consumeEnergy(data, def.energyCost)) return false;
		WeaponCore.FireConfig cfg = baseCfg(user);
		cfg.speed = def.speed;
		cfg.directDamage = def.damage;
		cfg.splashDamage = def.splashDamage;
		cfg.splashRadius = def.splashRadius;
		cfg.homing = true;
		cfg.turnRate = 140f;
		cfg.homeTarget = findLookTarget(user, 48);
		cfg.dmgClass = DamageClass.EXPLOSIVE;
		cfg.recoil = def.recoil;
		cfg.life = 15f;
		WeaponCore.fireProjectile(cfg);
		return true;
	}

	protected WeaponCore.FireConfig baseCfg(PlayerEntity user) {
		WeaponCore.FireConfig cfg = new WeaponCore.FireConfig();
		cfg.owner = user;
		cfg.pos = WeaponCore.muzzle(user, 0.9f, 0.15f, -0.1f);
		cfg.dir = WeaponCore.aimDir(user);
		cfg.dmgClass = def.dmgClass;
		cfg.life = 5f;
		return cfg;
	}

	protected static Vec3d spread(Vec3d dir, float degrees, net.minecraft.util.math.random.Random random) {
		double yaw = Math.toRadians((random.nextDouble() - 0.5) * 2 * degrees);
		double pitch = Math.toRadians((random.nextDouble() - 0.5) * 2 * degrees);
		Vec3d d = dir.normalize();
		Vec3d right = d.crossProduct(new Vec3d(0, 1, 0));
		if (right.lengthSquared() < 1e-6) right = new Vec3d(1, 0, 0);
		right = right.normalize();
		Vec3d up = right.crossProduct(d).normalize();
		return d.add(right.multiply(Math.tan(yaw))).add(up.multiply(Math.tan(pitch))).normalize();
	}

	protected static LivingEntity findLookTarget(PlayerEntity user, double range) {
		Vec3d start = user.getEyePos();
		Vec3d end = start.add(WeaponCore.aimDir(user).multiply(range));
		LivingEntity best = null;
		double bestDot = 0.92;
		for (LivingEntity e : user.getWorld().getEntitiesByClass(LivingEntity.class,
				user.getBoundingBox().expand(range), ent -> ent != user && ent.isAlive())) {
			Vec3d to = e.getPos().add(0, e.getHeight() * 0.5, 0).subtract(start).normalize();
			double dot = to.dotProduct(WeaponCore.aimDir(user));
			if (dot > bestDot && start.squaredDistanceTo(e.getPos()) < range * range) {
				bestDot = dot;
				best = e;
			}
		}
		return best;
	}

	/** Helper for writing lastFire into custom data component. */
	public static final class NbtWrite {
		public static void lastFire(ItemStack stack, long time) {
			net.minecraft.component.type.NbtComponent existing = stack.getOrDefault(
					net.minecraft.component.DataComponentTypes.CUSTOM_DATA,
					net.minecraft.component.type.NbtComponent.DEFAULT);
			net.minecraft.nbt.NbtCompound nbt = existing.copyNbt();
			nbt.putLong("lastFire", time);
			stack.set(net.minecraft.component.DataComponentTypes.CUSTOM_DATA,
					net.minecraft.component.type.NbtComponent.of(nbt));
		}
	}
}
