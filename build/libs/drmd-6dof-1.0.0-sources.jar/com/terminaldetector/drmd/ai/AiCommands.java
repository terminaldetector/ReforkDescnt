package com.terminaldetector.drmd.ai;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.terminaldetector.drmd.entity.AirMineEntity;
import com.terminaldetector.drmd.entity.DroneEntity;
import com.terminaldetector.drmd.entity.ModEntities;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_3222;

public final class AiCommands {
	private AiCommands() {}

	public static void register() {
		CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
			LiteralArgumentBuilder<class_2168> root = class_2170.method_9247("6dof_spawn");
			for (AiRole role : AiRole.values()) {
				AiRole r = role;
				root.then(class_2170.method_9247(r.id).executes(ctx -> {
					spawn(ctx.getSource().method_44023(), r, 1);
					return 1;
				}));
			}
			dispatcher.register(root);

			dispatcher.register(class_2170.method_9247("6dof_spawn_squad")
					.then(class_2170.method_9244("n", IntegerArgumentType.integer(1, 16)).executes(ctx -> {
						int n = IntegerArgumentType.getInteger(ctx, "n");
						class_3222 p = ctx.getSource().method_44023();
						AiRole[] pool = {AiRole.ASSAULT, AiRole.INTERCEPTOR, AiRole.MG, AiRole.RPG, AiRole.LASER};
						for (int i = 0; i < n; i++) spawn(p, pool[i % pool.length], 1);
						return n;
					})));

			dispatcher.register(class_2170.method_9247("6dof_spawn_mine").executes(ctx -> {
				class_3222 p = ctx.getSource().method_44023();
				AirMineEntity mine = ModEntities.AIR_MINE.method_5883(p.method_51469());
				if (mine != null) {
					class_243 pos = p.method_19538().method_1019(p.method_5828(1f).method_1021(4));
					mine.method_5808(pos.field_1352, pos.field_1351, pos.field_1350, 0, 0);
					p.method_51469().method_8649(mine);
				}
				return 1;
			}));

			dispatcher.register(class_2170.method_9247("d6_kill_npcs")
					.requires(s -> s.method_9259(2))
					.executes(ctx -> {
						class_3222 p = ctx.getSource().method_44023();
						int n = 0;
						for (var e : p.method_51469().method_27909()) {
							if (e instanceof DroneEntity || e instanceof AirMineEntity) {
								e.method_31472();
								n++;
							}
						}
						int finalN = n;
						ctx.getSource().method_9226(() -> class_2561.method_43470("Removed " + finalN + " NPCs"), true);
						return n;
					}));
		});
	}

	private static void spawn(class_3222 player, AiRole role, int count) {
		for (int i = 0; i < count; i++) {
			DroneEntity drone = ModEntities.DRONE.method_5883(player.method_51469());
			if (drone == null) continue;
			class_243 look = player.method_5828(1f);
			class_243 pos = player.method_19538().method_1019(look.method_1021(6 + i)).method_1031(
					(player.method_59922().method_43058() - 0.5) * 3,
					1 + player.method_59922().method_43058() * 2,
					(player.method_59922().method_43058() - 0.5) * 3);
			drone.method_5808(pos.field_1352, pos.field_1351, pos.field_1350, player.method_36454(), 0);
			drone.applyRole(role);
			drone.method_5980(player);
			player.method_51469().method_8649(drone);
		}
	}
}
