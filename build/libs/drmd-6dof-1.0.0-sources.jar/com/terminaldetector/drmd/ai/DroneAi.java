package com.terminaldetector.drmd.ai;

import com.terminaldetector.drmd.DescentMod;
import com.terminaldetector.drmd.entity.DroneEntity;
import java.util.EnumSet;
import net.minecraft.class_1309;
import net.minecraft.class_1352;
import net.minecraft.class_243;
import net.minecraft.class_3532;

/**
 * Combat motion phases: ORBIT → RUN (dive/climb) → BREAK (+ barrel/split-s/immelmann).
 * Boids weights from d6_ai.lua: sep 2.8 / coh 0.8 / align 1.0 / target 2.2.
 */
public final class DroneAi {
	public enum Phase { ORBIT, RUN, BREAK }

	public static class CombatGoal extends class_1352 {
		private final DroneEntity drone;

		public CombatGoal(DroneEntity drone) {
			this.drone = drone;
			this.method_6265(EnumSet.of(class_4134.field_18405, class_4134.field_18406));
		}

		@Override
		public boolean method_6264() {
			return drone.method_5968() != null && drone.method_5968().method_5805();
		}

		@Override
		public void method_6268() {
			class_1309 target = drone.method_5968();
			if (target == null) return;
			float dt = 1f / 20f;
			drone.addPhaseTimer(dt);

			class_243 pos = drone.method_19538();
			class_243 tpos = target.method_19538().method_1031(0, target.method_17682() * 0.5, 0);
			class_243 toTarget = tpos.method_1020(pos);
			double dist = toTarget.method_1033();
			double preferred = DescentMod.su(drone.getRole().speed > 500 ? 500 : 700);

			Phase phase = drone.getPhase();
			if (phase == Phase.ORBIT && drone.getPhaseTimer() > 3f) drone.setPhase(Phase.RUN);
			else if (phase == Phase.RUN && drone.getPhaseTimer() > 1.5f) drone.setPhase(Phase.BREAK);
			else if (phase == Phase.BREAK && drone.getPhaseTimer() > 1.2f) drone.setPhase(Phase.ORBIT);

			class_243 desire;
			switch (drone.getPhase()) {
				case ORBIT -> {
					class_243 tangent = toTarget.method_1036(new class_243(0, 1, 0));
					if (tangent.method_1027() < 1e-4) tangent = new class_243(1, 0, 0);
					tangent = tangent.method_1029();
					double radial = class_3532.method_15350((dist - preferred) / preferred, -1, 1);
					desire = tangent.method_1021(2.2).method_1019(toTarget.method_1029().method_1021(-radial));
				}
				case RUN -> desire = toTarget.method_1029().method_1031(0, drone.method_59922().method_43056() ? 0.4 : -0.4, 0);
				case BREAK -> {
					class_243 away = pos.method_1020(tpos).method_1029();
					desire = away.method_1031(0, 0.6, 0).method_1019(drone.method_5720().method_1021(0.5));
				}
				default -> desire = toTarget.method_1029();
			}

			// Simple separation from nearby drones
			class_243 sep = class_243.field_1353;
			for (DroneEntity other : drone.method_37908().method_8390(DroneEntity.class,
					drone.method_5829().method_1014(DescentMod.su(90)), d -> d != drone)) {
				class_243 away = pos.method_1020(other.method_19538());
				double d = away.method_1033();
				if (d > 1e-3 && d < DescentMod.su(90)) {
					sep = sep.method_1019(away.method_1029().method_1021(2.8 / d));
				}
			}
			desire = desire.method_1019(sep).method_1029();

			double maxSpd = DescentMod.su(drone.getRole().speed);
			class_243 vel = desire.method_1021(maxSpd / 20.0);
			drone.method_18799(vel);
			drone.field_6037 = true;
			drone.method_5988().method_6226(target, 30f, 30f);

			if (dist < DescentMod.su(2000)) {
				drone.tryFireAt(target);
			}
		}
	}
}
