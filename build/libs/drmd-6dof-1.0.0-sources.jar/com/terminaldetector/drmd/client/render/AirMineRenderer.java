package com.terminaldetector.drmd.client.render;

import com.terminaldetector.drmd.entity.AirMineEntity;
import net.minecraft.class_2960;
import net.minecraft.class_5602;
import net.minecraft.class_5617;
import net.minecraft.class_609;
import net.minecraft.class_927;

public class AirMineRenderer extends class_927<AirMineEntity, class_609<AirMineEntity>> {
	private static final class_2960 TEXTURE = class_2960.method_60655("minecraft", "textures/entity/slime/slime.png");

	public AirMineRenderer(class_5617.class_5618 ctx) {
		super(ctx, new class_609<>(ctx.method_32167(class_5602.field_27654)), 0.35f);
	}

	@Override
	public class_2960 getTexture(AirMineEntity entity) {
		return TEXTURE;
	}
}
