package com.terminaldetector.drmd.client.render;

import com.terminaldetector.drmd.entity.ProjectileEntity;
import net.minecraft.class_2960;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_5617;
import net.minecraft.class_897;

public class ProjectileRenderer extends class_897<ProjectileEntity> {
	public ProjectileRenderer(class_5617.class_5618 ctx) {
		super(ctx);
	}

	@Override
	public void render(ProjectileEntity entity, float yaw, float tickDelta, class_4587 matrices,
					   class_4597 consumers, int light) {
		// Particles handle visual; keep shadow-less
		super.method_3936(entity, yaw, tickDelta, matrices, consumers, light);
	}

	@Override
	public class_2960 getTexture(ProjectileEntity entity) {
		return class_2960.method_60655("minecraft", "textures/misc/white.png");
	}
}
