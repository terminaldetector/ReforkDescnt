package com.terminaldetector.drmd.client.render;

import com.terminaldetector.drmd.entity.DroneEntity;
import net.minecraft.class_2960;
import net.minecraft.class_5602;
import net.minecraft.class_5617;
import net.minecraft.class_604;
import net.minecraft.class_927;

public class DroneRenderer extends class_927<DroneEntity, class_604<DroneEntity>> {
	private static final class_2960 TEXTURE = class_2960.method_60655("minecraft", "textures/entity/silverfish.png");

	public DroneRenderer(class_5617.class_5618 ctx) {
		super(ctx, new class_604<>(ctx.method_32167(class_5602.field_27598)), 0.4f);
	}

	@Override
	public class_2960 getTexture(DroneEntity entity) {
		return TEXTURE;
	}
}
