package com.terminaldetector.drmd.client.hud;

import com.terminaldetector.drmd.client.DescentClientState;
import com.terminaldetector.drmd.client.input.DescentKeybinds;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;

/**
 * Cockpit HUD — port of d6_cockpit.lua + d6_client.lua:
 * Shield/Hull/Energy bars, speed, roll, gravity warning, dash CD, weapon mode.
 */
public final class DescentHud {
	private DescentHud() {}

	public static void render(class_332 ctx, float tickDelta) {
		class_310 mc = class_310.method_1551();
		if (mc.field_1724 == null || mc.field_1690.field_1842 || !DescentClientState.enabled) return;

		int sw = mc.method_22683().method_4486();
		int sh = mc.method_22683().method_4502();

		// Crosshair
		int cx = sw / 2, cy = sh / 2;
		ctx.method_25294(cx - 8, cy, cx + 9, cy + 1, 0xAA00DCFF);
		ctx.method_25294(cx, cy - 8, cx + 1, cy + 9, 0xAA00DCFF);

		int left = 12;
		int bottom = sh - 14;

		drawBar(ctx, left, bottom - 36, 120, 8, DescentClientState.shield / Math.max(1f, DescentClientState.shieldMax), 0xFF33AADD, "SHIELD");
		float hp = mc.field_1724.method_6032() / mc.field_1724.method_6063();
		drawBar(ctx, left, bottom - 24, 120, 8, hp, 0xFFDD4433, "HULL");
		drawBar(ctx, left, bottom - 12, 120, 8, DescentClientState.energy / Math.max(1f, DescentClientState.energyMax), 0xFF44DD66, "ENERGY");

		// Right side info
		String[] lines = {
				String.format("SPD %.0f", DescentClientState.speed * 20),
				String.format("ROLL %.0f°", DescentClientState.roll),
				"PRESET " + DescentClientState.preset.toUpperCase(),
				"RKT " + rocketLabel(DescentClientState.rocketSub),
				DescentClientState.alwaysRun ? "ALWAYS-RUN" : "",
				DescentClientState.flightAssist ? "FA ON" : "FA OFF",
				String.format("GRAVY %.0f", DescentClientState.gravy)
		};
		int y = sh - 14 - lines.length * 10;
		for (String line : lines) {
			if (line == null || line.isEmpty()) { y += 10; continue; }
			ctx.method_27535(mc.field_1772, class_2561.method_43470(line), sw - 12 - mc.field_1772.method_1727(line), y, 0xFFCCEEFF);
			y += 10;
		}

		// Dash CD
		if (DescentClientState.dashCd > 0) {
			float pct = 1f - DescentClientState.dashCd / 1.8f;
			drawBar(ctx, cx - 40, cy + 18, 80, 3, pct, 0xFFFFAA00, null);
		}

		// Gravity warning
		if (DescentClientState.gravityFactor <= 0 && false) {
			// reserved
		}
		// Approximate idle warning via gravityFactor approaching
		if (DescentClientState.gravityFactor > 0 && DescentClientState.gravityFactor < 1f) {
			String warn = String.format("⚠ GRAVITY RAMP %.0f%%", DescentClientState.gravityFactor * 100);
			ctx.method_27534(mc.field_1772, class_2561.method_43470(warn), cx, 20, 0xFFFFCC33);
		} else if (DescentClientState.gravityFactor >= 1f) {
			ctx.method_27534(mc.field_1772, class_2561.method_43470("⚠ GRAVITY ACTIVE"), cx, 20, 0xFFFF4422);
		}

		// Hint strip
		String hint = "[H] 6DOF  [Shift] Dash  [R] Afterburn  [Z] Hook  [M] Workshop";
		ctx.method_27534(mc.field_1772, class_2561.method_43470(hint), cx, sh - 10, 0x88AABBCC);
	}

	private static String rocketLabel(int sub) {
		return switch (sub) {
			case 1 -> "×3 VOLLEY";
			case 2 -> "×6 HOMING";
			case 3 -> "☢ ATOMIC";
			default -> "×1 DIRECT";
		};
	}

	private static void drawBar(class_332 ctx, int x, int y, int w, int h, float pct, int color, String label) {
		pct = Math.max(0f, Math.min(1f, pct));
		ctx.method_25294(x - 1, y - 1, x + w + 1, y + h + 1, 0x88000000);
		ctx.method_25294(x, y, x + w, y + h, 0xFF222222);
		ctx.method_25294(x, y, x + (int) (w * pct), y + h, color);
		if (label != null) {
			class_310 mc = class_310.method_1551();
			ctx.method_27535(mc.field_1772, class_2561.method_43470(label), x + w + 6, y - 1, 0xFFCCDDEE);
		}
	}
}
