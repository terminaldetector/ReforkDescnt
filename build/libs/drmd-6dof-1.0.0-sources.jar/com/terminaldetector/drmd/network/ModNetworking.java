package com.terminaldetector.drmd.network;

import com.terminaldetector.drmd.DescentMod;
import com.terminaldetector.drmd.DescentPlayerData;
import com.terminaldetector.drmd.energy.EnergyPreset;
import com.terminaldetector.drmd.energy.EnergySystem;
import com.terminaldetector.drmd.flight.FlightSystem;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public final class ModNetworking {
	public static final class_2960 INPUT_ID = class_2960.method_60655(DescentMod.MOD_ID, "input");
	public static final class_2960 SYNC_ID = class_2960.method_60655(DescentMod.MOD_ID, "sync");
	public static final class_2960 ACTION_ID = class_2960.method_60655(DescentMod.MOD_ID, "action");

	public record InputPayload(float forward, float strafe, float vertical, float roll,
							   boolean dash, boolean hook) implements class_8710 {
		public static final class_9154<InputPayload> ID = new class_9154<>(INPUT_ID);
		public static final class_9139<class_9129, InputPayload> CODEC = class_9139.method_58025(
				class_9135.field_48552, InputPayload::forward,
				class_9135.field_48552, InputPayload::strafe,
				class_9135.field_48552, InputPayload::vertical,
				class_9135.field_48552, InputPayload::roll,
				class_9135.field_48547, InputPayload::dash,
				class_9135.field_48547, InputPayload::hook,
				InputPayload::new
		);
		@Override public class_9154<? extends class_8710> method_56479() { return ID; }
	}

	public record SyncPayload(boolean enabled, float energy, float energyMax, float shield, float shieldMax,
							  float roll, float speed, int rocketSub, String preset, float gravy,
							  float dashCd, float gravityFactor, boolean alwaysRun, boolean flightAssist,
							  boolean radar) implements class_8710 {
		public static final class_9154<SyncPayload> ID = new class_9154<>(SYNC_ID);
		public static final class_9139<class_9129, SyncPayload> CODEC = class_9139.method_56438(
				(payload, buf) -> {
					buf.method_52964(payload.enabled);
					buf.method_52941(payload.energy);
					buf.method_52941(payload.energyMax);
					buf.method_52941(payload.shield);
					buf.method_52941(payload.shieldMax);
					buf.method_52941(payload.roll);
					buf.method_52941(payload.speed);
					buf.method_10804(payload.rocketSub);
					buf.method_10814(payload.preset);
					buf.method_52941(payload.gravy);
					buf.method_52941(payload.dashCd);
					buf.method_52941(payload.gravityFactor);
					buf.method_52964(payload.alwaysRun);
					buf.method_52964(payload.flightAssist);
					buf.method_52964(payload.radar);
				},
				buf -> new SyncPayload(
						buf.readBoolean(),
						buf.readFloat(),
						buf.readFloat(),
						buf.readFloat(),
						buf.readFloat(),
						buf.readFloat(),
						buf.readFloat(),
						buf.method_10816(),
						buf.method_19772(),
						buf.readFloat(),
						buf.readFloat(),
						buf.readFloat(),
						buf.readBoolean(),
						buf.readBoolean(),
						buf.readBoolean()
				)
		);
		@Override public class_9154<? extends class_8710> method_56479() { return ID; }
	}

	public record ActionPayload(String action) implements class_8710 {
		public static final class_9154<ActionPayload> ID = new class_9154<>(ACTION_ID);
		public static final class_9139<class_9129, ActionPayload> CODEC = class_9139.method_56434(
				class_9135.field_48554, ActionPayload::action, ActionPayload::new
		);
		@Override public class_9154<? extends class_8710> method_56479() { return ID; }
	}

	private ModNetworking() {}

	public static void register() {
		PayloadTypeRegistry.playC2S().register(InputPayload.ID, InputPayload.CODEC);
		PayloadTypeRegistry.playC2S().register(ActionPayload.ID, ActionPayload.CODEC);
		PayloadTypeRegistry.playS2C().register(SyncPayload.ID, SyncPayload.CODEC);

		ServerPlayNetworking.registerGlobalReceiver(InputPayload.ID, (payload, context) -> {
			class_3222 player = context.player();
			FlightSystem.InputState in = FlightSystem.input(player);
			in.forward = payload.forward();
			in.strafe = payload.strafe();
			in.vertical = payload.vertical();
			in.roll = payload.roll();
			if (payload.dash()) in.dash = true;
			if (payload.hook()) FlightSystem.toggleHook(player);
		});

		ServerPlayNetworking.registerGlobalReceiver(ActionPayload.ID, (payload, context) -> {
			class_3222 player = context.player();
			DescentPlayerData data = DescentPlayerData.get(player);
			switch (payload.action()) {
				case "toggle" -> FlightSystem.toggle(player);
				case "dash" -> FlightSystem.tryDash(player);
				case "alwaysrun" -> data.setAlwaysRun(!data.isAlwaysRun());
				case "flightassist" -> data.setFlightAssist(!data.isFlightAssist());
				case "radar" -> data.setRadarEnabled(!data.isRadarEnabled());
				case "rocket_next" -> data.setRocketSubmode(data.getRocketSubmode() + 1);
				case "reset_roll" -> { data.setRoll(0); data.setRollVel(0); }
				case "preset_balanced" -> EnergySystem.setPreset(data, EnergyPreset.BALANCED);
				case "preset_assault" -> EnergySystem.setPreset(data, EnergyPreset.ASSAULT);
				case "preset_interceptor" -> EnergySystem.setPreset(data, EnergyPreset.INTERCEPTOR);
				case "preset_siege" -> EnergySystem.setPreset(data, EnergyPreset.SIEGE);
				default -> {}
			}
			syncPlayer(player, data);
		});
	}

	public static void syncPlayer(class_3222 player, DescentPlayerData data) {
		float speed = (float) data.getFlightVelocity().method_1033();
		ServerPlayNetworking.send(player, new SyncPayload(
				data.isEnabled(),
				data.getEnergy(), data.getEnergyMax(),
				data.getShield(), data.getShieldMax(),
				data.getRoll(), speed,
				data.getRocketSubmode(),
				data.getPreset().id,
				data.getGravyEnergy(),
				data.getDashCooldown(),
				data.getGravityFactor(),
				data.isAlwaysRun(),
				data.isFlightAssist(),
				data.isRadarEnabled()
		));
	}
}
