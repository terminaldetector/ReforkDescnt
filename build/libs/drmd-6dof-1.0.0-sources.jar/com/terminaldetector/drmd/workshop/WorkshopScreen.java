package com.terminaldetector.drmd.workshop;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;

/**
 * Weapon Workshop UI — 4 tabs (Stats / Projectile / Flak / Guidance) + templates + code export.
 * Port of SCK menu/workshop.lua schema-driven editors.
 */
public class WorkshopScreen extends class_437 {
	private enum Tab { STATS, PROJECTILE, FLAK, GUIDANCE }

	private Tab tab = Tab.STATS;
	private WeaponConfig config = new WeaponConfig();
	private final List<class_342> fields = new ArrayList<>();
	private String status = "Ready";

	public WorkshopScreen() {
		super(class_2561.method_43470("DRMD Weapon Workshop"));
	}

	@Override
	protected void method_25426() {
		method_37067();
		fields.clear();
		int bx = 10;
		method_37063(class_4185.method_46430(class_2561.method_43470("Stats"), b -> switchTab(Tab.STATS))
				.method_46434(bx, 8, 60, 18).method_46431());
		method_37063(class_4185.method_46430(class_2561.method_43470("Projectile"), b -> switchTab(Tab.PROJECTILE))
				.method_46434(bx + 64, 8, 70, 18).method_46431());
		method_37063(class_4185.method_46430(class_2561.method_43470("Flak"), b -> switchTab(Tab.FLAK))
				.method_46434(bx + 138, 8, 50, 18).method_46431());
		method_37063(class_4185.method_46430(class_2561.method_43470("Guidance"), b -> switchTab(Tab.GUIDANCE))
				.method_46434(bx + 192, 8, 70, 18).method_46431());

		method_37063(class_4185.method_46430(class_2561.method_43470("Cannon"), b -> loadTemplate("cannon"))
				.method_46434(field_22789 - 210, 8, 60, 18).method_46431());
		method_37063(class_4185.method_46430(class_2561.method_43470("Missile"), b -> loadTemplate("missile"))
				.method_46434(field_22789 - 146, 8, 60, 18).method_46431());
		method_37063(class_4185.method_46430(class_2561.method_43470("Flak T"), b -> loadTemplate("flak"))
				.method_46434(field_22789 - 82, 8, 40, 18).method_46431());
		method_37063(class_4185.method_46430(class_2561.method_43470("Seeker"), b -> loadTemplate("seeker"))
				.method_46434(field_22789 - 38, 8, 30, 18).method_46431());

		method_37063(class_4185.method_46430(class_2561.method_43470("Copy Java"), b -> {
			String code = CodeGenerator.generateJava(config);
			if (field_22787 != null) field_22787.field_1774.method_1455(code);
			status = "Copied generated Java to clipboard";
		}).method_46434(10, field_22790 - 24, 90, 18).method_46431());

		method_37063(class_4185.method_46430(class_2561.method_43470("Close"), b -> method_25419())
				.method_46434(field_22789 - 70, field_22790 - 24, 60, 18).method_46431());

		rebuildFields();
	}

	private void switchTab(Tab t) {
		flushFields();
		tab = t;
		method_25426();
	}

	private void loadTemplate(String name) {
		config = WeaponConfig.template(name);
		status = "Loaded template: " + name;
		method_25426();
	}

	private Map<String, Object> currentMap() {
		return switch (tab) {
			case STATS -> config.weapon;
			case PROJECTILE -> config.projectile;
			case FLAK -> config.flak;
			case GUIDANCE -> config.guidance;
		};
	}

	private List<WeaponSchema.Field> currentSchema() {
		return switch (tab) {
			case STATS -> WeaponSchema.WEAPON;
			case PROJECTILE -> WeaponSchema.PROJECTILE;
			case FLAK -> WeaponSchema.FLAK;
			case GUIDANCE -> WeaponSchema.GUIDANCE;
		};
	}

	private void rebuildFields() {
		Map<String, Object> data = currentMap();
		List<WeaponSchema.Field> schema = currentSchema();
		int y = 36;
		String lastSection = "";
		for (WeaponSchema.Field f : schema) {
			if (!f.section().equals(lastSection)) {
				lastSection = f.section();
				y += 6;
			}
			class_342 tf = new class_342(field_22793, 120, y, 160, 16, class_2561.method_43470(f.label()));
			tf.method_1852(String.valueOf(data.getOrDefault(f.key(), f.defaultValue())));
			tf.method_1863(s -> data.put(f.key(), parse(f, s)));
			fields.add(tf);
			method_25429(tf);
			y += 20;
			if (y > field_22790 - 40) break;
		}
	}

	private Object parse(WeaponSchema.Field f, String s) {
		try {
			return switch (f.type()) {
				case INT -> Integer.parseInt(s.trim());
				case FLOAT -> Float.parseFloat(s.trim());
				case BOOL -> Boolean.parseBoolean(s.trim());
				case ENUM, STRING -> s;
			};
		} catch (Exception e) {
			return f.defaultValue();
		}
	}

	private void flushFields() {
		List<WeaponSchema.Field> schema = currentSchema();
		Map<String, Object> data = currentMap();
		for (int i = 0; i < fields.size() && i < schema.size(); i++) {
			data.put(schema.get(i).key(), parse(schema.get(i), fields.get(i).method_1882()));
		}
	}

	@Override
	public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
		method_25420(context, mouseX, mouseY, delta);
		context.method_27534(field_22793, field_22785, field_22789 / 2, 12, 0xFFFFFF);
		List<WeaponSchema.Field> schema = currentSchema();
		int y = 36;
		String lastSection = "";
		int i = 0;
		for (WeaponSchema.Field f : schema) {
			if (i >= fields.size()) break;
			if (!f.section().equals(lastSection)) {
				lastSection = f.section();
				context.method_27535(field_22793, class_2561.method_43470("§e" + lastSection), 10, y, 0xFFFFAA);
				y += 6;
			}
			context.method_27535(field_22793, class_2561.method_43470(f.label()), 10, y + 4, 0xCCDDEE);
			fields.get(i).method_46419(y);
			fields.get(i).method_25394(context, mouseX, mouseY, delta);
			y += 20;
			i++;
		}
		context.method_27535(field_22793, class_2561.method_43470(status), 110, field_22790 - 20, 0x88FF88);
		super.method_25394(context, mouseX, mouseY, delta);
	}

	@Override
	public boolean method_25421() {
		return false;
	}
}
