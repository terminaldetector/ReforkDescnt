package com.terminaldetector.drmd.workshop;

import com.terminaldetector.drmd.network.ModNetworking;
import com.terminaldetector.drmd.weapon.items.DescentWeaponItem;
import com.terminaldetector.drmd.weapon.registry.WeaponRegistry;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Weapon Workshop — Stats / Projectile / Flak / Guidance / Clusters.
 * Clusters tab ports SCK menu/clusters.lua and applies to live weapons via ConstructionRegistry.
 */
public class WorkshopScreen extends class_437 {
	private enum Tab { STATS, PROJECTILE, FLAK, GUIDANCE, CLUSTERS }

	private Tab tab = Tab.STATS;
	private WeaponConfig config = new WeaponConfig();
	private final List<class_342> fields = new ArrayList<>();
	private String status = "Ready — construction adapted to DRMD weapons";
	private String selectedCluster = "Center";
	private int selectedModule = -1;
	private final List<class_4185> clusterButtons = new ArrayList<>();

	public WorkshopScreen() {
		super(class_2561.method_43470("DRMD Weapon Workshop"));
	}

	@Override
	protected void method_25426() {
		method_37067();
		fields.clear();
		clusterButtons.clear();

		int bx = 8;
		addTab("Stats", Tab.STATS, bx, 60);
		addTab("Projectile", Tab.PROJECTILE, bx + 64, 72);
		addTab("Flak", Tab.FLAK, bx + 140, 50);
		addTab("Guidance", Tab.GUIDANCE, bx + 194, 70);
		addTab("Clusters", Tab.CLUSTERS, bx + 268, 70);

		method_37063(class_4185.method_46430(class_2561.method_43470("Cannon"), b -> loadTemplate("cannon"))
				.method_46434(field_22789 - 250, 8, 56, 18).method_46431());
		method_37063(class_4185.method_46430(class_2561.method_43470("Missile"), b -> loadTemplate("missile"))
				.method_46434(field_22789 - 190, 8, 56, 18).method_46431());
		method_37063(class_4185.method_46430(class_2561.method_43470("Flak T"), b -> loadTemplate("flak"))
				.method_46434(field_22789 - 130, 8, 48, 18).method_46431());
		method_37063(class_4185.method_46430(class_2561.method_43470("Seeker"), b -> loadTemplate("seeker"))
				.method_46434(field_22789 - 78, 8, 48, 18).method_46431());

		method_37063(class_4185.method_46430(class_2561.method_43470("Copy Java"), b -> {
			flushFields();
			String code = CodeGenerator.generateJava(config);
			if (field_22787 != null) field_22787.field_1774.method_1455(code);
			status = "Copied Java + clusters to clipboard";
		}).method_46434(10, field_22790 - 24, 80, 18).method_46431());

		method_37063(class_4185.method_46430(class_2561.method_43470("Load Held"), b -> loadHeldWeapon())
				.method_46434(96, field_22790 - 24, 70, 18).method_46431());

		method_37063(class_4185.method_46430(class_2561.method_43470("Apply Build"), b -> applyConstruction())
				.method_46434(172, field_22790 - 24, 80, 18).method_46431());

		method_37063(class_4185.method_46430(class_2561.method_43470("Reset Layout"), b -> resetLayout())
				.method_46434(258, field_22790 - 24, 80, 18).method_46431());

		method_37063(class_4185.method_46430(class_2561.method_43470("Close"), b -> method_25419())
				.method_46434(field_22789 - 70, field_22790 - 24, 60, 18).method_46431());

		if (tab == Tab.CLUSTERS) rebuildClusterUi();
		else rebuildFields();
	}

	private void addTab(String label, Tab t, int x, int w) {
		method_37063(class_4185.method_46430(class_2561.method_43470(label), b -> switchTab(t))
				.method_46434(x, 8, w, 18).method_46431());
	}

	private void switchTab(Tab t) {
		flushFields();
		tab = t;
		method_25426();
	}

	private void loadTemplate(String name) {
		config = WeaponConfig.template(name);
		status = "Loaded template: " + name + " (clusters from " + config.targetWeaponId + ")";
		method_25426();
	}

	private void loadHeldWeapon() {
		class_310 mc = class_310.method_1551();
		if (mc.field_1724 == null) return;
		class_1799 stack = mc.field_1724.method_6047();
		if (!(stack.method_7909() instanceof DescentWeaponItem wep)) {
			status = "Hold a DRMD weapon to load its construction";
			return;
		}
		String id = wep.getDef().id;
		config = WeaponConfig.fromExistingWeapon(id);
		var def = WeaponRegistry.get(id);
		if (def != null) {
			config.weapon.put("PrintName", def.displayName);
			config.weapon.put("FireRate", def.fireRate);
			config.weapon.put("Damage", def.damage);
			config.weapon.put("EnergyCost", def.energyCost);
			config.weapon.put("SplashRadius", def.splashRadius);
			config.projectile.put("InitialVelocity", def.speed);
		}
		status = "Loaded construction for weapon_d6_" + id
				+ (ConstructionRegistry.hasOverride(id) ? " (override)" : " (default layout)");
		tab = Tab.CLUSTERS;
		method_25426();
	}

	private void applyConstruction() {
		flushFields();
		String id = config.targetWeaponId;
		if (id == null || id.isEmpty()) {
			id = ConstructionRegistry.normalize(String.valueOf(config.weapon.get("ClassName")));
			config.targetWeaponId = id;
		}
		List<ClusterModule> mods = new ArrayList<>();
		for (ClusterModule m : config.clusters) mods.add(m.copy());
		WeaponClusters.sort(mods);

		// Persist locally + ask server
		ConstructionRegistry.setOverride(id, mods);
		ClientPlayNetworking.send(new ModNetworking.ConstructionPayload(id, ClusterModule.listToNbt(mods)));
		status = "Applied construction to weapon_d6_" + id + " (" + mods.size() + " modules, "
				+ WeaponClusters.extractMuzzles(mods).size() + " muzzles)";
	}

	private void resetLayout() {
		String id = config.targetWeaponId;
		ConstructionRegistry.clearOverride(id);
		ClientPlayNetworking.send(new ModNetworking.ConstructionPayload(id, new net.minecraft.class_2499()));
		config.loadDefaultClusters(id);
		status = "Reset " + id + " to default Doom-style layout";
		method_25426();
	}

	private Map<String, Object> currentMap() {
		return switch (tab) {
			case STATS -> config.weapon;
			case PROJECTILE -> config.projectile;
			case FLAK -> config.flak;
			case GUIDANCE -> config.guidance;
			case CLUSTERS -> config.weapon; // unused
		};
	}

	private List<WeaponSchema.Field> currentSchema() {
		return switch (tab) {
			case STATS -> WeaponSchema.WEAPON;
			case PROJECTILE -> WeaponSchema.PROJECTILE;
			case FLAK -> WeaponSchema.FLAK;
			case GUIDANCE -> WeaponSchema.GUIDANCE;
			case CLUSTERS -> List.of();
		};
	}

	private void rebuildFields() {
		Map<String, Object> data = currentMap();
		List<WeaponSchema.Field> schema = currentSchema();
		int y = 36;
		String lastSection = "";
		for (WeaponSchema.Field f : schema) {
			if (!f.section().equals(lastSection)) {
				lastSection = f.section();
				y += 6;
			}
			class_342 tf = new class_342(field_22793, 120, y, 160, 16, class_2561.method_43470(f.label()));
			tf.method_1852(String.valueOf(data.getOrDefault(f.key(), f.defaultValue())));
			tf.method_1863(s -> data.put(f.key(), parse(f, s)));
			fields.add(tf);
			method_25429(tf);
			y += 20;
			if (y > field_22790 - 40) break;
		}
	}

	private void rebuildClusterUi() {
		int y = 32;
		// Target weapon id field
		class_342 target = new class_342(field_22793, 120, y, 120, 16, class_2561.method_43470("target"));
		target.method_1852(config.targetWeaponId);
		target.method_1863(s -> config.targetWeaponId = ConstructionRegistry.normalize(s));
		fields.add(target);
		method_25429(target);

		method_37063(class_4185.method_46430(class_2561.method_43470("Load Defaults"), b -> {
			config.loadDefaultClusters(config.targetWeaponId);
			status = "Loaded default layout for " + config.targetWeaponId;
			method_25426();
		}).method_46434(250, y, 90, 16).method_46431());

		y = 54;
		for (int i = 0; i < WeaponClusters.ORDER.length; i++) {
			String cn = WeaponClusters.ORDER[i];
			int fi = i;
			class_4185 btn = class_4185.method_46430(class_2561.method_43470(cn), b -> {
				selectedCluster = cn;
				selectedModule = -1;
				method_25426();
			}).method_46434(10 + i * 70, y, 66, 18).method_46431();
			clusterButtons.add(btn);
			method_37063(btn);
		}

		y = 80;
		List<ClusterModule> inZone = WeaponClusters.inCluster(config.clusters, selectedCluster);
		method_37063(class_4185.method_46430(class_2561.method_43470("+ Module"), b -> {
			ClusterModule m = WeaponClusters.make(selectedCluster, inZone.size() + 1,
					"mod_" + (inZone.size() + 1), "barrel", 19, 0, 0, 1f, true, config.clusters.size() + 1);
			config.clusters.add(m);
			WeaponClusters.sort(config.clusters);
			selectedModule = WeaponClusters.inCluster(config.clusters, selectedCluster).size() - 1;
			status = "Added module to " + selectedCluster;
			method_25426();
		}).method_46434(10, y, 70, 16).method_46431());

		method_37063(class_4185.method_46430(class_2561.method_43470("− Remove"), b -> {
			List<ClusterModule> zone = WeaponClusters.inCluster(config.clusters, selectedCluster);
			if (selectedModule >= 0 && selectedModule < zone.size()) {
				config.clusters.remove(zone.get(selectedModule));
				selectedModule = -1;
				status = "Removed module";
				method_25426();
			}
		}).method_46434(86, y, 70, 16).method_46431());

		method_37063(class_4185.method_46430(class_2561.method_43470("Toggle Muzzle"), b -> {
			List<ClusterModule> zone = WeaponClusters.inCluster(config.clusters, selectedCluster);
			if (selectedModule >= 0 && selectedModule < zone.size()) {
				ClusterModule m = zone.get(selectedModule);
				m.muzzle = !m.muzzle;
				if (m.muzzle && m.muzzleIdx <= 0) m.muzzleIdx = 1;
				status = m.name + " muzzle=" + m.muzzle + " idx=" + m.muzzleIdx;
				method_25426();
			}
		}).method_46434(162, y, 90, 16).method_46431());

		y = 102;
		List<ClusterModule> zone = WeaponClusters.inCluster(config.clusters, selectedCluster);
		for (int i = 0; i < zone.size(); i++) {
			ClusterModule m = zone.get(i);
			int idx = i;
			String label = String.format("#%d %s [%s] %s", m.slot, m.name, m.model,
					m.muzzle ? "M" + m.muzzleIdx : "-");
			method_37063(class_4185.method_46430(class_2561.method_43470(label), b -> {
				selectedModule = idx;
				method_25426();
			}).method_46434(10, y, 220, 14).method_46431());
			y += 16;
			if (y > field_22790 - 120) break;
		}

		// Edit selected module transforms
		if (selectedModule >= 0 && selectedModule < zone.size()) {
			ClusterModule m = zone.get(selectedModule);
			int ey = Math.min(y + 8, field_22790 - 110);
			addEdit(ey, "fwd", m.posFwd, v -> m.posFwd = v);
			addEdit(ey + 18, "rgt", m.posRgt, v -> m.posRgt = v);
			addEdit(ey + 36, "up", m.posUp, v -> m.posUp = v);
			addEdit(ey + 54, "scale", m.scaleX, v -> m.scaleX = m.scaleY = m.scaleZ = v);
			addEdit(ey + 72, "muzzleIdx", m.muzzleIdx, v -> m.muzzleIdx = Math.max(1, v.intValue()));

			class_342 nameF = new class_342(field_22793, field_22789 - 160, ey, 140, 14, class_2561.method_43470("name"));
			nameF.method_1852(m.name);
			nameF.method_1863(s -> m.name = s);
			fields.add(nameF);
			method_25429(nameF);

			class_342 modelF = new class_342(field_22793, field_22789 - 160, ey + 18, 140, 14, class_2561.method_43470("model"));
			modelF.method_1852(m.model);
			modelF.method_1863(s -> m.model = s);
			fields.add(modelF);
			method_25429(modelF);
		}
	}

	private void addEdit(int y, String label, float value, java.util.function.Consumer<Float> setter) {
		class_342 tf = new class_342(field_22793, field_22789 - 160, y, 60, 14, class_2561.method_43470(label));
		tf.method_1852(String.valueOf(value));
		tf.method_1863(s -> {
			try { setter.accept(Float.parseFloat(s.trim())); } catch (Exception ignored) {}
		});
		fields.add(tf);
		method_25429(tf);
	}

	private Object parse(WeaponSchema.Field f, String s) {
		try {
			return switch (f.type()) {
				case INT -> Integer.parseInt(s.trim());
				case FLOAT -> Float.parseFloat(s.trim());
				case BOOL -> Boolean.parseBoolean(s.trim());
				case ENUM, STRING -> s;
			};
		} catch (Exception e) {
			return f.defaultValue();
		}
	}

	private void flushFields() {
		if (tab == Tab.CLUSTERS) return;
		List<WeaponSchema.Field> schema = currentSchema();
		Map<String, Object> data = currentMap();
		for (int i = 0; i < fields.size() && i < schema.size(); i++) {
			data.put(schema.get(i).key(), parse(schema.get(i), fields.get(i).method_1882()));
		}
		Object cn = data.get("ClassName");
		if (cn != null) config.targetWeaponId = ConstructionRegistry.normalize(String.valueOf(cn));
	}

	@Override
	public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
		method_25420(context, mouseX, mouseY, delta);
		context.method_27534(field_22793, field_22785, field_22789 / 2, 12, 0xFFFFFF);

		if (tab == Tab.CLUSTERS) {
			renderClusters(context);
		} else {
			List<WeaponSchema.Field> schema = currentSchema();
			int y = 36;
			String lastSection = "";
			int i = 0;
			for (WeaponSchema.Field f : schema) {
				if (i >= fields.size()) break;
				if (!f.section().equals(lastSection)) {
					lastSection = f.section();
					context.method_27535(field_22793, class_2561.method_43470("§e" + lastSection), 10, y, 0xFFFFAA);
					y += 6;
				}
				context.method_27535(field_22793, class_2561.method_43470(f.label()), 10, y + 4, 0xCCDDEE);
				fields.get(i).method_46419(y);
				fields.get(i).method_25394(context, mouseX, mouseY, delta);
				y += 20;
				i++;
			}
		}

		for (class_342 tf : fields) {
			if (tab == Tab.CLUSTERS) tf.method_25394(context, mouseX, mouseY, delta);
		}

		context.method_27535(field_22793, class_2561.method_43470(status), 10, field_22790 - 38, 0x88FF88);
		super.method_25394(context, mouseX, mouseY, delta);
	}

	private void renderClusters(class_332 context) {
		context.method_27535(field_22793, class_2561.method_43470("Target weapon id"), 10, 34, 0xCCDDEE);
		context.method_27535(field_22793,
				class_2561.method_43470("§e" + selectedCluster + "§r — "
						+ WeaponClusters.LABELS[WeaponClusters.rank(selectedCluster)]),
				10, 74, 0xFFFFFF);

		// Schematic preview of modules relative to camera
		int px = field_22789 - 170, py = 54, pw = 150, ph = 90;
		context.method_25294(px, py, px + pw, py + ph, 0x88000000);
		context.method_25294(px, py, px + pw, py + 1, 0xFF445566);
		context.method_25294(px, py + ph - 1, px + pw, py + ph, 0xFF445566);
		context.method_25294(px, py, px + 1, py + ph, 0xFF445566);
		context.method_25294(px + pw - 1, py, px + pw, py + ph, 0xFF445566);
		context.method_27534(field_22793, class_2561.method_43470("VIEW"), px + pw / 2, py + 2, 0x8899AA);
		int cx = px + pw / 2, cy = py + ph / 2 + 6;
		for (ClusterModule m : config.clusters) {
			int col = colorFor(m.cluster);
			int mx = cx + (int) (m.posRgt * 1.6f);
			int my = cy - (int) (m.posUp * 1.6f);
			int s = Math.max(3, (int) (4 * m.scaleX));
			context.method_25294(mx - s, my - s, mx + s, my + s, col);
			if (m.muzzle) context.method_25294(mx - 1, my - 1, mx + 2, my + 2, 0xFFFFFFFF);
		}
		context.method_25294(cx - 2, cy - 2, cx + 3, cy + 3, 0xFF00DCFF); // camera

		if (selectedModule >= 0) {
			context.method_27535(field_22793, class_2561.method_43470("name"), field_22789 - 200, Math.min(field_22790 - 110, 110), 0xAAAAAA);
			context.method_27535(field_22793, class_2561.method_43470("model"), field_22789 - 200, Math.min(field_22790 - 92, 128), 0xAAAAAA);
			int ey = Math.min(WeaponClusters.inCluster(config.clusters, selectedCluster).size() * 16 + 110, field_22790 - 110);
			String[] labs = {"fwd", "rgt", "up", "scale", "mIdx"};
			for (int i = 0; i < labs.length; i++) {
				context.method_27535(field_22793, class_2561.method_43470(labs[i]), field_22789 - 200, ey + i * 18, 0xAAAAAA);
			}
		}

		int muzzles = WeaponClusters.extractMuzzles(config.clusters).size();
		context.method_27535(field_22793,
				class_2561.method_43470("Modules: " + config.clusters.size() + "  Muzzles: " + muzzles
						+ (ConstructionRegistry.hasOverride(config.targetWeaponId) ? "  §aOVERRIDE" : "  §7default")),
				10, field_22790 - 52, 0xAACCFF);
	}

	private static int colorFor(String cluster) {
		int i = WeaponClusters.rank(cluster);
		int[] c = WeaponClusters.COLORS[i];
		return 0xFF000000 | (c[0] << 16) | (c[1] << 8) | c[2];
	}

	@Override
	public boolean method_25421() {
		return false;
	}
}
