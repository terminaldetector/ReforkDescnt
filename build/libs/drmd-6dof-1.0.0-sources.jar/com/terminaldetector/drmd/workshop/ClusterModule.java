package com.terminaldetector.drmd.workshop;

import net.minecraft.class_2487;
import net.minecraft.class_2499;

/**
 * One construction module — port of SCK / D6_SCKBridge flat module format:
 * { cluster, slot, name, type, model, pos, angle, size, color, anim, attach }
 */
public class ClusterModule {
	public String cluster = "Center";
	public int slot;
	public String name = "module";
	public String type = "Model"; // Model | Sprite | Quad
	public String model = "barrel"; // logical MC part id
	public float posFwd, posRgt, posUp;
	public float pitch, yaw, roll;
	public float scaleX = 1f, scaleY = 1f, scaleZ = 1f;
	public int colorR = 255, colorG = 255, colorB = 255, colorA = 255;
	public boolean muzzle;
	public int muzzleIdx = 1;
	public float spin;
	public float bobAmp;
	public float bobFreq;
	public float kick;

	public ClusterModule copy() {
		ClusterModule m = new ClusterModule();
		m.cluster = cluster;
		m.slot = slot;
		m.name = name;
		m.type = type;
		m.model = model;
		m.posFwd = posFwd;
		m.posRgt = posRgt;
		m.posUp = posUp;
		m.pitch = pitch;
		m.yaw = yaw;
		m.roll = roll;
		m.scaleX = scaleX;
		m.scaleY = scaleY;
		m.scaleZ = scaleZ;
		m.colorR = colorR;
		m.colorG = colorG;
		m.colorB = colorB;
		m.colorA = colorA;
		m.muzzle = muzzle;
		m.muzzleIdx = muzzleIdx;
		m.spin = spin;
		m.bobAmp = bobAmp;
		m.bobFreq = bobFreq;
		m.kick = kick;
		return m;
	}

	public class_2487 toNbt() {
		class_2487 n = new class_2487();
		n.method_10582("cluster", cluster);
		n.method_10569("slot", slot);
		n.method_10582("name", name);
		n.method_10582("type", type);
		n.method_10582("model", model);
		n.method_10548("fwd", posFwd);
		n.method_10548("rgt", posRgt);
		n.method_10548("up", posUp);
		n.method_10548("pitch", pitch);
		n.method_10548("yaw", yaw);
		n.method_10548("roll", roll);
		n.method_10548("sx", scaleX);
		n.method_10548("sy", scaleY);
		n.method_10548("sz", scaleZ);
		n.method_10569("cr", colorR);
		n.method_10569("cg", colorG);
		n.method_10569("cb", colorB);
		n.method_10569("ca", colorA);
		n.method_10556("muzzle", muzzle);
		n.method_10569("muzzleIdx", muzzleIdx);
		n.method_10548("spin", spin);
		n.method_10548("bobAmp", bobAmp);
		n.method_10548("bobFreq", bobFreq);
		n.method_10548("kick", kick);
		return n;
	}

	public static ClusterModule fromNbt(class_2487 n) {
		ClusterModule m = new ClusterModule();
		m.cluster = n.method_10545("cluster") ? n.method_10558("cluster") : "Center";
		m.slot = n.method_10550("slot");
		m.name = n.method_10545("name") ? n.method_10558("name") : "module";
		m.type = n.method_10545("type") ? n.method_10558("type") : "Model";
		m.model = n.method_10545("model") ? n.method_10558("model") : "barrel";
		m.posFwd = n.method_10583("fwd");
		m.posRgt = n.method_10583("rgt");
		m.posUp = n.method_10583("up");
		m.pitch = n.method_10583("pitch");
		m.yaw = n.method_10583("yaw");
		m.roll = n.method_10583("roll");
		m.scaleX = n.method_10545("sx") ? n.method_10583("sx") : 1f;
		m.scaleY = n.method_10545("sy") ? n.method_10583("sy") : 1f;
		m.scaleZ = n.method_10545("sz") ? n.method_10583("sz") : 1f;
		m.colorR = n.method_10545("cr") ? n.method_10550("cr") : 255;
		m.colorG = n.method_10545("cg") ? n.method_10550("cg") : 255;
		m.colorB = n.method_10545("cb") ? n.method_10550("cb") : 255;
		m.colorA = n.method_10545("ca") ? n.method_10550("ca") : 255;
		m.muzzle = n.method_10577("muzzle");
		m.muzzleIdx = n.method_10545("muzzleIdx") ? n.method_10550("muzzleIdx") : 1;
		m.spin = n.method_10583("spin");
		m.bobAmp = n.method_10583("bobAmp");
		m.bobFreq = n.method_10583("bobFreq");
		m.kick = n.method_10583("kick");
		return m;
	}

	public static class_2499 listToNbt(java.util.List<ClusterModule> mods) {
		class_2499 list = new class_2499();
		for (ClusterModule m : mods) list.add(m.toNbt());
		return list;
	}

	public static java.util.List<ClusterModule> listFromNbt(class_2499 list) {
		java.util.ArrayList<ClusterModule> out = new java.util.ArrayList<>();
		for (int i = 0; i < list.size(); i++) out.add(fromNbt(list.method_10602(i)));
		return out;
	}
}
