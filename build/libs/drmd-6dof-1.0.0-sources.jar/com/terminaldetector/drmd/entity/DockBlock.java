package com.terminaldetector.drmd.entity;

import com.terminaldetector.drmd.DescentPlayerData;
import com.terminaldetector.drmd.energy.EnergySystem;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;

/** d6_dock — heal / energy / shield regen while colliding. */
public class DockBlock extends class_2248 {
	public DockBlock(class_2251 settings) {
		super(settings);
	}

	@Override
	public void method_9548(class_2680 state, class_1937 world, class_2338 pos, class_1297 entity) {
		if (world.field_9236 || !(entity instanceof class_1657 player)) return;
		if (player.field_6012 % 10 != 0) return;
		DescentPlayerData data = DescentPlayerData.get(player);
		if (!data.isEnabled()) return;
		player.method_6025(12.5f);
		EnergySystem.add(data, 10f);
		data.setShield(Math.min(data.getShieldMax(), data.getShield() + 10f));
	}
}
