package com.terminaldetector.drmd.entity;

import com.terminaldetector.drmd.DescentMod;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public final class ModEntities {
	public static final class_1299<ProjectileEntity> PROJECTILE = class_2378.method_10230(
			class_7923.field_41177,
			class_2960.method_60655(DescentMod.MOD_ID, "projectile"),
			class_1299.class_1300.<ProjectileEntity>method_5903(ProjectileEntity::new, class_1311.field_17715)
					.method_17687(0.35f, 0.35f)
					.method_27299(128)
					.method_27300(1)
					.build()
	);

	public static final class_1299<DroneEntity> DRONE = class_2378.method_10230(
			class_7923.field_41177,
			class_2960.method_60655(DescentMod.MOD_ID, "drone"),
			class_1299.class_1300.<DroneEntity>method_5903(DroneEntity::new, class_1311.field_6302)
					.method_17687(0.9f, 0.9f)
					.method_27299(96)
					.build()
	);

	public static final class_1299<AirMineEntity> AIR_MINE = class_2378.method_10230(
			class_7923.field_41177,
			class_2960.method_60655(DescentMod.MOD_ID, "air_mine"),
			class_1299.class_1300.<AirMineEntity>method_5903(AirMineEntity::new, class_1311.field_6302)
					.method_17687(0.6f, 0.6f)
					.method_27299(64)
					.build()
	);

	private ModEntities() {}

	public static void register() {
		FabricDefaultAttributeRegistry.register(DRONE, DroneEntity.createDroneAttributes());
		FabricDefaultAttributeRegistry.register(AIR_MINE, AirMineEntity.createAttributes());
		DescentMod.LOGGER.info("Registered DRMD entities");
	}
}
