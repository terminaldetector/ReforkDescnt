package com.terminaldetector.drmd.entity;

import com.terminaldetector.drmd.DescentMod;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3620;
import net.minecraft.class_4970;
import net.minecraft.class_7923;

/**
 * Map entities from d6_entities.fgd — placeable blocks with BE logic.
 */
public final class ModBlocks {
	public static final class_2248 CHECKPOINT = register("checkpoint",
			new CheckpointBlock(class_4970.class_2251.method_9630(class_2246.field_10327).method_31710(class_3620.field_16001)));
	public static final class_2248 DOCK = register("dock",
			new DockBlock(class_4970.class_2251.method_9630(class_2246.field_10085).method_31710(class_3620.field_15983)));
	public static final class_2248 COMBAT_ZONE = register("combat_zone",
			new MarkerBlock(class_4970.class_2251.method_9630(class_2246.field_10033).method_22488().method_31710(class_3620.field_16020)));
	public static final class_2248 NAV_NODE = register("nav_node",
			new MarkerBlock(class_4970.class_2251.method_9630(class_2246.field_31037).method_31710(class_3620.field_16010)));
	public static final class_2248 OBJECTIVE = register("objective",
			new MarkerBlock(class_4970.class_2251.method_9630(class_2246.field_10205).method_31710(class_3620.field_15994)));

	private ModBlocks() {}

	private static class_2248 register(String id, class_2248 block) {
		class_2960 ident = class_2960.method_60655(DescentMod.MOD_ID, id);
		class_2378.method_10230(class_7923.field_41175, ident, block);
		class_2378.method_10230(class_7923.field_41178, ident, new class_1747(block, new class_1792.class_1793()));
		return block;
	}

	public static void register() {
		DescentMod.LOGGER.info("Registered DRMD map blocks");
	}
}
