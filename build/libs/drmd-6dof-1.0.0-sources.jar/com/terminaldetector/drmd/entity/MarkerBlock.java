package com.terminaldetector.drmd.entity;

import net.minecraft.class_2248;

/** Generic marker for combat_zone / nav_node / objective. */
public class MarkerBlock extends class_2248 {
	public MarkerBlock(class_2251 settings) {
		super(settings);
	}
}
