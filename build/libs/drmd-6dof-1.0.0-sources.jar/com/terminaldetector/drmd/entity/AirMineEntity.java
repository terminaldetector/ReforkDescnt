package com.terminaldetector.drmd.entity;

import com.terminaldetector.drmd.DescentMod;
import com.terminaldetector.drmd.weapon.core.DamageClass;
import com.terminaldetector.drmd.weapon.core.WeaponCore;
import net.minecraft.class_1299;
import net.minecraft.class_1588;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_5132;
import net.minecraft.class_5134;

/** Air mine — drift 45, trigger 160, blast 120 (Source units). */
public class AirMineEntity extends class_1588 {
	private float blipTimer = 1.2f;

	public AirMineEntity(class_1299<? extends AirMineEntity> type, class_1937 world) {
		super(type, world);
		method_5875(true);
	}

	public static class_5132.class_5133 createAttributes() {
		return class_1588.method_26918()
				.method_26868(class_5134.field_23716, 40)
				.method_26868(class_5134.field_23719, 0.1)
				.method_26868(class_5134.field_23717, 24);
	}

	@Override
	protected void method_5959() {}

	@Override
	public void method_5773() {
		super.method_5773();
		method_5875(true);
		if (method_37908().field_9236) return;

		// Slow drift
		class_243 drift = new class_243(
				(field_5974.method_43058() - 0.5) * DescentMod.su(45) / 20.0,
				(field_5974.method_43058() - 0.5) * DescentMod.su(20) / 20.0,
				(field_5974.method_43058() - 0.5) * DescentMod.su(45) / 20.0);
		method_18799(method_18798().method_1021(0.9).method_1019(drift));
		field_6037 = true;

		blipTimer -= 1f / 20f;
		double trigger = DescentMod.su(160);
		class_1657 nearest = method_37908().method_18460(this, trigger);
		if (nearest != null && method_5858(nearest) < trigger * trigger) {
			detonate();
		} else if (blipTimer <= 0) {
			blipTimer = 1.2f;
			if (method_37908() instanceof class_3218 sw) {
				sw.method_14199(class_2398.field_11207, method_23317(), method_23318(), method_23321(), 2, 0.1, 0.1, 0.1, 0.01);
			}
		}
	}

	private void detonate() {
		if (method_37908() instanceof class_3218 sw) {
			WeaponCore.splashDamage(this, sw, method_19538(), 120f, (float) DescentMod.su(160), DamageClass.EXPLOSIVE);
			sw.method_14199(class_2398.field_11236, method_23317(), method_23318(), method_23321(), 8, 0.5, 0.5, 0.5, 0.1);
		}
		method_31472();
	}
}
