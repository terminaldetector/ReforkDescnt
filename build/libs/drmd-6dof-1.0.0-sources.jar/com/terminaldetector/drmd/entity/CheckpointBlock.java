package com.terminaldetector.drmd.entity;

import com.terminaldetector.drmd.DescentPlayerData;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2680;

/** d6_checkpoint — notifies when a 6DOF player touches it. */
public class CheckpointBlock extends class_2248 {
	public CheckpointBlock(class_2251 settings) {
		super(settings);
	}

	@Override
	public void method_9548(class_2680 state, class_1937 world, class_2338 pos, class_1297 entity) {
		if (world.field_9236 || !(entity instanceof class_1657 player)) return;
		DescentPlayerData data = DescentPlayerData.get(player);
		if (!data.isEnabled()) return;
		if (player.field_6012 % 40 == 0) {
			player.method_7353(class_2561.method_43470("§aDRMD Checkpoint saved"), true);
		}
	}
}
