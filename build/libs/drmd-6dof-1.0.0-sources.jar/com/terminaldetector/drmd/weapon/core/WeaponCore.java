package com.terminaldetector.drmd.weapon.core;

import com.terminaldetector.drmd.DescentMod;
import com.terminaldetector.drmd.DescentPlayerData;
import com.terminaldetector.drmd.entity.ModEntities;
import com.terminaldetector.drmd.entity.ProjectileEntity;
import com.terminaldetector.drmd.shield.ShieldSystem;
import java.util.List;
import java.util.function.Consumer;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_3966;

/**
 * Weapon firing framework — port of D6_Wep.FireProjectile / DirectDamage / SplashDamage.
 */
public final class WeaponCore {
	private WeaponCore() {}

	public static class FireConfig {
		public class_1309 owner;
		public class_243 pos;
		public class_243 dir;
		public float speed = 40f; // already in MC units preferred; if from Source use DescentMod.su
		public boolean speedIsSourceUnits = true;
		public String model = "default";
		public float scale = 1f;
		public DamageClass dmgClass = DamageClass.KINETIC;
		public float mass = 1f;
		public float gravity = 0f;
		public float drag = 0f;
		public float inherit = 1f;
		public float recoil = 0f;
		public float life = 5f;
		public float directDamage = 0f;
		public float splashDamage = 0f;
		public float splashRadius = 0f;
		public boolean homing = false;
		public float turnRate = 90f;
		public class_1297 homeTarget;
		public int pierceCount = 0;
		public int colorR = 180, colorG = 220, colorB = 255;
		public Consumer<HitContext> onHit;
	}

	public record HitContext(ProjectileEntity projectile, class_1297 hitEntity, class_243 hitPos, class_243 hitNormal, boolean isBlock) {}

	public static ProjectileEntity fireProjectile(FireConfig cfg) {
		if (cfg.owner == null || cfg.owner.method_37908().field_9236) return null;
		class_3218 world = (class_3218) cfg.owner.method_37908();

		float spd = cfg.speedIsSourceUnits ? (float) DescentMod.su(cfg.speed) : cfg.speed;
		class_243 dir = cfg.dir.method_1029();
		class_243 shipVel = class_243.field_1353;
		float inheritFactor = cfg.inherit;
		float recoilFactor = cfg.recoil;

		if (cfg.owner instanceof class_1657 player) {
			DescentPlayerData data = DescentPlayerData.get(player);
			shipVel = data.getFlightVelocity();
			inheritFactor *= data.getWepInherit();
			recoilFactor *= data.getWepRecoil();
		} else {
			shipVel = cfg.owner.method_18798();
		}

		class_243 vel = dir.method_1021(spd).method_1019(shipVel.method_1021(inheritFactor));

		ProjectileEntity proj = ModEntities.PROJECTILE.method_5883(world);
		if (proj == null) return null;
		proj.setOwner(cfg.owner);
		proj.method_33574(cfg.pos);
		proj.method_18799(vel);
		proj.setDamageClass(cfg.dmgClass);
		proj.setDirectDamage(cfg.directDamage);
		proj.setSplashDamage(cfg.splashDamage);
		// Splash radii from GMod are Source units when > ~20
		float splashR = cfg.splashRadius;
		if (splashR > 20f) splashR = (float) DescentMod.su(splashR);
		proj.setSplashRadius(splashR);
		proj.setLifeTicks((int) (cfg.life * 20));
		proj.setGravityStrength(cfg.gravity);
		proj.setDrag(cfg.drag);
		proj.setHoming(cfg.homing, cfg.turnRate, cfg.homeTarget);
		proj.setPierceCount(cfg.pierceCount);
		proj.setColor(cfg.dmgClass.r, cfg.dmgClass.g, cfg.dmgClass.b);
		proj.setOnHit(cfg.onHit);
		world.method_8649(proj);

		applyRecoil(cfg.owner, dir, recoilFactor);
		return proj;
	}

	public static void applyRecoil(class_1309 owner, class_243 dir, float recoilSource) {
		if (recoilSource <= 0) return;
		class_243 push = dir.method_1029().method_1021(-DescentMod.su(recoilSource) * 0.15);
		if (owner instanceof class_1657 player) {
			DescentPlayerData data = DescentPlayerData.get(player);
			if (data.isEnabled()) {
				data.setFlightVelocity(data.getFlightVelocity().method_1019(push));
				return;
			}
		}
		owner.method_5762(push.field_1352, push.field_1351, push.field_1350);
		owner.field_6037 = true;
	}

	public static void directDamage(class_1309 attacker, class_1297 target, float amount, DamageClass dmgClass) {
		if (amount <= 0 || target == null || !target.method_5805()) return;
		if (target instanceof class_1657 ply) {
			DescentPlayerData data = DescentPlayerData.get(ply);
			amount = ShieldSystem.absorb(data, amount, dmgClass);
			if (amount <= 0) return;
		}
		class_1282 src = attacker.method_48923().method_48812(attacker);
		if (attacker instanceof class_1657 p) {
			src = attacker.method_48923().method_48802(p);
		}
		target.method_5643(src, amount);
	}

	public static void splashDamage(class_1309 attacker, class_3218 world, class_243 pos, float amount, float radius, DamageClass dmgClass) {
		if (amount <= 0 || radius <= 0) return;
		class_238 box = new class_238(pos, pos).method_1014(radius);
		List<class_1309> list = world.method_8390(class_1309.class, box, e -> e.method_5805() && e != attacker);
		for (class_1309 e : list) {
			double dist = e.method_19538().method_1022(pos);
			if (dist > radius) continue;
			float falloff = (float) (1.0 - dist / radius);
			directDamage(attacker, e, amount * falloff, dmgClass);
			class_243 knock = e.method_19538().method_1020(pos).method_1029().method_1021(0.4 * falloff);
			e.method_5762(knock.field_1352, knock.field_1351 + 0.1, knock.field_1350);
			e.field_6037 = true;
		}
	}

	public static void hitscan(class_1309 owner, class_243 start, class_243 dir, float rangeSource, float damage, DamageClass dmgClass, Consumer<HitContext> onHit) {
		if (owner.method_37908().field_9236) return;
		class_3218 world = (class_3218) owner.method_37908();
		double range = DescentMod.su(rangeSource);
		class_243 end = start.method_1019(dir.method_1029().method_1021(range));
		class_3965 blockHit = world.method_17742(new class_3959(start, end,
				class_3959.class_3960.field_17558, class_3959.class_242.field_1348, owner));
		class_3966 entityHit = raycastEntities(owner, start, blockHit.method_17783() == class_239.class_240.field_1333 ? end : blockHit.method_17784());

		if (entityHit != null) {
			directDamage(owner, entityHit.method_17782(), damage, dmgClass);
			if (onHit != null) onHit.accept(new HitContext(null, entityHit.method_17782(), entityHit.method_17784(), dir.method_22882(), false));
		} else if (blockHit.method_17783() != class_239.class_240.field_1333 && onHit != null) {
			onHit.accept(new HitContext(null, null, blockHit.method_17784(), class_243.method_24954(blockHit.method_17780().method_10163()), true));
		}
	}

	private static class_3966 raycastEntities(class_1309 owner, class_243 start, class_243 end) {
		class_238 box = owner.method_5829().method_18804(end.method_1020(start)).method_1014(1.0);
		class_3966 best = null;
		double bestDist = Double.MAX_VALUE;
		for (class_1297 e : owner.method_37908().method_8333(owner, box, ent -> ent instanceof class_1309 && ent.method_5805())) {
			class_238 eb = e.method_5829().method_1014(0.3);
			var opt = eb.method_992(start, end);
			if (opt.isPresent()) {
				double d = start.method_1025(opt.get());
				if (d < bestDist) {
					bestDist = d;
					best = new class_3966(e, opt.get());
				}
			}
		}
		return best;
	}

	public static class_243 muzzle(class_1657 player, float forward, float right, float up) {
		DescentPlayerData data = DescentPlayerData.get(player);
		class_243 look = player.method_5828(1f);
		class_243 r = look.method_1036(new class_243(0, 1, 0));
		if (r.method_1027() < 1e-6) r = new class_243(1, 0, 0);
		r = r.method_1029();
		class_243 u = r.method_1036(look).method_1029();
		double roll = Math.toRadians(data.getRoll());
		class_243 rr = r.method_1021(Math.cos(roll)).method_1019(u.method_1021(Math.sin(roll)));
		class_243 uu = u.method_1021(Math.cos(roll)).method_1020(r.method_1021(Math.sin(roll)));
		return player.method_33571()
				.method_1019(look.method_1021(forward))
				.method_1019(rr.method_1021(right))
				.method_1019(uu.method_1021(up));
	}

	/**
	 * Muzzle from construction clusters — port of D6_Wep.MuzzleFor / D6_SCKBridge.GetMuzzle.
	 * Offsets are Source inches converted to blocks via /16.
	 */
	public static class_243 muzzleFor(class_1657 player, String weaponId, int idx) {
		var off = com.terminaldetector.drmd.workshop.ConstructionRegistry.getMuzzle(weaponId, idx);
		return muzzle(player, off.mcFwd(), off.mcRgt(), off.mcUp());
	}

	/** All construction muzzle world positions for multi-barrel fire. */
	public static java.util.List<class_243> allMuzzles(class_1657 player, String weaponId) {
		java.util.Map<Integer, com.terminaldetector.drmd.workshop.WeaponClusters.MuzzleOffset> map =
				com.terminaldetector.drmd.workshop.ConstructionRegistry.getMuzzles(weaponId);
		java.util.ArrayList<class_243> out = new java.util.ArrayList<>();
		if (map.isEmpty()) {
			out.add(muzzle(player, 0.9f, 0.15f, -0.1f));
			return out;
		}
		java.util.TreeMap<Integer, com.terminaldetector.drmd.workshop.WeaponClusters.MuzzleOffset> sorted =
				new java.util.TreeMap<>(map);
		for (var e : sorted.entrySet()) {
			var o = e.getValue();
			out.add(muzzle(player, o.mcFwd(), o.mcRgt(), o.mcUp()));
		}
		return out;
	}

	public static class_243 aimDir(class_1657 player) {
		return player.method_5828(1f);
	}
}
