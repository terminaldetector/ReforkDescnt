package com.terminaldetector.drmd.weapon.items;

import com.terminaldetector.drmd.DescentMod;
import com.terminaldetector.drmd.weapon.core.DamageClass;
import com.terminaldetector.drmd.weapon.registry.WeaponDef;
import com.terminaldetector.drmd.weapon.registry.WeaponRegistry;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.class_1761;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

public final class ModItems {
	public static class_1792 MG;
	public static class_1792 PLASMA;
	public static class_1792 HEAVY;
	public static class_1792 LASER;
	public static class_1792 ROCKETS;
	public static class_1792 GRAVY_RAILGUN;
	public static class_1792 VULCAN;
	public static class_1792 FLAK;
	public static class_1792 HOMING;
	public static class_1792 CONCUSSION;
	public static class_1792 SMART_MISSILE;
	public static class_1792 MEGA_MISSILE;
	public static class_1792 QUAD_LASER;
	public static class_1792 RAILMK2;
	public static class_1792 BFG;
	public static class_1792 FRAG;
	public static class_1792 OVERDRIVE;
	public static class_1792 SHOCKWAVE;
	public static class_1792 DARKLANCE;
	public static class_1792 DARKFIELD;
	public static class_1792 ENERGYTRAP;
	public static class_1792 GRAVMINE;
	public static class_1792 PLASMAMINE;
	public static class_1792 REACTOR;
	public static class_1792 WARP;
	public static class_1792 TELEFRAG;
	public static class_1792 WHIPLASH;

	public static final class_5321<class_1761> GROUP_KEY = class_5321.method_29179(class_7924.field_44688, class_2960.method_60655(DescentMod.MOD_ID, "weapons"));

	private ModItems() {}

	private static class_1792 register(String id, class_1792 item) {
		return class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(DescentMod.MOD_ID, id), item);
	}

	public static void register() {

		WeaponDef def_mg = new WeaponDef("mg", "Пулемёт", "primary", 1f, 0.06f, 12f, 0f, 0f, 5000f, 5f, DamageClass.KINETIC, "mg");
		MG = register("weapon_d6_mg", new DescentWeaponItem(def_mg, new class_1792.class_1793()));
		WeaponRegistry.register(def_mg);
		WeaponDef def_plasma = new WeaponDef("plasma", "Плазма", "primary", 8f, 0.45f, 45f, 25f, 120f, 3200f, 40f, DamageClass.EXOTIC, "plasma");
		PLASMA = register("weapon_d6_plasma", new DescentWeaponItem(def_plasma, new class_1792.class_1793()));
		WeaponRegistry.register(def_plasma);
		WeaponDef def_heavy = new WeaponDef("heavy", "Тяжёлый", "primary", 18f, 1.1f, 80f, 60f, 220f, 1100f, 160f, DamageClass.EXPLOSIVE, "heavy");
		HEAVY = register("weapon_d6_heavy", new DescentWeaponItem(def_heavy, new class_1792.class_1793()));
		WeaponRegistry.register(def_heavy);
		WeaponDef def_laser = new WeaponDef("laser", "Лазер", "primary", 0f, 0.4f, 150f, 0f, 0f, 0f, 30f, DamageClass.ENERGY, "laser");
		LASER = register("weapon_d6_laser", new DescentWeaponItem(def_laser, new class_1792.class_1793()));
		WeaponRegistry.register(def_laser);
		WeaponDef def_rockets = new WeaponDef("rockets", "Ракеты", "primary", 20f, 0.8f, 80f, 50f, 200f, 2800f, 120f, DamageClass.EXPLOSIVE, "rockets");
		ROCKETS = register("weapon_d6_rockets", new DescentWeaponItem(def_rockets, new class_1792.class_1793()));
		WeaponRegistry.register(def_rockets);
		WeaponDef def_gravy_railgun = new WeaponDef("gravy_railgun", "Грави-Рельса", "primary", 0f, 0.3f, 0f, 0f, 0f, 18000f, 0f, DamageClass.EXOTIC, "gravy");
		GRAVY_RAILGUN = register("weapon_d6_gravy_railgun", new DescentWeaponItem(def_gravy_railgun, new class_1792.class_1793()));
		WeaponRegistry.register(def_gravy_railgun);
		WeaponDef def_vulcan = new WeaponDef("vulcan", "Вулкан", "secondary", 2f, 0.065f, 15f, 0f, 0f, 4800f, 8f, DamageClass.KINETIC, "vulcan");
		VULCAN = register("weapon_d6_vulcan", new DescentWeaponItem(def_vulcan, new class_1792.class_1793()));
		WeaponRegistry.register(def_vulcan);
		WeaponDef def_flak = new WeaponDef("flak", "Флак-пушка", "secondary", 14f, 0.7f, 12f, 16f, 90f, 3500f, 40f, DamageClass.EXPLOSIVE, "flak");
		FLAK = register("weapon_d6_flak", new DescentWeaponItem(def_flak, new class_1792.class_1793()));
		WeaponRegistry.register(def_flak);
		WeaponDef def_homing = new WeaponDef("homing", "ГСН-ракета", "heavy", 0f, 3.5f, 90f, 40f, 160f, 1400f, 80f, DamageClass.EXPLOSIVE, "homing");
		HOMING = register("weapon_d6_homing", new DescentWeaponItem(def_homing, new class_1792.class_1793()));
		WeaponRegistry.register(def_homing);
		WeaponDef def_concussion = new WeaponDef("concussion", "КС-ракета", "heavy", 0f, 2.0f, 120f, 90f, 280f, 1600f, 200f, DamageClass.EXPLOSIVE, "basic");
		CONCUSSION = register("weapon_d6_concussion", new DescentWeaponItem(def_concussion, new class_1792.class_1793()));
		WeaponRegistry.register(def_concussion);
		WeaponDef def_smart_missile = new WeaponDef("smart_missile", "Умная-ракета", "heavy", 0f, 4.0f, 110f, 60f, 200f, 1600f, 100f, DamageClass.EXPLOSIVE, "homing");
		SMART_MISSILE = register("weapon_d6_smart_missile", new DescentWeaponItem(def_smart_missile, new class_1792.class_1793()));
		WeaponRegistry.register(def_smart_missile);
		WeaponDef def_mega_missile = new WeaponDef("mega_missile", "Мега-ракета", "heavy", 0f, 8.0f, 350f, 200f, 500f, 800f, 500f, DamageClass.EXPLOSIVE, "basic");
		MEGA_MISSILE = register("weapon_d6_mega_missile", new DescentWeaponItem(def_mega_missile, new class_1792.class_1793()));
		WeaponRegistry.register(def_mega_missile);
		WeaponDef def_quad_laser = new WeaponDef("quad_laser", "Quad-лазер", "secondary", 12f, 0.3f, 30f, 0f, 0f, 0f, 20f, DamageClass.ENERGY, "quad_laser");
		QUAD_LASER = register("weapon_d6_quad_laser", new DescentWeaponItem(def_quad_laser, new class_1792.class_1793()));
		WeaponRegistry.register(def_quad_laser);
		WeaponDef def_railmk2 = new WeaponDef("railmk2", "Рельса МК2", "heavy", 18f, 0.6f, 120f, 0f, 0f, 8000f, 80f, DamageClass.KINETIC, "rail");
		RAILMK2 = register("weapon_d6_railmk2", new DescentWeaponItem(def_railmk2, new class_1792.class_1793()));
		WeaponRegistry.register(def_railmk2);
		WeaponDef def_bfg = new WeaponDef("bfg", "BFG-излучатель", "heavy", 80f, 10.0f, 300f, 150f, 600f, 400f, 200f, DamageClass.EXOTIC, "bfg");
		BFG = register("weapon_d6_bfg", new DescentWeaponItem(def_bfg, new class_1792.class_1793()));
		WeaponRegistry.register(def_bfg);
		WeaponDef def_frag = new WeaponDef("frag", "Фраг-пускатель", "secondary", 24f, 1.5f, 60f, 50f, 180f, 2000f, 60f, DamageClass.EXPLOSIVE, "frag");
		FRAG = register("weapon_d6_frag", new DescentWeaponItem(def_frag, new class_1792.class_1793()));
		WeaponRegistry.register(def_frag);
		WeaponDef def_overdrive = new WeaponDef("overdrive", "Овердрайв-луч", "utility", 3f, 0.08f, 25f, 0f, 0f, 0f, 5f, DamageClass.ENERGY, "beam");
		OVERDRIVE = register("weapon_d6_overdrive", new DescentWeaponItem(def_overdrive, new class_1792.class_1793()));
		WeaponRegistry.register(def_overdrive);
		WeaponDef def_shockwave = new WeaponDef("shockwave", "Энерговолна", "utility", 40f, 3.0f, 20f, 80f, 700f, 0f, 0f, DamageClass.ENERGY, "shockwave");
		SHOCKWAVE = register("weapon_d6_shockwave", new DescentWeaponItem(def_shockwave, new class_1792.class_1793()));
		WeaponRegistry.register(def_shockwave);
		WeaponDef def_darklance = new WeaponDef("darklance", "Копьё тьмы", "heavy", 70f, 5.0f, 250f, 0f, 0f, 0f, 50f, DamageClass.EXOTIC, "darklance");
		DARKLANCE = register("weapon_d6_darklance", new DescentWeaponItem(def_darklance, new class_1792.class_1793()));
		WeaponRegistry.register(def_darklance);
		WeaponDef def_darkfield = new WeaponDef("darkfield", "Поле тьмы", "utility", 45f, 4.0f, 18f, 0f, 400f, 800f, 0f, DamageClass.EXOTIC, "deploy");
		DARKFIELD = register("weapon_d6_darkfield", new DescentWeaponItem(def_darkfield, new class_1792.class_1793()));
		WeaponRegistry.register(def_darkfield);
		WeaponDef def_energytrap = new WeaponDef("energytrap", "Энерго-капкан", "utility", 22f, 1.2f, 6f, 0f, 150f, 1200f, 0f, DamageClass.ENERGY, "deploy");
		ENERGYTRAP = register("weapon_d6_energytrap", new DescentWeaponItem(def_energytrap, new class_1792.class_1793()));
		WeaponRegistry.register(def_energytrap);
		WeaponDef def_gravmine = new WeaponDef("gravmine", "Грави-мина", "utility", 30f, 1.5f, 90f, 0f, 300f, 900f, 0f, DamageClass.EXOTIC, "deploy");
		GRAVMINE = register("weapon_d6_gravmine", new DescentWeaponItem(def_gravmine, new class_1792.class_1793()));
		WeaponRegistry.register(def_gravmine);
		WeaponDef def_plasmamine = new WeaponDef("plasmamine", "Плазма-мина", "utility", 25f, 1.0f, 120f, 100f, 260f, 900f, 0f, DamageClass.EXOTIC, "deploy");
		PLASMAMINE = register("weapon_d6_plasmamine", new DescentWeaponItem(def_plasmamine, new class_1792.class_1793()));
		WeaponRegistry.register(def_plasmamine);
		WeaponDef def_reactor = new WeaponDef("reactor", "Сброс реактора", "utility", 30f, 15.0f, 300f, 300f, 600f, 600f, 0f, DamageClass.EXPLOSIVE, "reactor");
		REACTOR = register("weapon_d6_reactor", new DescentWeaponItem(def_reactor, new class_1792.class_1793()));
		WeaponRegistry.register(def_reactor);
		WeaponDef def_warp = new WeaponDef("warp", "Боевой варп", "utility", 30f, 2.5f, 100f, 0f, 200f, 0f, 0f, DamageClass.EXOTIC, "warp");
		WARP = register("weapon_d6_warp", new DescentWeaponItem(def_warp, new class_1792.class_1793()));
		WeaponRegistry.register(def_warp);
		WeaponDef def_telefrag = new WeaponDef("telefrag", "Телефраг", "utility", 50f, 5.0f, 1000f, 0f, 140f, 0f, 0f, DamageClass.EXOTIC, "telefrag");
		TELEFRAG = register("weapon_d6_telefrag", new DescentWeaponItem(def_telefrag, new class_1792.class_1793()));
		WeaponRegistry.register(def_telefrag);
		WeaponDef def_whiplash = new WeaponDef("whiplash", "Хлыст", "utility", 20f, 3.0f, 80f, 0f, 160f, 0f, 0f, DamageClass.KINETIC, "whiplash");
		WHIPLASH = register("weapon_d6_whiplash", new DescentWeaponItem(def_whiplash, new class_1792.class_1793()));
		WeaponRegistry.register(def_whiplash);

		class_2378.method_39197(class_7923.field_44687, GROUP_KEY, FabricItemGroup.builder()
				.method_47320(() -> new class_1799(MG))
				.method_47321(class_2561.method_43471("itemGroup.drmd.weapons"))
				.method_47317((ctx, entries) -> {
					entries.method_45421(MG);
					entries.method_45421(PLASMA);
					entries.method_45421(HEAVY);
					entries.method_45421(LASER);
					entries.method_45421(ROCKETS);
					entries.method_45421(GRAVY_RAILGUN);
					entries.method_45421(VULCAN);
					entries.method_45421(FLAK);
					entries.method_45421(HOMING);
					entries.method_45421(CONCUSSION);
					entries.method_45421(SMART_MISSILE);
					entries.method_45421(MEGA_MISSILE);
					entries.method_45421(QUAD_LASER);
					entries.method_45421(RAILMK2);
					entries.method_45421(BFG);
					entries.method_45421(FRAG);
					entries.method_45421(OVERDRIVE);
					entries.method_45421(SHOCKWAVE);
					entries.method_45421(DARKLANCE);
					entries.method_45421(DARKFIELD);
					entries.method_45421(ENERGYTRAP);
					entries.method_45421(GRAVMINE);
					entries.method_45421(PLASMAMINE);
					entries.method_45421(REACTOR);
					entries.method_45421(WARP);
					entries.method_45421(TELEFRAG);
					entries.method_45421(WHIPLASH);
				})
				.method_47324());

		DescentMod.LOGGER.info("Registered {} DRMD weapons", 27);
	}
}
