package com.terminaldetector.drmd.command;

import com.mojang.brigadier.arguments.FloatArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.terminaldetector.drmd.DescentPlayerData;
import com.terminaldetector.drmd.energy.EnergyPreset;
import com.terminaldetector.drmd.energy.EnergySystem;
import com.terminaldetector.drmd.flight.FlightSystem;
import com.terminaldetector.drmd.network.ModNetworking;
import com.terminaldetector.drmd.weapon.items.ModItems;
import com.terminaldetector.drmd.weapon.registry.WeaponRegistry;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.class_1799;
import net.minecraft.class_2170;
import net.minecraft.class_2561;
import net.minecraft.class_3222;

public final class DescentCommands {
	private DescentCommands() {}

	public static void register() {
		CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
			dispatcher.register(class_2170.method_9247("6dof")
					.then(class_2170.method_9247("toggle").executes(ctx -> {
						FlightSystem.toggle(ctx.getSource().method_44023());
						return 1;
					}))
					.then(class_2170.method_9247("dash").executes(ctx -> {
						FlightSystem.tryDash(ctx.getSource().method_44023());
						return 1;
					}))
					.then(class_2170.method_9247("alwaysrun").executes(ctx -> {
						class_3222 p = ctx.getSource().method_44023();
						DescentPlayerData d = DescentPlayerData.get(p);
						d.setAlwaysRun(!d.isAlwaysRun());
						ModNetworking.syncPlayer(p, d);
						return 1;
					}))
					.then(class_2170.method_9247("flightassist").executes(ctx -> {
						class_3222 p = ctx.getSource().method_44023();
						DescentPlayerData d = DescentPlayerData.get(p);
						d.setFlightAssist(!d.isFlightAssist());
						ctx.getSource().method_9226(() -> class_2561.method_43470("Flight Assist: " + d.isFlightAssist()), false);
						return 1;
					}))
			);

			dispatcher.register(class_2170.method_9247("d6")
					.then(class_2170.method_9247("energy")
							.then(class_2170.method_9247("preset")
									.then(class_2170.method_9244("name", StringArgumentType.word()).executes(ctx -> {
										class_3222 p = ctx.getSource().method_44023();
										DescentPlayerData d = DescentPlayerData.get(p);
										EnergySystem.setPreset(d, EnergyPreset.fromId(StringArgumentType.getString(ctx, "name")));
										ModNetworking.syncPlayer(p, d);
										ctx.getSource().method_9226(() -> class_2561.method_43470("Preset: " + d.getPreset().id), false);
										return 1;
									})))
							.then(class_2170.method_9247("set")
									.then(class_2170.method_9244("w", FloatArgumentType.floatArg(0))
											.then(class_2170.method_9244("s", FloatArgumentType.floatArg(0))
													.then(class_2170.method_9244("e", FloatArgumentType.floatArg(0)).executes(ctx -> {
														class_3222 p = ctx.getSource().method_44023();
														DescentPlayerData d = DescentPlayerData.get(p);
														d.setAlloc(FloatArgumentType.getFloat(ctx, "w"),
																FloatArgumentType.getFloat(ctx, "s"),
																FloatArgumentType.getFloat(ctx, "e"));
														ModNetworking.syncPlayer(p, d);
														return 1;
													}))))))
					.then(class_2170.method_9247("set")
							.requires(s -> s.method_9259(2))
							.then(class_2170.method_9244("key", StringArgumentType.word())
									.then(class_2170.method_9244("value", FloatArgumentType.floatArg()).executes(ctx -> {
										class_3222 p = ctx.getSource().method_44023();
										DescentPlayerData d = DescentPlayerData.get(p);
										String key = StringArgumentType.getString(ctx, "key");
										float val = FloatArgumentType.getFloat(ctx, "value");
										switch (key.toLowerCase()) {
											case "gravity" -> d.setGravity(val);
											case "accel" -> d.setAccel(val);
											case "drag" -> d.setDrag(val);
											case "maxspeed" -> d.setMaxSpeed(val);
											default -> {
												ctx.getSource().method_9213(class_2561.method_43470("Unknown key: " + key));
												return 0;
											}
										}
										ctx.getSource().method_9226(() -> class_2561.method_43470("Set " + key + " = " + val), true);
										return 1;
									}))))
					.then(class_2170.method_9247("weapons")
							.then(class_2170.method_9247("list").executes(ctx -> {
								WeaponRegistry.all().forEach(w ->
										ctx.getSource().method_9226(() -> class_2561.method_43470("- " + w.id + " (" + w.displayName + ")"), false));
								return 1;
							}))
							.then(class_2170.method_9247("give_all")
									.requires(s -> s.method_9259(2))
									.executes(ctx -> {
										class_3222 p = ctx.getSource().method_44023();
										p.method_7270(new class_1799(ModItems.MG));
										p.method_7270(new class_1799(ModItems.PLASMA));
										p.method_7270(new class_1799(ModItems.HEAVY));
										p.method_7270(new class_1799(ModItems.LASER));
										p.method_7270(new class_1799(ModItems.ROCKETS));
										p.method_7270(new class_1799(ModItems.GRAVY_RAILGUN));
										p.method_7270(new class_1799(ModItems.VULCAN));
										p.method_7270(new class_1799(ModItems.FLAK));
										p.method_7270(new class_1799(ModItems.BFG));
										ctx.getSource().method_9226(() -> class_2561.method_43470("Gave core weapon set"), false);
										return 1;
									})))
					.then(class_2170.method_9247("radar").executes(ctx -> {
						class_3222 p = ctx.getSource().method_44023();
						DescentPlayerData d = DescentPlayerData.get(p);
						d.setRadarEnabled(!d.isRadarEnabled());
						return 1;
					}))
					.then(class_2170.method_9247("reset_roll").executes(ctx -> {
						class_3222 p = ctx.getSource().method_44023();
						DescentPlayerData d = DescentPlayerData.get(p);
						d.setRoll(0); d.setRollVel(0);
						return 1;
					}))
			);
		});
	}
}
