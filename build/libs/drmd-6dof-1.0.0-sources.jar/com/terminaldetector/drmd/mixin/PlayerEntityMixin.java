package com.terminaldetector.drmd.mixin;

import com.terminaldetector.drmd.DescentPlayerData;
import net.minecraft.class_1657;
import net.minecraft.class_2487;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1657.class)
public class PlayerEntityMixin {
	@Inject(method = "writeCustomDataToNbt", at = @At("RETURN"))
	private void drmd$write(class_2487 nbt, CallbackInfo ci) {
		class_1657 self = (class_1657) (Object) this;
		DescentPlayerData.get(self).writeNbt(nbt);
	}

	@Inject(method = "readCustomDataFromNbt", at = @At("RETURN"))
	private void drmd$read(class_2487 nbt, CallbackInfo ci) {
		class_1657 self = (class_1657) (Object) this;
		DescentPlayerData.get(self).readNbt(nbt);
	}
}
