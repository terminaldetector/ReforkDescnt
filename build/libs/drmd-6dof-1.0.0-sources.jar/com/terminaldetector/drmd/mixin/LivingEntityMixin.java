package com.terminaldetector.drmd.mixin;

import com.terminaldetector.drmd.DescentPlayerData;
import com.terminaldetector.drmd.shield.ShieldSystem;
import com.terminaldetector.drmd.weapon.core.DamageClass;
import net.minecraft.class_1282;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(class_1309.class)
public class LivingEntityMixin {
	@ModifyVariable(method = "damage", at = @At("HEAD"), argsOnly = true)
	private float drmd$shieldAbsorb(float amount, class_1282 source) {
		class_1309 self = (class_1309) (Object) this;
		if (!(self instanceof class_1657 player)) return amount;
		DescentPlayerData data = DescentPlayerData.get(player);
		if (!data.isEnabled()) return amount;
		DamageClass cls = DamageClass.KINETIC;
		String n = source.method_5525();
		if (n.contains("magic") || n.contains("lightning") || n.contains("thorns")) cls = DamageClass.ENERGY;
		else if (n.contains("explosion") || n.contains("fireworks")) cls = DamageClass.EXPLOSIVE;
		return ShieldSystem.absorb(data, amount, cls);
	}
}
