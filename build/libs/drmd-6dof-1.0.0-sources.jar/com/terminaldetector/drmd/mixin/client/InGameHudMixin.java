package com.terminaldetector.drmd.mixin.client;

import com.terminaldetector.drmd.client.hud.DescentHud;
import net.minecraft.class_329;
import net.minecraft.class_332;
import net.minecraft.class_9779;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_329.class)
public class InGameHudMixin {
	@Inject(method = "render", at = @At("RETURN"))
	private void drmd$hud(class_332 context, class_9779 tickCounter, CallbackInfo ci) {
		DescentHud.render(context, tickCounter.method_60637(false));
	}
}
