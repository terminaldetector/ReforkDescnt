DRMD 6DOF — evening test pack
=============================

PC (Java / Fabric 1.21.1)
  1. Install Fabric Loader 1.21.1 + Fabric API
  2. Copy pc/drmd-6dof-1.0.0.jar into .minecraft/mods/
  3. Launch, join world — 6DoF is native. Craft/use Pyro GX.

MCPE Master / Bedrock
  A) Open mcpe/drmd-6dof-mcpe-master-1.0.5.mcaddon
  B) Or unzip mcpe/drmd-6dof-mcpe-master-1.0.5.zip into games/com.mojang
  Then: enable both packs + Beta APIs
  Descent axes: nose pitch / barrel roll / yaw — HUD on screen

Full features = PC Fabric build.
MCPE = UX sandbox (see mcpe/README.md).
