package com.terminaldetector.drmd.command;

import com.mojang.brigadier.arguments.FloatArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.terminaldetector.drmd.DescentPlayerData;
import com.terminaldetector.drmd.energy.EnergyPreset;
import com.terminaldetector.drmd.energy.EnergySystem;
import com.terminaldetector.drmd.flight.FlightSystem;
import com.terminaldetector.drmd.network.ModNetworking;
import com.terminaldetector.drmd.weapon.items.ModItems;
import com.terminaldetector.drmd.weapon.registry.WeaponRegistry;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.class_1799;
import net.minecraft.class_2170;
import net.minecraft.class_2561;
import net.minecraft.class_3222;

public final class DescentCommands {
	private DescentCommands() {}

	public static void register() {
		CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
			dispatcher.register(class_2170.method_9247("6dof")
					.then(class_2170.method_9247("toggle").executes(ctx -> {
						FlightSystem.toggle(ctx.getSource().method_44023());
						return 1;
					}))
					.then(class_2170.method_9247("dash").executes(ctx -> {
						FlightSystem.tryDash(ctx.getSource().method_44023());
						return 1;
					}))
					.then(class_2170.method_9247("alwaysrun").executes(ctx -> {
						class_3222 p = ctx.getSource().method_44023();
						DescentPlayerData d = DescentPlayerData.get(p);
						d.setAlwaysRun(!d.isAlwaysRun());
						ModNetworking.syncPlayer(p, d);
						return 1;
					}))
					.then(class_2170.method_9247("flightassist").executes(ctx -> {
						class_3222 p = ctx.getSource().method_44023();
						DescentPlayerData d = DescentPlayerData.get(p);
						d.setFlightAssist(!d.isFlightAssist());
						ctx.getSource().method_9226(() -> class_2561.method_43470("Flight Assist: " + d.isFlightAssist()), false);
						return 1;
					}))
			);

			dispatcher.register(class_2170.method_9247("d6")
					.then(class_2170.method_9247("energy")
							.then(class_2170.method_9247("preset")
									.then(class_2170.method_9244("name", StringArgumentType.word()).executes(ctx -> {
										class_3222 p = ctx.getSource().method_44023();
										DescentPlayerData d = DescentPlayerData.get(p);
										EnergySystem.setPreset(d, EnergyPreset.fromId(StringArgumentType.getString(ctx, "name")));
										ModNetworking.syncPlayer(p, d);
										ctx.getSource().method_9226(() -> class_2561.method_43470("Preset: " + d.getPreset().id), false);
										return 1;
									})))
							.then(class_2170.method_9247("set")
									.then(class_2170.method_9244("w", FloatArgumentType.floatArg(0))
											.then(class_2170.method_9244("s", FloatArgumentType.floatArg(0))
													.then(class_2170.method_9244("e", FloatArgumentType.floatArg(0)).executes(ctx -> {
														class_3222 p = ctx.getSource().method_44023();
														DescentPlayerData d = DescentPlayerData.get(p);
														d.setAlloc(FloatArgumentType.getFloat(ctx, "w"),
																FloatArgumentType.getFloat(ctx, "s"),
																FloatArgumentType.getFloat(ctx, "e"));
														ModNetworking.syncPlayer(p, d);
														return 1;
													}))))))
					.then(class_2170.method_9247("set")
							.requires(s -> s.method_9259(2))
							.then(class_2170.method_9244("key", StringArgumentType.word())
									.then(class_2170.method_9244("value", FloatArgumentType.floatArg()).executes(ctx -> {
										class_3222 p = ctx.getSource().method_44023();
										DescentPlayerData d = DescentPlayerData.get(p);
										String key = StringArgumentType.getString(ctx, "key");
										float val = FloatArgumentType.getFloat(ctx, "value");
										switch (key.toLowerCase()) {
											case "gravity" -> d.setGravity(val);
											case "accel" -> d.setAccel(val);
											case "drag" -> d.setDrag(val);
											case "maxspeed" -> d.setMaxSpeed(val);
											default -> {
												ctx.getSource().method_9213(class_2561.method_43470("Unknown key: " + key));
												return 0;
											}
										}
										ctx.getSource().method_9226(() -> class_2561.method_43470("Set " + key + " = " + val), true);
										return 1;
									}))))
					.then(class_2170.method_9247("weapons")
							.then(class_2170.method_9247("list").executes(ctx -> {
								WeaponRegistry.all().forEach(w ->
										ctx.getSource().method_9226(() -> class_2561.method_43470("- " + w.id + " (" + w.displayName + ")"), false));
								return 1;
							}))
							.then(class_2170.method_9247("give_all")
									.requires(s -> s.method_9259(2))
									.executes(ctx -> {
										class_3222 p = ctx.getSource().method_44023();
										p.method_7270(new class_1799(ModItems.MG));
										p.method_7270(new class_1799(ModItems.PLASMA));
										p.method_7270(new class_1799(ModItems.HEAVY));
										p.method_7270(new class_1799(ModItems.LASER));
										p.method_7270(new class_1799(ModItems.ROCKETS));
										p.method_7270(new class_1799(ModItems.GRAVY_RAILGUN));
										p.method_7270(new class_1799(ModItems.VULCAN));
										p.method_7270(new class_1799(ModItems.FLAK));
										p.method_7270(new class_1799(ModItems.BFG));
										ctx.getSource().method_9226(() -> class_2561.method_43470("Gave core weapon set"), false);
										return 1;
									})))
					.then(class_2170.method_9247("radar").executes(ctx -> {
						class_3222 p = ctx.getSource().method_44023();
						DescentPlayerData d = DescentPlayerData.get(p);
						d.setRadarEnabled(!d.isRadarEnabled());
						return 1;
					}))
					.then(class_2170.method_9247("reset_roll").executes(ctx -> {
						class_3222 p = ctx.getSource().method_44023();
						DescentPlayerData d = DescentPlayerData.get(p);
						d.setRoll(0); d.setRollVel(0);
						return 1;
					}))
					.then(class_2170.method_9247("orient")
							.then(class_2170.method_9247("reset").executes(ctx -> {
								class_3222 p = ctx.getSource().method_44023();
								com.terminaldetector.drmd.world.LocalOrientation.clear(p.method_5667());
								ctx.getSource().method_9226(() -> class_2561.method_43470("Local UP reset to world +Y"), false);
								return 1;
							})))
					.then(class_2170.method_9247("construct")
							.executes(ctx -> {
								class_3222 p = ctx.getSource().method_44023();
								com.terminaldetector.drmd.world.build.ConstructionMode.toggle(p);
								return 1;
							}))
					.then(class_2170.method_9247("worldgen")
							.requires(s -> s.method_9259(2))
							.then(class_2170.method_9247("industrial")
									.then(class_2170.method_9244("style", StringArgumentType.word()).executes(ctx -> {
										class_3222 p = ctx.getSource().method_44023();
										String styleName = StringArgumentType.getString(ctx, "style");
										com.terminaldetector.drmd.world.WorldRules.ComplexStyle style;
										try {
											style = com.terminaldetector.drmd.world.WorldRules.ComplexStyle.valueOf(styleName.toUpperCase());
										} catch (Exception e) {
											style = com.terminaldetector.drmd.world.WorldRules.ComplexStyle.ABANDONED_RESEARCH;
										}
										var pos = p.method_24515();
										com.terminaldetector.drmd.world.gen.ModWorldgen.forceGenerate(p.method_51469(), pos, style);
										com.terminaldetector.drmd.world.WorldRules.ComplexStyle finalStyle = style;
										ctx.getSource().method_9226(() -> class_2561.method_43470(
												"Generated Industrial Underground [" + finalStyle + "] at " + pos.method_23854()), true);
										return 1;
									}))
									.executes(ctx -> {
										class_3222 p = ctx.getSource().method_44023();
										com.terminaldetector.drmd.world.gen.ModWorldgen.forceGenerate(
												p.method_51469(), p.method_24515(),
												com.terminaldetector.drmd.world.WorldRules.ComplexStyle.ANCIENT_POWER);
										ctx.getSource().method_9226(() -> class_2561.method_43470("Generated Industrial Underground nearby"), true);
										return 1;
									})))
					.then(class_2170.method_9247("kit")
							.requires(s -> s.method_9259(2))
							.executes(ctx -> {
								class_3222 p = ctx.getSource().method_44023();
								p.method_7270(new class_1799(com.terminaldetector.drmd.entity.ModWorldBlocks.BUILD_TOOL));
								p.method_7270(new class_1799(com.terminaldetector.drmd.entity.ModWorldBlocks.CONSTRUCTION_LASER));
								p.method_7270(new class_1799(com.terminaldetector.drmd.entity.ModWorldBlocks.REPAIR_LASER));
								p.method_7270(new class_1799(com.terminaldetector.drmd.entity.ModWorldBlocks.MINING_LASER));
								p.method_7270(new class_1799(com.terminaldetector.drmd.entity.ModWorldBlocks.GRAVITY_SCANNER));
								p.method_7270(new class_1799(com.terminaldetector.drmd.entity.ModWorldBlocks.SIX_D_SOIL));
								p.method_7270(new class_1799(com.terminaldetector.drmd.entity.ModWorldBlocks.GRAVITY_GENERATOR));
								p.method_7270(new class_1799(com.terminaldetector.drmd.entity.ModWorldBlocks.GRAVITY_TORCH, 16));
								p.method_7270(new class_1799(com.terminaldetector.drmd.entity.ModWorldBlocks.MAGNETIC_ANOMALY));
								p.method_7270(new class_1799(com.terminaldetector.drmd.entity.ModWorldBlocks.VOLUME_TURRET));
								p.method_7270(new class_1799(com.terminaldetector.drmd.entity.ModWorldBlocks.LASER_TURRET));
								p.method_7270(new class_1799(com.terminaldetector.drmd.entity.ModWorldBlocks.PLASMA_TURRET));
								p.method_7270(new class_1799(com.terminaldetector.drmd.entity.ModWorldBlocks.POINT_DEFENSE_TURRET));
								p.method_7270(new class_1799(com.terminaldetector.drmd.entity.ModWorldBlocks.LASER_BARRIER));
								p.method_7270(new class_1799(com.terminaldetector.drmd.entity.ModWorldBlocks.HERMETIC_GATE));
								p.method_7270(new class_1799(com.terminaldetector.drmd.entity.ModWorldBlocks.UNSTABLE_REACTOR));
								ctx.getSource().method_9226(() -> class_2561.method_43470("Gave Phase 3 engineer / gravity / turret kit"), false);
								return 1;
							}))
					.then(class_2170.method_9247("start")
							.executes(ctx -> {
								class_3222 p = ctx.getSource().method_44023();
								com.terminaldetector.drmd.world.base.ReactorRoomStarter.activate(p);
								ctx.getSource().method_9226(() -> class_2561.method_43470("Descent Reactor Room activated"), true);
								return 1;
							}))
					.then(class_2170.method_9247("ship")
							.executes(ctx -> {
								class_3222 p = ctx.getSource().method_44023();
								var ship = com.terminaldetector.drmd.entity.ModEntities.PYRO_SHIP.method_5883(p.method_51469());
								if (ship != null) {
									var pos = p.method_19538().method_1019(p.method_5828(1f).method_1021(3));
									ship.method_5808(pos.field_1352, pos.field_1351, pos.field_1350, p.method_36454(), 0);
									p.method_51469().method_8649(ship);
									ctx.getSource().method_9226(() -> class_2561.method_43470("Spawned Pyro transport — ПКМ to board"), false);
								}
								return 1;
							}))
					.then(class_2170.method_9247("worldgen2")
							.requires(s -> s.method_9259(2))
							.then(class_2170.method_9244("kind", StringArgumentType.word()).executes(ctx -> {
								class_3222 p = ctx.getSource().method_44023();
								String name = StringArgumentType.getString(ctx, "kind").toUpperCase();
								com.terminaldetector.drmd.world.gen2.MacroEntry.Kind kind;
								try {
									kind = com.terminaldetector.drmd.world.gen2.MacroEntry.Kind.valueOf(name);
								} catch (Exception e) {
									kind = switch (name) {
										case "CONTINENT" -> com.terminaldetector.drmd.world.gen2.MacroEntry.Kind.FLOATING_CONTINENT;
										case "SPIRAL" -> com.terminaldetector.drmd.world.gen2.MacroEntry.Kind.SPIRAL_RANGE;
										case "INVERTED" -> com.terminaldetector.drmd.world.gen2.MacroEntry.Kind.INVERTED_ISLAND;
										case "LUNAR", "MOON" -> com.terminaldetector.drmd.world.gen2.MacroEntry.Kind.LUNAR_BASE;
										case "CRASH", "CRASHED" -> com.terminaldetector.drmd.world.gen2.MacroEntry.Kind.CRASHED_UFO;
										case "SAUCER", "FLYING" -> com.terminaldetector.drmd.world.gen2.MacroEntry.Kind.UFO;
										default -> com.terminaldetector.drmd.world.gen2.MacroEntry.Kind.ARCH;
									};
								}
								var pos = p.method_24515().method_10086(8);
								var entry = com.terminaldetector.drmd.world.gen2.ModWorldgen2.forceGenerate(
										p.method_51469(), pos, kind);
								com.terminaldetector.drmd.world.gen2.MacroEntry.Kind finalKind = kind;
								ctx.getSource().method_9226(() -> class_2561.method_43470(
										"WG2.0 " + finalKind + " [" + entry.label + "] at " + pos.method_23854()), true);
								return 1;
							})))
					.then(class_2170.method_9247("mega")
							.requires(s -> s.method_9259(2))
							.then(class_2170.method_9244("type", StringArgumentType.word()).executes(ctx -> {
								class_3222 p = ctx.getSource().method_44023();
								String type = StringArgumentType.getString(ctx, "type").toLowerCase();
								var world = p.method_51469();
								var at = p.method_19538().method_1019(p.method_5828(1f).method_1021(12));
								switch (type) {
									case "worm" -> {
										var e = com.terminaldetector.drmd.entity.ModEntities.MEGA_WORM.method_5883(world);
										if (e != null) {
											e.method_5808(at.field_1352, at.field_1351, at.field_1350, p.method_36454(), 0);
											world.method_8649(e);
										}
									}
									case "swarm" -> {
										var e = com.terminaldetector.drmd.entity.ModEntities.DRONE_SWARM.method_5883(world);
										if (e != null) {
											e.method_5808(at.field_1352, at.field_1351, at.field_1350, 0, 0);
											world.method_8649(e);
										}
									}
									case "keeper" -> {
										var e = com.terminaldetector.drmd.entity.ModEntities.REACTOR_KEEPER.method_5883(world);
										if (e != null) {
											e.method_5808(at.field_1352, at.field_1351, at.field_1350, 0, 0);
											world.method_8649(e);
										}
									}
									case "ufo", "saucer" -> {
										var e = com.terminaldetector.drmd.entity.ModEntities.SKY_UFO.method_5883(world);
										if (e != null) {
											e.method_5808(at.field_1352, at.field_1351, at.field_1350, 0, 0);
											world.method_8649(e);
										}
									}
									default -> {
										ctx.getSource().method_9213(class_2561.method_43470("Use: worm | swarm | keeper | ufo"));
										return 0;
									}
								}
								ctx.getSource().method_9226(() -> class_2561.method_43470("Spawned mega creature: " + type), true);
								return 1;
							})))
					.then(class_2170.method_9247("llod")
							.executes(ctx -> {
								class_3222 p = ctx.getSource().method_44023();
								ModNetworking.syncLlod(p);
								int n = com.terminaldetector.drmd.world.gen2.MacroWorld.size();
								var bands = com.terminaldetector.drmd.world.llod.LlodRegistry.queryVisible(p.method_24515(), 64);
								long c0 = bands.stream().filter(s -> s.level() == com.terminaldetector.drmd.world.llod.LlodLevel.LLOD0).count();
								long c1 = bands.stream().filter(s -> s.level() == com.terminaldetector.drmd.world.llod.LlodLevel.LLOD1).count();
								long c2 = bands.stream().filter(s -> s.level() == com.terminaldetector.drmd.world.llod.LlodLevel.LLOD2).count();
								ctx.getSource().method_9226(() -> class_2561.method_43470(
										"Voxel LLOD sync — macros=" + n
												+ " visible LLOD0=" + c0 + " LLOD1=" + c1 + " LLOD2=" + c2), false);
								return 1;
							}))
					.then(class_2170.method_9247("bomb")
							.requires(s -> s.method_9259(2))
							.then(class_2170.method_9244("type", StringArgumentType.word()).executes(ctx -> {
								class_3222 p = ctx.getSource().method_44023();
								String name = StringArgumentType.getString(ctx, "type").toLowerCase();
								class_1799 stack = switch (name) {
									case "cluster" -> new class_1799(ModItems.BOMB_CLUSTER, 8);
									case "incendiary", "fire" -> new class_1799(ModItems.BOMB_INCENDIARY, 8);
									case "guided", "laser" -> new class_1799(ModItems.BOMB_GUIDED, 8);
									default -> new class_1799(ModItems.BOMB_TNT, 8);
								};
								p.method_7270(stack);
								p.method_7270(new class_1799(ModItems.LASER_DESIGNATOR));
								ctx.getSource().method_9226(() -> class_2561.method_43470(
										"Bomb bay: " + name + " + laser designator"), false);
								return 1;
							}))
							.executes(ctx -> {
								class_3222 p = ctx.getSource().method_44023();
								p.method_7270(new class_1799(ModItems.BOMB_TNT, 8));
								p.method_7270(new class_1799(ModItems.BOMB_CLUSTER, 4));
								p.method_7270(new class_1799(ModItems.BOMB_INCENDIARY, 4));
								p.method_7270(new class_1799(ModItems.BOMB_GUIDED, 4));
								p.method_7270(new class_1799(ModItems.LASER_DESIGNATOR));
								ctx.getSource().method_9226(() -> class_2561.method_43470("Full bomb bay issued"), false);
								return 1;
							}))
					.then(class_2170.method_9247("laser")
							.executes(ctx -> {
								class_3222 p = ctx.getSource().method_44023();
								p.method_7270(new class_1799(ModItems.LASER_DESIGNATOR));
								ctx.getSource().method_9226(() -> class_2561.method_43470("Laser designator ready"), false);
								return 1;
							}))
					.then(class_2170.method_9247("atmosphere")
							.executes(ctx -> {
								class_3222 p = ctx.getSource().method_44023();
								var band = com.terminaldetector.drmd.world.atmosphere.AtmosphereBand.at(p.method_37908(), p.method_23318());
								ctx.getSource().method_9226(() -> class_2561.method_43470(
										"Atmosphere: " + band.label
												+ (p.method_37908().method_27983() == net.minecraft.class_1937.field_25181 ? " [END vacuum]" : "")
												+ " | drag=" + band.airDrag
												+ " thrust×" + band.thrustScale
												+ " blast×" + band.blastScale
												+ " | smoke=" + com.terminaldetector.drmd.world.smoke.SmokeSystem.all().size()
												+ " fire=" + com.terminaldetector.drmd.world.fire.FireSystem.focusCount()), false);
								return 1;
							}))
					.then(class_2170.method_9247("endreactor")
							.requires(s -> s.method_9259(2))
							.executes(ctx -> {
								var server = ctx.getSource().method_9211();
								var end = server.method_3847(net.minecraft.class_1937.field_25181);
								if (end == null) {
									ctx.getSource().method_9213(class_2561.method_43470("End dimension unavailable"));
									return 0;
								}
								com.terminaldetector.drmd.world.end.EndReactorState st =
										com.terminaldetector.drmd.world.end.EndReactorState.get(end);
								st.setBaseGenerated(false);
								st.setPhase(com.terminaldetector.drmd.world.end.EndReactorState.Phase.SHIELDED);
								com.terminaldetector.drmd.world.end.EndReactorSession.ensureBase(end);
								ctx.getSource().method_9226(() -> class_2561.method_43470(
										"End giga-reactor base forced — phase " + st.getPhase()), true);
								return 1;
							}))
			);
		});
	}
}
