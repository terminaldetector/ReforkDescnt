package com.terminaldetector.drmd.client.input;

import com.terminaldetector.drmd.client.DescentClient;
import com.terminaldetector.drmd.client.DescentClientState;
import com.terminaldetector.drmd.client.flight.ShipAttitudeClient;
import com.terminaldetector.drmd.network.ModNetworking;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

/**
 * Binds matching COMMANDS.txt: H toggle, SHIFT dash, R alwaysrun, Q/E roll, etc.
 */
public final class DescentKeybinds {
	public static class_304 toggle;
	public static class_304 dash;
	public static class_304 alwaysRun;
	public static class_304 flightAssist;
	public static class_304 radar;
	public static class_304 rollLeft;
	public static class_304 rollRight;
	public static class_304 ascend;
	public static class_304 descend;
	public static class_304 hook;
	public static class_304 workshop;
	public static class_304 rocketMode;
	public static class_304 resetRoll;

	private static boolean dashQueued;
	private static boolean hookQueued;
	private static boolean wasEnabled;

	private DescentKeybinds() {}

	public static void register() {
		toggle = KeyBindingHelper.registerKeyBinding(new class_304("key.drmd.toggle", class_3675.class_307.field_1668, GLFW.GLFW_KEY_H, "key.category.drmd"));
		dash = KeyBindingHelper.registerKeyBinding(new class_304("key.drmd.dash", class_3675.class_307.field_1668, GLFW.GLFW_KEY_LEFT_SHIFT, "key.category.drmd"));
		alwaysRun = KeyBindingHelper.registerKeyBinding(new class_304("key.drmd.alwaysrun", class_3675.class_307.field_1668, GLFW.GLFW_KEY_R, "key.category.drmd"));
		flightAssist = KeyBindingHelper.registerKeyBinding(new class_304("key.drmd.flightassist", class_3675.class_307.field_1668, GLFW.GLFW_KEY_F, "key.category.drmd"));
		radar = KeyBindingHelper.registerKeyBinding(new class_304("key.drmd.radar", class_3675.class_307.field_1668, GLFW.GLFW_KEY_T, "key.category.drmd"));
		rollLeft = KeyBindingHelper.registerKeyBinding(new class_304("key.drmd.roll_left", class_3675.class_307.field_1668, GLFW.GLFW_KEY_Q, "key.category.drmd"));
		rollRight = KeyBindingHelper.registerKeyBinding(new class_304("key.drmd.roll_right", class_3675.class_307.field_1668, GLFW.GLFW_KEY_E, "key.category.drmd"));
		ascend = KeyBindingHelper.registerKeyBinding(new class_304("key.drmd.ascend", class_3675.class_307.field_1668, GLFW.GLFW_KEY_SPACE, "key.category.drmd"));
		descend = KeyBindingHelper.registerKeyBinding(new class_304("key.drmd.descend", class_3675.class_307.field_1668, GLFW.GLFW_KEY_LEFT_CONTROL, "key.category.drmd"));
		hook = KeyBindingHelper.registerKeyBinding(new class_304("key.drmd.hook", class_3675.class_307.field_1668, GLFW.GLFW_KEY_Z, "key.category.drmd"));
		workshop = KeyBindingHelper.registerKeyBinding(new class_304("key.drmd.workshop", class_3675.class_307.field_1668, GLFW.GLFW_KEY_M, "key.category.drmd"));
		rocketMode = KeyBindingHelper.registerKeyBinding(new class_304("key.drmd.rocket_mode", class_3675.class_307.field_1668, GLFW.GLFW_KEY_G, "key.category.drmd"));
		resetRoll = KeyBindingHelper.registerKeyBinding(new class_304("key.drmd.reset_roll", class_3675.class_307.field_1668, GLFW.GLFW_KEY_X, "key.category.drmd"));
	}

	public static void tick(class_310 client) {
		boolean en = DescentClientState.enabled;
		if (en && !wasEnabled && client.field_1724 != null) {
			ShipAttitudeClient.resetFromPlayer(client.field_1724);
		}
		if (!en && wasEnabled) {
			ShipAttitudeClient.clear();
			DescentClientState.attitudeValid = false;
		}
		wasEnabled = en;

		while (toggle.method_1436()) sendAction("toggle");
		while (dash.method_1436()) { dashQueued = true; sendAction("dash"); }
		while (alwaysRun.method_1436()) sendAction("alwaysrun");
		while (flightAssist.method_1436()) sendAction("flightassist");
		while (radar.method_1436()) sendAction("radar");
		while (rocketMode.method_1436()) sendAction("rocket_next");
		while (resetRoll.method_1436()) {
			if (client.field_1724 != null && en) {
				ShipAttitudeClient.level();
				ShipAttitudeClient.applyToPlayer(client.field_1724);
			}
			sendAction("reset_roll");
		}
		while (workshop.method_1436()) DescentClient.openWorkshop();
		if (hook.method_1434()) hookQueued = true;

		if (en && client.field_1724 != null) {
			float rollIn = 0;
			if (rollLeft.method_1434()) rollIn -= 1;
			if (rollRight.method_1434()) rollIn += 1;
			ShipAttitudeClient.applyRollInput(rollIn, 1f / 20f);
			if (Math.abs(rollIn) > 0.01f) ShipAttitudeClient.applyToPlayer(client.field_1724);
		}
	}

	public static void sendInput(class_310 client) {
		if (client.field_1724 == null) return;
		float forward = 0, strafe = 0, vertical = 0, roll = 0;
		if (client.field_1690.field_1894.method_1434()) forward += 1;
		if (client.field_1690.field_1881.method_1434()) forward -= 1;
		if (client.field_1690.field_1913.method_1434()) strafe += 1;
		if (client.field_1690.field_1849.method_1434()) strafe -= 1;
		if (ascend.method_1434()) vertical += 1;
		if (descend.method_1434()) vertical -= 1;
		if (rollLeft.method_1434()) roll -= 1;
		if (rollRight.method_1434()) roll += 1;

		boolean dash = dashQueued;
		boolean hk = hookQueued;
		dashQueued = false;
		hookQueued = false;

		boolean att = DescentClientState.enabled && DescentClientState.attitudeValid;
		ClientPlayNetworking.send(new ModNetworking.InputPayload(
				forward, strafe, vertical, roll, dash, hk,
				att,
				att ? DescentClientState.attFx : 0,
				att ? DescentClientState.attFy : 0,
				att ? DescentClientState.attFz : 1,
				att ? DescentClientState.attUx : 0,
				att ? DescentClientState.attUy : 1,
				att ? DescentClientState.attUz : 0
		));
	}

	private static void sendAction(String action) {
		ClientPlayNetworking.send(new ModNetworking.ActionPayload(action));
	}
}
