package com.terminaldetector.drmd.client.gravity;

import com.terminaldetector.drmd.client.DescentClientState;
import net.minecraft.class_243;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import org.joml.Quaternionf;
import org.joml.Vector3f;

/**
 * Stabilizes the view so local gravity UP reads as screen-up —
 * soft lerp, no ship attitude freelook.
 */
public final class FootGravityCamera {
	private static class_243 visualUp = new class_243(0, 1, 0);

	private FootGravityCamera() {}

	public static void tickClient() {
		class_243 target = DescentClientState.footGravity
				? new class_243(DescentClientState.localUx, DescentClientState.localUy, DescentClientState.localUz)
				: new class_243(0, 1, 0);
		if (target.method_1027() < 1e-6) target = new class_243(0, 1, 0);
		target = target.method_1029();
		double blend = DescentClientState.footGravity ? 0.22 : 0.28;
		visualUp = visualUp.method_1019(target.method_1020(visualUp).method_1021(blend));
		if (visualUp.method_1027() < 1e-8) visualUp = target;
		else visualUp = visualUp.method_1029();
	}

	public static void apply(class_4587 matrices) {
		if (DescentClientState.enabled) return;
		class_243 up = visualUp;
		if (isNearWorldUp(up) && !DescentClientState.footGravity) return;

		class_243 worldUp = new class_243(0, 1, 0);
		double dot = class_3532.method_15350(worldUp.method_1026(up), -1.0, 1.0);
		class_243 axis = worldUp.method_1036(up);
		if (axis.method_1027() < 1e-10) {
			if (dot < 0) {
				// Ceiling: 180° about view-forward proxy (X)
				matrices.method_22907(new Quaternionf().rotationXYZ((float) Math.PI, 0, 0));
			}
			return;
		}
		axis = axis.method_1029();
		float angle = (float) Math.acos(dot);
		matrices.method_22907(new Quaternionf().fromAxisAngleRad(
				new Vector3f((float) axis.field_1352, (float) axis.field_1351, (float) axis.field_1350), angle));
	}

	public static boolean isNearWorldUp(class_243 up) {
		return up.method_1028(0, 1, 0) < 0.0025;
	}

	public static void reset() {
		visualUp = new class_243(0, 1, 0);
	}
}
