package com.terminaldetector.drmd.client.smoke;

import com.mojang.blaze3d.systems.RenderSystem;
import com.terminaldetector.drmd.world.llod.LlodLevel;
import com.terminaldetector.drmd.world.smoke.SmokeSystem;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.class_243;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_310;
import net.minecraft.class_757;
import org.joml.Matrix4f;

/**
 * Smoke LLOD: far columns (LLOD0) → large puffs (LLOD1) → local blobs (LLOD2).
 */
public final class SmokeRenderer {
	private SmokeRenderer() {}

	public static void register() {
		WorldRenderEvents.AFTER_TRANSLUCENT.register(SmokeRenderer::render);
	}

	private static void render(WorldRenderContext ctx) {
		class_310 mc = class_310.method_1551();
		if (mc.field_1724 == null || mc.field_1687 == null) return;
		var clouds = SmokeSystem.visibleNear(mc.field_1724.method_19538(), 64);
		if (clouds.isEmpty()) return;

		class_243 cam = ctx.camera().method_19326();
		Matrix4f mat = ctx.matrixStack().method_23760().method_23761();
		RenderSystem.enableBlend();
		RenderSystem.defaultBlendFunc();
		RenderSystem.disableCull();
		RenderSystem.setShader(class_757::method_34540);
		RenderSystem.depthMask(false);

		class_287 buf = class_289.method_1348().method_60827(class_293.class_5596.field_27382, class_290.field_1576);
		int drawn = 0;
		for (SmokeSystem.Cloud c : clouds) {
			LlodLevel band = SmokeSystem.drawBand(c, cam);
			float a = switch (band) {
				case LLOD0 -> 0.12f * c.density;
				case LLOD1 -> 0.18f * c.density;
				case LLOD2 -> 0.28f * c.density;
				default -> 0.35f * c.density;
			};
			float r = ((c.colorRgb >> 16) & 0xFF) / 255f;
			float g = ((c.colorRgb >> 8) & 0xFF) / 255f;
			float b = (c.colorRgb & 0xFF) / 255f;
			float rad = c.radius * switch (band) {
				case LLOD0 -> 2.2f;
				case LLOD1 -> 1.4f;
				default -> 1.0f;
			};
			int puffs = band == LlodLevel.LLOD0 ? 1 : band == LlodLevel.LLOD1 ? 3 : 5;
			for (int i = 0; i < puffs; i++) {
				float ox = (i - puffs / 2f) * rad * 0.35f;
				box(buf, mat,
						(float) (c.pos.field_1352 + ox - cam.field_1352),
						(float) (c.pos.field_1351 - cam.field_1351),
						(float) (c.pos.field_1350 - cam.field_1350),
						rad * (band == LlodLevel.LLOD0 ? 1.5f : 0.7f),
						r, g, b, a);
				if (++drawn > 400) break;
			}
			if (drawn > 400) break;
		}
		var built = buf.method_60794();
		if (built != null) class_286.method_43433(built);
		RenderSystem.depthMask(true);
		RenderSystem.enableCull();
		RenderSystem.disableBlend();
	}

	private static void box(class_287 buf, Matrix4f mat, float cx, float cy, float cz,
							float r, float red, float g, float b, float a) {
		float x0 = cx - r, x1 = cx + r, y0 = cy - r * 0.6f, y1 = cy + r * 1.2f, z0 = cz - r, z1 = cz + r;
		quad(buf, mat, x0, y0, z0, x1, y0, z0, x1, y1, z0, x0, y1, z0, red, g, b, a);
		quad(buf, mat, x0, y0, z1, x0, y1, z1, x1, y1, z1, x1, y0, z1, red, g, b, a);
		quad(buf, mat, x0, y0, z0, x0, y0, z1, x1, y0, z1, x1, y0, z0, red, g, b, a);
		quad(buf, mat, x0, y1, z0, x1, y1, z0, x1, y1, z1, x0, y1, z1, red, g, b, a);
		quad(buf, mat, x0, y0, z0, x0, y1, z0, x0, y1, z1, x0, y0, z1, red, g, b, a);
		quad(buf, mat, x1, y0, z0, x1, y0, z1, x1, y1, z1, x1, y1, z0, red, g, b, a);
	}

	private static void quad(class_287 buf, Matrix4f mat,
							 float x0, float y0, float z0, float x1, float y1, float z1,
							 float x2, float y2, float z2, float x3, float y3, float z3,
							 float r, float g, float b, float a) {
		buf.method_22918(mat, x0, y0, z0).method_22915(r, g, b, a);
		buf.method_22918(mat, x1, y1, z1).method_22915(r, g, b, a);
		buf.method_22918(mat, x2, y2, z2).method_22915(r, g, b, a);
		buf.method_22918(mat, x3, y3, z3).method_22915(r, g, b, a);
	}
}
