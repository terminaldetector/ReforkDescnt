package com.terminaldetector.drmd.client.flight;

import com.terminaldetector.drmd.client.DescentClientState;
import com.terminaldetector.drmd.flight.ShipAttitude;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_3959;
import net.minecraft.class_4184;
import net.minecraft.class_746;

/**
 * Descent CalcView port (d6_client.lua D6_Cam_CV) adapted to Minecraft Camera.
 *
 * GMod applies full Angle (incl. roll) + CamLag / reactor micro-motion / engine vib /
 * ship-relative third person. MC Camera has no roll — bank stays on the view matrix;
 * this class owns position lag and third-person placement relative to ship axes.
 */
public final class DescentCamera {
	/** Source CamLag pullback scaled for MC blocks (intent: afterburner “mass”). */
	private static final double LAG_MAX = 0.38;
	private static final double DASH_KICK = 0.55;
	private static final double MICRO_MAX = 0.07;
	private static final double VIB_BASE = 0.012;
	private static final double VIB_AR = 0.028;
	/** Third person: GMod Forward*-100 + Up*22 → feel-matched MC distances. */
	private static final double TP_BACK = 5.5;
	private static final double TP_UP = 1.25;

	private static class_243 camLag = class_243.field_1353;
	private static class_243 dashKick = class_243.field_1353;
	private static float smoothedRoll;
	private static boolean leveling;
	private static long lastDashPulseMs;

	private DescentCamera() {}

	public static void clear() {
		camLag = class_243.field_1353;
		dashKick = class_243.field_1353;
		smoothedRoll = 0;
		leveling = false;
	}

	/** Pulse opposite-dash camera kick (client dash front-edge). */
	public static void pulseDash(class_243 worldDir) {
		if (worldDir == null || worldDir.method_1027() < 1e-8) return;
		long now = System.currentTimeMillis();
		if (now - lastDashPulseMs < 200) return;
		lastDashPulseMs = now;
		dashKick = worldDir.method_1029().method_1021(-DASH_KICK);
	}

	public static void beginLevel() {
		leveling = true;
	}

	public static boolean isLeveling() {
		return leveling;
	}

	public static float viewRoll() {
		return smoothedRoll;
	}

	/**
	 * Per-client-tick: CamLag / kick decay / soft roll level (CreateMove-adjacent).
	 */
	public static void tick(class_746 player, float dt) {
		if (!DescentClientState.enabled || !DescentClientState.attitudeValid) {
			clear();
			return;
		}
		ShipAttitude att = ShipAttitudeClient.get();
		class_243 forward = att.forward();
		class_243 vel = player.method_18798();

		class_243 lagTarget = class_243.field_1353;
		if (DescentClientState.alwaysRun) {
			double fwdSpd = vel.method_1026(forward) * 20.0; // blocks/sec feel
			double pull = class_3532.method_15350(fwdSpd / 12.0, 0.0, 1.0) * LAG_MAX;
			lagTarget = forward.method_1021(-pull);
		}
		lagTarget = lagTarget.method_1019(dashKick);
		double lerpT = class_3532.method_15350(10.0 * dt, 0.0, 1.0);
		camLag = lerpVec(camLag, lagTarget, lerpT);
		dashKick = lerpVec(dashKick, class_243.field_1353, class_3532.method_15350(6.0 * dt, 0.0, 1.0));

		// Soft level (GMod double-tap R → Ang.r Lerp); X starts this
		if (leveling) {
			att.rollLocal(-att.bankDegrees() * class_3532.method_15363(12f * dt, 0f, 1f));
			ShipAttitudeClient.decayRollVel(class_3532.method_15363(12f * dt, 0f, 1f));
			if (Math.abs(att.bankDegrees()) < 0.35f) {
				att.levelRoll();
				ShipAttitudeClient.zeroRollVel();
				leveling = false;
			}
			ShipAttitudeClient.applyToPlayer(player);
		}

		smoothedRoll = class_3532.method_16439(class_3532.method_15363(14f * dt, 0f, 1f), smoothedRoll, att.bankDegrees());
	}

	/**
	 * Apply to Minecraft Camera after vanilla {@code Camera.update}.
	 * First person: eye + CamLag + micro + vib. Third person: ship-relative chase with clip.
	 */
	public static void apply(class_4184 camera, CameraAccess access, boolean thirdPerson, float tickDelta) {
		class_310 mc = class_310.method_1551();
		class_746 player = mc.field_1724;
		if (player == null || !DescentClientState.enabled || !DescentClientState.attitudeValid) return;

		ShipAttitude att = ShipAttitudeClient.get();
		class_243 forward = att.forward();
		class_243 up = att.up();
		class_243 right = att.right();

		// Drive yaw/pitch from full ship attitude (entity pitch still clamped for net)
		float yaw = att.yawDegrees();
		float pitch = class_3532.method_15363(att.pitchDegrees(), -89.9f, 89.9f);
		access.drmd$setRotation(yaw, pitch);

		class_243 eye = player.method_30950(tickDelta).method_1031(0, player.method_5751(), 0);
		double t = (player.method_37908().method_8510() + tickDelta) + player.method_5628() * 0.37;

		class_243 origin = eye.method_1019(camLag);

		double spd = player.method_18798().method_1033() * 20.0;
		double mmAmp = class_3532.method_15350(spd / 22.0, 0.0, 1.0) * MICRO_MAX;
		if (mmAmp > 0.004) {
			origin = origin
					.method_1019(right.method_1021(Math.sin(t * 8.3) * mmAmp))
					.method_1019(up.method_1021(Math.sin(t * 11.7) * mmAmp * 0.55));
		}

		boolean ar = DescentClientState.alwaysRun;
		double vibAmp = (ar ? VIB_AR : VIB_BASE) * class_3532.method_15350(spd / 14.0, 0.0, 1.0);
		if (vibAmp > 0.001) {
			origin = origin.method_1019(
					right.method_1021(Math.sin(t * 61) * vibAmp)
							.method_1019(up.method_1021(Math.sin(t * 67) * vibAmp))
							.method_1019(forward.method_1021(Math.sin(t * 53) * vibAmp)));
		}

		if (thirdPerson) {
			class_243 back = forward.method_1021(-TP_BACK).method_1019(up.method_1021(TP_UP));
			class_243 want = origin.method_1019(back);
			var hit = player.method_37908().method_17742(new class_3959(
					origin, want,
					class_3959.class_3960.field_23142,
					class_3959.class_242.field_1348,
					player));
			if (hit.method_17783() != class_239.class_240.field_1333) {
				class_243 hp = hit.method_17784();
				class_243 n = new class_243(hit.method_17780().method_10148(), hit.method_17780().method_10164(), hit.method_17780().method_10165());
				want = hp.method_1019(n.method_1021(0.2));
			}
			access.drmd$setPos(want);
		} else {
			access.drmd$setPos(origin);
		}
	}

	/** FOV delta degrees while afterburning (Descent menu had FOV 60–130). */
	public static float fovBoost() {
		if (!DescentClientState.enabled) return 0;
		float boost = 0;
		if (DescentClientState.alwaysRun) boost += 6f;
		boost += class_3532.method_15363(DescentClientState.speed / 2.5f, 0f, 1f) * 4f;
		return boost;
	}

	private static class_243 lerpVec(class_243 a, class_243 b, double t) {
		return new class_243(
				class_3532.method_16436(t, a.field_1352, b.field_1352),
				class_3532.method_16436(t, a.field_1351, b.field_1351),
				class_3532.method_16436(t, a.field_1350, b.field_1350));
	}

	/** Narrow accessor surface used by CameraMixin (avoids leaking invokers elsewhere). */
	public interface CameraAccess {
		void drmd$setPos(class_243 pos);
		void drmd$setRotation(float yaw, float pitch);
	}
}
