package com.terminaldetector.drmd.client.flight;

import com.terminaldetector.drmd.client.DescentClientState;
import com.terminaldetector.drmd.flight.ShipAttitude;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_746;

/**
 * Client-owned Descent attitude — port of d6_client.lua CreateMove (D6_Cam_CM).
 *
 * Two-layer angular filter (author notes in GMod):
 *   TurnVel  — smooths mouse (≈ ft*8)
 *   AngVel   — body inertia (FA on ≈ ft*5, FA off ≈ ft*2)
 * Roll uses inertial RollVel around local Forward; bank soft-clamped ±180.
 */
public final class ShipAttitudeClient {
	private static final ShipAttitude ATT = new ShipAttitude();
	private static final float ROLL_SPEED = 175f;
	private static final float ROLL_LIMIT = 180f;

	private static boolean primed;
	private static float turnPitch;
	private static float turnYaw;
	private static float angPitch;
	private static float angYaw;
	private static float rollVel;

	private ShipAttitudeClient() {}

	public static ShipAttitude get() {
		return ATT;
	}

	public static boolean isPrimed() {
		return primed;
	}

	public static void resetFromPlayer(class_746 player) {
		ATT.fromLook(player.method_5828(1f));
		primed = true;
		turnPitch = turnYaw = angPitch = angYaw = 0;
		rollVel = 0;
		DescentCamera.clear();
		applyToPlayer(player);
	}

	public static void clear() {
		primed = false;
		turnPitch = turnYaw = angPitch = angYaw = 0;
		rollVel = 0;
		DescentCamera.clear();
	}

	/**
	 * Mouse deltas once per render frame (Mouse.updateMouse → changeLookDirection).
	 * FrameTime-scaled Lerp rates match GMod CreateMove.
	 */
	public static void applyMouse(class_746 player, double cursorDeltaX, double cursorDeltaY) {
		if (!primed) resetFromPlayer(player);
		float dt = frameDt();
		float targetYaw = (float) (-cursorDeltaX * 0.15);
		float targetPitch = (float) (-cursorDeltaY * 0.15);

		float turnK = class_3532.method_15363(8f * dt, 0f, 1f);
		turnYaw = class_3532.method_16439(turnK, turnYaw, targetYaw);
		turnPitch = class_3532.method_16439(turnK, turnPitch, targetPitch);

		float angDamp = DescentClientState.flightAssist ? 5f : 2f;
		float angK = class_3532.method_15363(angDamp * dt, 0f, 1f);
		angYaw = class_3532.method_16439(angK, angYaw, turnYaw);
		angPitch = class_3532.method_16439(angK, angPitch, turnPitch);

		ATT.yawLocal(angYaw);
		ATT.pitchLocal(angPitch);
		clampBank();
		applyToPlayer(player);
	}

	/** Every client tick while flying so roll inertia decays without held keys. */
	public static void tickRoll(class_746 player, float rollInput, float dt) {
		if (!primed) return;
		float target = rollInput * ROLL_SPEED;
		rollVel = class_3532.method_16439(class_3532.method_15363(5f * dt, 0f, 1f), rollVel, target);
		if (Math.abs(rollVel) > 0.01f) {
			ATT.rollLocal(rollVel * dt);
			clampBank();
		}
		applyToPlayer(player);
	}

	public static void decayRollVel(float t) {
		rollVel = class_3532.method_16439(t, rollVel, 0f);
	}

	public static void zeroRollVel() {
		rollVel = 0;
	}

	public static void level() {
		DescentCamera.beginLevel();
	}

	public static void applyToPlayer(class_746 player) {
		player.method_36456(ATT.yawDegrees());
		player.method_36457(clampPitch(ATT.pitchDegrees()));
		player.field_5982 = player.method_36454();
		player.field_6004 = player.method_36455();
		DescentClientState.roll = ATT.bankDegrees();
		DescentClientState.pitch = ATT.pitchDegrees();
		DescentClientState.attFx = (float) ATT.fx;
		DescentClientState.attFy = (float) ATT.fy;
		DescentClientState.attFz = (float) ATT.fz;
		DescentClientState.attUx = (float) ATT.ux;
		DescentClientState.attUy = (float) ATT.uy;
		DescentClientState.attUz = (float) ATT.uz;
		DescentClientState.attitudeValid = true;
	}

	private static void clampBank() {
		float bank = ATT.bankDegrees();
		if (bank > ROLL_LIMIT) ATT.rollLocal(-(bank - ROLL_LIMIT));
		else if (bank < -ROLL_LIMIT) ATT.rollLocal(-(bank + ROLL_LIMIT));
	}

	private static float clampPitch(float p) {
		return class_3532.method_15363(p, -90f, 90f);
	}

	/** GMod FrameTime analogue from MC last frame duration (1.0 = one game tick). */
	private static float frameDt() {
		class_310 mc = class_310.method_1551();
		if (mc == null) return 1f / 60f;
		float ticks = mc.method_60646().method_60636();
		return class_3532.method_15363(ticks / 20f, 1f / 300f, 0.1f);
	}
}
