package com.terminaldetector.drmd.client.flight;

import com.terminaldetector.drmd.client.DescentClientState;
import com.terminaldetector.drmd.flight.ShipAttitude;
import net.minecraft.class_3532;
import net.minecraft.class_746;

/**
 * Client-owned Descent attitude — mouse pitch/yaw rotate local ship axes (GMod-like).
 * Port of d6_client.lua Ang:RotateAroundAxis(Right/Up/Forward) with light turn smoothing.
 */
public final class ShipAttitudeClient {
	private static final ShipAttitude ATT = new ShipAttitude();
	private static boolean primed;
	private static float turnPitch;
	private static float turnYaw;
	private static float rollVel;

	private ShipAttitudeClient() {}

	public static ShipAttitude get() {
		return ATT;
	}

	public static void resetFromPlayer(class_746 player) {
		ATT.fromLook(player.method_5828(1f));
		primed = true;
		turnPitch = 0;
		turnYaw = 0;
		rollVel = 0;
		applyToPlayer(player);
	}

	public static void clear() {
		primed = false;
		turnPitch = 0;
		turnYaw = 0;
		rollVel = 0;
	}

	/** Apply raw mouse cursor deltas (same units as changeLookDirection). */
	public static void applyMouse(class_746 player, double cursorDeltaX, double cursorDeltaY) {
		if (!primed) resetFromPlayer(player);
		// Vanilla sensitivity already baked into deltas by Mouse.updateMouse
		float targetYaw = (float) (-cursorDeltaX * 0.15);
		float targetPitch = (float) (-cursorDeltaY * 0.15);
		// Soft lerp toward mouse intent (d6_client TurnVel)
		turnYaw = class_3532.method_16439(0.55f, turnYaw, targetYaw);
		turnPitch = class_3532.method_16439(0.55f, turnPitch, targetPitch);
		ATT.yawLocal(turnYaw);
		ATT.pitchLocal(turnPitch);
		applyToPlayer(player);
	}

	public static void applyRollInput(float rollInput, float dt) {
		if (!primed) return;
		// Inertial roll like GMod RollVel
		float target = rollInput * 220f;
		rollVel = class_3532.method_16439(Math.min(1f, 5f * dt), rollVel, target);
		if (Math.abs(rollVel) > 0.01f) {
			ATT.rollLocal(rollVel * dt);
		}
	}

	public static void level() {
		ATT.levelRoll();
		rollVel = 0;
	}

	public static void applyToPlayer(class_746 player) {
		player.method_36456(ATT.yawDegrees());
		player.method_36457(clampPitch(ATT.pitchDegrees()));
		player.field_5982 = player.method_36454();
		player.field_6004 = player.method_36455();
		DescentClientState.roll = ATT.bankDegrees();
		DescentClientState.pitch = ATT.pitchDegrees();
		DescentClientState.attFx = (float) ATT.fx;
		DescentClientState.attFy = (float) ATT.fy;
		DescentClientState.attFz = (float) ATT.fz;
		DescentClientState.attUx = (float) ATT.ux;
		DescentClientState.attUy = (float) ATT.uy;
		DescentClientState.attUz = (float) ATT.uz;
		DescentClientState.attitudeValid = true;
	}

	private static float clampPitch(float p) {
		return class_3532.method_15363(p, -90f, 90f);
	}
}
