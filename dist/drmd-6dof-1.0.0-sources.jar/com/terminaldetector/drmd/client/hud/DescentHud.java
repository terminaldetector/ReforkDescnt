package com.terminaldetector.drmd.client.hud;

import com.terminaldetector.drmd.client.DescentClientState;
import java.util.ArrayDeque;
import java.util.Locale;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_3959;
import net.minecraft.class_3966;

/**
 * Concept cockpit HUD — emerald tactical overlay (Descent / mockup style).
 * Keeps vanilla hotbar/hearts; draws flight readouts, 3D radar, target lock, weapons, logs.
 */
public final class DescentHud {
	private static final int GREEN = 0xFF33FF88;
	private static final int GREEN_DIM = 0xAA22AA55;
	private static final int GREEN_DARK = 0x66001108;
	private static final int RED = 0xFFFF4455;
	private static final int AMBER = 0xFFFFCC44;
	private static final int PANEL = 0x99000810;
	private static final int PANEL_EDGE = 0xFF1AFF7A;

	private static final ArrayDeque<String> LOG = new ArrayDeque<>();
	private static String lastTargetName = "";
	private static int logCooldown;

	private DescentHud() {}

	public static void pushLog(String line) {
		LOG.addFirst(line);
		while (LOG.size() > 5) LOG.removeLast();
	}

	public static void render(class_332 ctx, float tickDelta) {
		class_310 mc = class_310.method_1551();
		if (mc.field_1724 == null || mc.field_1690.field_1842 || !DescentClientState.enabled) return;

		int sw = mc.method_22683().method_4486();
		int sh = mc.method_22683().method_4502();
		int cx = sw / 2;
		int cy = sh / 2;

		maybeCombatLog(mc);
		drawFlightStatus(ctx, mc, 8, 8);
		drawAttitude(ctx, mc, 8, 72);
		drawCoords(ctx, mc, 8, 148);
		drawBiomeLayer(ctx, mc, 8, 180);
		drawAtmosphere(ctx, mc, 8, 200);
		drawRadar(ctx, mc, sw - 78, 8, 64);
		TargetInfo target = resolveTarget(mc);
		drawTargetPanel(ctx, mc, 8, 226, target);
		drawWeapons(ctx, mc, sw - 120, 90);
		drawDefense(ctx, mc, sw - 120, sh - 88);
		drawCrosshair(ctx, cx, cy, target != null);
		drawCockpitPanels(ctx, cx, sh - 54);
		drawCombatLog(ctx, mc, 8, sh - 78);
		drawDashBar(ctx, cx, cy);
		drawAttitudeLadder(ctx, cx, cy);
		if (mc.field_1690.method_31044().method_31034() == false) {
			ctx.method_27534(mc.field_1772, class_2561.method_43470("3RD · SHIP CAM"), cx, sh - 62, GREEN_DIM);
		}
		com.terminaldetector.drmd.client.hud.TerrainMap3d.render(ctx, mc);

		if (DescentClientState.gravityFactor > 0.05f) {
			String warn = DescentClientState.gravityFactor >= 1f
					? "⚠ GRAVITY ACTIVE"
					: String.format(Locale.ROOT, "⚠ GRAVITY RAMP %.0f%%", DescentClientState.gravityFactor * 100);
			ctx.method_27534(mc.field_1772, class_2561.method_43470(warn), cx, 4, AMBER);
		}
	}

	private static void drawFlightStatus(class_332 ctx, class_310 mc, int x, int y) {
		panel(ctx, x - 2, y - 2, 128, 62);
		float thrust = class_3532.method_15363(DescentClientState.speed / 2.5f, 0f, 1f);
		line(ctx, mc, x, y, "6DOF MODE: ON", GREEN);
		line(ctx, mc, x, y + 10, String.format(Locale.ROOT, "THRUST: %d%%", (int) (thrust * 100)), GREEN);
		line(ctx, mc, x, y + 20, "DAMPENERS: " + (DescentClientState.flightAssist ? "ON" : "OFF"), GREEN);
		line(ctx, mc, x, y + 30, String.format(Locale.ROOT, "PRESET: %s",
				DescentClientState.preset == null ? "—" : DescentClientState.preset.toUpperCase(Locale.ROOT)), GREEN);
		line(ctx, mc, x, y + 40, String.format(Locale.ROOT, "GRAVITY: %.2fG", DescentClientState.gravityFactor), GREEN);
		line(ctx, mc, x, y + 50, String.format(Locale.ROOT, "SPEED: %.1f m/s", DescentClientState.speed * 20f), GREEN);
	}

	private static void drawAttitude(class_332 ctx, class_310 mc, int x, int y) {
		panel(ctx, x - 2, y - 2, 128, 68);
		float pitch = DescentClientState.pitch;
		float roll = DescentClientState.roll;
		line(ctx, mc, x, y, "ATTITUDE", GREEN);
		line(ctx, mc, x, y + 11, String.format(Locale.ROOT, "P %+6.1f°", pitch), GREEN);
		segBar(ctx, x, y + 21, 110, 5, (pitch + 90f) / 180f, 0xFF44DDBB);
		int rollColor = Math.abs(roll) > 90f ? RED : (Math.abs(roll) > 4f ? AMBER : GREEN);
		line(ctx, mc, x, y + 30, String.format(Locale.ROOT, "R %+6.1f°", roll), rollColor);
		segBar(ctx, x, y + 40, 110, 5, (roll + 180f) / 360f, rollColor);
		line(ctx, mc, x, y + 50, "Q/E roll · X level", GREEN_DIM);
	}

	private static void drawAttitudeLadder(class_332 ctx, int cx, int cy) {
		if (!DescentClientState.attitudeValid) return;
		float roll = DescentClientState.roll;
		float pitch = DescentClientState.pitch;
		// Horizon line banks with ship roll (GMod-style cue)
		double rad = Math.toRadians(roll);
		int hw = 36;
		int hx = (int) (Math.cos(rad) * hw);
		int hy = (int) (Math.sin(rad) * hw);
		int py = (int) class_3532.method_15363(pitch * 0.35f, -18, 18);
		ctx.method_25294(cx - hx, cy + py - hy, cx + hx + 1, cy + py - hy + 1, GREEN);
		ctx.method_25294(cx - hx, cy + py + hy, cx + hx + 1, cy + py + hy + 1, GREEN_DIM);
	}

	private static void drawCoords(class_332 ctx, class_310 mc, int x, int y) {
		var p = mc.field_1724;
		line(ctx, mc, x, y, String.format(Locale.ROOT, "X %.1f", p.method_23317()), GREEN_DIM);
		line(ctx, mc, x, y + 9, String.format(Locale.ROOT, "Y %.1f", p.method_23318()), GREEN_DIM);
		line(ctx, mc, x, y + 18, String.format(Locale.ROOT, "Z %.1f", p.method_23321()), GREEN_DIM);
	}

	private static void drawBiomeLayer(class_332 ctx, class_310 mc, int x, int y) {
		var layer = com.terminaldetector.drmd.world.WorldRules.practicalLayer(mc.field_1724.method_23318());
		String biome = com.terminaldetector.drmd.world.WorldRules.biomeLabel(layer);
		line(ctx, mc, x, y, "BIOME: " + biome.toUpperCase(Locale.ROOT), GREEN);
		line(ctx, mc, x, y + 9, "LAYER: " + layer.name().replace('_', ' '), GREEN_DIM);
	}

	private static void drawAtmosphere(class_332 ctx, class_310 mc, int x, int y) {
		var band = com.terminaldetector.drmd.world.atmosphere.AtmosphereBand.at(mc.field_1724.method_23318());
		int color = switch (band) {
			case NEAR_SPACE -> 0xFF88CCFF;
			case THIN -> 0xFFAAEEFF;
			case DEEP_PRESSURE -> AMBER;
			default -> GREEN_DIM;
		};
		line(ctx, mc, x, y, "ATM: " + band.label.toUpperCase(Locale.ROOT), color);
		if (DescentClientState.smokeObscurity > 0.08f) {
			line(ctx, mc, x, y + 9, String.format(Locale.ROOT, "SMOKE %d%%",
					(int) (DescentClientState.smokeObscurity * 100)), AMBER);
		}
	}

	private static void drawRadar(class_332 ctx, class_310 mc, int x, int y, int size) {
		panel(ctx, x - 2, y - 2, size + 4, size + 14);
		line(ctx, mc, x, y, "RADAR 3D", GREEN);
		int ox = x + size / 2;
		int oy = y + 10 + size / 2;
		int r = size / 2 - 2;
		// Sphere rings
		ring(ctx, ox, oy, r, GREEN_DIM);
		ring(ctx, ox, oy, r * 2 / 3, GREEN_DIM);
		ring(ctx, ox, oy, r / 3, GREEN_DIM);
		ctx.method_25294(ox - r, oy, ox + r + 1, oy + 1, GREEN_DIM);
		ctx.method_25294(ox, oy - r, ox + 1, oy + r + 1, GREEN_DIM);
		ctx.method_25294(ox - 1, oy - 1, ox + 2, oy + 2, GREEN);

		if (!DescentClientState.radar || mc.field_1687 == null) return;
		double range = 96 * (1.0 - DescentClientState.smokeObscurity * 0.7);
		for (class_1297 e : mc.field_1687.method_18112()) {
			if (e == mc.field_1724 || !(e instanceof class_1309) || !e.method_5805()) continue;
			class_243 rel = e.method_19538().method_1020(mc.field_1724.method_19538());
			if (rel.method_1027() > range * range) continue;
			// Project into local view plane (yaw only for 2D scope + height tint)
			float yaw = mc.field_1724.method_36454() * ((float) Math.PI / 180f);
			double lx = rel.field_1352 * Math.cos(yaw) + rel.field_1350 * Math.sin(yaw);
			double lz = -rel.field_1352 * Math.sin(yaw) + rel.field_1350 * Math.cos(yaw);
			double ly = rel.field_1351;
			int px = ox + (int) (lx / range * r);
			int py = oy + (int) (lz / range * r) - (int) (ly / range * (r / 2.0));
			if (px < ox - r || px > ox + r || py < oy - r || py > oy + r) continue;
			boolean hostile = e instanceof net.minecraft.class_1588;
			ctx.method_25294(px - 1, py - 1, px + 2, py + 2, hostile ? RED : GREEN);
		}
	}

	private static void drawTargetPanel(class_332 ctx, class_310 mc, int x, int y, TargetInfo t) {
		panel(ctx, x - 2, y - 2, 130, 58);
		line(ctx, mc, x, y, "TARGET INFO", GREEN);
		if (t == null) {
			line(ctx, mc, x, y + 12, "NO LOCK", GREEN_DIM);
			wireBox(ctx, x + 4, y + 28, 28, 22, GREEN_DIM);
			return;
		}
		line(ctx, mc, x, y + 11, t.name, GREEN);
		line(ctx, mc, x, y + 21, String.format(Locale.ROOT, "HP %d/%d", t.hp, t.hpMax), t.hp < t.hpMax / 3 ? RED : GREEN);
		line(ctx, mc, x, y + 31, String.format(Locale.ROOT, "DIST %dm", t.dist), GREEN_DIM);
		line(ctx, mc, x, y + 41, String.format(Locale.ROOT, "VEL %.1f", t.vel), GREEN_DIM);
		wireBox(ctx, x + 96, y + 14, 28, 36, GREEN);
		// Simple wireframe silhouette
		ctx.method_25294(x + 108, y + 22, x + 112, y + 42, GREEN);
		ctx.method_25294(x + 100, y + 30, x + 120, y + 33, GREEN);
	}

	private static void drawWeapons(class_332 ctx, class_310 mc, int x, int y) {
		panel(ctx, x - 2, y - 2, 112, 72);
		line(ctx, mc, x, y, "WEAPONS", GREEN);
		String[] slots = {
				"1 CANNON   ∞",
				"2 PLASMA  " + ammoFromEnergy(0.8f),
				"3 MISSILE " + ammoFromEnergy(0.4f),
				"4 GRAVY   " + String.format(Locale.ROOT, "%02.0f", DescentClientState.gravy)
		};
		for (int i = 0; i < slots.length; i++) {
			int color = (i == Math.min(3, DescentClientState.rocketSub)) ? GREEN : GREEN_DIM;
			line(ctx, mc, x, y + 12 + i * 12, slots[i], color);
		}
	}

	private static void drawDefense(class_332 ctx, class_310 mc, int x, int y) {
		panel(ctx, x - 2, y - 2, 112, 56);
		float shield = DescentClientState.shield / Math.max(1f, DescentClientState.shieldMax);
		float armor = mc.field_1724.method_6032() / mc.field_1724.method_6063();
		line(ctx, mc, x, y, String.format(Locale.ROOT, "SHIELD %d%%", (int) (shield * 100)), 0xFF44AAFF);
		segBar(ctx, x, y + 10, 100, 6, shield, 0xFF3399EE);
		line(ctx, mc, x, y + 20, String.format(Locale.ROOT, "ARMOR  %d%%", (int) (armor * 100)), 0xFF66FFCC);
		segBar(ctx, x, y + 30, 100, 6, armor, 0xFF44DDBB);
		// Ship top-down silhouette
		ctx.method_25294(x + 40, y + 40, x + 60, y + 42, GREEN);
		ctx.method_25294(x + 48, y + 38, x + 52, y + 48, GREEN);
		ctx.method_25294(x + 36, y + 44, x + 64, y + 46, GREEN_DIM);
	}

	private static void drawCombatLog(class_332 ctx, class_310 mc, int x, int y) {
		panel(ctx, x - 2, y - 2, 160, 48);
		int yy = y;
		for (String s : LOG) {
			line(ctx, mc, x, yy, s, GREEN_DIM);
			yy += 9;
		}
		if (LOG.isEmpty()) {
			line(ctx, mc, x, y, "[SYS] Descent link online", GREEN_DIM);
		}
	}

	private static void drawCockpitPanels(class_332 ctx, int cx, int y) {
		// Three green instrument plates under crosshair (concept dashboard)
		int w = 48, h = 28, gap = 8;
		int x0 = cx - (w * 3 + gap * 2) / 2;
		for (int i = 0; i < 3; i++) {
			int px = x0 + i * (w + gap);
			panel(ctx, px, y, w, h);
			if (i == 0) {
				float t = class_3532.method_15363(DescentClientState.speed / 2.5f, 0, 1);
				segBar(ctx, px + 6, y + 10, w - 12, 8, t, GREEN);
			} else if (i == 1) {
				// LOCK diamond
				int mx = px + w / 2, my = y + h / 2;
				ctx.method_25294(mx - 6, my, mx + 7, my + 1, GREEN);
				ctx.method_25294(mx, my - 6, mx + 1, my + 7, GREEN);
				class_310 mc = class_310.method_1551();
				ctx.method_27534(mc.field_1772, class_2561.method_43470("LOCK"), mx, my + 8, GREEN);
			} else {
				float e = DescentClientState.energy / Math.max(1f, DescentClientState.energyMax);
				segBar(ctx, px + 6, y + 10, w - 12, 8, e, 0xFF44FFAA);
			}
		}
	}

	private static void drawCrosshair(class_332 ctx, int cx, int cy, boolean lock) {
		int c = lock ? RED : GREEN;
		// Outer brackets
		ctx.method_25294(cx - 14, cy - 1, cx - 6, cy + 2, c);
		ctx.method_25294(cx + 7, cy - 1, cx + 15, cy + 2, c);
		ctx.method_25294(cx - 1, cy - 14, cx + 2, cy - 6, c);
		ctx.method_25294(cx - 1, cy + 7, cx + 2, cy + 15, c);
		// Center pip
		ctx.method_25294(cx, cy, cx + 1, cy + 1, 0xFFFFFFFF);
		if (lock) {
			ctx.method_27534(class_310.method_1551().field_1772,
					class_2561.method_43470("LOCK"), cx, cy - 22, RED);
		}
	}

	private static void drawDashBar(class_332 ctx, int cx, int cy) {
		if (DescentClientState.dashCd <= 0) return;
		float pct = 1f - DescentClientState.dashCd / 1.8f;
		segBar(ctx, cx - 40, cy + 20, 80, 3, pct, AMBER);
	}

	private static TargetInfo resolveTarget(class_310 mc) {
		if (mc.field_1724 == null || mc.field_1687 == null) return null;
		class_3966 hit = rayEntity(mc, 96);
		if (hit == null || !(hit.method_17782() instanceof class_1309 living) || living == mc.field_1724) return null;
		String name = living.method_5477().getString();
		if (!name.equals(lastTargetName)) {
			lastTargetName = name;
			pushLog("[SYS] Target lock: " + name);
		}
		return new TargetInfo(
				name,
				(int) living.method_6032(),
				(int) living.method_6063(),
				(int) mc.field_1724.method_5739(living),
				(float) living.method_18798().method_1033() * 20f
		);
	}

	private static class_3966 rayEntity(class_310 mc, double range) {
		class_243 eye = mc.field_1724.method_33571();
		class_243 end = eye.method_1019(mc.field_1724.method_5828(1f).method_1021(range));
		class_1297 focused = null;
		double best = range;
		for (class_1297 e : mc.field_1687.method_8335(mc.field_1724, mc.field_1724.method_5829().method_1014(range))) {
			if (!(e instanceof class_1309) || !e.method_5805()) continue;
			var box = e.method_5829().method_1014(0.3);
			var opt = box.method_992(eye, end);
			if (opt.isPresent()) {
				double d = eye.method_1022(opt.get());
				if (d < best) {
					best = d;
					focused = e;
				}
			}
		}
		// Also respect block occlusion lightly
		var blockHit = mc.field_1687.method_17742(new class_3959(eye, end,
				class_3959.class_3960.field_17558, class_3959.class_242.field_1348, mc.field_1724));
		if (blockHit.method_17783() == class_239.class_240.field_1332 && eye.method_1022(blockHit.method_17784()) + 0.5 < best) {
			return null;
		}
		return focused == null ? null : new class_3966(focused);
	}

	private static void maybeCombatLog(class_310 mc) {
		if (logCooldown > 0) {
			logCooldown--;
			return;
		}
		if (DescentClientState.shield < 30 && DescentClientState.shield > 0) {
			pushLog("[SYS] Shield critical");
			logCooldown = 80;
		} else if (DescentClientState.alwaysRun) {
			pushLog("[SYS] Afterburner engaged");
			logCooldown = 100;
		}
	}

	private static String ammoFromEnergy(float factor) {
		int n = (int) (DescentClientState.energy * factor);
		return String.format(Locale.ROOT, "%03d", Math.max(0, n));
	}

	private static void panel(class_332 ctx, int x, int y, int w, int h) {
		ctx.method_25294(x, y, x + w, y + h, PANEL);
		ctx.method_25294(x, y, x + w, y + 1, PANEL_EDGE);
		ctx.method_25294(x, y + h - 1, x + w, y + h, PANEL_EDGE);
		ctx.method_25294(x, y, x + 1, y + h, PANEL_EDGE);
		ctx.method_25294(x + w - 1, y, x + w, y + h, PANEL_EDGE);
	}

	private static void line(class_332 ctx, class_310 mc, int x, int y, String s, int color) {
		ctx.method_51439(mc.field_1772, class_2561.method_43470(s), x, y, color, false);
	}

	private static void segBar(class_332 ctx, int x, int y, int w, int h, float pct, int color) {
		pct = class_3532.method_15363(pct, 0f, 1f);
		ctx.method_25294(x, y, x + w, y + h, 0xFF102018);
		int segs = 12;
		int filled = (int) (segs * pct);
		int segW = Math.max(1, (w - (segs - 1)) / segs);
		for (int i = 0; i < segs; i++) {
			int sx = x + i * (segW + 1);
			int col = i < filled ? color : 0xFF1A2A22;
			ctx.method_25294(sx, y, sx + segW, y + h, col);
		}
	}

	private static void ring(class_332 ctx, int cx, int cy, int r, int color) {
		for (int a = 0; a < 360; a += 8) {
			double rad = Math.toRadians(a);
			int x = cx + (int) (Math.cos(rad) * r);
			int y = cy + (int) (Math.sin(rad) * r);
			ctx.method_25294(x, y, x + 1, y + 1, color);
		}
	}

	private static void wireBox(class_332 ctx, int x, int y, int w, int h, int color) {
		ctx.method_25294(x, y, x + w, y + 1, color);
		ctx.method_25294(x, y + h - 1, x + w, y + h, color);
		ctx.method_25294(x, y, x + 1, y + h, color);
		ctx.method_25294(x + w - 1, y, x + w, y + h, color);
	}

	private record TargetInfo(String name, int hp, int hpMax, int dist, float vel) {}
}
