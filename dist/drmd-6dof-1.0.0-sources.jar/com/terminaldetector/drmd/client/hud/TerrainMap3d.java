package com.terminaldetector.drmd.client.hud;

import com.terminaldetector.drmd.client.DescentClientState;
import com.terminaldetector.drmd.client.flight.ShipAttitudeClient;
import com.terminaldetector.drmd.client.llod.LlodClientState;
import com.terminaldetector.drmd.entity.PyroShipEntity;
import com.terminaldetector.drmd.flight.ShipAttitude;
import com.terminaldetector.drmd.world.WorldRules;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_2902;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_746;

/**
 * Pyro GX tactical 3D terrain map (Overlord Vertor–style volumetric scanner).
 * Toggle with Tab+H while piloting Pyro GX (or with 6DoF on as fallback).
 *
 * Isometric heightfield of nearby columns in ship-local axes + macro markers.
 */
public final class TerrainMap3d {
	private static final int GRID = 28;          // samples per side
	private static final int STEP = 3;           // blocks between samples
	private static final int PANEL_W = 220;
	private static final int PANEL_H = 160;

	private static boolean open;
	private static int[][] heights;              // relative Y to player
	private static byte[][] kinds;               // 0 air/void, 1 solid, 2 liquid, 3 industrial
	private static int scanAge;
	private static float yawView;

	private TerrainMap3d() {}

	public static boolean isOpen() { return open; }

	public static void toggle() {
		open = !open;
		if (open) {
			scanAge = 999;
			class_310 mc = class_310.method_1551();
			if (mc.field_1724 != null) {
				mc.field_1724.method_7353(class_2561.method_43470("§bPYRO GX §f· 3D MAP ON §7(Tab+H)"), true);
			}
		} else {
			class_310 mc = class_310.method_1551();
			if (mc.field_1724 != null) {
				mc.field_1724.method_7353(class_2561.method_43470("§7PYRO GX · 3D MAP OFF"), true);
			}
		}
	}

	public static void close() { open = false; }

	/** Allowed when piloting Pyro GX, or 6DoF enabled (ship systems online). */
	public static boolean canUse(class_746 player) {
		if (player == null) return false;
		if (player.method_5854() instanceof PyroShipEntity) return true;
		return DescentClientState.enabled;
	}

	public static void tick(class_310 mc) {
		if (!open || mc.field_1724 == null || mc.field_1687 == null) return;
		if (!canUse(mc.field_1724)) {
			open = false;
			return;
		}
		scanAge++;
		if (scanAge < 8 && heights != null) return;
		scanAge = 0;
		rescan(mc.field_1687, mc.field_1724);
		if (DescentClientState.attitudeValid) {
			yawView = ShipAttitudeClient.get().yawDegrees();
		} else {
			yawView = mc.field_1724.method_36454();
		}
	}

	private static void rescan(class_1937 world, class_746 player) {
		heights = new int[GRID][GRID];
		kinds = new byte[GRID][GRID];
		class_2338 origin = player.method_24515();
		int half = (GRID * STEP) / 2;
		for (int ix = 0; ix < GRID; ix++) {
			for (int iz = 0; iz < GRID; iz++) {
				int wx = origin.method_10263() - half + ix * STEP;
				int wz = origin.method_10260() - half + iz * STEP;
				int top = world.method_8624(class_2902.class_2903.field_13203, wx, wz);
				// Also probe near player Y for caves / industrial voids
				int probeY = origin.method_10264();
				class_2338.class_2339 m = new class_2338.class_2339(wx, probeY, wz);
				int solidNear = findNearestSolid(world, m, probeY, 24);
				int hy = solidNear != Integer.MIN_VALUE ? solidNear : top;
				heights[ix][iz] = hy - origin.method_10264();
				class_2680 st = world.method_8320(new class_2338(wx, hy, wz));
				if (st.method_27852(class_2246.field_10382) || st.method_27852(class_2246.field_10164)) kinds[ix][iz] = 2;
				else if (st.method_27852(class_2246.field_10327) || st.method_27852(class_2246.field_23261) || st.method_27852(class_2246.field_10085)
						|| st.method_27852(class_2246.field_27119) || st.method_27852(class_2246.field_10174)) kinds[ix][iz] = 3;
				else if (st.method_26215()) kinds[ix][iz] = 0;
				else kinds[ix][iz] = 1;
			}
		}
	}

	private static int findNearestSolid(class_1937 world, class_2338.class_2339 m, int centerY, int range) {
		for (int d = 0; d <= range; d++) {
			for (int sign : new int[]{0, 1, -1}) {
				if (d == 0 && sign != 0) continue;
				int y = centerY + d * (sign == 0 ? 0 : sign);
				if (sign == 0 && d > 0) continue;
				m.method_33098(y);
				class_2680 st = world.method_8320(m);
				if (!st.method_26215() && st.method_26214(world, m) >= 0) return y;
			}
		}
		return Integer.MIN_VALUE;
	}

	public static void render(class_332 ctx, class_310 mc) {
		if (!open || mc.field_1724 == null || heights == null) return;
		int sw = mc.method_22683().method_4486();
		int sh = mc.method_22683().method_4502();
		int px = sw - PANEL_W - 10;
		int py = sh / 2 - PANEL_H / 2;

		// Panel
		ctx.method_25294(px - 2, py - 14, px + PANEL_W + 2, py + PANEL_H + 2, 0xCC000810);
		ctx.method_25294(px - 2, py - 14, px + PANEL_W + 2, py - 13, 0xFF1AFF7A);
		ctx.method_25294(px - 2, py + PANEL_H + 1, px + PANEL_W + 2, py + PANEL_H + 2, 0xFF1AFF7A);
		ctx.method_51439(mc.field_1772, class_2561.method_43470("PYRO GX · 3D MAP"), px, py - 11, 0xFF33FF88, false);
		ctx.method_51439(mc.field_1772, class_2561.method_43470("Tab+H"), px + PANEL_W - 36, py - 11, 0xAA22AA55, false);

		float yaw = yawView * ((float) Math.PI / 180f);
		float cos = class_3532.method_15362(yaw);
		float sin = class_3532.method_15374(yaw);
		// Isometric projection factors
		float sx = 3.2f;
		float sy = 1.55f;
		int ox = px + PANEL_W / 2;
		int oy = py + PANEL_H / 2 + 8;

		ShipAttitude att = DescentClientState.attitudeValid ? ShipAttitudeClient.get() : null;
		class_243 up = att != null ? att.up() : new class_243(0, 1, 0);

		// Heightfield wire mesh
		for (int ix = 0; ix < GRID - 1; ix++) {
			for (int iz = 0; iz < GRID - 1; iz++) {
				int[] a = project(ix, iz, heights[ix][iz], cos, sin, sx, sy, ox, oy);
				int[] b = project(ix + 1, iz, heights[ix + 1][iz], cos, sin, sx, sy, ox, oy);
				int[] c = project(ix, iz + 1, heights[ix][iz + 1], cos, sin, sx, sy, ox, oy);
				int col = colorFor(kinds[ix][iz], heights[ix][iz], up.field_1351);
				if (inPanel(a, px, py) || inPanel(b, px, py)) line(ctx, a[0], a[1], b[0], b[1], col);
				if (inPanel(a, px, py) || inPanel(c, px, py)) line(ctx, a[0], a[1], c[0], c[1], col);
			}
		}

		// Player pip at center
		ctx.method_25294(ox - 2, oy - 2, ox + 3, oy + 3, 0xFFFFFFFF);
		ctx.method_25294(ox - 1, oy - 5, ox + 2, oy - 2, 0xFF33FF88);

		// Macro / LLOD blips
		class_2338 origin = mc.field_1724.method_24515();
		int half = (GRID * STEP) / 2;
		for (var e : LlodClientState.INSTANCE.entries()) {
			double lx = e.center().field_1352 - origin.method_10263();
			double lz = e.center().field_1350 - origin.method_10260();
			double ly = e.center().field_1351 - origin.method_10264();
			if (lx * lx + lz * lz > (half + 24.0) * (half + 24.0)) continue;
			float rx = (float) (lx * cos - lz * sin);
			float rz = (float) (lx * sin + lz * cos);
			int x = ox + (int) ((rx - rz) * sx * 0.22f);
			int y = oy + (int) ((rx + rz) * sy * 0.22f - ly * 0.35f);
			if (x < px || x > px + PANEL_W || y < py || y > py + PANEL_H) continue;
			ctx.method_25294(x - 1, y - 1, x + 2, y + 2, 0xFF000000 | (e.colorRgb() & 0xFFFFFF));
		}

		var layer = WorldRules.practicalLayer(mc.field_1724.method_23318());
		ctx.method_51439(mc.field_1772, class_2561.method_43470(WorldRules.biomeLabel(layer)), px + 4, py + PANEL_H - 10, 0xAA22AA55, false);
		String mode = mc.field_1724.method_5854() instanceof PyroShipEntity ? "PILOT" : "LINK";
		ctx.method_51439(mc.field_1772, class_2561.method_43470(mode), px + PANEL_W - 28, py + PANEL_H - 10, 0xFF33FF88, false);
	}

	private static int[] project(int ix, int iz, int h, float cos, float sin, float sx, float sy, int ox, int oy) {
		float cx = (ix - GRID / 2f) * STEP;
		float cz = (iz - GRID / 2f) * STEP;
		float rx = cx * cos - cz * sin;
		float rz = cx * sin + cz * cos;
		int x = ox + (int) ((rx - rz) * sx * 0.22f);
		int y = oy + (int) ((rx + rz) * sy * 0.22f - h * 0.45f);
		return new int[]{x, y};
	}

	private static boolean inPanel(int[] p, int px, int py) {
		return p[0] >= px && p[0] <= px + PANEL_W && p[1] >= py && p[1] <= py + PANEL_H;
	}

	private static int colorFor(byte kind, int h, double upY) {
		// Dimmer when ship is inverted (up.y < 0) — still readable
		int alpha = upY < -0.3 ? 0xAA000000 : 0xFF000000;
		return switch (kind) {
			case 2 -> alpha | 0x4488FF;
			case 3 -> alpha | 0xFFAA44;
			case 0 -> alpha | 0x224433;
			default -> {
				int g = class_3532.method_15340(80 + h * 3, 40, 200);
				yield alpha | (g << 8) | 0x330000 | class_3532.method_15340(60 + h, 20, 120);
			}
		};
	}

	private static void line(class_332 ctx, int x0, int y0, int x1, int y1, int color) {
		int dx = Math.abs(x1 - x0), dy = Math.abs(y1 - y0);
		int sx = x0 < x1 ? 1 : -1;
		int sy = y0 < y1 ? 1 : -1;
		int err = dx - dy;
		int x = x0, y = y0;
		int steps = 0;
		while (true) {
			ctx.method_25294(x, y, x + 1, y + 1, color);
			if (x == x1 && y == y1) break;
			if (++steps > 200) break;
			int e2 = 2 * err;
			if (e2 > -dy) { err -= dy; x += sx; }
			if (e2 < dx) { err += dx; y += sy; }
		}
	}
}
