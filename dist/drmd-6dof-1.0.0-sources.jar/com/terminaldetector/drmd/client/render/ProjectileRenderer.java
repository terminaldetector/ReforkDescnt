package com.terminaldetector.drmd.client.render;

import com.terminaldetector.drmd.entity.ProjectileEntity;
import net.minecraft.class_1921;
import net.minecraft.class_243;
import net.minecraft.class_2960;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_5617;
import net.minecraft.class_7833;
import net.minecraft.class_897;

/**
 * Lightweight 3D projectile silhouettes (bolt / rocket / orb / drill) —
 * reuses debug filled box path like WeaponViewRenderer (no external meshes).
 */
public class ProjectileRenderer extends class_897<ProjectileEntity> {
	public ProjectileRenderer(class_5617.class_5618 ctx) {
		super(ctx);
	}

	@Override
	public void render(ProjectileEntity entity, float yaw, float tickDelta, class_4587 matrices,
					   class_4597 consumers, int light) {
		matrices.method_22903();
		class_243 vel = entity.method_18798();
		float bodyYaw = yaw;
		float bodyPitch = 0;
		if (vel.method_1027() > 1e-6) {
			bodyYaw = (float) (class_3532.method_15349(vel.field_1352, vel.field_1350) * (180F / Math.PI));
			bodyPitch = (float) (class_3532.method_15349(vel.field_1351, Math.sqrt(vel.field_1352 * vel.field_1352 + vel.field_1350 * vel.field_1350)) * (180F / Math.PI));
		}
		matrices.method_22907(class_7833.field_40716.rotationDegrees(bodyYaw));
		matrices.method_22907(class_7833.field_40714.rotationDegrees(-bodyPitch));

		float s = 0.12f * entity.getVisualScale();
		int argb = 0xFF000000 | entity.getColorRgb();
		int mesh = entity.getMeshKind();
		switch (mesh) {
			case ProjectileEntity.MESH_ROCKET -> {
				matrices.method_22903();
				matrices.method_22905(s * 0.7f, s * 0.7f, s * 2.4f);
				drawBox(matrices, consumers, argb);
				matrices.method_22909();
				matrices.method_22903();
				matrices.method_46416(0, 0, -s * 1.4f);
				matrices.method_22905(s * 1.1f, s * 1.1f, s * 0.6f);
				drawBox(matrices, consumers, brighten(argb));
				matrices.method_22909();
			}
			case ProjectileEntity.MESH_ORB -> {
				matrices.method_22905(s * 1.6f, s * 1.6f, s * 1.6f);
				drawBox(matrices, consumers, argb);
			}
			case ProjectileEntity.MESH_DRILL -> {
				matrices.method_22903();
				matrices.method_22905(s * 0.55f, s * 0.55f, s * 2.8f);
				drawBox(matrices, consumers, argb);
				matrices.method_22909();
				matrices.method_22903();
				matrices.method_46416(0, 0, s * 1.2f);
				matrices.method_22905(s * 0.95f, s * 0.95f, s * 0.7f);
				drawBox(matrices, consumers, 0xFFFFAA33);
				matrices.method_22909();
			}
			default -> {
				matrices.method_22905(s * 0.45f, s * 0.45f, s * 1.6f);
				drawBox(matrices, consumers, argb);
			}
		}
		matrices.method_22909();
		super.method_3936(entity, yaw, tickDelta, matrices, consumers, light);
	}

	private static int brighten(int argb) {
		int a = (argb >> 24) & 255;
		int r = Math.min(255, ((argb >> 16) & 255) + 40);
		int g = Math.min(255, ((argb >> 8) & 255) + 40);
		int b = Math.min(255, (argb & 255) + 40);
		return (a << 24) | (r << 16) | (g << 8) | b;
	}

	private static void drawBox(class_4587 matrices, class_4597 consumers, int argb) {
		var entry = matrices.method_23760();
		class_4588 vc = consumers.getBuffer(class_1921.method_49047());
		float a = ((argb >> 24) & 255) / 255f;
		float r = ((argb >> 16) & 255) / 255f;
		float g = ((argb >> 8) & 255) / 255f;
		float b = (argb & 255) / 255f;
		float x0 = -0.5f, y0 = -0.5f, z0 = -0.5f;
		float x1 = 0.5f, y1 = 0.5f, z1 = 0.5f;
		quad(vc, entry, x0, y0, z0, x1, y0, z0, x1, y0, z1, x0, y0, z1, r, g, b, a);
		quad(vc, entry, x0, y1, z0, x0, y1, z1, x1, y1, z1, x1, y1, z0, r, g, b, a);
		quad(vc, entry, x0, y0, z0, x0, y1, z0, x1, y1, z0, x1, y0, z0, r, g, b, a);
		quad(vc, entry, x0, y0, z1, x1, y0, z1, x1, y1, z1, x0, y1, z1, r, g, b, a);
		quad(vc, entry, x0, y0, z0, x0, y0, z1, x0, y1, z1, x0, y1, z0, r, g, b, a);
		quad(vc, entry, x1, y0, z0, x1, y1, z0, x1, y1, z1, x1, y0, z1, r, g, b, a);
	}

	private static void quad(class_4588 vc, class_4587.class_4665 entry,
							 float x0, float y0, float z0, float x1, float y1, float z1,
							 float x2, float y2, float z2, float x3, float y3, float z3,
							 float r, float g, float b, float a) {
		vc.method_22918(entry.method_23761(), x0, y0, z0).method_22915(r, g, b, a);
		vc.method_22918(entry.method_23761(), x1, y1, z1).method_22915(r, g, b, a);
		vc.method_22918(entry.method_23761(), x2, y2, z2).method_22915(r, g, b, a);
		vc.method_22918(entry.method_23761(), x3, y3, z3).method_22915(r, g, b, a);
	}

	@Override
	public class_2960 getTexture(ProjectileEntity entity) {
		return class_2960.method_60655("minecraft", "textures/misc/white.png");
	}
}
