package com.terminaldetector.drmd.client.render;

import com.terminaldetector.drmd.world.mega.SkyUfoEntity;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_5617;
import net.minecraft.class_897;
import org.joml.Matrix4f;

/**
 * Airborne XCOM-style saucer — procedural disc + dome for LLOD-scale presence.
 */
public class SkyUfoRenderer extends class_897<SkyUfoEntity> {
	private static final class_2960 TEXTURE = class_2960.method_60655("minecraft", "textures/block/oxidized_copper.png");

	public SkyUfoRenderer(class_5617.class_5618 ctx) {
		super(ctx);
		this.field_4673 = 3.5f;
	}

	@Override
	public void render(SkyUfoEntity entity, float yaw, float tickDelta, class_4587 matrices,
					   class_4597 consumers, int light) {
		super.method_3936(entity, yaw, tickDelta, matrices, consumers, light);
		class_4588 buf = consumers.getBuffer(class_1921.method_23580(TEXTURE));
		float pulse = 0.92f + 0.08f * class_3532.method_15374((entity.field_6012 + tickDelta) * 0.2f);

		matrices.method_22903();
		matrices.method_22905(pulse, pulse, pulse);
		// Flat saucer
		cube(buf, matrices.method_23760().method_23761(), 3.2f, 0.35f, 3.2f, light, 80, 220, 180, 210);
		// Dome
		matrices.method_22904(0, 0.7, 0);
		cube(buf, matrices.method_23760().method_23761(), 1.2f, 0.7f, 1.2f, light, 120, 255, 220, 230);
		// Under-beam glow
		matrices.method_22904(0, -1.6, 0);
		cube(buf, matrices.method_23760().method_23761(), 0.45f, 1.2f, 0.45f, light, 255, 200, 80, 160);
		matrices.method_22909();
	}

	private static void cube(class_4588 buf, Matrix4f mat, float hx, float hy, float hz,
							 int light, int r, int g, int b, int a) {
		quad(buf, mat, -hx, -hy, -hz, hx, -hy, -hz, hx, hy, -hz, -hx, hy, -hz, light, r, g, b, a);
		quad(buf, mat, -hx, -hy, hz, -hx, hy, hz, hx, hy, hz, hx, -hy, hz, light, r, g, b, a);
		quad(buf, mat, -hx, hy, -hz, hx, hy, -hz, hx, hy, hz, -hx, hy, hz, light, r, g, b, a);
		quad(buf, mat, -hx, -hy, -hz, -hx, -hy, hz, hx, -hy, hz, hx, -hy, -hz, light, r, g, b, a);
		quad(buf, mat, -hx, -hy, -hz, -hx, hy, -hz, -hx, hy, hz, -hx, -hy, hz, light, r, g, b, a);
		quad(buf, mat, hx, -hy, -hz, hx, -hy, hz, hx, hy, hz, hx, hy, -hz, light, r, g, b, a);
	}

	private static void quad(class_4588 buf, Matrix4f mat,
							 float x0, float y0, float z0,
							 float x1, float y1, float z1,
							 float x2, float y2, float z2,
							 float x3, float y3, float z3,
							 int light, int r, int g, int b, int a) {
		buf.method_22918(mat, x0, y0, z0).method_1336(r, g, b, a).method_22913(0, 0).method_22922(0).method_60803(light).method_22914(0, 1, 0);
		buf.method_22918(mat, x1, y1, z1).method_1336(r, g, b, a).method_22913(1, 0).method_22922(0).method_60803(light).method_22914(0, 1, 0);
		buf.method_22918(mat, x2, y2, z2).method_1336(r, g, b, a).method_22913(1, 1).method_22922(0).method_60803(light).method_22914(0, 1, 0);
		buf.method_22918(mat, x3, y3, z3).method_1336(r, g, b, a).method_22913(0, 1).method_22922(0).method_60803(light).method_22914(0, 1, 0);
	}

	@Override
	public class_2960 getTexture(SkyUfoEntity entity) {
		return TEXTURE;
	}
}
