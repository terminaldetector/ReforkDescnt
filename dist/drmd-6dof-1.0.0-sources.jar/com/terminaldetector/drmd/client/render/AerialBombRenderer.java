package com.terminaldetector.drmd.client.render;

import com.terminaldetector.drmd.world.bombardment.AerialBombEntity;
import net.minecraft.class_2960;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_5617;
import net.minecraft.class_897;

/** Bomb trail / explosion particles carry the look; renderer keeps shadow-less tracking. */
public class AerialBombRenderer extends class_897<AerialBombEntity> {
	public AerialBombRenderer(class_5617.class_5618 ctx) {
		super(ctx);
	}

	@Override
	public void render(AerialBombEntity entity, float yaw, float tickDelta, class_4587 matrices,
					   class_4597 consumers, int light) {
		super.method_3936(entity, yaw, tickDelta, matrices, consumers, light);
	}

	@Override
	public class_2960 getTexture(AerialBombEntity entity) {
		return class_2960.method_60655("minecraft", "textures/misc/white.png");
	}
}
