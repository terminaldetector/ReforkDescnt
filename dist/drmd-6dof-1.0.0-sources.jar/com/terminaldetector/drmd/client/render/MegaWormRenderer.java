package com.terminaldetector.drmd.client.render;

import com.terminaldetector.drmd.world.mega.MegaWormEntity;
import net.minecraft.class_1921;
import net.minecraft.class_243;
import net.minecraft.class_2960;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_5617;
import net.minecraft.class_897;
import org.joml.Matrix4f;

/**
 * Procedural multi-segment sky worm — landscape-scale body the player can fly along.
 */
public class MegaWormRenderer extends class_897<MegaWormEntity> {
	private static final class_2960 TEXTURE = class_2960.method_60655("minecraft", "textures/block/magma.png");

	public MegaWormRenderer(class_5617.class_5618 ctx) {
		super(ctx);
	}

	@Override
	public void render(MegaWormEntity entity, float yaw, float tickDelta, class_4587 matrices,
					   class_4597 consumers, int light) {
		super.method_3936(entity, yaw, tickDelta, matrices, consumers, light);
		class_4588 buf = consumers.getBuffer(class_1921.method_23572(TEXTURE));
		class_243 origin = entity.method_30950(tickDelta);
		for (int i = 0; i < MegaWormEntity.SEGMENTS; i++) {
			class_243 seg = entity.segmentPos(i, tickDelta).method_1020(origin);
			float scale = 1.6f - i * 0.03f;
			matrices.method_22903();
			matrices.method_22904(seg.field_1352, seg.field_1351, seg.field_1350);
			Matrix4f mat = matrices.method_23760().method_23761();
			cube(buf, mat, scale, light, 180, 90 + i * 2, 40);
			matrices.method_22909();
		}
	}

	private static void cube(class_4588 buf, Matrix4f mat, float s, int light, int r, int g, int b) {
		float h = s;
		quad(buf, mat, -s, -h, -s, s, -h, -s, s, h, -s, -s, h, -s, light, r, g, b);
		quad(buf, mat, -s, -h, s, -s, h, s, s, h, s, s, -h, s, light, r, g, b);
		quad(buf, mat, -s, h, -s, s, h, -s, s, h, s, -s, h, s, light, r, g, b);
		quad(buf, mat, -s, -h, -s, -s, -h, s, s, -h, s, s, -h, -s, light, r, g, b);
		quad(buf, mat, -s, -h, -s, -s, h, -s, -s, h, s, -s, -h, s, light, r, g, b);
		quad(buf, mat, s, -h, -s, s, -h, s, s, h, s, s, h, -s, light, r, g, b);
	}

	private static void quad(class_4588 buf, Matrix4f mat,
							 float x0, float y0, float z0,
							 float x1, float y1, float z1,
							 float x2, float y2, float z2,
							 float x3, float y3, float z3,
							 int light, int r, int g, int b) {
		buf.method_22918(mat, x0, y0, z0).method_1336(r, g, b, 255).method_22913(0, 0).method_22922(0).method_60803(light).method_22914(0, 1, 0);
		buf.method_22918(mat, x1, y1, z1).method_1336(r, g, b, 255).method_22913(1, 0).method_22922(0).method_60803(light).method_22914(0, 1, 0);
		buf.method_22918(mat, x2, y2, z2).method_1336(r, g, b, 255).method_22913(1, 1).method_22922(0).method_60803(light).method_22914(0, 1, 0);
		buf.method_22918(mat, x3, y3, z3).method_1336(r, g, b, 255).method_22913(0, 1).method_22922(0).method_60803(light).method_22914(0, 1, 0);
	}

	@Override
	public class_2960 getTexture(MegaWormEntity entity) {
		return TEXTURE;
	}
}
