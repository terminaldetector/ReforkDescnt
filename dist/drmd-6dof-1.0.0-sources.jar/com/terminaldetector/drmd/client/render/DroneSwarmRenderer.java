package com.terminaldetector.drmd.client.render;

import com.terminaldetector.drmd.world.mega.DroneSwarmEntity;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_5617;
import net.minecraft.class_897;
import org.joml.Matrix4f;

/**
 * Swarm anchor — translucent cloud silhouette; actual drones are separate entities.
 */
public class DroneSwarmRenderer extends class_897<DroneSwarmEntity> {
	private static final class_2960 TEXTURE = class_2960.method_60655("minecraft", "textures/block/redstone_block.png");

	public DroneSwarmRenderer(class_5617.class_5618 ctx) {
		super(ctx);
	}

	@Override
	public void render(DroneSwarmEntity entity, float yaw, float tickDelta, class_4587 matrices,
					   class_4597 consumers, int light) {
		super.method_3936(entity, yaw, tickDelta, matrices, consumers, light);
		class_4588 buf = consumers.getBuffer(class_1921.method_23580(TEXTURE));
		Matrix4f mat = matrices.method_23760().method_23761();
		float s = 8f;
		quad(buf, mat, -s, -s * 0.4f, -s, s, -s * 0.4f, -s, s, s * 0.4f, -s, -s, s * 0.4f, -s, light);
		quad(buf, mat, -s, -s * 0.4f, s, -s, s * 0.4f, s, s, s * 0.4f, s, s, -s * 0.4f, s, light);
		quad(buf, mat, -s, s * 0.4f, -s, s, s * 0.4f, -s, s, s * 0.4f, s, -s, s * 0.4f, s, light);
		quad(buf, mat, -s, -s * 0.4f, -s, -s, -s * 0.4f, s, s, -s * 0.4f, s, s, -s * 0.4f, -s, light);
	}

	private static void quad(class_4588 buf, Matrix4f mat,
							 float x0, float y0, float z0,
							 float x1, float y1, float z1,
							 float x2, float y2, float z2,
							 float x3, float y3, float z3,
							 int light) {
		buf.method_22918(mat, x0, y0, z0).method_1336(200, 40, 40, 90).method_22913(0, 0).method_22922(0).method_60803(light).method_22914(0, 1, 0);
		buf.method_22918(mat, x1, y1, z1).method_1336(200, 40, 40, 90).method_22913(1, 0).method_22922(0).method_60803(light).method_22914(0, 1, 0);
		buf.method_22918(mat, x2, y2, z2).method_1336(200, 40, 40, 90).method_22913(1, 1).method_22922(0).method_60803(light).method_22914(0, 1, 0);
		buf.method_22918(mat, x3, y3, z3).method_1336(200, 40, 40, 90).method_22913(0, 1).method_22922(0).method_60803(light).method_22914(0, 1, 0);
	}

	@Override
	public class_2960 getTexture(DroneSwarmEntity entity) {
		return TEXTURE;
	}
}
