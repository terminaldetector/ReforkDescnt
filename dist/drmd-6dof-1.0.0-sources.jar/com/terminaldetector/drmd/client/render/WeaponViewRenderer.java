package com.terminaldetector.drmd.client.render;

import com.terminaldetector.drmd.client.DescentClientState;
import com.terminaldetector.drmd.weapon.items.DescentWeaponItem;
import com.terminaldetector.drmd.workshop.ClusterModule;
import com.terminaldetector.drmd.workshop.ConstructionRegistry;
import com.terminaldetector.drmd.workshop.WeaponClusters;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.class_1799;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_7833;
import java.util.List;

/**
 * First-person Doom-style weapon view from construction clusters.
 * Port of d6_wepview.lua + d6_sck_bridge VElements pipeline.
 * Modules are drawn as colored boxes relative to the camera (no GMod models).
 */
public final class WeaponViewRenderer {
	private WeaponViewRenderer() {}

	public static void register() {
		WorldRenderEvents.AFTER_TRANSLUCENT.register(context -> {
			class_310 mc = class_310.method_1551();
			if (mc.field_1724 == null || mc.field_1690.method_31044().method_31034() == false) return;
			if (!DescentClientState.enabled) return;
			if (mc.field_1690.field_1842) return;

			class_1799 stack = mc.field_1724.method_6047();
			if (!(stack.method_7909() instanceof DescentWeaponItem wep)) return;

			List<ClusterModule> modules = ConstructionRegistry.getModules(wep.getDef().id);
			if (modules.isEmpty()) return;

			class_4587 matrices = context.matrixStack();
			class_4597 consumers = context.consumers();
			if (matrices == null || consumers == null) return;

			matrices.method_22903();
			// Camera-relative: origin at eye, looking down -Z in view space via camera transform already applied.
			// WorldRenderEvents gives world space — convert eye offset manually.
			class_243 cam = context.camera().method_19326();
			float yaw = context.camera().method_19330();
			float pitch = context.camera().method_19329();
			float roll = com.terminaldetector.drmd.client.flight.DescentCamera.viewRoll();

			class_243 look;
			class_243 right;
			class_243 up;
			if (DescentClientState.attitudeValid) {
				var att = com.terminaldetector.drmd.client.flight.ShipAttitudeClient.get();
				look = att.forward();
				up = att.up();
				right = att.right();
			} else {
				look = class_243.method_1030(pitch, yaw);
				right = look.method_1036(new class_243(0, 1, 0));
				if (right.method_1027() < 1e-6) right = new class_243(1, 0, 0);
				right = right.method_1029();
				up = right.method_1036(look).method_1029();
			}
			class_243 rr = right;
			class_243 uu = up;

			float time = (mc.field_1724.field_6012 + context.tickCounter().method_60637(false)) / 20f;

			for (ClusterModule m : modules) {
				float fwd = m.posFwd / 16f;
				float rgt = m.posRgt / 16f;
				float upp = m.posUp / 16f;
				if (m.bobAmp > 0 && m.bobFreq > 0) {
					upp += (float) (Math.sin(time * m.bobFreq * Math.PI * 2) * m.bobAmp / 16f);
				}
				class_243 pos = cam.method_1019(look.method_1021(fwd)).method_1019(rr.method_1021(rgt)).method_1019(uu.method_1021(upp));

				matrices.method_22903();
				matrices.method_22904(pos.field_1352 - cam.field_1352, pos.field_1351 - cam.field_1351, pos.field_1350 - cam.field_1350);
				matrices.method_22907(class_7833.field_40716.rotationDegrees(-yaw));
				matrices.method_22907(class_7833.field_40714.rotationDegrees(pitch));
				matrices.method_22907(class_7833.field_40718.rotationDegrees(roll + m.roll));
				if (m.spin != 0) {
					matrices.method_22907(class_7833.field_40718.rotationDegrees(time * m.spin * 60f));
				}
				float s = 0.08f * m.scaleX;
				matrices.method_22905(s, s, s * (modelLength(m.model)));

				int[] rgb = colorForModel(m);
				int argb = (m.colorA << 24) | (rgb[0] << 16) | (rgb[1] << 8) | rgb[2];
				if ("gravy".equals(m.model)) {
					drawGravyClaw(matrices, consumers, argb);
				} else if ("nosegun".equals(m.model)) {
					drawNoseGun(matrices, consumers, argb);
				} else {
					drawBox(matrices, consumers, argb, 15728880);
				}
				matrices.method_22909();
			}
			matrices.method_22909();
		});
	}

	/** Gravy manipulator — fork/claw silhouette (MC is simple enough for procedural barrels). */
	private static void drawGravyClaw(class_4587 matrices, class_4597 consumers, int argb) {
		drawBox(matrices, consumers, argb, 15728880);
		matrices.method_22903();
		matrices.method_46416(-0.7f, 0.4f, 0.6f);
		matrices.method_22905(0.35f, 0.35f, 1.4f);
		drawBox(matrices, consumers, argb, 15728880);
		matrices.method_22909();
		matrices.method_22903();
		matrices.method_46416(0.7f, 0.4f, 0.6f);
		matrices.method_22905(0.35f, 0.35f, 1.4f);
		drawBox(matrices, consumers, argb, 15728880);
		matrices.method_22909();
		matrices.method_22903();
		matrices.method_46416(0f, -0.55f, 0.5f);
		matrices.method_22905(0.3f, 0.3f, 1.2f);
		drawBox(matrices, consumers, argb, 15728880);
		matrices.method_22909();
	}

	private static void drawNoseGun(class_4587 matrices, class_4597 consumers, int argb) {
		drawBox(matrices, consumers, argb, 15728880);
		matrices.method_22903();
		matrices.method_46416(0, 0, 0.55f);
		matrices.method_22905(0.55f, 0.55f, 0.9f);
		drawBox(matrices, consumers, argb, 15728880);
		matrices.method_22909();
	}

	private static float modelLength(String model) {
		return switch (model) {
			case "nosegun" -> 2.2f;
			case "strider" -> 2.8f;
			case "gravy" -> 1.4f;
			default -> 1.8f; // barrel
		};
	}

	private static int[] colorForModel(ClusterModule m) {
		// Tint by cluster role, modulated by model type
		int[] base = WeaponClusters.COLORS[WeaponClusters.rank(m.cluster)];
		return switch (m.model) {
			case "gravy" -> new int[]{180, 200, 255};
			case "strider" -> new int[]{220, 160, 80};
			case "nosegun" -> new int[]{Math.min(255, base[0] + 40), base[1], base[2]};
			default -> base;
		};
	}

	private static void drawBox(class_4587 matrices, class_4597 consumers, int argb, int light) {
		// Use debug/immediate filled quad via Minecraft's built-in debug renderer style
		var entry = matrices.method_23760();
		var vc = consumers.getBuffer(net.minecraft.class_1921.method_49047());
		float a = ((argb >> 24) & 255) / 255f;
		float r = ((argb >> 16) & 255) / 255f;
		float g = ((argb >> 8) & 255) / 255f;
		float b = (argb & 255) / 255f;
		float x0 = -0.5f, y0 = -0.5f, z0 = -0.5f;
		float x1 = 0.5f, y1 = 0.5f, z1 = 0.5f;
		// 6 faces — compact
		quad(vc, entry, x0, y0, z0, x1, y0, z0, x1, y0, z1, x0, y0, z1, r, g, b, a); // -Y
		quad(vc, entry, x0, y1, z0, x0, y1, z1, x1, y1, z1, x1, y1, z0, r, g, b, a); // +Y
		quad(vc, entry, x0, y0, z0, x0, y1, z0, x1, y1, z0, x1, y0, z0, r, g, b, a); // -Z
		quad(vc, entry, x0, y0, z1, x1, y0, z1, x1, y1, z1, x0, y1, z1, r, g, b, a); // +Z
		quad(vc, entry, x0, y0, z0, x0, y0, z1, x0, y1, z1, x0, y1, z0, r, g, b, a); // -X
		quad(vc, entry, x1, y0, z0, x1, y1, z0, x1, y1, z1, x1, y0, z1, r, g, b, a); // +X
	}

	private static void quad(net.minecraft.class_4588 vc, class_4587.class_4665 entry,
							 float x0, float y0, float z0, float x1, float y1, float z1,
							 float x2, float y2, float z2, float x3, float y3, float z3,
							 float r, float g, float b, float a) {
		vc.method_22918(entry.method_23761(), x0, y0, z0).method_22915(r, g, b, a);
		vc.method_22918(entry.method_23761(), x1, y1, z1).method_22915(r, g, b, a);
		vc.method_22918(entry.method_23761(), x2, y2, z2).method_22915(r, g, b, a);
		vc.method_22918(entry.method_23761(), x3, y3, z3).method_22915(r, g, b, a);
	}
}
