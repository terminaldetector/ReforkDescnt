package com.terminaldetector.drmd.client.render;

import com.terminaldetector.drmd.world.end.EndReactorBossEntity;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_5617;
import net.minecraft.class_897;
import org.joml.Matrix4f;

/**
 * End giga-reactor core — procedural orb + ring silhouette.
 */
public class EndReactorBossRenderer extends class_897<EndReactorBossEntity> {
	private static final class_2960 TEXTURE = class_2960.method_60655("minecraft", "textures/block/crying_obsidian.png");

	public EndReactorBossRenderer(class_5617.class_5618 ctx) {
		super(ctx);
		this.field_4673 = 2.4f;
	}

	@Override
	public void render(EndReactorBossEntity entity, float yaw, float tickDelta, class_4587 matrices,
					   class_4597 consumers, int light) {
		super.method_3936(entity, yaw, tickDelta, matrices, consumers, light);
		float pulse = 0.85f + 0.15f * class_3532.method_15374((entity.field_6012 + tickDelta) * 0.15f);
		boolean shielded = entity.method_6032() >= entity.method_6063() * 0.99f
				|| entity.field_6012 < 40; // visual only; shield state is server-driven via particles
		class_4588 buf = consumers.getBuffer(class_1921.method_23580(TEXTURE));

		matrices.method_22903();
		matrices.method_22905(pulse, pulse, pulse);
		Matrix4f mat = matrices.method_23760().method_23761();
		cube(buf, mat, 1.6f, light, 180, 60, 255, 210);
		cube(buf, mat, 1.05f, light, 255, 120, 255, 230);
		matrices.method_22909();

		// Outer ring
		matrices.method_22903();
		matrices.method_22904(0, 0.2, 0);
		float spin = (entity.field_6012 + tickDelta) * 0.04f;
		for (int i = 0; i < 8; i++) {
			double a = spin + i * (Math.PI * 2 / 8);
			matrices.method_22903();
			matrices.method_22904(Math.cos(a) * 2.4, Math.sin(a * 1.3) * 0.35, Math.sin(a) * 2.4);
			cube(buf, matrices.method_23760().method_23761(), 0.35f, light,
					shielded ? 80 : 255, shielded ? 160 : 80, 255, 200);
			matrices.method_22909();
		}
		matrices.method_22909();
	}

	private static void cube(class_4588 buf, Matrix4f mat, float s, int light, int r, int g, int b, int a) {
		quad(buf, mat, -s, -s, -s, s, -s, -s, s, s, -s, -s, s, -s, light, r, g, b, a);
		quad(buf, mat, -s, -s, s, -s, s, s, s, s, s, s, -s, s, light, r, g, b, a);
		quad(buf, mat, -s, s, -s, s, s, -s, s, s, s, -s, s, s, light, r, g, b, a);
		quad(buf, mat, -s, -s, -s, -s, -s, s, s, -s, s, s, -s, -s, light, r, g, b, a);
		quad(buf, mat, -s, -s, -s, -s, s, -s, -s, s, s, -s, -s, s, light, r, g, b, a);
		quad(buf, mat, s, -s, -s, s, -s, s, s, s, s, s, s, -s, light, r, g, b, a);
	}

	private static void quad(class_4588 buf, Matrix4f mat,
							 float x0, float y0, float z0,
							 float x1, float y1, float z1,
							 float x2, float y2, float z2,
							 float x3, float y3, float z3,
							 int light, int r, int g, int b, int a) {
		buf.method_22918(mat, x0, y0, z0).method_1336(r, g, b, a).method_22913(0, 0).method_22922(0).method_60803(light).method_22914(0, 1, 0);
		buf.method_22918(mat, x1, y1, z1).method_1336(r, g, b, a).method_22913(1, 0).method_22922(0).method_60803(light).method_22914(0, 1, 0);
		buf.method_22918(mat, x2, y2, z2).method_1336(r, g, b, a).method_22913(1, 1).method_22922(0).method_60803(light).method_22914(0, 1, 0);
		buf.method_22918(mat, x3, y3, z3).method_1336(r, g, b, a).method_22913(0, 1).method_22922(0).method_60803(light).method_22914(0, 1, 0);
	}

	@Override
	public class_2960 getTexture(EndReactorBossEntity entity) {
		return TEXTURE;
	}
}
