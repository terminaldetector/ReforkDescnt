package com.terminaldetector.drmd.client.render;

import com.terminaldetector.drmd.DescentMod;
import com.terminaldetector.drmd.entity.ReactorDisplayEntity;
import com.terminaldetector.drmd.entity.model.ReactorCoreModel;
import net.minecraft.class_2960;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_5601;
import net.minecraft.class_5617;
import net.minecraft.class_7833;
import net.minecraft.class_897;

public class ReactorDisplayRenderer extends class_897<ReactorDisplayEntity> {
	public static final class_5601 LAYER = new class_5601(class_2960.method_60655(DescentMod.MOD_ID, "reactor_core"), "main");
	private static final class_2960 TEXTURE = class_2960.method_60655(DescentMod.MOD_ID, "textures/entity/reactor_core.png");
	private final ReactorCoreModel<ReactorDisplayEntity> model;

	public ReactorDisplayRenderer(class_5617.class_5618 ctx) {
		super(ctx);
		this.model = new ReactorCoreModel<>(ctx.method_32167(LAYER));
	}

	@Override
	public void render(ReactorDisplayEntity entity, float yaw, float tickDelta, class_4587 matrices,
					   class_4597 consumers, int light) {
		matrices.method_22903();
		matrices.method_22905(-1.5f, -1.5f, 1.5f);
		matrices.method_22904(0, -1.0, 0);
		matrices.method_22907(class_7833.field_40716.rotationDegrees((entity.field_6012 + tickDelta) * 2f));
		model.method_2819(entity, 0, 0, entity.field_6012 + tickDelta, 0, 0);
		class_4588 vc = consumers.getBuffer(model.method_23500(TEXTURE));
		model.method_2828(matrices, vc, light, class_4608.field_21444, 0xFFFFFFFF);
		matrices.method_22909();
		super.method_3936(entity, yaw, tickDelta, matrices, consumers, light);
	}

	@Override
	public class_2960 getTexture(ReactorDisplayEntity entity) {
		return TEXTURE;
	}
}
