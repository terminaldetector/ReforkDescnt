package com.terminaldetector.drmd.client.render;

import com.terminaldetector.drmd.DescentMod;
import com.terminaldetector.drmd.entity.DroneEntity;
import com.terminaldetector.drmd.entity.model.DescentDroneModel;
import net.minecraft.class_2960;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_5601;
import net.minecraft.class_5617;
import net.minecraft.class_927;

public class DroneRenderer extends class_927<DroneEntity, DescentDroneModel<DroneEntity>> {
	public static final class_5601 LAYER = new class_5601(class_2960.method_60655(DescentMod.MOD_ID, "drone"), "main");
	private static final class_2960 TEXTURE = class_2960.method_60655(DescentMod.MOD_ID, "textures/entity/drone.png");

	public DroneRenderer(class_5617.class_5618 ctx) {
		super(ctx, new DescentDroneModel<>(ctx.method_32167(LAYER)), 0.4f);
	}

	@Override
	public void render(DroneEntity entity, float yaw, float tickDelta, class_4587 matrices,
					   class_4597 consumers, int light) {
		matrices.method_22903();
		matrices.method_22905(1.2f, 1.2f, 1.2f);
		matrices.method_22907(net.minecraft.class_7833.field_40718.rotationDegrees(entity.getFlightRoll()));
		super.method_4054(entity, yaw, tickDelta, matrices, consumers, light);
		matrices.method_22909();
	}

	@Override
	public class_2960 getTexture(DroneEntity entity) {
		return TEXTURE;
	}
}
