package com.terminaldetector.drmd.client.render;

import com.terminaldetector.drmd.DescentMod;
import com.terminaldetector.drmd.entity.PyroShipEntity;
import com.terminaldetector.drmd.entity.model.PyroShipModel;
import net.minecraft.class_2960;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_5601;
import net.minecraft.class_5617;
import net.minecraft.class_7833;
import net.minecraft.class_897;

public class PyroShipRenderer extends class_897<PyroShipEntity> {
	public static final class_5601 LAYER = new class_5601(class_2960.method_60655(DescentMod.MOD_ID, "pyro_ship"), "main");
	private static final class_2960 TEXTURE = class_2960.method_60655(DescentMod.MOD_ID, "textures/entity/pyro_ship.png");
	private final PyroShipModel<PyroShipEntity> model;

	public PyroShipRenderer(class_5617.class_5618 ctx) {
		super(ctx);
		this.model = new PyroShipModel<>(ctx.method_32167(LAYER));
		this.field_4673 = 0.8f;
	}

	@Override
	public void render(PyroShipEntity entity, float yaw, float tickDelta, class_4587 matrices,
					   class_4597 consumers, int light) {
		matrices.method_22903();
		matrices.method_22907(class_7833.field_40716.rotationDegrees(-yaw));
		matrices.method_22907(class_7833.field_40714.rotationDegrees(entity.method_36455()));
		matrices.method_22905(-1f, -1f, 1f);
		matrices.method_22904(0, -0.5, 0);
		model.method_2819(entity, 0, 0, entity.field_6012 + tickDelta, 0, 0);
		class_4588 vc = consumers.getBuffer(model.method_23500(TEXTURE));
		model.method_2828(matrices, vc, light, class_4608.field_21444, 0xFFFFFFFF);
		matrices.method_22909();
		super.method_3936(entity, yaw, tickDelta, matrices, consumers, light);
	}

	@Override
	public class_2960 getTexture(PyroShipEntity entity) {
		return TEXTURE;
	}
}
