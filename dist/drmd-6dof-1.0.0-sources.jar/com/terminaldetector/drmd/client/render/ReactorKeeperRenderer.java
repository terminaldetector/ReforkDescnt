package com.terminaldetector.drmd.client.render;

import com.terminaldetector.drmd.world.mega.ReactorKeeperEntity;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_5617;
import net.minecraft.class_897;
import org.joml.Matrix4f;

/**
 * Reactor Keeper — procedural sentinel silhouette (placeholder mega-mob).
 */
public class ReactorKeeperRenderer extends class_897<ReactorKeeperEntity> {
	private static final class_2960 TEXTURE = class_2960.method_60655("minecraft", "textures/block/sea_lantern.png");

	public ReactorKeeperRenderer(class_5617.class_5618 ctx) {
		super(ctx);
	}

	@Override
	public void render(ReactorKeeperEntity entity, float yaw, float tickDelta, class_4587 matrices,
					   class_4597 consumers, int light) {
		super.method_3936(entity, yaw, tickDelta, matrices, consumers, light);
		class_4588 buf = consumers.getBuffer(class_1921.method_23580(TEXTURE));
		Matrix4f mat = matrices.method_23760().method_23761();
		float s = 2.2f;
		cube(buf, mat, s, light, 60, 220, 255, 200);
		// Core
		matrices.method_22903();
		matrices.method_22904(0, 1.2, 0);
		cube(buf, matrices.method_23760().method_23761(), 0.9f, light, 255, 255, 200, 230);
		matrices.method_22909();
	}

	private static void cube(class_4588 buf, Matrix4f mat, float s, int light, int r, int g, int b, int a) {
		quad(buf, mat, -s, -s, -s, s, -s, -s, s, s, -s, -s, s, -s, light, r, g, b, a);
		quad(buf, mat, -s, -s, s, -s, s, s, s, s, s, s, -s, s, light, r, g, b, a);
		quad(buf, mat, -s, s, -s, s, s, -s, s, s, s, -s, s, s, light, r, g, b, a);
		quad(buf, mat, -s, -s, -s, -s, -s, s, s, -s, s, s, -s, -s, light, r, g, b, a);
		quad(buf, mat, -s, -s, -s, -s, s, -s, -s, s, s, -s, -s, s, light, r, g, b, a);
		quad(buf, mat, s, -s, -s, s, -s, s, s, s, s, s, s, -s, light, r, g, b, a);
	}

	private static void quad(class_4588 buf, Matrix4f mat,
							 float x0, float y0, float z0,
							 float x1, float y1, float z1,
							 float x2, float y2, float z2,
							 float x3, float y3, float z3,
							 int light, int r, int g, int b, int a) {
		buf.method_22918(mat, x0, y0, z0).method_1336(r, g, b, a).method_22913(0, 0).method_22922(0).method_60803(light).method_22914(0, 1, 0);
		buf.method_22918(mat, x1, y1, z1).method_1336(r, g, b, a).method_22913(1, 0).method_22922(0).method_60803(light).method_22914(0, 1, 0);
		buf.method_22918(mat, x2, y2, z2).method_1336(r, g, b, a).method_22913(1, 1).method_22922(0).method_60803(light).method_22914(0, 1, 0);
		buf.method_22918(mat, x3, y3, z3).method_1336(r, g, b, a).method_22913(0, 1).method_22922(0).method_60803(light).method_22914(0, 1, 0);
	}

	@Override
	public class_2960 getTexture(ReactorKeeperEntity entity) {
		return TEXTURE;
	}
}
