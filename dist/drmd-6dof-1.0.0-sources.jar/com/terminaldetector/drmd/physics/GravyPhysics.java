package com.terminaldetector.drmd.physics;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_1297;
import net.minecraft.class_1937;
import net.minecraft.class_243;
import net.minecraft.class_3222;

/**
 * Havok-like subset for the gravity gun — grab / hold spring / throw.
 * Not a full rigid-body solver: enough for Descent gravy feel in Minecraft.
 *
 * <p>Status: scaffold. Wire from {@code DescentWeaponItem.fireGravy} next.</p>
 */
public final class GravyPhysics {
	private static final Map<UUID, Grab> GRABS = new ConcurrentHashMap<>();

	public record Grab(UUID targetId, float mass, class_243 holdOffset) {}

	private GravyPhysics() {}

	public static boolean isHolding(class_3222 player) {
		return GRABS.containsKey(player.method_5667());
	}

	public static void release(class_3222 player) {
		GRABS.remove(player.method_5667());
	}

	/** Begin grab if look-ray hits a living / prop entity within range. */
	public static boolean tryGrab(class_3222 player, class_1297 target, float mass) {
		if (target == null || !target.method_5805()) return false;
		GRABS.put(player.method_5667(), new Grab(target.method_5667(), Math.max(0.2f, mass), new class_243(0, 0, 2.5)));
		return true;
	}

	/** Spring-hold toward a point in front of the player's eyes (6DoF-friendly). */
	public static void tick(class_3222 player) {
		Grab grab = GRABS.get(player.method_5667());
		if (grab == null) return;
		class_1937 world = player.method_37908();
		class_1297 target = null;
		for (class_1297 e : ((net.minecraft.class_3218) world).method_27909()) {
			if (e.method_5667().equals(grab.targetId())) {
				target = e;
				break;
			}
		}
		if (target == null || !target.method_5805()) {
			release(player);
			return;
		}
		class_243 hold = player.method_33571().method_1019(player.method_5828(1f).method_1021(3.2));
		class_243 delta = hold.method_1020(target.method_19538());
		// Soft spring + damp (Havok-lite)
		double k = 0.35 / grab.mass();
		double damp = 0.82;
		class_243 vel = target.method_18798().method_1021(damp).method_1019(delta.method_1021(k));
		target.method_18799(vel);
		target.field_6037 = true;
		target.field_6017 = 0;
	}

	public static void fling(class_3222 player, float power) {
		Grab grab = GRABS.get(player.method_5667());
		if (grab == null) return;
		for (class_1297 e : ((net.minecraft.class_3218) player.method_37908()).method_27909()) {
			if (!e.method_5667().equals(grab.targetId())) continue;
			class_243 impulse = player.method_5828(1f).method_1021(power / grab.mass());
			e.method_5762(impulse.field_1352, impulse.field_1351, impulse.field_1350);
			e.field_6037 = true;
			break;
		}
		release(player);
	}
}
