package com.terminaldetector.drmd.mixin;

import com.terminaldetector.drmd.DescentPlayerData;
import com.terminaldetector.drmd.entity.PyroShipEntity;
import com.terminaldetector.drmd.shield.ShieldSystem;
import com.terminaldetector.drmd.weapon.core.DamageClass;
import com.terminaldetector.drmd.world.gravity.FootGravitySystem;
import net.minecraft.class_1282;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_243;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1309.class)
public class LivingEntityMixin {
	@ModifyVariable(method = "damage", at = @At("HEAD"), argsOnly = true)
	private float drmd$shieldAbsorb(float amount, class_1282 source) {
		class_1309 self = (class_1309) (Object) this;
		if (!(self instanceof class_1657 player)) return amount;
		DescentPlayerData data = DescentPlayerData.get(player);
		if (!data.isEnabled()) return amount;
		DamageClass cls = DamageClass.KINETIC;
		String n = source.method_5525();
		if (n.contains("magic") || n.contains("lightning") || n.contains("thorns")) cls = DamageClass.ENERGY;
		else if (n.contains("explosion") || n.contains("fireworks")) cls = DamageClass.EXPLOSIVE;
		return ShieldSystem.absorb(data, amount, cls);
	}

	/** Local-UP foot travel — walls/ceilings from gravity torch / generator. */
	@Inject(method = "travel", at = @At("HEAD"), cancellable = true)
	private void drmd$footGravityTravel(class_243 movementInput, CallbackInfo ci) {
		class_1309 self = (class_1309) (Object) this;
		if (!(self instanceof class_1657 player)) return;
		if (player.method_5854() instanceof PyroShipEntity) return;
		if (DescentPlayerData.get(player).isEnabled()) return;
		if (!FootGravitySystem.isActive(player.method_5667())) return;
		FootGravitySystem.travel(player, movementInput);
		ci.cancel();
	}
}
