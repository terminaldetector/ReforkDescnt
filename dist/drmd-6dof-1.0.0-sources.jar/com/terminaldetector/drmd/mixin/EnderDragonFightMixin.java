package com.terminaldetector.drmd.mixin;

import com.terminaldetector.drmd.world.end.EndReactorSession;
import net.minecraft.class_2881;
import net.minecraft.class_3218;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Suppress vanilla dragon loop — End fight is the mega-reactor base.
 */
@Mixin(class_2881.class)
public class EnderDragonFightMixin {
	@Shadow @Final private class_3218 world;

	@Inject(method = "tick", at = @At("HEAD"), cancellable = true)
	private void drmd$replaceDragonFight(CallbackInfo ci) {
		EndReactorSession.suppressDragons(world);
		EndReactorSession.ensureBase(world);
		ci.cancel();
	}

	@Inject(method = "respawnDragon", at = @At("HEAD"), cancellable = true)
	private void drmd$noRespawn(CallbackInfo ci) {
		ci.cancel();
	}
}
