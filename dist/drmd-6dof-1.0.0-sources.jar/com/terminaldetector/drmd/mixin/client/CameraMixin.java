package com.terminaldetector.drmd.mixin.client;

import com.terminaldetector.drmd.client.DescentClientState;
import com.terminaldetector.drmd.client.flight.DescentCamera;
import net.minecraft.class_1297;
import net.minecraft.class_1922;
import net.minecraft.class_243;
import net.minecraft.class_4184;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * After vanilla Camera.update, apply Descent CalcView placement
 * (CamLag / micro-motion / vib / ship-relative third person).
 */
@Mixin(class_4184.class)
public class CameraMixin {
	@Inject(method = "update", at = @At("RETURN"))
	private void drmd$descentCalcView(class_1922 area, class_1297 focusedEntity, boolean thirdPerson,
									  boolean inverseView, float tickDelta, CallbackInfo ci) {
		if (!DescentClientState.enabled || !DescentClientState.attitudeValid) return;
		class_4184 self = (class_4184) (Object) this;
		CameraAccessor acc = (CameraAccessor) self;
		DescentCamera.apply(self, new DescentCamera.CameraAccess() {
			@Override
			public void drmd$setPos(class_243 pos) {
				acc.drmd$invokeSetPos(pos);
			}

			@Override
			public void drmd$setRotation(float yaw, float pitch) {
				acc.drmd$invokeSetRotation(yaw, pitch);
			}
		}, thirdPerson || inverseView, tickDelta);
	}
}
