package com.terminaldetector.drmd.mixin.client;

import net.minecraft.class_243;
import net.minecraft.class_4184;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_4184.class)
public interface CameraAccessor {
	@Invoker("setPos")
	void drmd$invokeSetPos(class_243 pos);

	@Invoker("setRotation")
	void drmd$invokeSetRotation(float yaw, float pitch);
}
