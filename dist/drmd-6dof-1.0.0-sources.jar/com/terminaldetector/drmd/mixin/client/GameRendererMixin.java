package com.terminaldetector.drmd.mixin.client;

import com.terminaldetector.drmd.client.DescentClientState;
import com.terminaldetector.drmd.client.flight.DescentCamera;
import com.terminaldetector.drmd.client.gravity.FootGravityCamera;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_757;
import net.minecraft.class_7833;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_757.class)
public class GameRendererMixin {
	@Inject(method = "bobView", at = @At("HEAD"), cancellable = true)
	private void drmd$cancelBob(class_4587 matrices, float tickDelta, CallbackInfo ci) {
		if (DescentClientState.enabled || DescentClientState.footGravity) ci.cancel();
	}

	/**
	 * 6DoF bank while flying; otherwise stabilize camera to local gravity UP
	 * (torch / wall / ceiling) so the world reads upright.
	 */
	@Inject(method = "tiltViewWhenHurt", at = @At("HEAD"), cancellable = true)
	private void drmd$cameraBank(class_4587 matrices, float tickDelta, CallbackInfo ci) {
		if (DescentClientState.enabled) {
			float roll = DescentCamera.viewRoll();
			if (Math.abs(roll) > 0.05f) {
				matrices.method_22907(class_7833.field_40718.rotationDegrees(roll));
			}
			ci.cancel();
			return;
		}
		if (DescentClientState.footGravity || !FootGravityCamera.isNearWorldUp(
				new net.minecraft.class_243(
						DescentClientState.localUx, DescentClientState.localUy, DescentClientState.localUz))) {
			FootGravityCamera.apply(matrices);
			ci.cancel();
		}
	}

	/** Mild FOV stretch under afterburner / speed — Descent menu FOV feel. */
	@Inject(method = "getFov", at = @At("RETURN"), cancellable = true)
	private void drmd$fovBoost(class_4184 camera, float tickDelta, boolean changingFov, CallbackInfoReturnable<Double> cir) {
		float boost = DescentCamera.fovBoost();
		if (boost > 0.01f) {
			cir.setReturnValue(cir.getReturnValueD() + boost);
		}
	}
}
