package com.terminaldetector.drmd.mixin.client;

import com.terminaldetector.drmd.client.DescentClientState;
import net.minecraft.class_4587;
import net.minecraft.class_757;
import net.minecraft.class_7833;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_757.class)
public class GameRendererMixin {
	@Inject(method = "bobView", at = @At("HEAD"), cancellable = true)
	private void drmd$cancelBob(class_4587 matrices, float tickDelta, CallbackInfo ci) {
		if (DescentClientState.enabled) ci.cancel();
	}

	/** Always-run camera bank for Descent roll (tiltViewWhenHurt runs every frame). */
	@Inject(method = "tiltViewWhenHurt", at = @At("HEAD"))
	private void drmd$cameraBank(class_4587 matrices, float tickDelta, CallbackInfo ci) {
		if (DescentClientState.enabled && Math.abs(DescentClientState.roll) > 0.05f) {
			matrices.method_22907(class_7833.field_40718.rotationDegrees(DescentClientState.roll));
		}
	}
}
