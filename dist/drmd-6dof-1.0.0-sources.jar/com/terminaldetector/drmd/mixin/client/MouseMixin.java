package com.terminaldetector.drmd.mixin.client;

import com.terminaldetector.drmd.client.DescentClientState;
import com.terminaldetector.drmd.client.flight.ShipAttitudeClient;
import net.minecraft.class_310;
import net.minecraft.class_312;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(class_312.class)
public class MouseMixin {
	@Redirect(
			method = "updateMouse",
			at = @At(
					value = "INVOKE",
					target = "Lnet/minecraft/client/network/ClientPlayerEntity;changeLookDirection(DD)V"
			)
	)
	private void drmd$descentLook(class_746 player, double cursorDeltaX, double cursorDeltaY) {
		if (DescentClientState.enabled && class_310.method_1551().field_1755 == null) {
			ShipAttitudeClient.applyMouse(player, cursorDeltaX, cursorDeltaY);
		} else {
			player.method_5872(cursorDeltaX, cursorDeltaY);
		}
	}
}
