package com.terminaldetector.drmd.mixin.client;

import com.terminaldetector.drmd.client.DescentClientState;
import com.terminaldetector.drmd.client.gravity.FootGravityCamera;
import net.minecraft.class_1309;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_922;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Align the local player model with foot-gravity UP so legs point into the floor
 * (wall/ceiling) — matches the stabilized camera.
 */
@Mixin(class_922.class)
public class LivingEntityRendererMixin {
	@Inject(method = "setupTransforms(Lnet/minecraft/entity/LivingEntity;Lnet/minecraft/client/util/math/MatrixStack;FFFF)V",
			at = @At("RETURN"))
	private void drmd$alignLocalUp(class_1309 entity, class_4587 matrices,
								   float animationProgress, float bodyYaw, float tickDelta, float scale,
								   CallbackInfo ci) {
		class_310 mc = class_310.method_1551();
		if (mc.field_1724 != entity) return;
		if (DescentClientState.enabled || !DescentClientState.footGravity) return;
		FootGravityCamera.apply(matrices);
	}
}
