package com.terminaldetector.drmd;

import com.terminaldetector.drmd.energy.EnergyPreset;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_1657;
import net.minecraft.class_243;
import net.minecraft.class_2487;

/**
 * Per-player DRMD state — mirrors GMod NWVars / ply fields from d6_core, energy, shield.
 */
public class DescentPlayerData {
	private static final Map<UUID, DescentPlayerData> STORE = new ConcurrentHashMap<>();

	public static DescentPlayerData get(class_1657 player) {
		return STORE.computeIfAbsent(player.method_5667(), id -> new DescentPlayerData());
	}

	public static void remove(UUID id) {
		STORE.remove(id);
	}

	// --- Flight (d6_core.lua CFG) ---
	private boolean enabled;
	private boolean flightAssist = true;
	private boolean alwaysRun;
	private boolean thirdPerson;
	private float roll;
	private float rollVel;
	private class_243 velocity = class_243.field_1353;
	private float thrustSpool;
	private float idleTimer;
	private float gravityFactor;
	private float dashCooldown;
	private float dashTimer;
	private boolean hookActive;
	private class_243 hookPos = class_243.field_1353;
	private boolean radarEnabled = true;

	/** Descent ship basis (synced from client while 6DoF). */
	private boolean shipAttitudeValid;
	private float shipFx, shipFy, shipFz = 1f;
	private float shipUx, shipUy = 1f, shipUz;

	// Tunable physics (admin d6_set) — Source units, scaled at runtime
	private float gravity = 200f;
	private float accel = 4200f;
	private float drag = 2.1f;
	private float maxSpeed = 2200f;

	// --- Energy (d6_energy.lua) ---
	private float energy = 100f;
	private float energyMax = 100f;
	private EnergyPreset preset = EnergyPreset.BALANCED;
	private float allocWeapons = 0.34f;
	private float allocShields = 0.33f;
	private float allocEngines = 0.33f;

	// --- Shields (d6_shield.lua) ---
	private float shield = 100f;
	private float shieldMax = 100f;
	private float shieldRegenDelay;

	// --- Combat ---
	private int rocketSubmode; // 0..3
	private int activeWeaponSlot;
	private float gravyEnergy = 100f;
	private boolean gravyGrabbing;

	// Workshop live-tuning overrides
	private float wepInherit = 1f;
	private float wepRecoil = 1f;

	/** First-join tip already shown. */
	private boolean sessionWelcomed;

	public void ensureInit() {
		if (energyMax <= 0) energyMax = 100f;
		if (shieldMax <= 0) shieldMax = 100f;
		if (energy <= 0 && !enabled) energy = energyMax;
		if (shield <= 0 && !enabled) shield = shieldMax;
	}

	public void writeNbt(class_2487 nbt) {
		class_2487 d = new class_2487();
		d.method_10556("enabled", enabled);
		d.method_10556("flightAssist", flightAssist);
		d.method_10556("alwaysRun", alwaysRun);
		d.method_10548("roll", roll);
		d.method_10548("energy", energy);
		d.method_10548("energyMax", energyMax);
		d.method_10582("preset", preset.id);
		d.method_10548("allocW", allocWeapons);
		d.method_10548("allocS", allocShields);
		d.method_10548("allocE", allocEngines);
		d.method_10548("shield", shield);
		d.method_10548("shieldMax", shieldMax);
		d.method_10569("rocketSub", rocketSubmode);
		d.method_10548("gravity", gravity);
		d.method_10548("accel", accel);
		d.method_10548("drag", drag);
		d.method_10548("maxSpeed", maxSpeed);
		d.method_10548("wepInherit", wepInherit);
		d.method_10548("wepRecoil", wepRecoil);
		d.method_10556("radar", radarEnabled);
		d.method_10556("sessionWelcomed", sessionWelcomed);
		nbt.method_10566("DrmdData", d);
	}

	public void readNbt(class_2487 nbt) {
		if (!nbt.method_10545("DrmdData")) return;
		class_2487 d = nbt.method_10562("DrmdData");
		enabled = d.method_10577("enabled");
		flightAssist = d.method_10545("flightAssist") ? d.method_10577("flightAssist") : true;
		alwaysRun = d.method_10577("alwaysRun");
		roll = d.method_10583("roll");
		energy = d.method_10583("energy");
		energyMax = d.method_10545("energyMax") ? d.method_10583("energyMax") : 100f;
		preset = EnergyPreset.fromId(d.method_10558("preset"));
		allocWeapons = d.method_10545("allocW") ? d.method_10583("allocW") : 0.34f;
		allocShields = d.method_10545("allocS") ? d.method_10583("allocS") : 0.33f;
		allocEngines = d.method_10545("allocE") ? d.method_10583("allocE") : 0.33f;
		shield = d.method_10583("shield");
		shieldMax = d.method_10545("shieldMax") ? d.method_10583("shieldMax") : 100f;
		rocketSubmode = d.method_10550("rocketSub");
		if (d.method_10545("gravity")) gravity = d.method_10583("gravity");
		if (d.method_10545("accel")) accel = d.method_10583("accel");
		if (d.method_10545("drag")) drag = d.method_10583("drag");
		if (d.method_10545("maxSpeed")) maxSpeed = d.method_10583("maxSpeed");
		if (d.method_10545("wepInherit")) wepInherit = d.method_10583("wepInherit");
		if (d.method_10545("wepRecoil")) wepRecoil = d.method_10583("wepRecoil");
		radarEnabled = !d.method_10545("radar") || d.method_10577("radar");
		sessionWelcomed = d.method_10577("sessionWelcomed");
	}

	// Getters / setters
	public boolean isEnabled() { return enabled; }
	public void setEnabled(boolean v) { this.enabled = v; }
	public boolean isFlightAssist() { return flightAssist; }
	public void setFlightAssist(boolean v) { this.flightAssist = v; }
	public boolean isAlwaysRun() { return alwaysRun; }
	public void setAlwaysRun(boolean v) { this.alwaysRun = v; }
	public boolean isThirdPerson() { return thirdPerson; }
	public void setThirdPerson(boolean v) { this.thirdPerson = v; }
	public float getRoll() { return roll; }
	public void setRoll(float roll) { this.roll = roll; }
	public float getRollVel() { return rollVel; }
	public void setRollVel(float rollVel) { this.rollVel = rollVel; }
	public class_243 getFlightVelocity() { return velocity; }
	public void setFlightVelocity(class_243 velocity) { this.velocity = velocity; }
	public float getThrustSpool() { return thrustSpool; }
	public void setThrustSpool(float thrustSpool) { this.thrustSpool = thrustSpool; }
	public float getIdleTimer() { return idleTimer; }
	public void setIdleTimer(float idleTimer) { this.idleTimer = idleTimer; }
	public float getGravityFactor() { return gravityFactor; }
	public void setGravityFactor(float gravityFactor) { this.gravityFactor = gravityFactor; }
	public float getDashCooldown() { return dashCooldown; }
	public void setDashCooldown(float dashCooldown) { this.dashCooldown = dashCooldown; }
	public float getDashTimer() { return dashTimer; }
	public void setDashTimer(float dashTimer) { this.dashTimer = dashTimer; }
	public boolean isHookActive() { return hookActive; }
	public void setHookActive(boolean hookActive) { this.hookActive = hookActive; }
	public class_243 getHookPos() { return hookPos; }
	public void setHookPos(class_243 hookPos) { this.hookPos = hookPos; }
	public boolean isRadarEnabled() { return radarEnabled; }
	public void setRadarEnabled(boolean radarEnabled) { this.radarEnabled = radarEnabled; }

	public float getGravity() { return gravity; }
	public void setGravity(float gravity) { this.gravity = gravity; }
	public float getAccel() { return accel; }
	public void setAccel(float accel) { this.accel = accel; }
	public float getDrag() { return drag; }
	public void setDrag(float drag) { this.drag = drag; }
	public float getMaxSpeed() { return maxSpeed; }
	public void setMaxSpeed(float maxSpeed) { this.maxSpeed = maxSpeed; }

	public float getEnergy() { return energy; }
	public void setEnergy(float energy) { this.energy = energy; }
	public float getEnergyMax() { return energyMax; }
	public void setEnergyMax(float energyMax) { this.energyMax = energyMax; }
	public EnergyPreset getPreset() { return preset; }
	public void setPreset(EnergyPreset preset) { this.preset = preset; }
	public float getAllocWeapons() { return allocWeapons; }
	public float getAllocShields() { return allocShields; }
	public float getAllocEngines() { return allocEngines; }
	public void setAlloc(float w, float s, float e) {
		float sum = w + s + e;
		if (sum <= 0) return;
		this.allocWeapons = w / sum;
		this.allocShields = s / sum;
		this.allocEngines = e / sum;
	}

	public float getShield() { return shield; }
	public void setShield(float shield) { this.shield = shield; }
	public float getShieldMax() { return shieldMax; }
	public void setShieldMax(float shieldMax) { this.shieldMax = shieldMax; }
	public float getShieldRegenDelay() { return shieldRegenDelay; }
	public void setShieldRegenDelay(float shieldRegenDelay) { this.shieldRegenDelay = shieldRegenDelay; }

	public int getRocketSubmode() { return rocketSubmode; }
	public void setRocketSubmode(int rocketSubmode) { this.rocketSubmode = rocketSubmode & 3; }
	public int getActiveWeaponSlot() { return activeWeaponSlot; }
	public void setActiveWeaponSlot(int activeWeaponSlot) { this.activeWeaponSlot = activeWeaponSlot; }
	public float getGravyEnergy() { return gravyEnergy; }
	public void setGravyEnergy(float gravyEnergy) { this.gravyEnergy = gravyEnergy; }
	public boolean isGravyGrabbing() { return gravyGrabbing; }
	public void setGravyGrabbing(boolean gravyGrabbing) { this.gravyGrabbing = gravyGrabbing; }
	public float getWepInherit() { return wepInherit; }
	public void setWepInherit(float wepInherit) { this.wepInherit = wepInherit; }
	public float getWepRecoil() { return wepRecoil; }
	public void setWepRecoil(float wepRecoil) { this.wepRecoil = wepRecoil; }
	public boolean isSessionWelcomed() { return sessionWelcomed; }
	public void setSessionWelcomed(boolean sessionWelcomed) { this.sessionWelcomed = sessionWelcomed; }

	public boolean hasShipAttitude() { return shipAttitudeValid; }

	public void clearShipAttitude() {
		this.shipAttitudeValid = false;
		this.shipFx = 0; this.shipFy = 0; this.shipFz = 1;
		this.shipUx = 0; this.shipUy = 1; this.shipUz = 0;
	}

	public void setShipAttitude(float fx, float fy, float fz, float ux, float uy, float uz) {
		this.shipFx = fx; this.shipFy = fy; this.shipFz = fz;
		this.shipUx = ux; this.shipUy = uy; this.shipUz = uz;
		this.shipAttitudeValid = true;
		com.terminaldetector.drmd.flight.ShipAttitude tmp = new com.terminaldetector.drmd.flight.ShipAttitude();
		tmp.setForwardUp(new class_243(fx, fy, fz), new class_243(ux, uy, uz));
		this.roll = tmp.bankDegrees();
	}

	public class_243 shipForward(class_1657 player) {
		if (shipAttitudeValid) return new class_243(shipFx, shipFy, shipFz).method_1029();
		return player.method_5828(1f);
	}

	public class_243 shipUp(class_1657 player) {
		if (shipAttitudeValid) {
			class_243 f = shipForward(player);
			class_243 u = new class_243(shipUx, shipUy, shipUz);
			u = u.method_1020(f.method_1021(u.method_1026(f)));
			if (u.method_1027() < 1e-8) return new class_243(0, 1, 0);
			return u.method_1029();
		}
		class_243 look = player.method_5828(1f);
		class_243 right = look.method_1036(new class_243(0, 1, 0));
		if (right.method_1027() < 1e-6) right = new class_243(1, 0, 0);
		return right.method_1029().method_1036(look).method_1029();
	}

	public class_243 shipRight(class_1657 player) {
		return shipForward(player).method_1036(shipUp(player)).method_1029();
	}

	public void levelShipAttitude(class_1657 player) {
		com.terminaldetector.drmd.flight.ShipAttitude a = new com.terminaldetector.drmd.flight.ShipAttitude();
		if (shipAttitudeValid) a.setForwardUp(new class_243(shipFx, shipFy, shipFz), new class_243(shipUx, shipUy, shipUz));
		else a.fromLook(player.method_5828(1f));
		a.levelRoll();
		setShipAttitude((float) a.fx, (float) a.fy, (float) a.fz, (float) a.ux, (float) a.uy, (float) a.uz);
	}
}
