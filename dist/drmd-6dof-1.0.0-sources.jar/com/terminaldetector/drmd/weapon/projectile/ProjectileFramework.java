package com.terminaldetector.drmd.weapon.projectile;

import com.terminaldetector.drmd.weapon.core.WeaponCore;
import com.terminaldetector.drmd.weapon.fx.WeaponFx;
import net.minecraft.class_1309;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_3218;

/**
 * Factory + shared hit behaviours for all ProjectileKind values.
 */
public final class ProjectileFramework {
	private ProjectileFramework() {}

	public static WeaponCore.FireConfig config(ProjectileKind kind, class_1309 owner, class_243 pos, class_243 dir) {
		WeaponCore.FireConfig cfg = new WeaponCore.FireConfig();
		cfg.owner = owner;
		cfg.pos = pos;
		cfg.dir = dir;
		cfg.dmgClass = kind.damageClass;
		cfg.gravity = kind.gravity;
		cfg.drag = kind.drag;
		cfg.homing = kind.defaultHoming;
		cfg.colorR = (kind.colorRgb >> 16) & 0xFF;
		cfg.colorG = (kind.colorRgb >> 8) & 0xFF;
		cfg.colorB = kind.colorRgb & 0xFF;
		cfg.onHit = ctx -> onHit(kind, ctx);
		switch (kind) {
			case LASER -> {
				cfg.speed = 8000;
				cfg.directDamage = 18;
				cfg.life = 1.2f;
				cfg.pierceCount = 2;
			}
			case PLASMA -> {
				cfg.speed = 3200;
				cfg.directDamage = 40;
				cfg.splashDamage = 20;
				cfg.splashRadius = 100;
				cfg.life = 3f;
			}
			case KINETIC -> {
				cfg.speed = 5000;
				cfg.directDamage = 28;
				cfg.life = 4f;
			}
			case DRILL_CHARGE -> {
				cfg.speed = 2800;
				cfg.directDamage = 25;
				cfg.life = 3f;
				cfg.drillCarve = true;
				cfg.meshKind = com.terminaldetector.drmd.entity.ProjectileEntity.MESH_DRILL;
				cfg.visualScale = 1.05f;
			}
			case ROCKET -> {
				cfg.speed = 2200;
				cfg.directDamage = 60;
				cfg.splashDamage = 80;
				cfg.splashRadius = 180;
				cfg.life = 5f;
				cfg.turnRate = 70f;
				cfg.worldBlast = true;
				cfg.meshKind = com.terminaldetector.drmd.entity.ProjectileEntity.MESH_ROCKET;
				cfg.visualScale = 1.2f;
			}
			case ENERGY_ORB -> {
				cfg.speed = 2600;
				cfg.directDamage = 35;
				cfg.splashDamage = 15;
				cfg.splashRadius = 90;
				cfg.life = 3.5f;
				cfg.meshKind = com.terminaldetector.drmd.entity.ProjectileEntity.MESH_ORB;
				cfg.visualScale = 1.3f;
				cfg.worldBlast = true;
			}
			case GRAVITY_SPHERE -> {
				cfg.speed = 1800;
				cfg.directDamage = 10;
				cfg.splashDamage = 5;
				cfg.splashRadius = 140;
				cfg.life = 4f;
				cfg.meshKind = com.terminaldetector.drmd.entity.ProjectileEntity.MESH_ORB;
				cfg.visualScale = 1.4f;
			}
		}
		return cfg;
	}

	public static void fire(ProjectileKind kind, class_1309 owner, class_243 pos, class_243 dir) {
		WeaponCore.fireProjectile(config(kind, owner, pos, dir));
	}

	private static void onHit(ProjectileKind kind, WeaponCore.HitContext ctx) {
		if (!(ctx.projectile().method_37908() instanceof class_3218 sw)) return;
		switch (kind) {
			case GRAVITY_SPHERE -> {
				// Pull nearby entities toward impact
				class_243 center = ctx.hitPos();
				for (class_1309 e : sw.method_8390(class_1309.class,
						new net.minecraft.class_238(center, center).method_1014(4), class_1309::method_5805)) {
					class_243 pull = center.method_1020(e.method_19538()).method_1021(0.15);
					e.method_5762(pull.field_1352, pull.field_1351, pull.field_1350);
					e.field_6037 = true;
				}
			}
			case DRILL_CHARGE -> {
				if (ctx.isBlock()) {
					WeaponFx.drillCarve(sw, class_2338.method_49638(ctx.hitPos()),
							ctx.projectile().getOwnerLiving());
				}
			}
			case ENERGY_ORB -> {
				class_1309 own = ctx.projectile().getOwnerLiving();
				if (own != null) {
					WeaponFx.explode(own, sw, ctx.hitPos(), 35f, 2.2f, kind.damageClass, false);
				}
			}
			case ROCKET -> {
				class_1309 own = ctx.projectile().getOwnerLiving();
				if (own != null && ctx.projectile().getDamageClass() != com.terminaldetector.drmd.weapon.core.DamageClass.EXPLOSIVE) {
					WeaponFx.explode(own, sw, ctx.hitPos(), 80f, 2.5f, kind.damageClass, true);
				}
			}
			default -> {}
		}
	}

	/** Map legacy weapon behavior strings onto kinds where possible. */
	public static ProjectileKind fromBehavior(String behavior) {
		if (behavior == null) return ProjectileKind.KINETIC;
		return switch (behavior) {
			case "laser", "quad_laser", "beam", "overdrive" -> ProjectileKind.LASER;
			case "plasma" -> ProjectileKind.PLASMA;
			case "rockets", "homing", "smart_missile", "mega_missile", "concussion" -> ProjectileKind.ROCKET;
			case "gravy" -> ProjectileKind.GRAVITY_SPHERE;
			case "bfg", "darklance" -> ProjectileKind.ENERGY_ORB;
			case "frag", "flak" -> ProjectileKind.DRILL_CHARGE;
			default -> ProjectileKind.KINETIC;
		};
	}
}
