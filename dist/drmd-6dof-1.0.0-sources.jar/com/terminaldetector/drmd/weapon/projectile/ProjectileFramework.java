package com.terminaldetector.drmd.weapon.projectile;

import com.terminaldetector.drmd.weapon.core.WeaponCore;
import net.minecraft.class_1309;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_3218;

/**
 * Factory + shared hit behaviours for all ProjectileKind values.
 */
public final class ProjectileFramework {
	private ProjectileFramework() {}

	public static WeaponCore.FireConfig config(ProjectileKind kind, class_1309 owner, class_243 pos, class_243 dir) {
		WeaponCore.FireConfig cfg = new WeaponCore.FireConfig();
		cfg.owner = owner;
		cfg.pos = pos;
		cfg.dir = dir;
		cfg.dmgClass = kind.damageClass;
		cfg.gravity = kind.gravity;
		cfg.drag = kind.drag;
		cfg.homing = kind.defaultHoming;
		cfg.colorR = (kind.colorRgb >> 16) & 0xFF;
		cfg.colorG = (kind.colorRgb >> 8) & 0xFF;
		cfg.colorB = kind.colorRgb & 0xFF;
		cfg.onHit = ctx -> onHit(kind, ctx);
		switch (kind) {
			case LASER -> {
				cfg.speed = 8000;
				cfg.directDamage = 18;
				cfg.life = 1.2f;
				cfg.pierceCount = 2;
			}
			case PLASMA -> {
				cfg.speed = 3200;
				cfg.directDamage = 40;
				cfg.splashDamage = 20;
				cfg.splashRadius = 100;
				cfg.life = 3f;
			}
			case KINETIC -> {
				cfg.speed = 5000;
				cfg.directDamage = 28;
				cfg.life = 4f;
			}
			case ROCKET -> {
				cfg.speed = 2200;
				cfg.directDamage = 60;
				cfg.splashDamage = 80;
				cfg.splashRadius = 180;
				cfg.life = 5f;
				cfg.turnRate = 70f;
			}
			case GRAVITY_SPHERE -> {
				cfg.speed = 1800;
				cfg.directDamage = 10;
				cfg.splashDamage = 5;
				cfg.splashRadius = 140;
				cfg.life = 4f;
			}
			case ENERGY_ORB -> {
				cfg.speed = 2600;
				cfg.directDamage = 35;
				cfg.splashDamage = 15;
				cfg.splashRadius = 90;
				cfg.life = 3.5f;
			}
			case DRILL_CHARGE -> {
				cfg.speed = 2800;
				cfg.directDamage = 25;
				cfg.life = 3f;
			}
		}
		return cfg;
	}

	public static void fire(ProjectileKind kind, class_1309 owner, class_243 pos, class_243 dir) {
		WeaponCore.fireProjectile(config(kind, owner, pos, dir));
	}

	private static void onHit(ProjectileKind kind, WeaponCore.HitContext ctx) {
		if (!(ctx.projectile().method_37908() instanceof class_3218 sw)) return;
		switch (kind) {
			case GRAVITY_SPHERE -> {
				// Pull nearby entities toward impact
				class_243 center = ctx.hitPos();
				for (class_1309 e : sw.method_8390(class_1309.class,
						new net.minecraft.class_238(center, center).method_1014(4), class_1309::method_5805)) {
					class_243 pull = center.method_1020(e.method_19538()).method_1021(0.15);
					e.method_5762(pull.field_1352, pull.field_1351, pull.field_1350);
					e.field_6037 = true;
				}
			}
			case DRILL_CHARGE -> {
				if (ctx.isBlock()) {
					class_2338 bp = class_2338.method_49638(ctx.hitPos());
					for (class_2338 p : class_2338.method_10097(bp.method_10069(-1, -1, -1), bp.method_10069(1, 1, 1))) {
						if (sw.method_8320(p).method_26214(sw, p) >= 0
								&& sw.method_8320(p).method_26214(sw, p) < 20
								&& !sw.method_8320(p).method_27852(class_2246.field_9987)) {
							sw.method_22352(p, true);
						}
					}
				}
			}
			case ENERGY_ORB -> {
				sw.method_8537(ctx.projectile(), ctx.hitPos().field_1352, ctx.hitPos().field_1351, ctx.hitPos().field_1350,
						1.2f, false, net.minecraft.class_1937.class_7867.field_40888);
			}
			default -> {}
		}
	}

	/** Map legacy weapon behavior strings onto kinds where possible. */
	public static ProjectileKind fromBehavior(String behavior) {
		if (behavior == null) return ProjectileKind.KINETIC;
		return switch (behavior) {
			case "laser", "quad_laser", "beam", "overdrive" -> ProjectileKind.LASER;
			case "plasma" -> ProjectileKind.PLASMA;
			case "rockets", "homing", "smart_missile", "mega_missile", "concussion" -> ProjectileKind.ROCKET;
			case "gravy" -> ProjectileKind.GRAVITY_SPHERE;
			case "bfg", "darklance" -> ProjectileKind.ENERGY_ORB;
			case "frag", "flak" -> ProjectileKind.DRILL_CHARGE;
			default -> ProjectileKind.KINETIC;
		};
	}
}
