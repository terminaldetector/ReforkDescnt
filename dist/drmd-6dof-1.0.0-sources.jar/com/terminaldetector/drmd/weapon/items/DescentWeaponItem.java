package com.terminaldetector.drmd.weapon.items;

import com.terminaldetector.drmd.DescentPlayerData;
import com.terminaldetector.drmd.energy.EnergySystem;
import com.terminaldetector.drmd.weapon.core.DamageClass;
import com.terminaldetector.drmd.weapon.core.WeaponCore;
import com.terminaldetector.drmd.weapon.registry.WeaponDef;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_243;
import net.minecraft.class_3417;
import net.minecraft.class_3419;

/**
 * Base DRMD weapon item — consumes shared energy and fires via WeaponCore.
 */
public class DescentWeaponItem extends class_1792 {
	private final WeaponDef def;

	public DescentWeaponItem(WeaponDef def, class_1793 settings) {
		super(settings.method_7889(1));
		this.def = def;
	}

	public WeaponDef getDef() { return def; }

	@Override
	public class_1271<class_1799> method_7836(class_1937 world, class_1657 user, class_1268 hand) {
		class_1799 stack = user.method_5998(hand);
		if (world.field_9236) return class_1271.method_22430(stack);

		DescentPlayerData data = DescentPlayerData.get(user);
		long now = world.method_8510();
		long last = 0L;
		var custom = stack.method_57824(net.minecraft.class_9334.field_49628);
		if (custom != null) last = custom.method_57461().method_10537("lastFire");
		int cdTicks = Math.max(1, (int) (def.fireRate * 20));
		if (now - last < cdTicks) return class_1271.method_22431(stack);

		if (!fire(world, user, data, stack)) {
			return class_1271.method_22431(stack);
		}

		NbtWrite.lastFire(stack, now);
		user.method_7357().method_7906(this, cdTicks);
		world.method_43128(null, user.method_23317(), user.method_23318(), user.method_23321(),
				class_3417.field_14702, class_3419.field_15248, 0.6f, 1.2f);
		return class_1271.method_22427(stack);
	}

	protected boolean fire(class_1937 world, class_1657 user, DescentPlayerData data, class_1799 stack) {
		return switch (def.behavior) {
			case "laser" -> fireLaser(user, data);
			case "quad_laser" -> fireQuadLaser(user, data);
			case "rockets" -> fireRockets(user, data);
			case "plasma" -> firePlasma(user, data);
			case "flak" -> fireFlak(user, data);
			case "frag" -> fireFrag(user, data);
			case "beam" -> fireBeam(user, data);
			case "shockwave" -> fireShockwave(user, data);
			case "warp" -> fireWarp(user, data);
			case "telefrag" -> fireTelefrag(user, data);
			case "reactor" -> fireReactor(user, data);
			case "gravy" -> fireGravy(user, data);
			case "whiplash" -> fireWhiplash(user, data);
			case "darklance" -> fireDarklance(user, data);
			case "deploy" -> fireDeploy(user, data);
			case "bfg" -> fireBfg(user, data);
			case "rail" -> fireRail(user, data);
			case "homing" -> fireHoming(user, data);
			case "vulcan", "mg", "heavy", "basic" -> fireBasic(user, data);
			default -> fireBasic(user, data);
		};
	}

	protected boolean consumeEnergy(DescentPlayerData data, float cost) {
		if (cost <= 0) return true;
		return EnergySystem.tryConsume(data, "weapons", cost);
	}

	protected boolean fireBasic(class_1657 user, DescentPlayerData data) {
		if (!consumeEnergy(data, def.energyCost)) return false;
		// Single-barrel weapons (mg/heavy/basic): primary muzzle only
		// Vulcan: all construction muzzles
		if ("vulcan".equals(def.behavior)) {
			fireFromAllMuzzles(user, cfg -> {
				cfg.directDamage = def.damage;
				cfg.speed = def.speed;
				cfg.recoil = def.recoil;
				cfg.dmgClass = def.dmgClass;
			});
		} else {
			WeaponCore.FireConfig cfg = baseCfg(user);
			cfg.directDamage = def.damage;
			cfg.splashDamage = def.splashDamage;
			cfg.splashRadius = def.splashRadius;
			cfg.speed = def.speed;
			cfg.recoil = def.recoil;
			cfg.dmgClass = def.dmgClass;
			cfg.meshKind = def.dmgClass == DamageClass.EXPLOSIVE
					? com.terminaldetector.drmd.entity.ProjectileEntity.MESH_ROCKET
					: (def.dmgClass == DamageClass.EXOTIC
					? com.terminaldetector.drmd.entity.ProjectileEntity.MESH_ORB
					: com.terminaldetector.drmd.entity.ProjectileEntity.MESH_BOLT);
			cfg.visualScale = def.splashRadius > 200 ? 1.35f : 1f;
			cfg.worldBlast = def.dmgClass == DamageClass.EXPLOSIVE && def.splashRadius >= 180;
			WeaponCore.fireProjectile(cfg);
		}
		return true;
	}

	protected boolean firePlasma(class_1657 user, DescentPlayerData data) {
		if (!consumeEnergy(data, def.energyCost)) return false;
		// Prefer construction muzzles 1+2 (SideLeft/SideRight); fallback dual offset
		var muzzles = WeaponCore.allMuzzles(user, def.id);
		if (muzzles.size() >= 2) {
			for (int i = 0; i < 2; i++) {
				WeaponCore.FireConfig cfg = baseCfg(user);
				cfg.pos = muzzles.get(i);
				cfg.directDamage = def.damage;
				cfg.splashDamage = def.splashDamage;
				cfg.splashRadius = def.splashRadius;
				cfg.speed = def.speed;
				cfg.recoil = i == 0 ? def.recoil : 0;
				cfg.dmgClass = DamageClass.EXOTIC;
				cfg.meshKind = com.terminaldetector.drmd.entity.ProjectileEntity.MESH_ORB;
				cfg.visualScale = 0.9f;
				WeaponCore.fireProjectile(cfg);
			}
		} else {
			for (float side : new float[]{-0.25f, 0.25f}) {
				WeaponCore.FireConfig cfg = baseCfg(user);
				cfg.pos = WeaponCore.muzzle(user, 0.8f, side, -0.1f);
				cfg.directDamage = def.damage;
				cfg.splashDamage = def.splashDamage;
				cfg.splashRadius = def.splashRadius;
				cfg.speed = def.speed;
				cfg.recoil = def.recoil * 0.5f;
				cfg.dmgClass = DamageClass.EXOTIC;
				cfg.meshKind = com.terminaldetector.drmd.entity.ProjectileEntity.MESH_ORB;
				cfg.visualScale = 0.9f;
				WeaponCore.fireProjectile(cfg);
			}
		}
		return true;
	}

	protected boolean fireFlak(class_1657 user, DescentPlayerData data) {
		if (!consumeEnergy(data, def.energyCost)) return false;
		class_243 aim = WeaponCore.aimDir(user);
		for (int i = 0; i < 12; i++) {
			class_243 dir = spread(aim, 7f, user.method_59922());
			WeaponCore.FireConfig cfg = baseCfg(user);
			cfg.dir = dir;
			cfg.directDamage = def.damage;
			cfg.splashDamage = def.splashDamage;
			cfg.splashRadius = def.splashRadius;
			cfg.speed = def.speed;
			cfg.recoil = i == 0 ? def.recoil : 0;
			cfg.life = 1.2f;
			cfg.dmgClass = DamageClass.EXPLOSIVE;
			cfg.meshKind = com.terminaldetector.drmd.entity.ProjectileEntity.MESH_BOLT;
			cfg.visualScale = 0.5f;
			cfg.worldBlast = false;
			WeaponCore.fireProjectile(cfg);
		}
		return true;
	}

	protected boolean fireFrag(class_1657 user, DescentPlayerData data) {
		if (!consumeEnergy(data, def.energyCost)) return false;
		WeaponCore.FireConfig cfg = baseCfg(user);
		cfg.directDamage = def.damage;
		cfg.splashDamage = def.splashDamage;
		cfg.splashRadius = def.splashRadius;
		cfg.speed = def.speed;
		cfg.recoil = def.recoil;
		cfg.dmgClass = DamageClass.EXPLOSIVE;
		cfg.onHit = ctx -> {
			if (user.method_37908().field_9236) return;
			for (int i = 0; i < 8; i++) {
				WeaponCore.FireConfig frag = new WeaponCore.FireConfig();
				frag.owner = user;
				frag.pos = ctx.hitPos();
				frag.dir = spread(new class_243(0, 1, 0), 180f, user.method_59922());
				frag.speed = 1200;
				frag.directDamage = 20;
				frag.life = 1.5f;
				frag.dmgClass = DamageClass.KINETIC;
				frag.inherit = 0;
				frag.meshKind = com.terminaldetector.drmd.entity.ProjectileEntity.MESH_BOLT;
				frag.visualScale = 0.4f;
				WeaponCore.fireProjectile(frag);
			}
		};
		cfg.meshKind = com.terminaldetector.drmd.entity.ProjectileEntity.MESH_DRILL;
		cfg.visualScale = 1.1f;
		cfg.worldBlast = true;
		cfg.drillCarve = true;
		WeaponCore.fireProjectile(cfg);
		return true;
	}

	protected boolean fireRockets(class_1657 user, DescentPlayerData data) {
		if (!consumeEnergy(data, def.energyCost)) return false;
		int sub = data.getRocketSubmode();
		int count = switch (sub) { case 1 -> 3; case 2 -> 6; default -> 1; };
		float speed = switch (sub) { case 1 -> 2600f; case 2 -> 2200f; case 3 -> 2000f; default -> 2800f; };
		boolean homing = sub == 2;
		boolean atomic = sub == 3;
		for (int i = 0; i < count; i++) {
			WeaponCore.FireConfig cfg = baseCfg(user);
			cfg.dir = count > 1 ? spread(WeaponCore.aimDir(user), 5f, user.method_59922()) : WeaponCore.aimDir(user);
			cfg.speed = speed;
			cfg.homing = homing;
			cfg.turnRate = 120f;
			cfg.directDamage = atomic ? 350 : 80;
			cfg.splashDamage = atomic ? 350 : 50;
			cfg.splashRadius = atomic ? 650 : 200;
			cfg.recoil = i == 0 ? (atomic ? 220 : 120) : 0;
			cfg.dmgClass = DamageClass.EXPLOSIVE;
			cfg.life = 6f;
			cfg.meshKind = com.terminaldetector.drmd.entity.ProjectileEntity.MESH_ROCKET;
			cfg.visualScale = atomic ? 1.8f : (count > 1 ? 0.85f : 1.2f);
			cfg.worldBlast = true;
			WeaponCore.fireProjectile(cfg);
		}
		return true;
	}

	protected boolean fireLaser(class_1657 user, DescentPlayerData data) {
		// Charge-style: spend up to 22 energy for scaled damage 40-150
		float spend = Math.min(22f, data.getEnergy());
		if (spend < 4f) return false;
		EnergySystem.tryConsume(data, "weapons", spend);
		float charge = spend / 22f;
		float dmg = 40f + 110f * charge;
		WeaponCore.hitscan(user, user.method_33571(), WeaponCore.aimDir(user), 8000f, dmg, DamageClass.ENERGY, null);
		WeaponCore.applyRecoil(user, WeaponCore.aimDir(user), 30f * charge);
		return true;
	}

	protected boolean fireQuadLaser(class_1657 user, DescentPlayerData data) {
		if (!consumeEnergy(data, def.energyCost)) return false;
		var muzzles = WeaponCore.allMuzzles(user, def.id);
		if (muzzles.size() >= 4) {
			for (int i = 0; i < 4; i++) {
				WeaponCore.hitscan(user, muzzles.get(i), WeaponCore.aimDir(user), 8000f, def.damage, DamageClass.ENERGY, null);
			}
		} else {
			for (float[] off : new float[][]{{-0.2f,0.1f},{0.2f,0.1f},{-0.2f,-0.1f},{0.2f,-0.1f}}) {
				class_243 start = WeaponCore.muzzle(user, 0.5f, off[0], off[1]);
				WeaponCore.hitscan(user, start, WeaponCore.aimDir(user), 8000f, def.damage, DamageClass.ENERGY, null);
			}
		}
		WeaponCore.applyRecoil(user, WeaponCore.aimDir(user), def.recoil);
		return true;
	}

	protected boolean fireBeam(class_1657 user, DescentPlayerData data) {
		if (!consumeEnergy(data, def.energyCost)) return false;
		WeaponCore.hitscan(user, user.method_33571(), WeaponCore.aimDir(user), 4000f, def.damage, DamageClass.ENERGY, ctx -> {
			if (ctx.hitEntity() instanceof class_1657 ply) {
				DescentPlayerData td = DescentPlayerData.get(ply);
				td.setShield(Math.max(0, td.getShield() - 12f));
			}
		});
		return true;
	}

	protected boolean fireShockwave(class_1657 user, DescentPlayerData data) {
		if (!consumeEnergy(data, def.energyCost)) return false;
		if (user.method_37908() instanceof net.minecraft.class_3218 sw) {
			WeaponCore.splashDamage(user, sw, user.method_19538(), def.splashDamage, def.splashRadius > 20 ? (float)com.terminaldetector.drmd.DescentMod.su(def.splashRadius) : def.splashRadius, DamageClass.ENERGY);
		}
		return true;
	}

	protected boolean fireWarp(class_1657 user, DescentPlayerData data) {
		if (!consumeEnergy(data, def.energyCost)) return false;
		class_243 dest = user.method_19538().method_1019(WeaponCore.aimDir(user).method_1021(com.terminaldetector.drmd.DescentMod.su(700)));
		user.method_5859(dest.field_1352, dest.field_1351, dest.field_1350);
		if (user.method_37908() instanceof net.minecraft.class_3218 sw) {
			WeaponCore.splashDamage(user, sw, dest, def.damage, (float)com.terminaldetector.drmd.DescentMod.su(200), DamageClass.EXOTIC);
		}
		return true;
	}

	protected boolean fireTelefrag(class_1657 user, DescentPlayerData data) {
		if (!consumeEnergy(data, def.energyCost)) return false;
		class_1309 target = findLookTarget(user, com.terminaldetector.drmd.DescentMod.su(4000));
		if (target == null) return false;
		user.method_5859(target.method_23317(), target.method_23318(), target.method_23321());
		if (user.method_37908() instanceof net.minecraft.class_3218 sw) {
			WeaponCore.splashDamage(user, sw, target.method_19538(), def.damage, (float)com.terminaldetector.drmd.DescentMod.su(140), DamageClass.EXOTIC);
		}
		return true;
	}

	protected boolean fireReactor(class_1657 user, DescentPlayerData data) {
		float spend = Math.max(30f, data.getEnergy());
		if (!EnergySystem.tryConsume(data, "weapons", spend)) return false;
		float frac = spend / data.getEnergyMax();
		float dmg = 150f + 450f * frac;
		float rad = 300f + 600f * frac;
		if (user.method_37908() instanceof net.minecraft.class_3218 sw) {
			// Inside / near Sky UFO core — dump reactor to kill the flying hull
			if (com.terminaldetector.drmd.world.mega.SkyUfoEntity.tryReactorDump(sw, user)) {
				return true;
			}
			float r = (float) com.terminaldetector.drmd.DescentMod.su(rad);
			com.terminaldetector.drmd.weapon.fx.WeaponFx.explode(
					user, sw, user.method_19538(), dmg, r, DamageClass.EXPLOSIVE, true);
		}
		return true;
	}

	protected boolean fireGravy(class_1657 user, DescentPlayerData data) {
		if (!(user instanceof net.minecraft.class_3222 sp)) return false;
		// Toggle grab / fling — Havok-lite via GravyPhysics
		if (com.terminaldetector.drmd.physics.GravyPhysics.isHolding(sp)) {
			if (data.getGravyEnergy() < 10f) return false;
			data.setGravyEnergy(data.getGravyEnergy() - 10f);
			com.terminaldetector.drmd.physics.GravyPhysics.fling(sp, 2.8f);
			data.setGravyGrabbing(false);
			return true;
		}
		if (data.getGravyEnergy() < 15f) return false;
		class_1309 look = findLookTarget(user, 12);
		if (look != null && look != user) {
			float mass = Math.max(0.4f, look.method_17681() * look.method_17682());
			if (com.terminaldetector.drmd.physics.GravyPhysics.tryGrab(sp, look, mass)) {
				data.setGravyEnergy(data.getGravyEnergy() - 15f);
				data.setGravyGrabbing(true);
				return true;
			}
		}
		// Fallback kinetic bolt when nothing to grab (prop-rail analogue)
		if (data.getGravyEnergy() < 20f) return false;
		data.setGravyEnergy(data.getGravyEnergy() - 20f);
		WeaponCore.FireConfig cfg = baseCfg(user);
		cfg.speed = 18000;
		cfg.directDamage = 80;
		cfg.pierceCount = 3;
		cfg.dmgClass = DamageClass.EXOTIC;
		cfg.recoil = 40;
		cfg.life = 2f;
		cfg.meshKind = com.terminaldetector.drmd.entity.ProjectileEntity.MESH_ORB;
		cfg.visualScale = 0.7f;
		WeaponCore.fireProjectile(cfg);
		return true;
	}

	protected boolean fireWhiplash(class_1657 user, DescentPlayerData data) {
		if (!consumeEnergy(data, def.energyCost)) return false;
		class_1309 target = findLookTarget(user, com.terminaldetector.drmd.DescentMod.su(1500));
		if (target == null) {
			// Zip forward
			class_243 dest = user.method_19538().method_1019(WeaponCore.aimDir(user).method_1021(com.terminaldetector.drmd.DescentMod.su(800)));
			data.setFlightVelocity(WeaponCore.aimDir(user).method_1021(com.terminaldetector.drmd.DescentMod.su(3200)));
			user.method_5859(dest.field_1352, dest.field_1351, dest.field_1350);
			return true;
		}
		class_243 mid = target.method_19538();
		user.method_5859(mid.field_1352, mid.field_1351, mid.field_1350);
		if (user.method_37908() instanceof net.minecraft.class_3218 sw) {
			WeaponCore.splashDamage(user, sw, mid, def.damage, (float)com.terminaldetector.drmd.DescentMod.su(160), DamageClass.KINETIC);
		}
		return true;
	}

	protected boolean fireDarklance(class_1657 user, DescentPlayerData data) {
		if (!consumeEnergy(data, def.energyCost)) return false;
		class_243 start = user.method_33571();
		class_243 dir = WeaponCore.aimDir(user);
		int hits = 0;
		for (int i = 0; i < 16 && hits < 8; i++) {
			WeaponCore.hitscan(user, start, dir, 2000f, def.damage, DamageClass.EXOTIC, ctx -> {});
			start = start.method_1019(dir.method_1021(com.terminaldetector.drmd.DescentMod.su(500)));
			hits++;
		}
		return true;
	}

	protected boolean fireDeploy(class_1657 user, DescentPlayerData data) {
		if (!consumeEnergy(data, def.energyCost)) return false;
		WeaponCore.FireConfig cfg = baseCfg(user);
		cfg.speed = def.speed > 0 ? def.speed : 900;
		cfg.directDamage = def.damage;
		cfg.splashDamage = def.splashDamage;
		cfg.splashRadius = def.splashRadius;
		cfg.gravity = 0.2f;
		cfg.life = 8f;
		cfg.dmgClass = def.dmgClass;
		cfg.recoil = 10;
		cfg.meshKind = def.dmgClass == DamageClass.EXOTIC
				? com.terminaldetector.drmd.entity.ProjectileEntity.MESH_ORB
				: com.terminaldetector.drmd.entity.ProjectileEntity.MESH_ROCKET;
		cfg.visualScale = 1.05f;
		cfg.worldBlast = def.dmgClass == DamageClass.EXPLOSIVE || def.dmgClass == DamageClass.EXOTIC;
		WeaponCore.fireProjectile(cfg);
		return true;
	}

	protected boolean fireBfg(class_1657 user, DescentPlayerData data) {
		if (!consumeEnergy(data, def.energyCost)) return false;
		WeaponCore.FireConfig cfg = baseCfg(user);
		cfg.speed = def.speed;
		cfg.directDamage = def.damage;
		cfg.splashDamage = def.splashDamage;
		cfg.splashRadius = def.splashRadius;
		cfg.dmgClass = DamageClass.EXOTIC;
		cfg.recoil = def.recoil;
		cfg.scale = 2.5f;
		cfg.meshKind = com.terminaldetector.drmd.entity.ProjectileEntity.MESH_ORB;
		cfg.visualScale = 2.4f;
		cfg.worldBlast = true;
		cfg.life = 8f;
		cfg.onHit = ctx -> {
			if (!(user.method_37908() instanceof net.minecraft.class_3218 sw)) return;
			int beams = 0;
			for (class_1309 e : sw.method_8390(class_1309.class, user.method_5829().method_1014(24),
					ent -> ent != user && ent.method_5805())) {
				if (beams++ >= 16) break;
				WeaponCore.directDamage(user, e, 30f, DamageClass.EXOTIC);
			}
		};
		WeaponCore.fireProjectile(cfg);
		return true;
	}

	protected boolean fireRail(class_1657 user, DescentPlayerData data) {
		if (!consumeEnergy(data, def.energyCost)) return false;
		WeaponCore.FireConfig cfg = baseCfg(user);
		cfg.speed = def.speed;
		cfg.directDamage = def.damage;
		cfg.pierceCount = 5;
		cfg.dmgClass = DamageClass.KINETIC;
		cfg.recoil = def.recoil;
		cfg.life = 2f;
		cfg.meshKind = com.terminaldetector.drmd.entity.ProjectileEntity.MESH_BOLT;
		cfg.visualScale = 0.85f;
		WeaponCore.fireProjectile(cfg);
		return true;
	}

	protected boolean fireHoming(class_1657 user, DescentPlayerData data) {
		if (def.energyCost > 0 && !consumeEnergy(data, def.energyCost)) return false;
		WeaponCore.FireConfig cfg = baseCfg(user);
		cfg.speed = def.speed;
		cfg.directDamage = def.damage;
		cfg.splashDamage = def.splashDamage;
		cfg.splashRadius = def.splashRadius;
		cfg.homing = true;
		cfg.turnRate = 140f;
		cfg.homeTarget = findLookTarget(user, 48);
		cfg.dmgClass = DamageClass.EXPLOSIVE;
		cfg.recoil = def.recoil;
		cfg.life = 15f;
		cfg.meshKind = com.terminaldetector.drmd.entity.ProjectileEntity.MESH_ROCKET;
		cfg.visualScale = def.splashRadius > 300 ? 1.6f : 1.15f;
		cfg.worldBlast = true;
		WeaponCore.fireProjectile(cfg);
		return true;
	}

	protected WeaponCore.FireConfig baseCfg(class_1657 user) {
		WeaponCore.FireConfig cfg = new WeaponCore.FireConfig();
		cfg.owner = user;
		cfg.pos = WeaponCore.muzzleFor(user, def.id, 1);
		cfg.dir = WeaponCore.aimDir(user);
		cfg.dmgClass = def.dmgClass;
		cfg.life = 5f;
		return cfg;
	}

	/** Fire one projectile per construction muzzle (multi-barrel layouts). */
	protected void fireFromAllMuzzles(class_1657 user, java.util.function.Consumer<WeaponCore.FireConfig> tune) {
		var muzzles = WeaponCore.allMuzzles(user, def.id);
		int i = 0;
		for (class_243 pos : muzzles) {
			WeaponCore.FireConfig cfg = baseCfg(user);
			cfg.pos = pos;
			tune.accept(cfg);
			if (i > 0) cfg.recoil = 0; // only first barrel applies ship recoil
			WeaponCore.fireProjectile(cfg);
			i++;
		}
	}

	protected static class_243 spread(class_243 dir, float degrees, net.minecraft.class_5819 random) {
		double yaw = Math.toRadians((random.method_43058() - 0.5) * 2 * degrees);
		double pitch = Math.toRadians((random.method_43058() - 0.5) * 2 * degrees);
		class_243 d = dir.method_1029();
		class_243 right = d.method_1036(new class_243(0, 1, 0));
		if (right.method_1027() < 1e-6) right = new class_243(1, 0, 0);
		right = right.method_1029();
		class_243 up = right.method_1036(d).method_1029();
		return d.method_1019(right.method_1021(Math.tan(yaw))).method_1019(up.method_1021(Math.tan(pitch))).method_1029();
	}

	protected static class_1309 findLookTarget(class_1657 user, double range) {
		class_243 start = user.method_33571();
		class_243 end = start.method_1019(WeaponCore.aimDir(user).method_1021(range));
		class_1309 best = null;
		double bestDot = 0.92;
		for (class_1309 e : user.method_37908().method_8390(class_1309.class,
				user.method_5829().method_1014(range), ent -> ent != user && ent.method_5805())) {
			class_243 to = e.method_19538().method_1031(0, e.method_17682() * 0.5, 0).method_1020(start).method_1029();
			double dot = to.method_1026(WeaponCore.aimDir(user));
			if (dot > bestDot && start.method_1025(e.method_19538()) < range * range) {
				bestDot = dot;
				best = e;
			}
		}
		return best;
	}

	/** Helper for writing lastFire into custom data component. */
	public static final class NbtWrite {
		public static void lastFire(class_1799 stack, long time) {
			net.minecraft.class_9279 existing = stack.method_57825(
					net.minecraft.class_9334.field_49628,
					net.minecraft.class_9279.field_49302);
			net.minecraft.class_2487 nbt = existing.method_57461();
			nbt.method_10544("lastFire", time);
			stack.method_57379(net.minecraft.class_9334.field_49628,
					net.minecraft.class_9279.method_57456(nbt));
		}
	}
}
