package com.terminaldetector.drmd.weapon.fx;

import com.terminaldetector.drmd.weapon.core.DamageClass;
import com.terminaldetector.drmd.weapon.core.WeaponCore;
import com.terminaldetector.drmd.world.atmosphere.AtmosphereRules;
import com.terminaldetector.drmd.world.fire.FireSystem;
import com.terminaldetector.drmd.world.smoke.SmokeSystem;
import net.minecraft.class_1309;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2390;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3532;
import org.joml.Vector3f;

/**
 * Shared weapon VFX / terrain effects — beams, melt stages, blasts, drill carve.
 * Reuses SmokeSystem / FireSystem / AtmosphereRules (same stack as bomb bay).
 */
public final class WeaponFx {
	private WeaponFx() {}

	/** Particle beam along a segment (engineer laser look). */
	public static void beam(class_3218 world, class_243 from, class_243 to, Vector3f color, float size) {
		class_243 delta = to.method_1020(from);
		double len = delta.method_1033();
		if (len < 1e-4) return;
		int n = class_3532.method_15340((int) (len * 3.5), 6, 96);
		for (int i = 0; i <= n; i++) {
			class_243 p = from.method_1019(delta.method_1021(i / (double) n));
			world.method_14199(new class_2390(color, size), p.field_1352, p.field_1351, p.field_1350, 1, 0, 0, 0, 0);
		}
		world.method_14199(class_2398.field_11207, to.field_1352, to.field_1351, to.field_1350, 2, 0.05, 0.05, 0.05, 0.01);
	}

	public static void beamEnergy(class_3218 world, class_243 from, class_243 to) {
		beam(world, from, to, new Vector3f(0.35f, 1f, 0.55f), 1.05f);
	}

	public static void beamDrill(class_3218 world, class_243 from, class_243 to) {
		beam(world, from, to, new Vector3f(1f, 0.55f, 0.12f), 1.15f);
		world.method_14199(class_2398.field_11239, to.field_1352, to.field_1351, to.field_1350, 2, 0.15, 0.15, 0.15, 0.02);
		world.method_14199(class_2398.field_11240, to.field_1352, to.field_1351, to.field_1350, 4, 0.1, 0.1, 0.1, 0.01);
	}

	public static void beamExotic(class_3218 world, class_243 from, class_243 to) {
		beam(world, from, to, new Vector3f(0.2f, 0.9f, 1f), 1.1f);
	}

	/**
	 * Soft “оплавление”: heat stage → soften → break. Intensity 1..3.
	 * Reuses existing block palette (no new assets).
	 */
	public static boolean melt(class_3218 world, class_2338 pos, int intensity, class_1309 breaker) {
		class_2680 st = world.method_8320(pos);
		if (st.method_26215() || st.method_26214(world, pos) < 0 || st.method_27852(class_2246.field_9987)) return false;
		float hard = st.method_26214(world, pos);
		if (hard >= 50) return false;

		world.method_14199(class_2398.field_11240,
				pos.method_10263() + 0.5, pos.method_10264() + 0.5, pos.method_10260() + 0.5,
				4 + intensity * 2, 0.25, 0.25, 0.25, 0.01);
		world.method_14199(class_2398.field_11251,
				pos.method_10263() + 0.5, pos.method_10264() + 0.6, pos.method_10260() + 0.5,
				3, 0.2, 0.2, 0.2, 0.01);
		world.method_8396(null, pos, class_3417.field_15102, class_3419.field_15245,
				0.25f + intensity * 0.1f, 1.4f + world.method_8409().method_43057() * 0.3f);

		class_2680 next = meltStage(st, intensity);
		if (next == null) {
			if (intensity >= 2 && hard < 20) {
				world.method_8651(pos, true, breaker);
				return true;
			}
			return false;
		}
		if (next.method_26215()) {
			world.method_8651(pos, true, breaker);
		} else {
			world.method_8652(pos, next, class_2248.field_31036);
			if (intensity >= 2 && world.method_8409().method_43048(4) == 0) {
				FireSystem.ignite(world, pos.method_10084(), 1);
			}
		}
		return true;
	}

	private static class_2680 meltStage(class_2680 st, int intensity) {
		if (st.method_27852(class_2246.field_10540) || st.method_27852(class_2246.field_22423)) {
			return intensity >= 3 ? class_2246.field_10164.method_9564() : class_2246.field_10092.method_9564();
		}
		if (st.method_27852(class_2246.field_10340) || st.method_27852(class_2246.field_28888) || st.method_27852(class_2246.field_10445)
				|| st.method_27852(class_2246.field_10056) || st.method_27852(class_2246.field_28900)) {
			return intensity >= 2 ? class_2246.field_10445.method_9564() : class_2246.field_29031.method_9564();
		}
		if (st.method_27852(class_2246.field_10212) || st.method_27852(class_2246.field_29027) || st.method_27852(class_2246.field_10085)
				|| st.method_27852(class_2246.field_10205) || st.method_27852(class_2246.field_27119)) {
			return class_2246.field_10092.method_9564();
		}
		if (st.method_27852(class_2246.field_10102) || st.method_27852(class_2246.field_10534) || st.method_27852(class_2246.field_10033)
				|| st.method_27852(class_2246.field_9979)) {
			return intensity >= 2 ? class_2246.field_10124.method_9564() : class_2246.field_10033.method_9564();
		}
		if (st.method_27852(class_2246.field_10515) || st.method_27852(class_2246.field_10092)) {
			return intensity >= 2 ? class_2246.field_10164.method_9564() : class_2246.field_10092.method_9564();
		}
		if (st.method_27852(class_2246.field_10295) || st.method_27852(class_2246.field_10225) || st.method_27852(class_2246.field_10384)
				|| st.method_27852(class_2246.field_10491)) {
			return class_2246.field_10382.method_9564();
		}
		if (intensity >= 3) return class_2246.field_10124.method_9564();
		return null;
	}

	/**
	 * Heavy-weapon blast — shield-aware splash + smoke/fire + optional soft crater.
	 * Avoids stacking vanilla explosion entity damage on top of WeaponCore splash.
	 */
	public static void explode(class_1309 attacker, class_3218 world, class_243 pos,
							   float splashDamage, float splashRadiusBlocks,
							   DamageClass dmgClass, boolean breakBlocks) {
		if (splashDamage > 0 && splashRadiusBlocks > 0) {
			WeaponCore.splashDamage(attacker, world, pos, splashDamage, splashRadiusBlocks, dmgClass);
		}
		float power = AtmosphereRules.scaleBlast(pos.field_1351,
				class_3532.method_15363(splashRadiusBlocks * 0.55f, 1.15f, 7.5f));
		SmokeSystem.emitExplosion(pos, power);
		world.method_14199(class_2398.field_11236, pos.field_1352, pos.field_1351, pos.field_1350, 1, 0, 0, 0, 0);
		if (power > 2.8f) {
			world.method_14199(class_2398.field_11221, pos.field_1352, pos.field_1351, pos.field_1350, 1, 0, 0, 0, 0);
		}
		world.method_60511(null, pos.field_1352, pos.field_1351, pos.field_1350, class_3417.field_15152, class_3419.field_15248,
				0.7f + power * 0.08f, 0.85f + world.method_8409().method_43057() * 0.2f);
		if (breakBlocks) {
			int r = class_3532.method_15340((int) (splashRadiusBlocks * 0.65f), 1, 5);
			class_2338 center = class_2338.method_49638(pos);
			for (class_2338 p : class_2338.method_10097(center.method_10069(-r, -r, -r), center.method_10069(r, r, r))) {
				if (p.method_10262(center) > r * r) continue;
				class_2680 st = world.method_8320(p);
				float h = st.method_26214(world, p);
				if (!st.method_26215() && h >= 0 && h < 15 && !st.method_27852(class_2246.field_9987)) {
					if (world.method_8409().method_43057() < 0.55f) {
						world.method_8651(p, true, attacker);
					}
				}
			}
		}
		if (dmgClass == DamageClass.EXPLOSIVE && power > 2.4f) {
			FireSystem.igniteBlast(world, class_2338.method_49638(pos),
					3 + (int) power, Math.max(2, (int) (splashRadiusBlocks * 0.35f)));
		}
	}

	/** 3×3 soft carve — ProjectileFramework DRILL_CHARGE behaviour, shared. */
	public static void drillCarve(class_3218 world, class_2338 center, class_1309 breaker) {
		for (class_2338 p : class_2338.method_10097(center.method_10069(-1, -1, -1), center.method_10069(1, 1, 1))) {
			class_2680 st = world.method_8320(p);
			float h = st.method_26214(world, p);
			if (!st.method_26215() && h >= 0 && h < 20 && !st.method_27852(class_2246.field_9987)) {
				if (world.method_8409().method_43048(3) == 0) melt(world, p, 2, breaker);
				else world.method_8651(p, true, breaker);
			}
		}
		world.method_14199(class_2398.field_11239,
				center.method_10263() + 0.5, center.method_10264() + 0.5, center.method_10260() + 0.5,
				8, 0.6, 0.6, 0.6, 0.02);
	}
}
