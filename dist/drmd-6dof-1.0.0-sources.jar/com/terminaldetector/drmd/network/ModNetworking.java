package com.terminaldetector.drmd.network;

import com.terminaldetector.drmd.DescentMod;
import com.terminaldetector.drmd.DescentPlayerData;
import com.terminaldetector.drmd.energy.EnergyPreset;
import com.terminaldetector.drmd.energy.EnergySystem;
import com.terminaldetector.drmd.flight.FlightSystem;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public final class ModNetworking {
	public static final class_2960 INPUT_ID = class_2960.method_60655(DescentMod.MOD_ID, "input");
	public static final class_2960 SYNC_ID = class_2960.method_60655(DescentMod.MOD_ID, "sync");
	public static final class_2960 ACTION_ID = class_2960.method_60655(DescentMod.MOD_ID, "action");
	public static final class_2960 LLOD_ID = class_2960.method_60655(DescentMod.MOD_ID, "llod");

	public record InputPayload(float forward, float strafe, float vertical, float roll,
							   boolean dash, boolean hook,
							   boolean attitude, float fx, float fy, float fz,
							   float ux, float uy, float uz) implements class_8710 {
		public static final class_9154<InputPayload> ID = new class_9154<>(INPUT_ID);
		public static final class_9139<class_9129, InputPayload> CODEC = class_9139.method_56438(
				(payload, buf) -> {
					buf.method_52941(payload.forward);
					buf.method_52941(payload.strafe);
					buf.method_52941(payload.vertical);
					buf.method_52941(payload.roll);
					buf.method_52964(payload.dash);
					buf.method_52964(payload.hook);
					buf.method_52964(payload.attitude);
					buf.method_52941(payload.fx);
					buf.method_52941(payload.fy);
					buf.method_52941(payload.fz);
					buf.method_52941(payload.ux);
					buf.method_52941(payload.uy);
					buf.method_52941(payload.uz);
				},
				buf -> new InputPayload(
						buf.readFloat(), buf.readFloat(), buf.readFloat(), buf.readFloat(),
						buf.readBoolean(), buf.readBoolean(),
						buf.readBoolean(),
						buf.readFloat(), buf.readFloat(), buf.readFloat(),
						buf.readFloat(), buf.readFloat(), buf.readFloat()
				)
		);
		@Override public class_9154<? extends class_8710> method_56479() { return ID; }
	}

	public record SyncPayload(boolean enabled, float energy, float energyMax, float shield, float shieldMax,
							  float roll, float speed, int rocketSub, String preset, float gravy,
							  float dashCd, float gravityFactor, boolean alwaysRun, boolean flightAssist,
							  boolean radar, boolean footGravity, float localUx, float localUy, float localUz
	) implements class_8710 {
		public static final class_9154<SyncPayload> ID = new class_9154<>(SYNC_ID);
		public static final class_9139<class_9129, SyncPayload> CODEC = class_9139.method_56438(
				(payload, buf) -> {
					buf.method_52964(payload.enabled);
					buf.method_52941(payload.energy);
					buf.method_52941(payload.energyMax);
					buf.method_52941(payload.shield);
					buf.method_52941(payload.shieldMax);
					buf.method_52941(payload.roll);
					buf.method_52941(payload.speed);
					buf.method_10804(payload.rocketSub);
					buf.method_10814(payload.preset);
					buf.method_52941(payload.gravy);
					buf.method_52941(payload.dashCd);
					buf.method_52941(payload.gravityFactor);
					buf.method_52964(payload.alwaysRun);
					buf.method_52964(payload.flightAssist);
					buf.method_52964(payload.radar);
					buf.method_52964(payload.footGravity);
					buf.method_52941(payload.localUx);
					buf.method_52941(payload.localUy);
					buf.method_52941(payload.localUz);
				},
				buf -> new SyncPayload(
						buf.readBoolean(),
						buf.readFloat(),
						buf.readFloat(),
						buf.readFloat(),
						buf.readFloat(),
						buf.readFloat(),
						buf.readFloat(),
						buf.method_10816(),
						buf.method_19772(),
						buf.readFloat(),
						buf.readFloat(),
						buf.readFloat(),
						buf.readBoolean(),
						buf.readBoolean(),
						buf.readBoolean(),
						buf.readBoolean(),
						buf.readFloat(),
						buf.readFloat(),
						buf.readFloat()
				)
		);
		@Override public class_9154<? extends class_8710> method_56479() { return ID; }
	}

	public record ActionPayload(String action) implements class_8710 {
		public static final class_9154<ActionPayload> ID = new class_9154<>(ACTION_ID);
		public static final class_9139<class_9129, ActionPayload> CODEC = class_9139.method_56434(
				class_9135.field_48554, ActionPayload::action, ActionPayload::new
		);
		@Override public class_9154<? extends class_8710> method_56479() { return ID; }
	}

	/** Server → client Voxel LLOD catalogue (compact; client expands LLOD0/1/2 meshes). */
	public record LlodPayload(java.util.List<LlodEntry> entries) implements class_8710 {
		public record LlodEntry(java.util.UUID id, String kind, double x, double y, double z,
								float rx, float ry, float rz, String level, int color, String label, long seed) {}

		public static final class_9154<LlodPayload> ID = new class_9154<>(LLOD_ID);
		public static final class_9139<class_9129, LlodPayload> CODEC = class_9139.method_56438(
				(payload, buf) -> {
					buf.method_10804(payload.entries.size());
					for (LlodEntry e : payload.entries) {
						buf.method_10797(e.id);
						buf.method_10814(e.kind);
						buf.method_52940(e.x);
						buf.method_52940(e.y);
						buf.method_52940(e.z);
						buf.method_52941(e.rx);
						buf.method_52941(e.ry);
						buf.method_52941(e.rz);
						buf.method_10814(e.level);
						buf.method_53002(e.color);
						buf.method_10814(e.label);
						buf.method_52974(e.seed);
					}
				},
				buf -> {
					int n = buf.method_10816();
					java.util.ArrayList<LlodEntry> list = new java.util.ArrayList<>(n);
					for (int i = 0; i < n; i++) {
						list.add(new LlodEntry(
								buf.method_10790(),
								buf.method_19772(),
								buf.readDouble(), buf.readDouble(), buf.readDouble(),
								buf.readFloat(), buf.readFloat(), buf.readFloat(),
								buf.method_19772(),
								buf.readInt(),
								buf.method_19772(),
								buf.readLong()
						));
					}
					return new LlodPayload(list);
				}
		);
		@Override public class_9154<? extends class_8710> method_56479() { return ID; }
	}

	/** Client → server construction apply (empty modules list = clear override). */
	public record ConstructionPayload(String weaponId, net.minecraft.class_2499 modules) implements class_8710 {
		public static final class_2960 CONSTRUCTION_ID = class_2960.method_60655(DescentMod.MOD_ID, "construction");
		public static final class_9154<ConstructionPayload> ID = new class_9154<>(CONSTRUCTION_ID);
		public static final class_9139<class_9129, ConstructionPayload> CODEC = class_9139.method_56438(
				(payload, buf) -> {
					buf.method_10814(payload.weaponId);
					buf.method_10794(payload.modules);
				},
				buf -> {
					String id = buf.method_19772();
					net.minecraft.class_2520 el = buf.method_10798();
					net.minecraft.class_2499 list = el instanceof net.minecraft.class_2499 l ? l : new net.minecraft.class_2499();
					return new ConstructionPayload(id, list);
				}
		);
		@Override public class_9154<? extends class_8710> method_56479() { return ID; }
	}

	private ModNetworking() {}

	public static void register() {
		PayloadTypeRegistry.playC2S().register(InputPayload.ID, InputPayload.CODEC);
		PayloadTypeRegistry.playC2S().register(ActionPayload.ID, ActionPayload.CODEC);
		PayloadTypeRegistry.playC2S().register(ConstructionPayload.ID, ConstructionPayload.CODEC);
		PayloadTypeRegistry.playS2C().register(SyncPayload.ID, SyncPayload.CODEC);
		PayloadTypeRegistry.playS2C().register(ConstructionPayload.ID, ConstructionPayload.CODEC);
		PayloadTypeRegistry.playS2C().register(LlodPayload.ID, LlodPayload.CODEC);

		ServerPlayNetworking.registerGlobalReceiver(InputPayload.ID, (payload, context) -> {
			class_3222 player = context.player();
			FlightSystem.InputState in = FlightSystem.input(player);
			in.forward = payload.forward();
			in.strafe = payload.strafe();
			in.vertical = payload.vertical();
			in.roll = payload.roll();
			if (payload.dash()) in.dash = true;
			if (payload.hook()) FlightSystem.toggleHook(player);
			if (payload.attitude()) {
				DescentPlayerData data = DescentPlayerData.get(player);
				data.setShipAttitude(
						payload.fx(), payload.fy(), payload.fz(),
						payload.ux(), payload.uy(), payload.uz());
			}
		});

		ServerPlayNetworking.registerGlobalReceiver(ActionPayload.ID, (payload, context) -> {
			class_3222 player = context.player();
			DescentPlayerData data = DescentPlayerData.get(player);
			switch (payload.action()) {
				case "toggle" -> FlightSystem.toggle(player);
				case "dash" -> FlightSystem.tryDash(player);
				case "alwaysrun" -> data.setAlwaysRun(!data.isAlwaysRun());
				case "flightassist" -> data.setFlightAssist(!data.isFlightAssist());
				case "radar" -> data.setRadarEnabled(!data.isRadarEnabled());
				case "rocket_next" -> data.setRocketSubmode(data.getRocketSubmode() + 1);
				case "reset_roll" -> {
					data.levelShipAttitude(player);
					data.setRoll(0);
					data.setRollVel(0);
				}
				case "preset_balanced" -> EnergySystem.setPreset(data, EnergyPreset.BALANCED);
				case "preset_assault" -> EnergySystem.setPreset(data, EnergyPreset.ASSAULT);
				case "preset_interceptor" -> EnergySystem.setPreset(data, EnergyPreset.INTERCEPTOR);
				case "preset_siege" -> EnergySystem.setPreset(data, EnergyPreset.SIEGE);
				default -> {}
			}
			syncPlayer(player, data);
		});

		ServerPlayNetworking.registerGlobalReceiver(ConstructionPayload.ID, (payload, context) -> {
			class_3222 player = context.player();
			if (!player.method_5687(2) && !player.method_5682().method_3724()) {
				return; // only ops / SP can publish constructions
			}
			String id = com.terminaldetector.drmd.workshop.ConstructionRegistry.normalize(payload.weaponId());
			if (payload.modules() == null || payload.modules().isEmpty()) {
				com.terminaldetector.drmd.workshop.ConstructionRegistry.clearOverride(id);
			} else {
				var mods = com.terminaldetector.drmd.workshop.ClusterModule.listFromNbt(payload.modules());
				com.terminaldetector.drmd.workshop.ConstructionRegistry.setOverride(id, mods);
			}
			// Broadcast to all players so clients update FP view + muzzles
			for (class_3222 p : player.method_5682().method_3760().method_14571()) {
				ServerPlayNetworking.send(p, payload);
			}
		});
	}

	public static void syncPlayer(class_3222 player, DescentPlayerData data) {
		float speed = (float) data.getFlightVelocity().method_1033();
		var up = com.terminaldetector.drmd.world.LocalOrientation.getUp(player.method_5667());
		boolean foot = com.terminaldetector.drmd.world.gravity.FootGravitySystem.isActive(player.method_5667());
		if (foot) {
			up = com.terminaldetector.drmd.world.gravity.FootGravitySystem.getUp(player.method_5667());
		}
		ServerPlayNetworking.send(player, new SyncPayload(
				data.isEnabled(),
				data.getEnergy(), data.getEnergyMax(),
				data.getShield(), data.getShieldMax(),
				data.getRoll(), speed,
				data.getRocketSubmode(),
				data.getPreset().id,
				data.getGravyEnergy(),
				data.getDashCooldown(),
				data.getGravityFactor(),
				data.isAlwaysRun(),
				data.isFlightAssist(),
				data.isRadarEnabled(),
				foot,
				(float) up.field_1352, (float) up.field_1351, (float) up.field_1350
		));
	}

	public static void syncLlod(class_3222 player) {
		var silhouettes = com.terminaldetector.drmd.world.llod.LlodRegistry.queryVisible(player.method_24515(), 64);
		java.util.ArrayList<LlodPayload.LlodEntry> entries = new java.util.ArrayList<>(silhouettes.size());
		for (var s : silhouettes) {
			entries.add(new LlodPayload.LlodEntry(
					s.id(),
					s.kind().name(),
					s.center().field_1352, s.center().field_1351, s.center().field_1350,
					s.radiusX(), s.radiusY(), s.radiusZ(),
					s.level().name(),
					s.colorRgb(),
					s.label(),
					s.seed()
			));
		}
		ServerPlayNetworking.send(player, new LlodPayload(entries));
	}
}
