package com.terminaldetector.drmd.ai;

import com.terminaldetector.drmd.DescentMod;
import com.terminaldetector.drmd.entity.DroneEntity;
import java.util.EnumSet;
import net.minecraft.class_1309;
import net.minecraft.class_1352;
import net.minecraft.class_243;
import net.minecraft.class_3532;

/**
 * Combat motion: ORBIT → RUN → BREAK with 6DoF attitude (yaw/pitch/roll from velocity).
 * Port of GMod drone combat — ~10 roles share this motion; no special per-mob port needed.
 */
public final class DroneAi {
	public enum Phase { ORBIT, RUN, BREAK }

	public static class CombatGoal extends class_1352 {
		private final DroneEntity drone;

		public CombatGoal(DroneEntity drone) {
			this.drone = drone;
			this.method_6265(EnumSet.of(class_4134.field_18405, class_4134.field_18406));
		}

		@Override
		public boolean method_6264() {
			return drone.method_5968() != null && drone.method_5968().method_5805();
		}

		@Override
		public void method_6268() {
			class_1309 target = drone.method_5968();
			if (target == null) return;
			float dt = 1f / 20f;
			drone.addPhaseTimer(dt);

			class_243 pos = drone.method_19538();
			class_243 tpos = target.method_19538().method_1031(0, target.method_17682() * 0.5, 0);
			class_243 toTarget = tpos.method_1020(pos);
			double dist = toTarget.method_1033();
			double preferred = DescentMod.su(drone.getRole().speed > 500 ? 500 : 700);

			Phase phase = drone.getPhase();
			if (phase == Phase.ORBIT && drone.getPhaseTimer() > 3f) drone.setPhase(Phase.RUN);
			else if (phase == Phase.RUN && drone.getPhaseTimer() > 1.5f) drone.setPhase(Phase.BREAK);
			else if (phase == Phase.BREAK && drone.getPhaseTimer() > 1.2f) drone.setPhase(Phase.ORBIT);

			class_243 desire;
			switch (drone.getPhase()) {
				case ORBIT -> {
					// Orbit in the plane facing the target (full 3D, not world-up locked)
					class_243 radial = toTarget.method_1027() > 1e-6 ? toTarget.method_1029() : new class_243(0, 0, 1);
					class_243 upHint = Math.abs(radial.field_1351) < 0.9 ? new class_243(0, 1, 0) : new class_243(1, 0, 0);
					class_243 tangent = radial.method_1036(upHint);
					if (tangent.method_1027() < 1e-4) tangent = new class_243(1, 0, 0);
					tangent = tangent.method_1029();
					double radialErr = class_3532.method_15350((dist - preferred) / preferred, -1, 1);
					desire = tangent.method_1021(2.2).method_1019(radial.method_1021(-radialErr));
				}
				case RUN -> desire = toTarget.method_1029().method_1031(0, drone.method_59922().method_43056() ? 0.4 : -0.4, 0);
				case BREAK -> {
					class_243 away = pos.method_1020(tpos).method_1029();
					desire = away.method_1031(0, 0.6, 0).method_1019(drone.method_5720().method_1021(0.5));
				}
				default -> desire = toTarget.method_1029();
			}

			class_243 sep = class_243.field_1353;
			for (DroneEntity other : drone.method_37908().method_8390(DroneEntity.class,
					drone.method_5829().method_1014(DescentMod.su(90)), d -> d != drone)) {
				class_243 away = pos.method_1020(other.method_19538());
				double d = away.method_1033();
				if (d > 1e-3 && d < DescentMod.su(90)) {
					sep = sep.method_1019(away.method_1029().method_1021(2.8 / d));
				}
			}
			desire = desire.method_1019(sep);
			if (desire.method_1027() < 1e-6) desire = toTarget;
			desire = desire.method_1029();

			double maxSpd = DescentMod.su(drone.getRole().speed);
			class_243 vel = desire.method_1021(maxSpd / 20.0);
			drone.method_18799(vel);
			drone.field_6037 = true;
			alignAttitude(drone, vel, desire, dt);

			if (dist < DescentMod.su(2000)) {
				drone.tryFireAt(target);
			}
		}

		/** Velocity-aligned yaw/pitch + bank roll — 6DoF feel without per-mob special cases. */
		private static void alignAttitude(DroneEntity drone, class_243 vel, class_243 desire, float dt) {
			if (vel.method_1027() < 1e-6) return;
			class_243 dir = vel.method_1029();
			float yaw = (float) (class_3532.method_15349(-dir.field_1352, dir.field_1350) * (180.0 / Math.PI));
			float pitch = (float) (class_3532.method_15349(-dir.field_1351, Math.sqrt(dir.field_1352 * dir.field_1352 + dir.field_1350 * dir.field_1350)) * (180.0 / Math.PI));
			drone.method_36456(yaw);
			drone.method_36457(pitch);
			drone.field_6283 = yaw;

			// Bank into turn: lateral desire vs current right vector
			class_243 forward = dir;
			class_243 worldUp = new class_243(0, 1, 0);
			class_243 right = forward.method_1036(worldUp);
			if (right.method_1027() < 1e-4) right = new class_243(1, 0, 0);
			right = right.method_1029();
			float bank = (float) class_3532.method_15350(desire.method_1026(right) * 55.0, -55.0, 55.0);
			float roll = class_3532.method_16439(1f - (float) Math.exp(-6f * dt), drone.getFlightRoll(), bank);
			drone.setFlightRoll(roll);
		}
	}
}
