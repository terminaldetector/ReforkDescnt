package com.terminaldetector.drmd.world.soil;

import com.terminaldetector.drmd.entity.ModBlockEntities;
import org.jetbrains.annotations.Nullable;

import java.util.EnumMap;
import java.util.Map;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2487;
import net.minecraft.class_2586;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2622;
import net.minecraft.class_2680;
import net.minecraft.class_7225;

public class SixDSoilBlockEntity extends class_2586 {
	private final Map<class_2350, SixDSoilBlock.FaceCrop> crops = new EnumMap<>(class_2350.class);

	public SixDSoilBlockEntity(class_2338 pos, class_2680 state) {
		super(ModBlockEntities.SIX_D_SOIL, pos, state);
		for (class_2350 d : class_2350.values()) crops.put(d, SixDSoilBlock.FaceCrop.MOSS);
	}

	public void setCrop(class_2350 face, SixDSoilBlock.FaceCrop crop) {
		crops.put(face, crop);
		method_5431();
	}

	public SixDSoilBlock.FaceCrop getCrop(class_2350 face) {
		return crops.getOrDefault(face, SixDSoilBlock.FaceCrop.MOSS);
	}

	@Override
	protected void method_11007(class_2487 nbt, class_7225.class_7874 registryLookup) {
		super.method_11007(nbt, registryLookup);
		class_2487 c = new class_2487();
		for (var e : crops.entrySet()) {
			c.method_10582(e.getKey().method_15434(), e.getValue().name());
		}
		nbt.method_10566("crops", c);
	}

	@Override
	protected void method_11014(class_2487 nbt, class_7225.class_7874 registryLookup) {
		super.method_11014(nbt, registryLookup);
		if (!nbt.method_10545("crops")) return;
		class_2487 c = nbt.method_10562("crops");
		for (class_2350 d : class_2350.values()) {
			String key = d.method_15434();
			if (c.method_10545(key)) {
				try {
					crops.put(d, SixDSoilBlock.FaceCrop.valueOf(c.method_10558(key)));
				} catch (IllegalArgumentException ignored) {}
			}
		}
	}

	@Nullable
	@Override
	public class_2596<class_2602> method_38235() {
		return class_2622.method_38585(this);
	}

	@Override
	public class_2487 method_16887(class_7225.class_7874 registryLookup) {
		return method_38244(registryLookup);
	}
}
