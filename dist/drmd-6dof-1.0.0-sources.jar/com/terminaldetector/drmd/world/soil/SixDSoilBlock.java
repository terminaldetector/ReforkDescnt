package com.terminaldetector.drmd.world.soil;

import com.mojang.serialization.MapCodec;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_2237;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2464;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2746;
import net.minecraft.class_3218;
import net.minecraft.class_3965;
import net.minecraft.class_5558;
import net.minecraft.class_5819;
import org.jetbrains.annotations.Nullable;

/**
 * 6D Soil — six working faces. Trees/fungi/vines/flowers/moss grow outward
 * relative to the face they sit on: spherical forests, ring gardens, ceiling jungles.
 */
public class SixDSoilBlock extends class_2237 {
	public static final class_2746 GROW_UP = class_2746.method_11825("grow_up");
	public static final class_2746 GROW_DOWN = class_2746.method_11825("grow_down");
	public static final class_2746 GROW_NORTH = class_2746.method_11825("grow_north");
	public static final class_2746 GROW_SOUTH = class_2746.method_11825("grow_south");
	public static final class_2746 GROW_EAST = class_2746.method_11825("grow_east");
	public static final class_2746 GROW_WEST = class_2746.method_11825("grow_west");

	public static final MapCodec<SixDSoilBlock> CODEC = method_54094(SixDSoilBlock::new);

	public SixDSoilBlock(class_2251 settings) {
		super(settings);
		method_9590(method_9595().method_11664()
				.method_11657(GROW_UP, false).method_11657(GROW_DOWN, false)
				.method_11657(GROW_NORTH, false).method_11657(GROW_SOUTH, false)
				.method_11657(GROW_EAST, false).method_11657(GROW_WEST, false));
	}

	@Override
	protected MapCodec<? extends class_2237> method_53969() {
		return field_46280;
	}

	@Override
	protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
		builder.method_11667(GROW_UP, GROW_DOWN, GROW_NORTH, GROW_SOUTH, GROW_EAST, GROW_WEST);
	}

	public static class_2746 propertyFor(class_2350 dir) {
		return switch (dir) {
			case field_11036 -> GROW_UP;
			case field_11033 -> GROW_DOWN;
			case field_11043 -> GROW_NORTH;
			case field_11035 -> GROW_SOUTH;
			case field_11034 -> GROW_EAST;
			case field_11039 -> GROW_WEST;
		};
	}

	@Nullable
	@Override
	public class_2586 method_10123(class_2338 pos, class_2680 state) {
		return new SixDSoilBlockEntity(pos, state);
	}

	@Override
	public class_2464 method_9604(class_2680 state) {
		return class_2464.field_11458;
	}

	@Override
	protected class_1269 method_55766(class_2680 state, class_1937 world, class_2338 pos, class_1657 player, class_3965 hit) {
		if (world.field_9236) return class_1269.field_5812;
		class_1799 stack = player.method_5998(class_1268.field_5808);
		class_2350 face = hit.method_17780();
		class_2746 prop = propertyFor(face);

		FaceCrop crop = FaceCrop.fromItem(stack);
		if (crop != null) {
			if (!state.method_11654(prop)) {
				world.method_8652(pos, state.method_11657(prop, true), class_2248.field_31036);
			}
			if (world.method_8321(pos) instanceof SixDSoilBlockEntity be) {
				be.setCrop(face, crop);
			}
			if (!player.method_31549().field_7477) stack.method_7934(1);
			tryGrowOutward(world, pos, face, crop);
			return class_1269.field_5812;
		}
		return class_1269.field_5811;
	}

	@Override
	protected boolean method_9542(class_2680 state) {
		return true;
	}

	@Override
	protected void method_9514(class_2680 state, class_3218 world, class_2338 pos, class_5819 random) {
		for (class_2350 dir : class_2350.values()) {
			if (!state.method_11654(propertyFor(dir))) continue;
			if (random.method_43048(8) != 0) continue;
			FaceCrop crop = FaceCrop.MOSS;
			if (world.method_8321(pos) instanceof SixDSoilBlockEntity be) {
				crop = be.getCrop(dir);
			}
			tryGrowOutward(world, pos, dir, crop);
		}
	}

	/** Growth always goes outward from the face — never absolute +Y. */
	public static void tryGrowOutward(class_1937 world, class_2338 soil, class_2350 face, FaceCrop crop) {
		class_2338 target = soil.method_10093(face);
		if (!world.method_8320(target).method_26215()) return;
		class_2680 plant = crop.plantState(face);
		if (plant != null) {
			world.method_8652(target, plant, class_2248.field_31036);
		}
	}

	@Nullable
	@Override
	public <T extends class_2586> class_5558<T> method_31645(class_1937 world, class_2680 state, class_2591<T> type) {
		return null;
	}

	public enum FaceCrop {
		TREE, MUSHROOM, VINE, FLOWER, MOSS;

		@Nullable
		public static FaceCrop fromItem(class_1799 stack) {
			if (stack.method_31574(class_1802.field_17535) || stack.method_31574(class_1802.field_17537) || stack.method_31574(class_1802.field_17536))
				return TREE;
			if (stack.method_31574(class_1802.field_17516) || stack.method_31574(class_1802.field_17517)) return MUSHROOM;
			if (stack.method_31574(class_1802.field_17523) || stack.method_31574(class_1802.field_28409)) return VINE;
			if (stack.method_31574(class_1802.field_8880) || stack.method_31574(class_1802.field_8491) || stack.method_31574(class_1802.field_8602)) return FLOWER;
			if (stack.method_31574(class_1802.field_28654) || stack.method_31574(class_1802.field_28653)) return MOSS;
			return null;
		}

		@Nullable
		public class_2680 plantState(class_2350 outward) {
			return switch (this) {
				case TREE -> {
					// Sapling proxy: oak leaves cluster as "tree grows outward"
					yield net.minecraft.class_2246.field_10503.method_9564();
				}
				case MUSHROOM -> net.minecraft.class_2246.field_10251.method_9564();
				case VINE -> {
					var vine = net.minecraft.class_2246.field_10597.method_9564();
					yield switch (outward.method_10153()) {
						case field_11043 -> vine.method_11657(net.minecraft.class_2541.field_11706, true);
						case field_11035 -> vine.method_11657(net.minecraft.class_2541.field_11699, true);
						case field_11034 -> vine.method_11657(net.minecraft.class_2541.field_11702, true);
						case field_11039 -> vine.method_11657(net.minecraft.class_2541.field_11696, true);
						default -> net.minecraft.class_2246.field_28411.method_9564();
					};
				}
				case FLOWER -> net.minecraft.class_2246.field_10449.method_9564();
				case MOSS -> net.minecraft.class_2246.field_28680.method_9564();
			};
		}
	}
}
