package com.terminaldetector.drmd.world.gravity;

/**
 * Local gravity field shape for generators / torches / station zones.
 */
public enum FieldShape {
	SPHERE,
	CYLINDER,
	PLANE
}
