package com.terminaldetector.drmd.world.gravity;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_243;

/**
 * Runtime catalogue of gravity fields — generators, torches, station zones.
 * Queried each flight tick to blend local UP / gravity strength.
 */
public final class GravityFields {
	public record Field(
		UUID id,
		class_2338 origin,
		class_243 downDir,
		double radius,
		float power,
		FieldShape shape,
		String label
	) {
		public double influenceAt(class_243 pos) {
			class_243 rel = pos.method_1020(class_243.method_24953(origin));
			return switch (shape) {
				case SPHERE -> {
					double d = rel.method_1033();
					yield d > radius ? 0 : (1.0 - d / radius) * power;
				}
				case CYLINDER -> {
					class_243 axis = downDir.method_1029();
					double along = rel.method_1026(axis);
					class_243 radial = rel.method_1020(axis.method_1021(along));
					double rd = radial.method_1033();
					yield (Math.abs(along) > radius || rd > radius * 0.55) ? 0
							: (1.0 - rd / (radius * 0.55)) * power;
				}
				case PLANE -> {
					double dist = Math.abs(rel.method_1026(downDir.method_1029()));
					double planar = rel.method_1020(downDir.method_1029().method_1021(rel.method_1026(downDir.method_1029()))).method_1033();
					yield (dist > 3.0 || planar > radius) ? 0 : (1.0 - planar / radius) * power;
				}
			};
		}
	}

	private static final Map<UUID, Field> FIELDS = new ConcurrentHashMap<>();

	private GravityFields() {}

	public static void put(Field field) {
		FIELDS.put(field.id(), field);
	}

	public static void remove(UUID id) {
		FIELDS.remove(id);
	}

	public static void clear() {
		FIELDS.clear();
	}

	public static List<Field> all() {
		return new ArrayList<>(FIELDS.values());
	}

	/**
	 * Blended sample: weighted average of down directions + max power.
	 * Returns null if no field affects the point.
	 */
	public static Sample sample(class_1937 world, class_243 pos) {
		class_243 sumDir = class_243.field_1353;
		double weight = 0;
		float maxPower = 0;
		String dominant = null;
		for (Field f : FIELDS.values()) {
			if (world != null && world.method_27983() == null) {
				// keep signature open for future per-world filtering
			}
			double w = f.influenceAt(pos);
			if (w <= 1e-4) continue;
			sumDir = sumDir.method_1019(f.downDir().method_1029().method_1021(w));
			weight += w;
			if (f.power() >= maxPower) {
				maxPower = f.power();
				dominant = f.label();
			}
		}
		if (weight < 1e-4) return null;
		return new Sample(sumDir.method_1029(), (float) Math.min(2.0, weight), maxPower, dominant);
	}

	public record Sample(class_243 downDir, float strength, float maxPower, String label) {
		public class_243 upDir() {
			return downDir.method_22882();
		}
	}
}
