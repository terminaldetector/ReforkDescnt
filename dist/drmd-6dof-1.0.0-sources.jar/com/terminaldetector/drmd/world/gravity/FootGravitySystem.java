package com.terminaldetector.drmd.world.gravity;

import com.terminaldetector.drmd.DescentPlayerData;
import com.terminaldetector.drmd.entity.PyroShipEntity;
import com.terminaldetector.drmd.network.ModNetworking;
import com.terminaldetector.drmd.world.LocalOrientation;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_1313;
import net.minecraft.class_1657;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_3222;
import net.minecraft.class_3532;
import net.minecraft.class_3959;

/**
 * On-foot local gravity — torch / generator redefine "down".
 * Pyro GX passengers are never affected; pilots keep thruster 6DoF.
 * After dismount (flight off), players walk on walls/ceilings with stable local UP.
 */
public final class FootGravitySystem {
	public static final double GRAVITY = 0.08;
	public static final double STICK_DIST = 1.4;

	public record State(class_243 up, boolean active, boolean grounded, String label) {}

	private static final Map<UUID, State> STATES = new ConcurrentHashMap<>();

	private FootGravitySystem() {}

	public static State get(UUID id) {
		return STATES.get(id);
	}

	public static boolean isActive(UUID id) {
		State s = STATES.get(id);
		return s != null && s.active();
	}

	public static class_243 getUp(UUID id) {
		State s = STATES.get(id);
		if (s != null && s.active()) return s.up();
		return LocalOrientation.getUp(id);
	}

	public static void clear(UUID id) {
		STATES.remove(id);
	}

	/** Server tick — orientation / activation only (motion via {@link #travel}). */
	public static void tick(class_3222 player) {
		if (player.method_5854() instanceof PyroShipEntity) {
			clear(player.method_5667());
			return;
		}
		DescentPlayerData data = DescentPlayerData.get(player);
		if (data.isEnabled()) {
			clear(player.method_5667());
			return;
		}

		GravityFields.Sample field = GravityFields.sample(player.method_37908(), player.method_19538());
		class_243 up;
		String label;
		if (field != null) {
			up = field.upDir().method_1029();
			label = field.label() != null ? field.label() : "Local Gravity";
		} else {
			up = LocalOrientation.getUp(player.method_5667());
			label = "Local";
			if (isWorldUp(up)) {
				player.method_5875(false);
				clear(player.method_5667());
				LocalOrientation.setUp(player.method_5667(), new class_243(0, 1, 0));
				if (player.field_6012 % 10 == 0) ModNetworking.syncPlayer(player, data);
				return;
			}
		}

		LocalOrientation.setUp(player.method_5667(), up);
		player.method_5875(true);
		player.field_6017 = 0f;

		boolean grounded = probeGround(player, up);
		STATES.put(player.method_5667(), new State(up, true, grounded, label));
		if (player.field_6012 % 2 == 0) ModNetworking.syncPlayer(player, data);
	}

	/**
	 * Remapped travel — replaces vanilla {@code LivingEntity.travel} while active.
	 * movementInput: strafe / jump / forward.
	 */
	public static void travel(class_1657 player, class_243 movementInput) {
		class_243 up = getUp(player.method_5667());
		if (up.method_1027() < 1e-6) up = new class_243(0, 1, 0);
		up = up.method_1029();

		float yawRad = player.method_36454() * class_3532.field_29847;
		class_243 prefer = new class_243(-class_3532.method_15374(yawRad), 0.0, class_3532.method_15362(yawRad));
		class_243 forward = prefer.method_1020(up.method_1021(prefer.method_1026(up)));
		if (forward.method_1027() < 1e-6) {
			prefer = Math.abs(up.field_1351) > 0.9 ? new class_243(0, 0, 1) : new class_243(0, 1, 0);
			forward = prefer.method_1020(up.method_1021(prefer.method_1026(up)));
		}
		forward = forward.method_1029();
		class_243 right = up.method_1036(forward).method_1029();
		forward = right.method_1036(up).method_1029();

		float speed = player.method_6029();
		class_243 wish = right.method_1021(movementInput.field_1352 * speed * 2.5)
				.method_1019(forward.method_1021(movementInput.field_1350 * speed * 2.5));

		boolean grounded = probeGround(player, up);
		class_243 vel = projectTangent(player.method_18798(), up);

		if (movementInput.field_1351 > 0 && grounded) {
			vel = vel.method_1019(up.method_1021(0.42));
			grounded = false;
		}

		vel = vel.method_1021(grounded ? 0.84 : 0.98);
		vel = vel.method_1019(wish);
		if (!grounded) {
			vel = vel.method_1019(up.method_22882().method_1021(GRAVITY));
		} else {
			// Kill into-floor component and keep contact
			double into = vel.method_1026(up.method_22882());
			if (into > 0) vel = vel.method_1020(up.method_22882().method_1021(into));
			snapToSurface(player, up);
		}

		player.method_18799(vel);
		player.method_5784(class_1313.field_6308, vel);
		player.field_6007 = true;
		player.method_24830(grounded);
		player.field_6017 = 0f;

		if (player instanceof class_3222 sp) {
			State prev = STATES.get(sp.method_5667());
			String label = prev != null ? prev.label() : "Local";
			STATES.put(sp.method_5667(), new State(up, true, grounded, label));
		}
	}

	private static boolean probeGround(class_1657 player, class_243 up) {
		class_243 down = up.method_22882();
		class_243 from = player.method_19538().method_1019(up.method_1021(0.08));
		var hit = player.method_37908().method_17742(new class_3959(
				from, from.method_1019(down.method_1021(STICK_DIST)),
				class_3959.class_3960.field_17558,
				class_3959.class_242.field_1348,
				player));
		return hit.method_17783() == class_239.class_240.field_1332
				&& hit.method_17784().method_1022(from) < STICK_DIST;
	}

	private static void snapToSurface(class_1657 player, class_243 up) {
		class_243 down = up.method_22882();
		class_243 from = player.method_19538().method_1019(up.method_1021(0.08));
		var hit = player.method_37908().method_17742(new class_3959(
				from, from.method_1019(down.method_1021(STICK_DIST)),
				class_3959.class_3960.field_17558,
				class_3959.class_242.field_1348,
				player));
		if (hit.method_17783() != class_239.class_240.field_1332) return;
		double stand = 0.0;
		class_243 target = hit.method_17784().method_1019(up.method_1021(stand));
		class_243 delta = target.method_1020(player.method_19538());
		double along = delta.method_1026(up);
		// Only correct along up/down, keep tangential freedom
		if (Math.abs(along) > 0.02) {
			player.method_33574(player.method_19538().method_1019(up.method_1021(along * 0.55)));
		}
	}

	private static class_243 projectTangent(class_243 v, class_243 up) {
		return v.method_1020(up.method_1021(v.method_1026(up)));
	}

	public static boolean isWorldUp(class_243 up) {
		return up.method_1028(0, 1, 0) < 0.04;
	}

	/** Adopt gravity field at a position (dismount / torch). */
	public static void adoptAt(class_3222 player, class_243 pos) {
		GravityFields.Sample field = GravityFields.sample(player.method_37908(), pos);
		if (field != null) {
			class_243 up = field.upDir().method_1029();
			LocalOrientation.setUp(player.method_5667(), up);
			STATES.put(player.method_5667(), new State(up, true, false,
					field.label() != null ? field.label() : "Local Gravity"));
			player.method_5875(true);
		}
	}

	/** Client mirror of active foot-gravity state (from sync). */
	public static void adoptClient(UUID id, class_243 up) {
		if (up.method_1027() < 1e-6) up = new class_243(0, 1, 0);
		up = up.method_1029();
		LocalOrientation.setUp(id, up);
		STATES.put(id, new State(up, true, false, "Local"));
	}
}
