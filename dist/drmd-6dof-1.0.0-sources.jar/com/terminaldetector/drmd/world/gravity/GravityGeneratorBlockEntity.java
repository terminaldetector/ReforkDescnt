package com.terminaldetector.drmd.world.gravity;

import com.terminaldetector.drmd.entity.ModBlockEntities;
import java.util.UUID;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_7225;

public class GravityGeneratorBlockEntity extends class_2586 {
	private UUID fieldId = UUID.randomUUID();
	private float radius = 24f;
	private float power = 1.0f;
	private FieldShape shape = FieldShape.SPHERE;

	public GravityGeneratorBlockEntity(class_2338 pos, class_2680 state) {
		super(ModBlockEntities.GRAVITY_GENERATOR, pos, state);
	}

	public float getRadius() { return radius; }
	public float getPower() { return power; }
	public FieldShape getShape() { return shape; }

	public void cyclePower() {
		power += 0.25f;
		if (power > 2.0f) power = 0.25f;
		radius = 12f + power * 16f;
		method_5431();
		registerField();
	}

	public void cycleShape() {
		FieldShape[] v = FieldShape.values();
		shape = v[(shape.ordinal() + 1) % v.length];
		method_5431();
		registerField();
	}

	public void registerField() {
		class_2350 facing = method_11010().method_11654(GravityGeneratorBlock.FACING);
		// Facing points "down" into the gravity well
		class_243 down = class_243.method_24954(facing.method_10163());
		GravityFields.put(new GravityFields.Field(
				fieldId, field_11867, down, radius, power, shape, "Generator"));
	}

	public void unregister() {
		GravityFields.remove(fieldId);
	}

	public static void tick(class_1937 world, class_2338 pos, class_2680 state, GravityGeneratorBlockEntity be) {
		if (world.method_8510() % 20 == 0) be.registerField();
	}

	@Override
	protected void method_11007(class_2487 nbt, class_7225.class_7874 registryLookup) {
		super.method_11007(nbt, registryLookup);
		nbt.method_25927("field", fieldId);
		nbt.method_10548("radius", radius);
		nbt.method_10548("power", power);
		nbt.method_10582("shape", shape.name());
	}

	@Override
	protected void method_11014(class_2487 nbt, class_7225.class_7874 registryLookup) {
		super.method_11014(nbt, registryLookup);
		if (nbt.method_25928("field")) fieldId = nbt.method_25926("field");
		radius = nbt.method_10545("radius") ? nbt.method_10583("radius") : 24f;
		power = nbt.method_10545("power") ? nbt.method_10583("power") : 1f;
		try {
			shape = FieldShape.valueOf(nbt.method_10558("shape"));
		} catch (Exception e) {
			shape = FieldShape.SPHERE;
		}
	}
}
