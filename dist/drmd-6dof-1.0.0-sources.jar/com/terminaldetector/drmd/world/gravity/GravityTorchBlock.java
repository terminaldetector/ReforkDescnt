package com.terminaldetector.drmd.world.gravity;

import com.mojang.serialization.MapCodec;
import org.jetbrains.annotations.Nullable;
import org.joml.Vector3f;

import java.util.UUID;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2390;
import net.minecraft.class_243;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2753;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3726;
import net.minecraft.class_5819;

/**
 * Gravity Torch — compact local gravity source (green torch).
 * Anyone in its zone treats the torch facing as "down".
 */
public class GravityTorchBlock extends class_2248 {
	public static final class_2753 FACING = class_2741.field_12525;
	public static final MapCodec<GravityTorchBlock> CODEC = method_54094(GravityTorchBlock::new);
	private static final float RADIUS = 8f;
	private static final float POWER = 0.85f;

	public GravityTorchBlock(class_2251 settings) {
		super(settings);
		method_9590(method_9595().method_11664().method_11657(FACING, class_2350.field_11036));
	}

	@Override
	protected MapCodec<? extends class_2248> method_53969() {
		return field_46280;
	}

	@Override
	protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
		builder.method_11667(FACING);
	}

	@Nullable
	@Override
	public class_2680 method_9605(class_1750 ctx) {
		// Place so the "flame" points opposite the clicked face → that axis becomes down for zones
		return method_9564().method_11657(FACING, ctx.method_8038());
	}

	@Override
	protected class_265 method_9530(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
		return class_259.method_1081(0.35, 0.0, 0.35, 0.65, 0.7, 0.65);
	}

	@Override
	protected void method_9615(class_2680 state, class_1937 world, class_2338 pos, class_2680 oldState, boolean notify) {
		super.method_9615(state, world, pos, oldState, notify);
		register(world, pos, state);
	}

	@Override
	protected void method_9536(class_2680 state, class_1937 world, class_2338 pos, class_2680 newState, boolean moved) {
		GravityFields.remove(torchId(pos));
		super.method_9536(state, world, pos, newState, moved);
	}

	@Override
	protected void method_9514(class_2680 state, class_3218 world, class_2338 pos, class_5819 random) {
		register(world, pos, state);
		// Soft-apply UP to nearby living entities (mobs + players)
		class_2350 face = state.method_11654(FACING);
		class_243 down = class_243.method_24954(face.method_10153().method_10163());
		class_243 up = down.method_22882();
		for (class_1309 e : world.method_8390(class_1309.class,
				new net.minecraft.class_238(pos).method_1014(RADIUS), class_1309::method_5805)) {
			if (e instanceof class_3222 sp) {
				com.terminaldetector.drmd.world.LocalOrientation.setUp(sp.method_5667(), up);
			} else {
				// Nudge mobs toward local down
				e.method_5762(down.field_1352 * 0.04, down.field_1351 * 0.04, down.field_1350 * 0.04);
				e.field_6037 = true;
			}
		}
		world.method_14199(new class_2390(new Vector3f(0.2f, 1f, 0.45f), 1.0f),
				pos.method_10263() + 0.5, pos.method_10264() + 0.7, pos.method_10260() + 0.5, 4, 0.15, 0.15, 0.15, 0.01);
	}

	@Override
	protected void method_9548(class_2680 state, class_1937 world, class_2338 pos, class_1297 entity) {
		if (world.field_9236) return;
		class_2350 face = state.method_11654(FACING);
		class_243 up = class_243.method_24954(face.method_10163());
		if (entity instanceof class_1657 p) {
			com.terminaldetector.drmd.world.LocalOrientation.setUp(p.method_5667(), up);
		}
	}

	private static void register(class_1937 world, class_2338 pos, class_2680 state) {
		class_2350 face = state.method_11654(FACING);
		// Torch stem points along FACING; gravity pulls opposite (toward the mount surface)
		class_243 down = class_243.method_24954(face.method_10153().method_10163());
		GravityFields.put(new GravityFields.Field(
				torchId(pos), pos, down, RADIUS, POWER, FieldShape.SPHERE, "Gravity Torch"));
	}

	private static UUID torchId(class_2338 pos) {
		return new UUID(0x67726176L ^ pos.method_10063(), 0x746F726368L ^ (pos.method_10063() >>> 1));
	}
}
