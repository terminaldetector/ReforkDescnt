package com.terminaldetector.drmd.world.gravity;

import com.mojang.serialization.MapCodec;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1937;
import net.minecraft.class_2237;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2753;
import net.minecraft.class_3965;
import net.minecraft.class_5558;
import org.jetbrains.annotations.Nullable;

/**
 * Gravity Generator — technological local-gravity source (radius / direction / shape / power).
 */
public class GravityGeneratorBlock extends class_2237 {
	public static final class_2753 FACING = class_2741.field_12525;
	public static final MapCodec<GravityGeneratorBlock> CODEC = method_54094(GravityGeneratorBlock::new);

	public GravityGeneratorBlock(class_2251 settings) {
		super(settings);
		method_9590(method_9595().method_11664().method_11657(FACING, class_2350.field_11033));
	}

	@Override
	protected MapCodec<? extends class_2237> method_53969() {
		return field_46280;
	}

	@Override
	protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
		builder.method_11667(FACING);
	}

	@Nullable
	@Override
	public class_2680 method_9605(class_1750 ctx) {
		return method_9564().method_11657(FACING, ctx.method_7715().method_10153());
	}

	@Nullable
	@Override
	public class_2586 method_10123(class_2338 pos, class_2680 state) {
		return new GravityGeneratorBlockEntity(pos, state);
	}

	@Nullable
	@Override
	public <T extends class_2586> class_5558<T> method_31645(class_1937 world, class_2680 state, class_2591<T> type) {
		return world.field_9236 ? null : method_31618(type,
				com.terminaldetector.drmd.entity.ModBlockEntities.GRAVITY_GENERATOR,
				GravityGeneratorBlockEntity::tick);
	}

	@Override
	protected class_1269 method_55766(class_2680 state, class_1937 world, class_2338 pos, class_1657 player, class_3965 hit) {
		if (world.field_9236) return class_1269.field_5812;
		class_2586 be = world.method_8321(pos);
		if (be instanceof GravityGeneratorBlockEntity gen) {
			if (player.method_5715()) {
				gen.cycleShape();
				player.method_7353(class_2561.method_43470("§aGravity field shape: §f" + gen.getShape()), true);
			} else {
				gen.cyclePower();
				player.method_7353(class_2561.method_43470(String.format("§aGravity power: §f%.1f  radius=%.0f",
						gen.getPower(), gen.getRadius())), true);
			}
		}
		return class_1269.field_5812;
	}

	@Override
	protected void method_9536(class_2680 state, class_1937 world, class_2338 pos, class_2680 newState, boolean moved) {
		if (!state.method_27852(newState.method_26204()) && world.method_8321(pos) instanceof GravityGeneratorBlockEntity gen) {
			gen.unregister();
		}
		super.method_9536(state, world, pos, newState, moved);
	}
}
