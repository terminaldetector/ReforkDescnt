package com.terminaldetector.drmd.world;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_2350;
import net.minecraft.class_243;

/**
 * Local orientation — any surface can be floor/wall/ceiling.
 * Magnetic anomalies and surface-snap building redefine local "up".
 */
public final class LocalOrientation {
	private static final Map<UUID, class_243> PLAYER_UP = new ConcurrentHashMap<>();

	private LocalOrientation() {}

	public static class_243 getUp(UUID playerId) {
		return PLAYER_UP.getOrDefault(playerId, new class_243(0, 1, 0));
	}

	public static void setUp(UUID playerId, class_243 up) {
		if (up.method_1027() < 1e-6) {
			PLAYER_UP.put(playerId, new class_243(0, 1, 0));
		} else {
			PLAYER_UP.put(playerId, up.method_1029());
		}
	}

	public static void clear(UUID playerId) {
		PLAYER_UP.remove(playerId);
	}

	public static void setFromDirection(UUID playerId, class_2350 dir) {
		setUp(playerId, class_243.method_24954(dir.method_10163()));
	}

	/** Convert world gravity direction for flight idle-grav / micro-grav. */
	public static class_243 gravityDir(UUID playerId) {
		return getUp(playerId).method_22882();
	}
}
