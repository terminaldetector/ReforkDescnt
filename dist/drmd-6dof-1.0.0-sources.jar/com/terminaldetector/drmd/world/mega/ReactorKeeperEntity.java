package com.terminaldetector.drmd.world.mega;

import com.terminaldetector.drmd.world.WorldRules;
import com.terminaldetector.drmd.world.gen2.MacroEntry;
import com.terminaldetector.drmd.world.gen2.MacroWorld;
import java.util.UUID;
import net.minecraft.class_1299;
import net.minecraft.class_1588;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_3218;
import net.minecraft.class_3532;
import net.minecraft.class_5132;
import net.minecraft.class_5134;

/**
 * Ancient Reactor Keeper — colossal sentinel tied to industrial cores.
 * World element: orbits a point, pulses energy, sparingly engages.
 */
public class ReactorKeeperEntity extends class_1588 {
	private UUID macroId;
	private class_243 anchor = class_243.field_1353;
	private float orbitAngle;

	public ReactorKeeperEntity(class_1299<? extends ReactorKeeperEntity> type, class_1937 world) {
		super(type, world);
		this.method_5875(true);
		this.method_5971();
	}

	public static class_5132.class_5133 createAttributes() {
		return class_1588.method_26918()
				.method_26868(class_5134.field_23716, 1500)
				.method_26868(class_5134.field_23719, 0.2)
				.method_26868(class_5134.field_23717, 96)
				.method_26868(class_5134.field_23721, 18)
				.method_26868(class_5134.field_23718, 1.0)
				.method_26868(class_5134.field_23720, 0.25);
	}

	/** Pin orbit center (lunar / End micro-reactor arenas). */
	public void setAnchor(class_243 a) {
		this.anchor = a;
	}

	@Override
	protected void method_5959() {}

	@Override
	public void method_5773() {
		super.method_5773();
		method_5875(true);
		if (method_37908().field_9236) return;

		if (anchor == class_243.field_1353) anchor = method_19538();
		orbitAngle += 0.01f;
		double r = 12;
		class_243 target = anchor.method_1031(Math.cos(orbitAngle) * r, Math.sin(orbitAngle * 0.5) * 4, Math.sin(orbitAngle) * r);
		class_243 delta = target.method_1020(method_19538()).method_1021(0.05);
		method_18799(delta);
		field_6037 = true;

		class_243 look = anchor.method_1020(method_19538());
		if (look.method_1027() > 1.0e-4) {
			float yaw = (float) (class_3532.method_15349(-look.field_1352, look.field_1350) * (180.0 / Math.PI));
			float pitch = (float) (class_3532.method_15349(-look.field_1351, Math.sqrt(look.field_1352 * look.field_1352 + look.field_1350 * look.field_1350)) * (180.0 / Math.PI));
			method_36456(yaw);
			method_36457(pitch);
		}

		if (field_6012 % 40 == 0 && method_37908() instanceof class_3218 sw) {
			sw.method_14199(class_2398.field_11207, method_23317(), method_23318() + 2, method_23321(), 12, 1.5, 1.5, 1.5, 0.02);
		}

		if (macroId == null) {
			macroId = UUID.randomUUID();
		}
		MacroWorld.put(new MacroEntry(macroId, MacroEntry.Kind.KEEPER, WorldRules.Layer.DEPTH_REACTORS,
				method_24515(), 20, 24, 20, 0x44DDFF, "Reactor Keeper"));

		class_1657 near = method_37908().method_18460(this, 32);
		if (near != null && method_5858(near) < 20 * 20) {
			method_5980(near);
			if (field_6012 % 25 == 0 && method_37908() instanceof class_3218 sw) {
				near.method_5643(sw.method_48963().method_48812(this), 10f);
				sw.method_14199(class_2398.field_29644,
						near.method_23317(), near.method_23318() + 1, near.method_23321(), 8, 0.4, 0.4, 0.4, 0.05);
			}
		}
	}

	@Override
	public void method_5650(class_5529 reason) {
		if (macroId != null) MacroWorld.remove(macroId);
		super.method_5650(reason);
	}

	@Override
	public void method_5652(class_2487 nbt) {
		super.method_5652(nbt);
		nbt.method_10549("ax", anchor.field_1352);
		nbt.method_10549("ay", anchor.field_1351);
		nbt.method_10549("az", anchor.field_1350);
		if (macroId != null) nbt.method_25927("macro", macroId);
	}

	@Override
	public void method_5749(class_2487 nbt) {
		super.method_5749(nbt);
		anchor = new class_243(nbt.method_10574("ax"), nbt.method_10574("ay"), nbt.method_10574("az"));
		if (nbt.method_25928("macro")) macroId = nbt.method_25926("macro");
	}

	@Override
	public boolean method_5753() {
		return true;
	}
}
