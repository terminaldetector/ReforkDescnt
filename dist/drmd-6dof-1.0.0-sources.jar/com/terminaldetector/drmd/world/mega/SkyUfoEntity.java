package com.terminaldetector.drmd.world.mega;

import com.terminaldetector.drmd.ai.AiRole;
import com.terminaldetector.drmd.entity.DroneEntity;
import com.terminaldetector.drmd.entity.ModEntities;
import com.terminaldetector.drmd.world.WorldRules;
import com.terminaldetector.drmd.world.fire.FireSystem;
import com.terminaldetector.drmd.world.gen2.MacroEntry;
import com.terminaldetector.drmd.world.gen2.MacroWorld;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2680;
import net.minecraft.class_2902;
import net.minecraft.class_2945;
import net.minecraft.class_3218;
import net.minecraft.class_3532;

/**
 * XCOM-style airborne UFO — cruising sky structure (LLOD), burns surface
 * builds underneath, continually drops swarm drones.
 */
public class SkyUfoEntity extends class_1297 {
	public static final int SWARM_CAP = 12;

	private final List<UUID> swarm = new ArrayList<>();
	private UUID macroId;
	private float cruiseYaw;
	private int burnCd;
	private int spawnCd;

	public SkyUfoEntity(class_1299<? extends SkyUfoEntity> type, class_1937 world) {
		super(type, world);
		this.field_5960 = true;
		this.method_5875(true);
	}

	@Override
	protected void method_5693(class_2945.class_9222 builder) {}

	@Override
	public void method_5773() {
		super.method_5773();
		if (method_37908().field_9236) return;

		cruiseYaw += 0.35f;
		double rad = Math.toRadians(cruiseYaw);
		class_243 vel = new class_243(-Math.sin(rad) * 0.35, Math.sin(field_6012 * 0.02) * 0.04, Math.cos(rad) * 0.35);
		method_18799(vel);
		field_6037 = true;
		method_33574(method_19538().method_1019(vel));
		method_36456(cruiseYaw);

		// Hold practical sky band
		double y = class_3532.method_15350(method_23318(), WorldRules.SKY_PRACTICAL_MIN + 10.0, WorldRules.SKY_PRACTICAL_MAX - 8.0);
		if (Math.abs(y - method_23318()) > 0.5) method_5814(method_23317(), y, method_23321());

		if (macroId == null) macroId = UUID.randomUUID();
		MacroWorld.put(new MacroEntry(macroId, MacroEntry.Kind.UFO, WorldRules.Layer.SKY_ARCHIPELAGO,
				method_24515(), 36, 10, 36, 0x55FFAA, "Sky UFO"));

		if (method_37908() instanceof class_3218 sw) {
			if (burnCd > 0) burnCd--;
			else {
				burnGround(sw);
				burnCd = 35 + field_5974.method_43048(25);
			}
			if (spawnCd > 0) spawnCd--;
			else {
				pruneSwarm(sw);
				if (swarm.size() < SWARM_CAP) {
					dropDrone(sw);
					spawnCd = 18;
				} else {
					spawnCd = 40;
				}
			}
			if (field_6012 % 12 == 0) {
				sw.method_14199(class_2398.field_11207, method_23317(), method_23318() - 1.5, method_23321(), 6, 1.5, 0.3, 1.5, 0.01);
				sw.method_14199(class_2398.field_11240, method_23317(), method_23318() - 2.0, method_23321(), 4, 0.8, 0.4, 0.8, 0.02);
			}
		}
	}

	private void burnGround(class_3218 world) {
		int sx = method_31477();
		int sz = method_31479();
		int top = world.method_8624(class_2902.class_2903.field_13197, sx, sz);
		class_2338 focus = new class_2338(sx, top, sz);
		FireSystem.igniteBlast(world, focus, 10, 8);
		// Scorch / soft-break player-scale builds under the beam
		for (int dx = -6; dx <= 6; dx++) {
			for (int dz = -6; dz <= 6; dz++) {
				if (dx * dx + dz * dz > 36) continue;
				if (field_5974.method_43048(3) != 0) continue;
				int ty = world.method_8624(class_2902.class_2903.field_13197, sx + dx, sz + dz);
				class_2338 p = new class_2338(sx + dx, ty - 1, sz + dz);
				class_2680 st = world.method_8320(p);
				if (st.method_26215() || st.method_26214(world, p) < 0) continue;
				float hard = st.method_26214(world, p);
				if (hard >= 0 && hard <= 3.5f && !st.method_27852(class_2246.field_9987) && !st.method_27852(class_2246.field_23261)) {
					if (field_5974.method_43056()) {
						world.method_8652(p, class_2246.field_10036.method_9564(), class_2248.field_31036);
					} else if (hard <= 2.0f) {
						world.method_8652(p, class_2246.field_10124.method_9564(), class_2248.field_31036);
						FireSystem.ignite(world, p, 2);
					}
				}
			}
		}
	}

	private void pruneSwarm(class_3218 world) {
		swarm.removeIf(id -> {
			class_1297 e = world.method_14190(id);
			return e == null || !e.method_5805();
		});
	}

	private void dropDrone(class_3218 world) {
		DroneEntity drone = ModEntities.DRONE.method_5883(world);
		if (drone == null) return;
		class_243 off = new class_243((field_5974.method_43058() - 0.5) * 10, -2 - field_5974.method_43058() * 4, (field_5974.method_43058() - 0.5) * 10);
		class_243 p = method_19538().method_1019(off);
		drone.method_5808(p.field_1352, p.field_1351, p.field_1350, field_5974.method_43057() * 360, 0);
		AiRole[] roles = {AiRole.ASSAULT, AiRole.INTERCEPTOR, AiRole.LASER, AiRole.MG, AiRole.SEEKER};
		drone.applyRole(roles[field_5974.method_43048(roles.length)]);
		world.method_8649(drone);
		swarm.add(drone.method_5667());
	}

	@Override
	public void method_5650(class_5529 reason) {
		if (macroId != null) MacroWorld.remove(macroId);
		super.method_5650(reason);
	}

	@Override
	protected void method_5749(class_2487 nbt) {
		if (nbt.method_25928("macro")) macroId = nbt.method_25926("macro");
		cruiseYaw = nbt.method_10583("cruise");
	}

	@Override
	protected void method_5652(class_2487 nbt) {
		if (macroId != null) nbt.method_25927("macro", macroId);
		nbt.method_10548("cruise", cruiseYaw);
	}

	@Override
	public boolean method_30948() {
		return false;
	}
}
