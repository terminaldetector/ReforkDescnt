package com.terminaldetector.drmd.world.mega;

import com.terminaldetector.drmd.ai.AiRole;
import com.terminaldetector.drmd.entity.DroneEntity;
import com.terminaldetector.drmd.entity.ModEntities;
import com.terminaldetector.drmd.entity.ModWorldBlocks;
import com.terminaldetector.drmd.weapon.core.DamageClass;
import com.terminaldetector.drmd.weapon.fx.WeaponFx;
import com.terminaldetector.drmd.world.WorldRules;
import com.terminaldetector.drmd.world.fire.FireSystem;
import com.terminaldetector.drmd.world.gen2.MacroEntry;
import com.terminaldetector.drmd.world.gen2.MacroWorld;
import com.terminaldetector.drmd.world.smoke.SmokeSystem;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_2902;
import net.minecraft.class_2940;
import net.minecraft.class_2943;
import net.minecraft.class_2945;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3532;

/**
 * XCOM-style airborne UFO — real enterable flying hull (not LLOD-only).
 * Cruise while carrying interior entities; destroy by reactor dump / bomb / core break.
 */
public class SkyUfoEntity extends class_1297 {
	public static final int SWARM_CAP = 12;
	public static final int MOVE_INTERVAL = 18;

	private static final class_2940<Boolean> MATERIALIZED =
			class_2945.method_12791(SkyUfoEntity.class, class_2943.field_13323);

	/** Active UFOs for bomb/reactor/core lookups. */
	private static final Map<UUID, SkyUfoEntity> ACTIVE = new ConcurrentHashMap<>();
	private static final Map<Long, UUID> CORE_INDEX = new ConcurrentHashMap<>();

	private final List<UUID> swarm = new ArrayList<>();
	private UUID macroId;
	private float cruiseYaw;
	private int burnCd;
	private int spawnCd;
	private int moveCd;
	private boolean hullReady;
	private boolean destroyed;
	private class_2338 hullCenter = class_2338.field_10980;
	private class_2338 corePos = class_2338.field_10980;
	private final Set<class_2338> hullBlocks = new HashSet<>();
	private class_238 interior = new class_238(0, 0, 0, 0, 0, 0);

	public SkyUfoEntity(class_1299<? extends SkyUfoEntity> type, class_1937 world) {
		super(type, world);
		this.field_5960 = true;
		this.method_5875(true);
	}

	@Override
	protected void method_5693(class_2945.class_9222 builder) {
		builder.method_56912(MATERIALIZED, false);
	}

	public boolean isMaterialized() {
		return field_6011.method_12789(MATERIALIZED);
	}

	public class_238 getInterior() {
		return interior;
	}

	public class_2338 getCorePos() {
		return corePos;
	}

	public boolean containsPos(class_243 pos) {
		return hullReady && interior.method_1006(pos);
	}

	@Override
	public void method_5773() {
		super.method_5773();
		if (method_37908().field_9236 || destroyed) return;
		if (!(method_37908() instanceof class_3218 sw)) return;

		ACTIVE.put(method_5667(), this);

		if (!hullReady) {
			materialize(sw, method_24515());
		}

		boolean occupied = hasOccupants(sw);
		cruiseYaw += occupied ? 0.12f : 0.35f;
		double rad = Math.toRadians(cruiseYaw);
		double speed = occupied ? 0.08 : 0.28;
		class_243 vel = new class_243(-Math.sin(rad) * speed, Math.sin(field_6012 * 0.015) * 0.02, Math.cos(rad) * speed);
		method_18799(vel);
		method_36456(cruiseYaw);

		double y = class_3532.method_15350(method_23318(), WorldRules.SKY_PRACTICAL_MIN + 14.0, WorldRules.SKY_PRACTICAL_MAX - 10.0);
		if (Math.abs(y - method_23318()) > 0.5) method_5814(method_23317(), y, method_23321());

		// Grid-crawl hull so interior stays coherent Minecraft blocks
		if (moveCd > 0) moveCd--;
		else {
			class_2338 want = class_2338.method_49637(method_23317() + vel.field_1352 * MOVE_INTERVAL,
					method_23318() + vel.field_1351 * MOVE_INTERVAL, method_23321() + vel.field_1350 * MOVE_INTERVAL);
			want = new class_2338(want.method_10263(),
					class_3532.method_15340(want.method_10264(), WorldRules.SKY_PRACTICAL_MIN + 14, WorldRules.SKY_PRACTICAL_MAX - 10),
					want.method_10260());
			if (!want.equals(hullCenter)) {
				relocateHull(sw, want);
			}
			moveCd = occupied ? MOVE_INTERVAL + 8 : MOVE_INTERVAL;
		}

		// Keep entity anchored to hull center
		method_5814(hullCenter.method_10263() + 0.5, hullCenter.method_10264() + 0.5, hullCenter.method_10260() + 0.5);

		if (macroId == null) macroId = UUID.randomUUID();
		MacroWorld.put(new MacroEntry(macroId, MacroEntry.Kind.UFO, WorldRules.Layer.SKY_ARCHIPELAGO,
				hullCenter, 28, 12, 28, 0x55FFAA, "Sky UFO"));

		// Core still present?
		if (hullReady && !sw.method_8320(corePos).method_27852(ModWorldBlocks.UNSTABLE_REACTOR)) {
			destroyFromCore(sw, null, "core ruptured");
			return;
		}

		if (burnCd > 0) burnCd--;
		else {
			burnGround(sw);
			burnCd = 40 + field_5974.method_43048(30);
		}
		if (spawnCd > 0) spawnCd--;
		else {
			pruneSwarm(sw);
			if (swarm.size() < SWARM_CAP) {
				dropDrone(sw);
				spawnCd = occupied ? 28 : 16;
			} else spawnCd = 40;
		}
		if (field_6012 % 14 == 0) {
			sw.method_14199(class_2398.field_11207, method_23317(), method_23318() - 2.0, method_23321(), 5, 1.2, 0.2, 1.2, 0.01);
			sw.method_14199(class_2398.field_11240, method_23317(), method_23318() - 2.5, method_23321(), 3, 0.6, 0.3, 0.6, 0.02);
		}
	}

	private boolean hasOccupants(class_3218 sw) {
		if (!hullReady) return false;
		return !sw.method_8390(class_1657.class, interior, class_1657::method_5805).isEmpty();
	}

	private void materialize(class_3218 sw, class_2338 at) {
		class_2338 center = at.method_10062();
		SkyUfoHull.Built built = SkyUfoHull.build(sw, center);
		hullCenter = built.center();
		corePos = built.core();
		hullBlocks.clear();
		hullBlocks.addAll(built.blocks());
		interior = built.interior();
		hullReady = true;
		field_6011.method_12778(MATERIALIZED, true);
		CORE_INDEX.put(corePos.method_10063(), method_5667());
		method_5814(hullCenter.method_10263() + 0.5, hullCenter.method_10264() + 0.5, hullCenter.method_10260() + 0.5);
		for (class_3222 p : sw.method_18456()) {
			if (method_5858(p) < 96 * 96) {
				p.method_7353(class_2561.method_43470("§aSky UFO hull online §7— fly the bay, dump reactor on the core."), false);
			}
		}
	}

	private void relocateHull(class_3218 sw, class_2338 newCenter) {
		if (!hullReady || destroyed) return;
		List<class_1297> carry = SkyUfoHull.collectInterior(sw, interior, this);
		class_243 delta = class_243.method_24954(newCenter.method_10059(hullCenter));
		CORE_INDEX.remove(corePos.method_10063());
		SkyUfoHull.clear(sw, hullBlocks);
		SkyUfoHull.Built built = SkyUfoHull.build(sw, newCenter);
		hullCenter = built.center();
		corePos = built.core();
		hullBlocks.clear();
		hullBlocks.addAll(built.blocks());
		interior = built.interior();
		CORE_INDEX.put(corePos.method_10063(), method_5667());
		SkyUfoHull.shiftEntities(carry, delta);
	}

	private void burnGround(class_3218 world) {
		int sx = hullCenter.method_10263();
		int sz = hullCenter.method_10260();
		int top = world.method_8624(class_2902.class_2903.field_13197, sx, sz);
		class_2338 focus = new class_2338(sx, top, sz);
		FireSystem.igniteBlast(world, focus, 8, 7);
		for (int dx = -5; dx <= 5; dx++) {
			for (int dz = -5; dz <= 5; dz++) {
				if (dx * dx + dz * dz > 30) continue;
				if (field_5974.method_43048(4) != 0) continue;
				int ty = world.method_8624(class_2902.class_2903.field_13197, sx + dx, sz + dz);
				class_2338 p = new class_2338(sx + dx, ty - 1, sz + dz);
				class_2680 st = world.method_8320(p);
				if (st.method_26215() || st.method_26214(world, p) < 0) continue;
				float hard = st.method_26214(world, p);
				if (hard >= 0 && hard <= 3.5f && !st.method_27852(class_2246.field_9987) && !st.method_27852(class_2246.field_23261)) {
					if (hard <= 2.0f && field_5974.method_43056()) {
						world.method_8652(p, class_2246.field_10124.method_9564(), class_2248.field_31036);
						FireSystem.ignite(world, p, 2);
					} else {
						world.method_8652(p, class_2246.field_10036.method_9564(), class_2248.field_31036);
					}
				}
			}
		}
	}

	private void pruneSwarm(class_3218 world) {
		swarm.removeIf(id -> {
			class_1297 e = world.method_14190(id);
			return e == null || !e.method_5805();
		});
	}

	private void dropDrone(class_3218 world) {
		DroneEntity drone = ModEntities.DRONE.method_5883(world);
		if (drone == null) return;
		class_243 off = new class_243((field_5974.method_43058() - 0.5) * 14, -3 - field_5974.method_43058() * 3, (field_5974.method_43058() - 0.5) * 14);
		class_243 p = method_19538().method_1019(off);
		drone.method_5808(p.field_1352, p.field_1351, p.field_1350, field_5974.method_43057() * 360, 0);
		AiRole[] roles = {AiRole.ASSAULT, AiRole.INTERCEPTOR, AiRole.LASER, AiRole.MG, AiRole.SEEKER};
		drone.applyRole(roles[field_5974.method_43048(roles.length)]);
		world.method_8649(drone);
		swarm.add(drone.method_5667());
	}

	/** Reactor dump / bomb / core break — catastrophic hull failure. */
	public void destroyFromCore(class_3218 sw, class_1657 culprit, String reason) {
		if (destroyed) return;
		destroyed = true;
		class_2338 epicenter = corePos;
		class_243 epic = class_243.method_24953(epicenter);
		if (culprit != null) {
			WeaponFx.explode(culprit, sw, epic, 180f, 9f, DamageClass.EXPLOSIVE, true);
		} else {
			sw.method_8537(this, epic.field_1352, epic.field_1351, epic.field_1350, 6.5f, true, class_1937.class_7867.field_40891);
			SmokeSystem.emitExplosion(epic, 8f);
		}
		FireSystem.igniteBlast(sw, epicenter, 16, 10);
		sw.method_60511(null, epicenter.method_10263() + 0.5, epicenter.method_10264() + 0.5, epicenter.method_10260() + 0.5,
				class_3417.field_15152, class_3419.field_15245, 2.5f, 0.55f);
		CORE_INDEX.remove(epicenter.method_10063());
		SkyUfoHull.shatter(sw, hullBlocks, epicenter);
		hullReady = false;
		field_6011.method_12778(MATERIALIZED, false);
		for (UUID id : swarm) {
			class_1297 e = sw.method_14190(id);
			if (e != null) e.method_31472();
		}
		swarm.clear();
		for (class_3222 p : sw.method_18456()) {
			p.method_7353(class_2561.method_43470("§cSky UFO destroyed §7(" + reason + ") — fly clear of the debris."), false);
		}
		if (macroId != null) MacroWorld.remove(macroId);
		ACTIVE.remove(method_5667());
		method_31472();
	}

	// —— static hooks ——

	public static SkyUfoEntity findContaining(class_3218 world, class_243 pos) {
		for (SkyUfoEntity ufo : ACTIVE.values()) {
			if (ufo.method_37908() == world && !ufo.destroyed && ufo.containsPos(pos)) return ufo;
		}
		return null;
	}

	public static SkyUfoEntity findNear(class_3218 world, class_2338 pos, double range) {
		double r2 = range * range;
		SkyUfoEntity best = null;
		double bestD = Double.MAX_VALUE;
		for (SkyUfoEntity ufo : ACTIVE.values()) {
			if (ufo.method_37908() != world || ufo.destroyed) continue;
			double d = ufo.corePos.method_10262(pos);
			if (d < r2 && d < bestD) {
				bestD = d;
				best = ufo;
			}
		}
		return best;
	}

	public static void notifyCoreBroken(class_3218 world, class_2338 pos) {
		UUID id = CORE_INDEX.remove(pos.method_10063());
		if (id == null) {
			SkyUfoEntity near = findNear(world, pos, 4);
			if (near != null) near.destroyFromCore(world, null, "reactor core destroyed");
			return;
		}
		SkyUfoEntity ufo = ACTIVE.get(id);
		if (ufo != null) ufo.destroyFromCore(world, null, "reactor core destroyed");
	}

	public static void notifyBombDetonation(class_3218 world, class_2338 pos, float power) {
		SkyUfoEntity ufo = findNear(world, pos, 6 + power);
		if (ufo != null && (ufo.containsPos(class_243.method_24953(pos)) || pos.method_19771(ufo.corePos, 7))) {
			ufo.destroyFromCore(world, null, "ordnance impact");
		}
	}

	public static boolean tryReactorDump(class_3218 world, class_1657 user) {
		SkyUfoEntity ufo = findContaining(world, user.method_19538());
		if (ufo == null) {
			ufo = findNear(world, user.method_24515(), 5);
		}
		if (ufo == null) return false;
		ufo.destroyFromCore(world, user, "reactor dump");
		return true;
	}

	@Override
	public void method_5650(class_5529 reason) {
		ACTIVE.remove(method_5667());
		CORE_INDEX.remove(corePos.method_10063());
		if (macroId != null) MacroWorld.remove(macroId);
		if (!destroyed && method_37908() instanceof class_3218 sw && hullReady) {
			SkyUfoHull.clear(sw, hullBlocks);
		}
		super.method_5650(reason);
	}

	@Override
	protected void method_5749(class_2487 nbt) {
		if (nbt.method_25928("macro")) macroId = nbt.method_25926("macro");
		cruiseYaw = nbt.method_10583("cruise");
		hullReady = false; // rebuild on next tick
	}

	@Override
	protected void method_5652(class_2487 nbt) {
		if (macroId != null) nbt.method_25927("macro", macroId);
		nbt.method_10548("cruise", cruiseYaw);
		nbt.method_10556("hull", hullReady);
	}

	@Override
	public boolean method_30948() {
		return false; // hull blocks provide collision
	}
}
