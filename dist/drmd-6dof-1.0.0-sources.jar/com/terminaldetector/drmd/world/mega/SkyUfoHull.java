package com.terminaldetector.drmd.world.mega;

import com.terminaldetector.drmd.entity.ModWorldBlocks;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import net.minecraft.class_1297;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_3218;

/**
 * Enterable flying saucer hull — hollow deck, bay door, reactor core.
 * Owned/moved by {@link SkyUfoEntity}.
 */
public final class SkyUfoHull {
	public static final int MAJOR = 11;
	public static final int MINOR = 4;

	private SkyUfoHull() {}

	public record Built(class_2338 center, class_2338 core, Set<class_2338> blocks, class_238 interior) {}

	/** Build hollow saucer at center. Returns core pos + block set for later clear/move. */
	public static Built build(class_3218 world, class_2338 center) {
		Set<class_2338> placed = new HashSet<>();
		class_2338.class_2339 m = new class_2338.class_2339();

		for (int x = -MAJOR; x <= MAJOR; x++) {
			for (int y = -MINOR; y <= MINOR + 1; y++) {
				for (int z = -MAJOR; z <= MAJOR; z++) {
					double nx = x / (double) MAJOR;
					double ny = (y + 0.2) / (double) (MINOR + 0.5);
					double nz = z / (double) MAJOR;
					double e = nx * nx + ny * ny * 1.7 + nz * nz;
					if (e > 1.02 || e < 0.52) continue;

					// Underside bay door — open shaft so Pyro can fly in from below
					boolean bay = z >= -2 && z <= 2 && x >= -2 && x <= 2 && y < -1;
					if (bay) continue;

					m.method_10103(center.method_10263() + x, center.method_10264() + y, center.method_10260() + z);
					if (!inLimit(world, m)) continue;

					boolean outer = e > 0.78;
					class_2680 state;
					if (outer) {
						state = class_2246.field_27116.method_9564();
					} else if (Math.abs(y) <= 1 && nx * nx + nz * nz < 0.55) {
						// Interior air (deck cavity)
						continue;
					} else if (y == -1 && nx * nx + nz * nz < 0.7) {
						state = class_2246.field_10297.method_9564(); // deck
					} else if ((x + z) % 7 == 0 && outer) {
						state = class_2246.field_10248.method_9564();
					} else {
						state = class_2246.field_10006.method_9564();
					}
					world.method_8652(m, state, class_2248.field_31028);
					placed.add(m.method_10062());
				}
			}
		}

		// Clear interior volume for flight
		for (int x = -7; x <= 7; x++) {
			for (int z = -7; z <= 7; z++) {
				if (x * x + z * z > 55) continue;
				for (int y = 0; y <= 2; y++) {
					m.method_10103(center.method_10263() + x, center.method_10264() + y, center.method_10260() + z);
					if (!inLimit(world, m)) continue;
					class_2680 cur = world.method_8320(m);
					if (cur.method_27852(class_2246.field_27116) || cur.method_27852(class_2246.field_10006)
							|| cur.method_27852(class_2246.field_10248)) {
						world.method_8652(m, class_2246.field_10124.method_9564(), class_2248.field_31028);
						placed.remove(m.method_10062());
					}
				}
				// Deck plate
				m.method_10103(center.method_10263() + x, center.method_10264() - 1, center.method_10260() + z);
				if (inLimit(world, m) && world.method_8320(m).method_26215()) {
					world.method_8652(m, class_2246.field_10297.method_9564(), class_2248.field_31028);
					placed.add(m.method_10062());
				}
			}
		}

		// Side bay door (open toward -Z)
		for (int x = -2; x <= 2; x++) {
			for (int y = 0; y <= 2; y++) {
				for (int z = -MAJOR; z <= -MAJOR + 2; z++) {
					m.method_10103(center.method_10263() + x, center.method_10264() + y, center.method_10260() + z);
					if (!inLimit(world, m)) continue;
					world.method_8652(m, class_2246.field_10124.method_9564(), class_2248.field_31028);
					placed.remove(m.method_10062());
				}
			}
		}

		// Reactor core pedestal
		class_2338 core = center.method_10086(1);
		world.method_8652(center, class_2246.field_10540.method_9564(), class_2248.field_31036);
		placed.add(center.method_10062());
		world.method_8652(core, ModWorldBlocks.UNSTABLE_REACTOR.method_9564(), class_2248.field_31036);
		placed.add(core.method_10062());
		world.method_8652(center.method_10086(2), class_2246.field_10174.method_9564(), class_2248.field_31036);
		placed.add(center.method_10086(2).method_10062());

		// Ring lights
		for (int a = 0; a < 360; a += 45) {
			double rad = Math.toRadians(a);
			class_2338 p = center.method_10069((int) (Math.cos(rad) * 8), 2, (int) (Math.sin(rad) * 8));
			if (inLimit(world, p)) {
				world.method_8652(p, class_2246.field_10174.method_9564(), class_2248.field_31028);
				placed.add(p.method_10062());
			}
		}

		class_238 interior = new class_238(
				center.method_10263() - 8.5, center.method_10264() - 1.5, center.method_10260() - 8.5,
				center.method_10263() + 8.5, center.method_10264() + 3.5, center.method_10260() + 8.5);
		return new Built(center.method_10062(), core.method_10062(), placed, interior);
	}

	public static void clear(class_3218 world, Set<class_2338> blocks) {
		if (blocks == null) return;
		for (class_2338 p : blocks) {
			class_2680 st = world.method_8320(p);
			if (isHullMaterial(st) || st.method_27852(ModWorldBlocks.UNSTABLE_REACTOR)
					|| st.method_27852(class_2246.field_10540) || st.method_27852(class_2246.field_10174)
					|| st.method_27852(class_2246.field_10297)) {
				world.method_8652(p, class_2246.field_10124.method_9564(), class_2248.field_31028);
			}
		}
		blocks.clear();
	}

	/** Shatter hull with leftover debris / fire. */
	public static void shatter(class_3218 world, Set<class_2338> blocks, class_2338 epicenter) {
		if (blocks == null) return;
		List<class_2338> copy = new ArrayList<>(blocks);
		for (class_2338 p : copy) {
			double d = p.method_10262(epicenter);
			class_2680 st = world.method_8320(p);
			if (!isHullMaterial(st) && !st.method_27852(ModWorldBlocks.UNSTABLE_REACTOR)
					&& !st.method_27852(class_2246.field_10540) && !st.method_27852(class_2246.field_10174)
					&& !st.method_27852(class_2246.field_10297)) continue;
			if (d < 36 || world.method_8409().method_43048(3) != 0) {
				world.method_8652(p, class_2246.field_10124.method_9564(), class_2248.field_31036);
				if (world.method_8409().method_43048(5) == 0) {
					com.terminaldetector.drmd.world.fire.FireSystem.ignite(world, p, 2);
				}
			} else if (st.method_27852(class_2246.field_27116)) {
				world.method_8652(p, class_2246.field_27119.method_9564(), class_2248.field_31028);
			}
		}
		blocks.clear();
	}

	public static List<class_1297> collectInterior(class_3218 world, class_238 interior, class_1297 exclude) {
		return world.method_8333(exclude, interior, e -> e.method_5805() && !(e instanceof SkyUfoEntity));
	}

	public static void shiftEntities(List<class_1297> entities, class_243 delta) {
		for (class_1297 e : entities) {
			e.method_33574(e.method_19538().method_1019(delta));
			e.field_6037 = true;
		}
	}

	public static boolean contains(class_238 interior, class_243 pos) {
		return interior.method_1006(pos);
	}

	private static boolean isHullMaterial(class_2680 st) {
		return st.method_27852(class_2246.field_27116)
				|| st.method_27852(class_2246.field_10006)
				|| st.method_27852(class_2246.field_10248)
				|| st.method_27852(class_2246.field_27119)
				|| st.method_27852(class_2246.field_10297);
	}

	private static boolean inLimit(class_3218 world, class_2338 pos) {
		int y = pos.method_10264();
		return y >= world.method_31607() && y < world.method_31607() + world.method_31605();
	}
}
