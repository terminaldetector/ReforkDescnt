package com.terminaldetector.drmd.world.mega;

import com.terminaldetector.drmd.entity.DroneEntity;
import com.terminaldetector.drmd.entity.ModEntities;
import com.terminaldetector.drmd.ai.AiRole;
import com.terminaldetector.drmd.world.WorldRules;
import com.terminaldetector.drmd.world.gen2.MacroEntry;
import com.terminaldetector.drmd.world.gen2.MacroWorld;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1937;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2945;
import net.minecraft.class_3218;

/**
 * Colossal drone swarm — a world element, not a single boss.
 * Anchor entity that maintains a cloud of assault drones and a macro silhouette.
 */
public class DroneSwarmEntity extends class_1297 {
	public static final int SWARM_SIZE = 18;
	private final List<UUID> members = new ArrayList<>();
	private UUID macroId;
	private int spawnCooldown;

	public DroneSwarmEntity(class_1299<? extends DroneSwarmEntity> type, class_1937 world) {
		super(type, world);
		this.field_5960 = true;
	}

	@Override
	protected void method_5693(class_2945.class_9222 builder) {}

	@Override
	public void method_5773() {
		super.method_5773();
		if (method_37908().field_9236) return;

		// Slow drift of swarm center
		method_18799(method_18798().method_1021(0.95).method_1031(
				(field_5974.method_43058() - 0.5) * 0.02,
				(field_5974.method_43058() - 0.5) * 0.01,
				(field_5974.method_43058() - 0.5) * 0.02));
		field_6037 = true;
		method_33574(method_19538().method_1019(method_18798()));

		if (macroId == null) {
			macroId = UUID.randomUUID();
			MacroWorld.put(new MacroEntry(macroId, MacroEntry.Kind.SWARM, WorldRules.Layer.SKY_ARCHIPELAGO,
					method_24515(), 48, 24, 48, 0xCC3333, "Drone Swarm"));
		} else {
			MacroWorld.put(new MacroEntry(macroId, MacroEntry.Kind.SWARM, WorldRules.Layer.SKY_ARCHIPELAGO,
					method_24515(), 48, 24, 48, 0xCC3333, "Drone Swarm"));
		}

		if (spawnCooldown > 0) {
			spawnCooldown--;
			return;
		}
		pruneMembers();
		if (members.size() < SWARM_SIZE && method_37908() instanceof class_3218 sw) {
			spawnOne(sw);
			spawnCooldown = 20;
		}
	}

	private void pruneMembers() {
		if (!(method_37908() instanceof class_3218 sw)) return;
		members.removeIf(id -> {
			class_1297 e = sw.method_14190(id);
			return e == null || !e.method_5805();
		});
	}

	private void spawnOne(class_3218 sw) {
		DroneEntity drone = ModEntities.DRONE.method_5883(sw);
		if (drone == null) return;
		class_243 off = new class_243(
				(field_5974.method_43058() - 0.5) * 30,
				(field_5974.method_43058() - 0.5) * 16,
				(field_5974.method_43058() - 0.5) * 30);
		class_243 p = method_19538().method_1019(off);
		drone.method_5808(p.field_1352, p.field_1351, p.field_1350, field_5974.method_43057() * 360, 0);
		AiRole[] roles = {AiRole.ASSAULT, AiRole.INTERCEPTOR, AiRole.MG, AiRole.LASER};
		drone.applyRole(roles[field_5974.method_43048(roles.length)]);
		sw.method_8649(drone);
		members.add(drone.method_5667());
	}

	@Override
	public void method_5650(class_5529 reason) {
		if (macroId != null) MacroWorld.remove(macroId);
		super.method_5650(reason);
	}

	@Override
	protected void method_5749(class_2487 nbt) {
		if (nbt.method_25928("macro")) macroId = nbt.method_25926("macro");
	}

	@Override
	protected void method_5652(class_2487 nbt) {
		if (macroId != null) nbt.method_25927("macro", macroId);
	}

	@Override
	public boolean method_30948() {
		return false;
	}
}
