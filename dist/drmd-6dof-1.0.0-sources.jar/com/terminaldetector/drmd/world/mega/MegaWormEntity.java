package com.terminaldetector.drmd.world.mega;

import com.terminaldetector.drmd.world.WorldRules;
import com.terminaldetector.drmd.world.gen2.MacroEntry;
import com.terminaldetector.drmd.world.gen2.MacroWorld;
import java.util.UUID;
import net.minecraft.class_1299;
import net.minecraft.class_1588;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_5132;
import net.minecraft.class_5134;

/**
 * Mega Creature — sky worm. Not a boss: a landscape element.
 * Placeholder length ~80 blocks (prototype); design target 1000+.
 * Players can fly along its body for minutes exploring the surface.
 */
public class MegaWormEntity extends class_1588 {
	public static final int SEGMENTS = 24;
	public static final float SEGMENT_SPACING = 3.2f;

	private UUID macroId;
	private float phase;

	public MegaWormEntity(class_1299<? extends MegaWormEntity> type, class_1937 world) {
		super(type, world);
		this.method_5875(true);
		this.method_5971();
	}

	public static class_5132.class_5133 createAttributes() {
		return class_1588.method_26918()
				.method_26868(class_5134.field_23716, 2000)
				.method_26868(class_5134.field_23719, 0.35)
				.method_26868(class_5134.field_23717, 256)
				.method_26868(class_5134.field_23721, 12)
				.method_26868(class_5134.field_23718, 1.0)
				.method_26868(class_5134.field_23720, 0.4);
	}

	@Override
	protected void method_5959() {}

	@Override
	public void method_5773() {
		super.method_5773();
		method_5875(true);
		if (method_37908().field_9236) {
			phase += 0.02f;
			return;
		}
		phase += 0.02f;
		// Slow serpentine cruise
		double yaw = Math.toRadians(method_36454());
		double pitch = Math.sin(phase) * 0.25;
		class_243 dir = new class_243(-Math.sin(yaw) * Math.cos(pitch), pitch, Math.cos(yaw) * Math.cos(pitch));
		method_18799(dir.method_1021(0.25));
		method_36456(method_36454() + (float) Math.sin(phase * 0.5) * 0.4f);
		field_6037 = true;

		if (macroId == null) {
			registerMacro();
		} else {
			MacroEntry old = MacroWorld.get(macroId);
			if (old != null) {
				MacroWorld.put(new MacroEntry(macroId, MacroEntry.Kind.WORM, WorldRules.Layer.SKY_ARCHIPELAGO,
						method_24515(), (int) (SEGMENTS * SEGMENT_SPACING), 8, 12, 0xAA6644, "Sky Worm"));
			}
		}

		// Mild aggro if player is very close to head
		class_1657 p = method_37908().method_18460(this, 12);
		if (p != null) method_5980(p);
	}

	private void registerMacro() {
		macroId = UUID.randomUUID();
		MacroWorld.put(new MacroEntry(macroId, MacroEntry.Kind.WORM, WorldRules.Layer.SKY_ARCHIPELAGO,
				method_24515(), (int) (SEGMENTS * SEGMENT_SPACING), 8, 12, 0xAA6644, "Sky Worm"));
	}

	/** World positions of body segments for rendering / collision feel. */
	public class_243 segmentPos(int index, float tickDelta) {
		float t = phase + index * 0.35f;
		double yaw = Math.toRadians(method_36454());
		class_243 back = new class_243(Math.sin(yaw), 0, -Math.cos(yaw)).method_1021(index * SEGMENT_SPACING);
		class_243 wave = new class_243(-Math.cos(yaw), 0, -Math.sin(yaw)).method_1021(Math.sin(t) * 2.5);
		class_243 vert = new class_243(0, Math.sin(t * 0.7) * 1.5, 0);
		return method_30950(tickDelta).method_1019(back).method_1019(wave).method_1019(vert);
	}

	@Override
	public void method_5650(class_5529 reason) {
		if (macroId != null) MacroWorld.remove(macroId);
		super.method_5650(reason);
	}

	@Override
	public void method_5652(class_2487 nbt) {
		super.method_5652(nbt);
		nbt.method_10548("phase", phase);
		if (macroId != null) nbt.method_25927("macro", macroId);
	}

	@Override
	public void method_5749(class_2487 nbt) {
		super.method_5749(nbt);
		phase = nbt.method_10583("phase");
		if (nbt.method_25928("macro")) macroId = nbt.method_25926("macro");
	}

	@Override
	public boolean method_5753() {
		return true;
	}
}
