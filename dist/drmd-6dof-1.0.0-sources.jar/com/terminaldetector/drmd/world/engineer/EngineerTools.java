package com.terminaldetector.drmd.world.engineer;

import com.terminaldetector.drmd.weapon.fx.WeaponFx;
import com.terminaldetector.drmd.world.LocalOrientation;
import com.terminaldetector.drmd.world.build.AdaptivePlacement;
import com.terminaldetector.drmd.world.build.ConstructionMode;
import com.terminaldetector.drmd.world.gravity.GravityFields;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1271;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1838;
import net.minecraft.class_1839;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_239;
import net.minecraft.class_2390;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import org.joml.Vector3f;

/**
 * Specialized engineer tools replacing pickaxe workflow in 6DoF volume.
 * Mining laser = continuous drill / melt installation (hold use).
 */
public final class EngineerTools {
	private EngineerTools() {}

	public static class ConstructionLaserItem extends class_1792 {
		public ConstructionLaserItem(class_1793 settings) { super(settings.method_7889(1)); }

		@Override
		public class_1271<class_1799> method_7836(class_1937 world, class_1657 user, class_1268 hand) {
			class_1799 stack = user.method_5998(hand);
			if (world.field_9236) return class_1271.method_22427(stack);
			if (user instanceof class_3222 sp && !ConstructionMode.isActive(sp.method_5667())) {
				ConstructionMode.set(sp, true);
			}
			class_2338 placed = AdaptivePlacement.placeAlongLook(world, user, user.method_5715() ? 32 : 12);
			if (placed != null) {
				beam(world, user, placed.method_46558(), new Vector3f(0.3f, 0.9f, 1f));
				world.method_8396(null, placed, class_3417.field_15167, class_3419.field_15245, 0.6f, 1.3f);
			}
			return class_1271.method_22427(stack);
		}
	}

	public static class RepairLaserItem extends class_1792 {
		public RepairLaserItem(class_1793 settings) { super(settings.method_7889(1)); }

		@Override
		public class_1271<class_1799> method_7836(class_1937 world, class_1657 user, class_1268 hand) {
			class_1799 stack = user.method_5998(hand);
			if (world.field_9236) return class_1271.method_22427(stack);
			class_3965 hit = ray(world, user, 16);
			if (hit.method_17783() == class_239.class_240.field_1332) {
				class_2338 pos = hit.method_17777();
				class_2680 st = world.method_8320(pos);
				if (st.method_27852(class_2246.field_10416) || st.method_27852(class_2246.field_29222)
						|| st.method_27852(class_2246.field_23867)) {
					world.method_8652(pos, class_2246.field_10056.method_9564(), class_2248.field_31036);
				} else if (st.method_26214(world, pos) >= 0) {
					world.method_8652(pos, st, class_2248.field_31036);
				}
				for (class_1309 e : world.method_8390(class_1309.class,
						new net.minecraft.class_238(pos).method_1014(3), class_1309::method_5805)) {
					e.method_6025(4f);
				}
				if (user instanceof class_3222 sp) {
					DescentShieldBoost(sp);
				}
				beam(world, user, pos.method_46558(), new Vector3f(0.3f, 1f, 0.4f));
				world.method_8396(null, pos, class_3417.field_14559, class_3419.field_15245, 0.35f, 1.6f);
				user.method_7353(class_2561.method_43470("§aRepair laser — structure refreshed"), true);
			}
			return class_1271.method_22427(stack);
		}

		private static void DescentShieldBoost(class_3222 sp) {
			var data = com.terminaldetector.drmd.DescentPlayerData.get(sp);
			data.setShield(Math.min(data.getShieldMax(), data.getShield() + 8f));
		}
	}

	/**
	 * Drill laser installation — hold RMB to continuously melt / carve along look.
	 * Reuses mining_laser texture + WeaponFx melt/drill.
	 */
	public static class MiningLaserItem extends class_1792 {
		public MiningLaserItem(class_1793 settings) { super(settings.method_7889(1)); }

		@Override
		public class_1271<class_1799> method_7836(class_1937 world, class_1657 user, class_1268 hand) {
			user.method_6019(hand);
			return class_1271.method_22428(user.method_5998(hand));
		}

		@Override
		public class_1839 method_7853(class_1799 stack) {
			return class_1839.field_8953;
		}

		@Override
		public int method_7881(class_1799 stack, class_1309 user) {
			return 72000;
		}

		@Override
		public void method_7852(class_1937 world, class_1309 user, class_1799 stack, int remainingUseTicks) {
			if (world.field_9236 || !(user instanceof class_1657 player)) return;
			if (remainingUseTicks % 2 != 0) return;
			if (!(world instanceof class_3218 sw)) return;

			class_3965 hit = ray(world, player, player.method_5715() ? 32 : 18);
			class_243 eye = player.method_33571();
			if (hit.method_17783() != class_239.class_240.field_1332) {
				class_243 end = eye.method_1019(player.method_5828(1f).method_1021(player.method_5715() ? 32 : 18));
				WeaponFx.beamDrill(sw, eye, end);
				return;
			}
			class_2338 pos = hit.method_17777();
			WeaponFx.beamDrill(sw, eye, hit.method_17784());
			int intensity = player.method_5715() ? 3 : 2;
			boolean carved = WeaponFx.melt(sw, pos, intensity, player);
			if (!carved) {
				class_2680 st = world.method_8320(pos);
				if (!st.method_26215() && st.method_26214(world, pos) >= 0 && st.method_26214(world, pos) < 50) {
					sw.method_8651(pos, true, player);
				}
			}
			// Widen tunnel slightly every few ticks while sneaking
			if (player.method_5715() && remainingUseTicks % 6 == 0) {
				WeaponFx.drillCarve(sw, pos, player);
			}
			world.method_8396(null, pos, class_3417.field_19344, class_3419.field_15245,
					0.25f, 1.6f + world.method_8409().method_43057() * 0.4f);
		}

		@Override
		public class_1269 method_7884(class_1838 context) {
			class_1657 user = context.method_8036();
			if (user != null) {
				user.method_6019(context.method_20287());
				return class_1269.field_21466;
			}
			return class_1269.field_5811;
		}
	}

	public static class GravityScannerItem extends class_1792 {
		public GravityScannerItem(class_1793 settings) { super(settings.method_7889(1)); }

		@Override
		public class_1271<class_1799> method_7836(class_1937 world, class_1657 user, class_1268 hand) {
			class_1799 stack = user.method_5998(hand);
			if (world.field_9236) return class_1271.method_22427(stack);
			class_243 up = LocalOrientation.getUp(user.method_5667());
			class_243 down = LocalOrientation.gravityDir(user.method_5667());
			GravityFields.Sample sample = GravityFields.sample(world, user.method_19538());
			String field = sample == null ? "none" : sample.label() + " p=" + String.format("%.2f", sample.maxPower());
			user.method_7353(class_2561.method_43470(String.format(
					"§aGravity Scanner §7UP=(%.2f,%.2f,%.2f) DOWN=(%.2f,%.2f,%.2f) field=%s",
					up.field_1352, up.field_1351, up.field_1350, down.field_1352, down.field_1351, down.field_1350, field)), false);
			if (world instanceof class_3218 sw) {
				class_243 eye = user.method_33571();
				for (int i = 1; i <= 12; i++) {
					class_243 p = eye.method_1019(down.method_1021(i * 0.5));
					sw.method_14199(new class_2390(new Vector3f(0.2f, 1f, 0.5f), 1.2f),
							p.field_1352, p.field_1351, p.field_1350, 1, 0, 0, 0, 0);
				}
				for (GravityFields.Field f : GravityFields.all()) {
					sw.method_14199(class_2398.field_11207,
							f.origin().method_10263() + 0.5, f.origin().method_10264() + 0.5, f.origin().method_10260() + 0.5,
							8, 0.4, 0.4, 0.4, 0.02);
				}
			}
			return class_1271.method_22427(stack);
		}
	}

	private static class_3965 ray(class_1937 world, class_1657 user, double range) {
		class_243 eye = user.method_33571();
		class_243 end = eye.method_1019(user.method_5828(1f).method_1021(range));
		return world.method_17742(new class_3959(eye, end,
				class_3959.class_3960.field_17559, class_3959.class_242.field_1348, user));
	}

	private static void beam(class_1937 world, class_1657 user, class_243 target, Vector3f color) {
		if (!(world instanceof class_3218 sw)) return;
		WeaponFx.beam(sw, user.method_33571(), target, color, 0.9f);
	}
}
