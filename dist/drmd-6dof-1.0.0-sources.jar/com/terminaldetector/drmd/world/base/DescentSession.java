package com.terminaldetector.drmd.world.base;

import com.terminaldetector.drmd.DescentMod;
import com.terminaldetector.drmd.DescentPlayerData;
import com.terminaldetector.drmd.ai.AiRole;
import com.terminaldetector.drmd.entity.DroneEntity;
import com.terminaldetector.drmd.entity.ModEntities;
import com.terminaldetector.drmd.entity.PyroShipEntity;
import com.terminaldetector.drmd.weapon.items.ModItems;
import com.terminaldetector.drmd.world.DescentWorldState;
import com.terminaldetector.drmd.world.WorldRules;
import com.terminaldetector.drmd.world.gen.IndustrialComplexGenerator;
import com.terminaldetector.drmd.world.gen2.MacroEntry;
import com.terminaldetector.drmd.world.gen2.MegaStructureGenerator;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2902;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_5819;
import net.minecraft.server.MinecraftServer;

/**
 * Makes Descent a native Minecraft mode: world-spawn hub, stock megastructures,
 * auto 6DoF for every player — not an optional /d6-only session.
 */
public final class DescentSession {
	private DescentSession() {}

	/** Called once when overworld is ready — seed hub + nearby stock features. */
	public static void seedWorld(MinecraftServer server) {
		class_3218 world = server.method_30002();
		if (world == null) return;
		DescentWorldState state = DescentWorldState.get(world);
		if (state.isStockSeeded()) return;

		class_2338 spawn = world.method_43126();
		int surfaceY = world.method_8624(class_2902.class_2903.field_13203, spawn.method_10263(), spawn.method_10260());
		class_2338 hub = new class_2338(spawn.method_10263() + 24, Math.max(surfaceY + 12, 90), spawn.method_10260() + 24);

		if (!state.isSpawnHubGenerated()) {
			generateSpawnHub(world, hub);
			state.setSpawnHubGenerated(true);
			DescentMod.LOGGER.info("Descent spawn hub generated at {}", hub.method_23854());
		}

		seedStockMegastructures(world, spawn);
		seedLayerBiomes(world, spawn);
		state.setStockSeeded(true);
		DescentMod.LOGGER.info("Descent stock worldgen seeded (all practical biome layers)");
	}

	/** Soft player onboarding — 6DoF on, tip message, creative gets Pyro GX. */
	public static void onPlayerJoin(class_3222 player) {
		DescentPlayerData data = DescentPlayerData.get(player);
		data.ensureInit();
		if (!data.isEnabled()) {
			data.setEnabled(true);
		}

		boolean first = !data.isSessionWelcomed();
		if (first) {
			data.setSessionWelcomed(true);
			player.method_7353(class_2561.method_43470(
					"§bDRMD 6DOF §f— Descent session is part of this world."), false);
			player.method_7353(class_2561.method_43470(
					"§7Fly with §fH§7 · craft §fPyro GX§7 · explore industrial caves & sky megastructures"), false);
			if (player.method_7337()) {
				player.method_7270(new class_1799(ModItems.PYRO_GX));
				player.method_7353(class_2561.method_43470("§aCreative: Pyro GX given — right-click to deploy."), false);
			}
		}
	}

	private static void generateSpawnHub(class_3218 world, class_2338 center) {
		IndustrialComplexGenerator.generateAt(world, center, WorldRules.ComplexStyle.ANCIENT_POWER, world.method_8409());

		PyroShipEntity ship = ModEntities.PYRO_SHIP.method_5883(world);
		if (ship != null) {
			ship.method_5808(center.method_10263() + 0.5, center.method_10264() - 4, center.method_10260() + 8.5, 0, 0);
			world.method_8649(ship);
		}

		AiRole[] roles = {
				AiRole.ASSAULT, AiRole.INTERCEPTOR, AiRole.MG, AiRole.LASER, AiRole.RPG,
				AiRole.ARTILLERY, AiRole.SUPPORT, AiRole.HEAVY, AiRole.SEEKER, AiRole.HEAVY_ELITE
		};
		for (int i = 0; i < roles.length; i++) {
			DroneEntity drone = ModEntities.DRONE.method_5883(world);
			if (drone == null) continue;
			double ang = i * (Math.PI * 2 / roles.length);
			drone.method_5808(
					center.method_10263() + Math.cos(ang) * 18,
					center.method_10264() + (i % 3) * 2,
					center.method_10260() + Math.sin(ang) * 18,
					0, 0);
			drone.applyRole(roles[i]);
			world.method_8649(drone);
		}

		// Multi-zone gravity preview (dynamic station sections)
		world.method_8652(center.method_10069(0, -6, 0),
				com.terminaldetector.drmd.entity.ModWorldBlocks.GRAVITY_GENERATOR.method_9564()
						.method_11657(com.terminaldetector.drmd.world.gravity.GravityGeneratorBlock.FACING,
								net.minecraft.class_2350.field_11033),
				net.minecraft.class_2248.field_31036);
		world.method_8652(center.method_10069(12, -4, 0),
				com.terminaldetector.drmd.entity.ModWorldBlocks.GRAVITY_TORCH.method_9564()
						.method_11657(com.terminaldetector.drmd.world.gravity.GravityTorchBlock.FACING,
								net.minecraft.class_2350.field_11034),
				net.minecraft.class_2248.field_31036);
		world.method_8652(center.method_10069(-12, -4, 0),
				com.terminaldetector.drmd.entity.ModWorldBlocks.GRAVITY_TORCH.method_9564()
						.method_11657(com.terminaldetector.drmd.world.gravity.GravityTorchBlock.FACING,
								net.minecraft.class_2350.field_11039),
				net.minecraft.class_2248.field_31036);
	}

	private static void seedStockMegastructures(class_3218 world, class_2338 spawn) {
		class_5819 random = world.method_8409();
		MacroEntry.Kind[] kinds = {
				MacroEntry.Kind.ARCH, MacroEntry.Kind.RING, MacroEntry.Kind.FLOATING_CONTINENT,
				MacroEntry.Kind.SPIRAL_RANGE, MacroEntry.Kind.INVERTED_ISLAND,
				MacroEntry.Kind.CANYON, MacroEntry.Kind.RIFT
		};
		for (int i = 0; i < kinds.length; i++) {
			MacroEntry.Kind kind = kinds[i];
			double ang = i * (Math.PI * 2 / kinds.length);
			int dist = 160 + i * 36;
			int x = spawn.method_10263() + (int) (Math.cos(ang) * dist);
			int z = spawn.method_10260() + (int) (Math.sin(ang) * dist);
			int y = switch (kind) {
				case RIFT, CANYON -> WorldRules.INDUSTRIAL_Y_MIN + 28;
				default -> WorldRules.SKY_PRACTICAL_MIN + 20 + i * 8;
			};
			class_2338 at = new class_2338(x, y, z);
			MegaStructureGenerator.generate(world, at, kind, class_5819.method_43049(world.method_8412() ^ (i * 31L)));
		}

		// One industrial complex under spawn
		class_2338 under = new class_2338(spawn.method_10263(), WorldRules.INDUSTRIAL_Y_MIN + 30, spawn.method_10260());
		IndustrialComplexGenerator.generateAt(world, under, WorldRules.ComplexStyle.CRYSTAL_REACTOR, random);
	}

	/**
	 * Ensure every practical Descent biome layer has a seeded landmark near spawn
	 * so HUD BIOME / LAYER readouts and exploration routes are immediately playable.
	 */
	private static void seedLayerBiomes(class_3218 world, class_2338 spawn) {
		class_5819 random = world.method_8409();
		WorldRules.ComplexStyle[] styles = WorldRules.ComplexStyle.values();

		// Depth reactors — second industrial node
		class_2338 depth = new class_2338(spawn.method_10263() - 64, WorldRules.INDUSTRIAL_Y_MIN + 18, spawn.method_10260() + 48);
		IndustrialComplexGenerator.generateAt(world, depth, styles[2 % styles.length], random);

		// Surface corridor — canyon + rift pair
		MegaStructureGenerator.generate(world,
				new class_2338(spawn.method_10263() + 96, WorldRules.INDUSTRIAL_Y_MAX - 8, spawn.method_10260() - 40),
				MacroEntry.Kind.CANYON, class_5819.method_43049(world.method_8412() ^ 0xC0FFEE));
		MegaStructureGenerator.generate(world,
				new class_2338(spawn.method_10263() - 110, WorldRules.INDUSTRIAL_Y_MIN + 36, spawn.method_10260() - 90),
				MacroEntry.Kind.RIFT, class_5819.method_43049(world.method_8412() ^ 0xBEEF));

		// Sky archipelago sample
		MegaStructureGenerator.generate(world,
				new class_2338(spawn.method_10263() + 48, WorldRules.SKY_PRACTICAL_MIN + 40, spawn.method_10260() + 120),
				MacroEntry.Kind.FLOATING_CONTINENT, class_5819.method_43049(world.method_8412() ^ 0x51A10001L));

		// Orbital belt (top practical band)
		MegaStructureGenerator.generate(world,
				new class_2338(spawn.method_10263() - 80, WorldRules.SKY_PRACTICAL_MAX - 12, spawn.method_10260() + 60),
				MacroEntry.Kind.RING, class_5819.method_43049(world.method_8412() ^ 0x0B817100L));

		// Near-end space marker island
		MegaStructureGenerator.generate(world,
				new class_2338(spawn.method_10263() + 20, WorldRules.SKY_PRACTICAL_MAX - 4, spawn.method_10260() - 140),
				MacroEntry.Kind.INVERTED_ISLAND, class_5819.method_43049(world.method_8412() ^ 0xEAD10001L));
	}
}
