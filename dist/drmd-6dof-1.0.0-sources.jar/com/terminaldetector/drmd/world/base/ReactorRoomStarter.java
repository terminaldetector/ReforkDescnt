package com.terminaldetector.drmd.world.base;

import com.terminaldetector.drmd.ai.AiRole;
import com.terminaldetector.drmd.entity.DroneEntity;
import com.terminaldetector.drmd.entity.ModEntities;
import com.terminaldetector.drmd.entity.ModWorldBlocks;
import com.terminaldetector.drmd.entity.PyroShipEntity;
import com.terminaldetector.drmd.entity.ReactorDisplayEntity;
import com.terminaldetector.drmd.weapon.items.ModItems;
import com.terminaldetector.drmd.world.WorldRules;
import com.terminaldetector.drmd.world.gen.IndustrialComplexGenerator;
import net.minecraft.class_1799;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;

/**
 * Starter Descent experience: carve a reactor room, place core + docks + ship + drones,
 * give the player a starter kit. One command → playable Descent-like session.
 */
public final class ReactorRoomStarter {
	private ReactorRoomStarter() {}

	public static void activate(class_3222 player) {
		class_3218 world = player.method_51469();
		class_2338 center = player.method_24515().method_10086(8);

		// 1) Reactor chamber (volume-first)
		IndustrialComplexGenerator.generateAt(world, center, WorldRules.ComplexStyle.ANCIENT_POWER, world.method_8409());

		// 2) Clear spawn pocket + landing pad
		clearSphere(world, center.method_10069(0, -6, 0), 5);
		class_2338 pad = center.method_10069(0, -8, 0);
		for (int x = -3; x <= 3; x++) {
			for (int z = -3; z <= 3; z++) {
				world.method_8652(pad.method_10069(x, 0, z), class_2246.field_10085.method_9564(), class_2248.field_31028);
				if (Math.abs(x) == 3 || Math.abs(z) == 3) {
					world.method_8652(pad.method_10069(x, 1, z), class_2246.field_10576.method_9564(), class_2248.field_31028);
				}
			}
		}
		world.method_8652(pad.method_10084(), class_2246.field_10174.method_9564(), class_2248.field_31028);

		// 3) Reactor display entity at core
		ReactorDisplayEntity reactor = ModEntities.REACTOR_DISPLAY.method_5883(world);
		if (reactor != null) {
			reactor.method_5808(center.method_10263() + 0.5, center.method_10264() - 1, center.method_10260() + 0.5, 0, 0);
			world.method_8649(reactor);
		}

		// 4) Magnetic anomaly + unstable accents
		world.method_8652(center.method_10069(10, 0, 0), ModWorldBlocks.MAGNETIC_ANOMALY.method_9564(), class_2248.field_31036);
		world.method_8652(center.method_10069(-10, 2, 4), ModWorldBlocks.VOLUME_TURRET.method_9564(), class_2248.field_31036);
		world.method_8652(center.method_10069(0, 8, 0), ModWorldBlocks.UNSTABLE_REACTOR.method_9564(), class_2248.field_31036);
		world.method_8652(pad.method_10069(2, 1, 0), ModWorldBlocks.SIX_D_SOIL.method_9564(), class_2248.field_31036);

		// 5) Dock marker
		world.method_8652(pad.method_10069(0, 1, 3), com.terminaldetector.drmd.entity.ModBlocks.DOCK.method_9564(), class_2248.field_31036);
		world.method_8652(pad.method_10069(0, 1, -3), com.terminaldetector.drmd.entity.ModBlocks.CHECKPOINT.method_9564(), class_2248.field_31036);

		// 6) Spawn Pyro transport
		PyroShipEntity ship = ModEntities.PYRO_SHIP.method_5883(world);
		if (ship != null) {
			class_2338 shipPos = pad.method_10086(2);
			ship.method_5808(shipPos.method_10263() + 0.5, shipPos.method_10264(), shipPos.method_10260() + 0.5, player.method_36454(), 0);
			world.method_8649(ship);
		}

		// 7) Enemy drones around the chamber
		AiRole[] roles = {AiRole.ASSAULT, AiRole.INTERCEPTOR, AiRole.MG, AiRole.RPG, AiRole.LASER};
		for (int i = 0; i < roles.length; i++) {
			class_2350 dir = class_2350.method_10139(i);
			class_2338 dp = center.method_10079(dir, 14).method_10086((i % 3) - 1);
			DroneEntity drone = ModEntities.DRONE.method_5883(world);
			if (drone == null) continue;
			drone.method_5808(dp.method_10263() + 0.5, dp.method_10264(), dp.method_10260() + 0.5, 0, 0);
			drone.applyRole(roles[i]);
			drone.method_5980(player);
			world.method_8649(drone);
		}

		// 8) Teleport player to pad + enable 6DoF + kit
		player.method_5859(pad.method_10263() + 0.5, pad.method_10264() + 2, pad.method_10260() + 0.5);
		var data = com.terminaldetector.drmd.DescentPlayerData.get(player);
		data.setEnabled(true);
		data.ensureInit();
		data.setEnergy(100);
		data.setShield(100);

		giveKit(player);
		player.method_7353(class_2561.method_43470("§bDRMD §fReactor Room online. §7Board the Pyro ship (ПКМ) or fly free (H)."), false);
		player.method_7353(class_2561.method_43470("§7Weapons in inventory · M = Workshop · /6dof_spawn assault for more drones"), false);
	}

	private static void giveKit(class_3222 player) {
		player.method_7270(new class_1799(ModItems.PYRO_GX));
		player.method_7270(new class_1799(ModItems.MG));
		player.method_7270(new class_1799(ModItems.PLASMA));
		player.method_7270(new class_1799(ModItems.LASER));
		player.method_7270(new class_1799(ModItems.ROCKETS));
		player.method_7270(new class_1799(ModItems.GRAVY_RAILGUN));
		player.method_7270(new class_1799(com.terminaldetector.drmd.entity.ModWorldBlocks.BUILD_TOOL));
		player.method_7270(new class_1799(com.terminaldetector.drmd.entity.ModWorldBlocks.SIX_D_SOIL, 16));
		player.method_7270(new class_1799(class_2246.field_10085, 64));
	}

	private static void clearSphere(class_3218 world, class_2338 c, int r) {
		class_2338.class_2339 m = new class_2338.class_2339();
		int r2 = r * r;
		for (int x = -r; x <= r; x++) {
			for (int y = -r; y <= r; y++) {
				for (int z = -r; z <= r; z++) {
					if (x * x + y * y + z * z > r2) continue;
					m.method_10103(c.method_10263() + x, c.method_10264() + y, c.method_10260() + z);
					world.method_8652(m, class_2246.field_10124.method_9564(), class_2248.field_31028);
				}
			}
		}
	}
}
