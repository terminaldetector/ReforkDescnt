package com.terminaldetector.drmd.world.gen2;

import com.terminaldetector.drmd.DescentMod;
import com.terminaldetector.drmd.world.WorldRules;
import com.terminaldetector.drmd.world.mega.DroneSwarmEntity;
import com.terminaldetector.drmd.world.mega.MegaWormEntity;
import com.terminaldetector.drmd.world.mega.ReactorKeeperEntity;
import com.terminaldetector.drmd.entity.ModEntities;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerChunkEvents;
import net.minecraft.class_1923;
import net.minecraft.class_2338;
import net.minecraft.class_2818;
import net.minecraft.class_3218;
import net.minecraft.class_5819;

/**
 * World Generation 2.0 — experimental multi-scale celestial / rift generation
 * plus rare mega-creature anchors. Practical Y mapped into Overworld height.
 */
public final class ModWorldgen2 {
	private ModWorldgen2() {}

	public static void register() {
		ServerChunkEvents.CHUNK_LOAD.register(ModWorldgen2::onChunkLoad);
		DescentMod.LOGGER.info("Registered World Generation 2.0 (mega-structures + mega fauna)");
	}

	private static void onChunkLoad(class_3218 world, class_2818 chunk) {
		if (world.method_27983() != class_3218.field_25179) return;
		class_1923 cp = chunk.method_12004();
		long seed = world.method_8412() ^ (((long) cp.field_9181) * 341873128712L) ^ (((long) cp.field_9180) * 132897987541L);

		// ~1 mega-structure per 18 chunks (stock sky / rift generation)
		if (Math.floorMod(seed, 18L) == 0L) {
			MacroEntry.Kind[] kinds = {
					MacroEntry.Kind.ARCH, MacroEntry.Kind.RING, MacroEntry.Kind.FLOATING_CONTINENT,
					MacroEntry.Kind.SPIRAL_RANGE, MacroEntry.Kind.INVERTED_ISLAND,
					MacroEntry.Kind.RIFT, MacroEntry.Kind.CANYON
			};
			MacroEntry.Kind kind = kinds[(int) Math.floorMod(seed >> 3, kinds.length)];
			int y = skyY(kind, seed);
			class_2338 origin = new class_2338(cp.method_8326() + 8, y, cp.method_8328() + 8);
			// Idempotent: LODESTONE marker placed by MegaStructureGenerator
			if (!world.method_8320(origin).method_27852(net.minecraft.class_2246.field_23261)) {
				world.method_8503().execute(() -> {
					if (world.method_8320(origin).method_27852(net.minecraft.class_2246.field_23261)) return;
					class_5819 random = class_5819.method_43049(seed);
					MegaStructureGenerator.generate(world, origin, kind, random);
				});
			}
		}

		// Mega fauna anchors — stock rarity
		if (Math.floorMod(seed ^ 0x9E3779B97F4A7C15L, 40L) == 0L) {
			int roll = (int) Math.floorMod(seed >> 7, 3L);
			int y = WorldRules.SKY_PRACTICAL_MIN + 20 + (int) Math.floorMod(seed, 40L);
			class_2338 at = new class_2338(cp.method_8326() + 8, y, cp.method_8328() + 8);
			world.method_8503().execute(() -> spawnMega(world, at, roll));
		}
	}

	private static int skyY(MacroEntry.Kind kind, long seed) {
		return switch (kind) {
			case RIFT, CANYON -> WorldRules.INDUSTRIAL_Y_MIN + 30 + (int) Math.floorMod(seed, 20L);
			case ARCH, RING, FLOATING_CONTINENT, SPIRAL_RANGE, INVERTED_ISLAND ->
					WorldRules.SKY_PRACTICAL_MIN + (int) Math.floorMod(seed, 60L);
			default -> WorldRules.SKY_PRACTICAL_MIN + 40;
		};
	}

	private static void spawnMega(class_3218 world, class_2338 at, int roll) {
		switch (roll) {
			case 0 -> {
				MegaWormEntity worm = ModEntities.MEGA_WORM.method_5883(world);
				if (worm != null) {
					worm.method_5808(at.method_10263() + 0.5, at.method_10264(), at.method_10260() + 0.5, 0, 0);
					world.method_8649(worm);
				}
			}
			case 1 -> {
				DroneSwarmEntity swarm = ModEntities.DRONE_SWARM.method_5883(world);
				if (swarm != null) {
					swarm.method_5808(at.method_10263() + 0.5, at.method_10264(), at.method_10260() + 0.5, 0, 0);
					world.method_8649(swarm);
				}
			}
			default -> {
				ReactorKeeperEntity keeper = ModEntities.REACTOR_KEEPER.method_5883(world);
				if (keeper != null) {
					int ky = WorldRules.INDUSTRIAL_Y_MIN + 28;
					keeper.method_5808(at.method_10263() + 0.5, ky, at.method_10260() + 0.5, 0, 0);
					world.method_8649(keeper);
				}
			}
		}
	}

	/** Force-generate a named mega-structure at a position (commands). */
	public static MacroEntry forceGenerate(class_3218 world, class_2338 pos, MacroEntry.Kind kind) {
		return MegaStructureGenerator.generate(world, pos, kind, world.method_8409());
	}
}
