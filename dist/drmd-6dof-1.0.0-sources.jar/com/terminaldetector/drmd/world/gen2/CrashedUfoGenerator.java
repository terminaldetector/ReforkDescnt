package com.terminaldetector.drmd.world.gen2;

import com.terminaldetector.drmd.ai.AiRole;
import com.terminaldetector.drmd.entity.AirMineEntity;
import com.terminaldetector.drmd.entity.DroneEntity;
import com.terminaldetector.drmd.entity.ModEntities;
import com.terminaldetector.drmd.entity.ModWorldBlocks;
import com.terminaldetector.drmd.world.WorldRules;
import java.util.UUID;
import net.minecraft.class_1936;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2902;
import net.minecraft.class_3218;
import net.minecraft.class_5819;

/**
 * XCOM-style crashed saucer — medium hull half-buried, dense traps + garrison.
 * Tuned for post-Pyro GX assault (too hot on foot).
 */
public final class CrashedUfoGenerator {
	private CrashedUfoGenerator() {}

	private static final AiRole[] GARRISON = {
			AiRole.ASSAULT, AiRole.INTERCEPTOR, AiRole.MG, AiRole.LASER, AiRole.RPG,
			AiRole.HEAVY, AiRole.SEEKER, AiRole.HEAVY_ELITE, AiRole.ARTILLERY
	};

	public static MacroEntry generate(class_1936 world, class_2338 hint, class_5819 random) {
		class_2338 origin = resolveCrashSite(world, hint);
		if (world.method_8320(origin).method_27852(class_2246.field_23261)) {
			return new MacroEntry(UUID.randomUUID(), MacroEntry.Kind.CRASHED_UFO,
					WorldRules.Layer.SURFACE, origin.method_10062(), 40, 20, 40, 0x66AA88, "Crashed UFO");
		}

		int major = 18;
		int minor = 6;
		class_2338.class_2339 m = new class_2338.class_2339();

		// Impact crater
		for (int x = -major - 4; x <= major + 4; x++) {
			for (int z = -major - 4; z <= major + 4; z++) {
				double d = Math.sqrt(x * x + z * z);
				if (d > major + 4) continue;
				int dig = (int) Math.max(1, (major + 2 - d) * 0.45);
				for (int y = 0; y <= dig; y++) {
					m.method_10103(origin.method_10263() + x, origin.method_10264() - y, origin.method_10260() + z);
					if (inLimit(world, m)) {
						world.method_8652(m, class_2246.field_10124.method_9564(), class_2248.field_31028);
					}
				}
				if (d > major - 1 && d < major + 3) {
					m.method_10103(origin.method_10263() + x, origin.method_10264() - dig, origin.method_10260() + z);
					if (inLimit(world, m)) {
						world.method_8652(m, class_2246.field_23869.method_9564(), class_2248.field_31028);
					}
				}
			}
		}

		// Saucer hull (ellipsoid shell, tilted slightly)
		for (int x = -major; x <= major; x++) {
			for (int y = -minor; y <= minor + 2; y++) {
				for (int z = -major; z <= major; z++) {
					double nx = x / (double) major;
					double ny = (y + 1) / (double) (minor + 1);
					double nz = z / (double) major;
					double e = nx * nx + ny * ny * 1.6 + nz * nz;
					if (e > 1.05 || e < 0.55) continue;
					m.method_10103(origin.method_10263() + x, origin.method_10264() + y - 2, origin.method_10260() + z);
					if (!inLimit(world, m)) continue;
					boolean outer = e > 0.82;
					if (outer) {
						world.method_8652(m, class_2246.field_27116.method_9564(), class_2248.field_31028);
					} else if (Math.abs(y) < 2 && nx * nx + nz * nz < 0.35) {
						world.method_8652(m, class_2246.field_10124.method_9564(), class_2248.field_31028);
					} else if (random.method_43048(40) == 0) {
						world.method_8652(m, class_2246.field_10248.method_9564(), class_2248.field_31028);
					} else {
						world.method_8652(m, class_2246.field_10006.method_9564(), class_2248.field_31028);
					}
				}
			}
		}

		// Interior deck + traps
		for (int x = -8; x <= 8; x++) {
			for (int z = -8; z <= 8; z++) {
				if (x * x + z * z > 64) continue;
				world.method_8652(origin.method_10069(x, -1, z), class_2246.field_10297.method_9564(), class_2248.field_31028);
				world.method_8652(origin.method_10069(x, 0, z), class_2246.field_10124.method_9564(), class_2248.field_31028);
				world.method_8652(origin.method_10069(x, 1, z), class_2246.field_10124.method_9564(), class_2248.field_31028);
				world.method_8652(origin.method_10069(x, 2, z), class_2246.field_10124.method_9564(), class_2248.field_31028);
			}
		}

		world.method_8652(origin, class_2246.field_23261.method_9564(), class_2248.field_31028);
		world.method_8652(origin.method_10086(3), ModWorldBlocks.UNSTABLE_REACTOR.method_9564(), class_2248.field_31036);

		// Trap lattice
		placeRing(world, origin, 6, 1, ModWorldBlocks.LASER_BARRIER);
		placeRing(world, origin, 10, 1, ModWorldBlocks.HERMETIC_GATE);
		world.method_8652(origin.method_10069(4, 1, 0), ModWorldBlocks.LASER_TURRET.method_9564(), class_2248.field_31036);
		world.method_8652(origin.method_10069(-4, 1, 0), ModWorldBlocks.PLASMA_TURRET.method_9564(), class_2248.field_31036);
		world.method_8652(origin.method_10069(0, 1, 4), ModWorldBlocks.POINT_DEFENSE_TURRET.method_9564(), class_2248.field_31036);
		world.method_8652(origin.method_10069(0, 1, -4), ModWorldBlocks.VOLUME_TURRET.method_9564(), class_2248.field_31036);
		world.method_8652(origin.method_10069(7, 1, 7), ModWorldBlocks.MAGNETIC_ANOMALY.method_9564(), class_2248.field_31036);
		world.method_8652(origin.method_10069(-7, 1, -7), ModWorldBlocks.MAGNETIC_ANOMALY.method_9564(), class_2248.field_31036);

		if (world instanceof class_3218 sw) {
			spawnThreats(sw, origin, random);
		}

		MacroEntry e = new MacroEntry(UUID.randomUUID(), MacroEntry.Kind.CRASHED_UFO,
				WorldRules.Layer.SURFACE, origin.method_10062(),
				major * 2 + 10, 16, major * 2 + 10, 0x66AA88, "Crashed UFO");
		MacroWorld.put(e);
		return e;
	}

	private static class_2338 resolveCrashSite(class_1936 world, class_2338 hint) {
		if (!(world instanceof class_3218 sw)) return hint;
		int y = sw.method_8624(class_2902.class_2903.field_13203, hint.method_10263(), hint.method_10260());
		if (y < 50) y = 70;
		return new class_2338(hint.method_10263(), Math.min(y, 120), hint.method_10260());
	}

	private static void placeRing(class_1936 world, class_2338 origin, int r, int y, class_2248 block) {
		for (int a = 0; a < 360; a += 45) {
			double rad = Math.toRadians(a);
			class_2338 p = origin.method_10069((int) (Math.cos(rad) * r), y, (int) (Math.sin(rad) * r));
			if (inLimit(world, p)) {
				world.method_8652(p, block.method_9564(), class_2248.field_31036);
			}
		}
	}

	private static void spawnThreats(class_3218 world, class_2338 origin, class_5819 random) {
		// Dense drone garrison — why Pyro GX is the entry ticket
		for (int i = 0; i < 14; i++) {
			DroneEntity drone = ModEntities.DRONE.method_5883(world);
			if (drone == null) continue;
			double ang = i * (Math.PI * 2 / 14);
			double rad = 5 + (i % 4);
			drone.method_5808(
					origin.method_10263() + Math.cos(ang) * rad,
					origin.method_10264() + 1 + (i % 3),
					origin.method_10260() + Math.sin(ang) * rad,
					0, 0);
			drone.applyRole(GARRISON[random.method_43048(GARRISON.length)]);
			world.method_8649(drone);
		}
		for (int i = 0; i < 10; i++) {
			AirMineEntity mine = ModEntities.AIR_MINE.method_5883(world);
			if (mine == null) continue;
			double ang = random.method_43058() * Math.PI * 2;
			double rad = 3 + random.method_43058() * 10;
			mine.method_5808(
					origin.method_10263() + Math.cos(ang) * rad,
					origin.method_10264() + 1 + random.method_43058() * 4,
					origin.method_10260() + Math.sin(ang) * rad,
					0, 0);
			world.method_8649(mine);
		}
	}

	private static boolean inLimit(class_1936 world, class_2338 pos) {
		int y = pos.method_10264();
		return y >= world.method_31607() && y < world.method_31607() + world.method_31605();
	}
}
