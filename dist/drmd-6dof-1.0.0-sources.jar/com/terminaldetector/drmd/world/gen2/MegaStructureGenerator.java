package com.terminaldetector.drmd.world.gen2;

import com.terminaldetector.drmd.world.WorldRules;
import java.util.UUID;
import net.minecraft.class_1936;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_5819;

/**
 * Experimental multi-scale celestial / terrain megastructures.
 * Generates "wrong-looking but fully flyable" space: rifts, canyons, arches,
 * rings, floating continents, spiral ranges, inverted islands.
 */
public final class MegaStructureGenerator {
	private MegaStructureGenerator() {}

	public static MacroEntry generate(class_1936 world, class_2338 origin, MacroEntry.Kind kind, class_5819 random) {
		if (world.method_8320(origin).method_27852(class_2246.field_23261)) {
			// Already generated this cell
			return entry(kind, WorldRules.practicalLayer(origin.method_10264()), origin, 8, 8, 8, 0x888888, kind.name());
		}
		MacroEntry e = switch (kind) {
			case RIFT -> rift(world, origin, random);
			case CANYON -> canyon(world, origin, random);
			case ARCH -> arch(world, origin, random);
			case RING -> naturalRing(world, origin, random);
			case FLOATING_CONTINENT -> floatingContinent(world, origin, random);
			case SPIRAL_RANGE -> spiralRange(world, origin, random);
			case INVERTED_ISLAND -> invertedIsland(world, origin, random);
			case LUNAR_BASE -> LunarBaseGenerator.generate(world, origin, random);
			case CRASHED_UFO -> CrashedUfoGenerator.generate(world, origin, random);
			default -> arch(world, origin, random);
		};
		// Lunar / crashed place their own LODESTONE marker
		if (kind != MacroEntry.Kind.LUNAR_BASE && kind != MacroEntry.Kind.CRASHED_UFO
				&& inLimit(world, origin)) {
			world.method_8652(origin, class_2246.field_23261.method_9564(), class_2248.field_31028);
		}
		return e;
	}

	/** Enormous vertical rift — multi-chunk deep fracture. */
	public static MacroEntry rift(class_1936 world, class_2338 origin, class_5819 random) {
		int length = 80 + random.method_43048(80);
		int depth = 40 + random.method_43048(40);
		int width = 6 + random.method_43048(8);
		class_2338.class_2339 m = new class_2338.class_2339();
		for (int i = -length / 2; i <= length / 2; i++) {
			double wobble = Math.sin(i * 0.08) * 8;
			for (int y = -depth; y <= depth / 3; y++) {
				for (int w = -width; w <= width; w++) {
					m.method_10103(origin.method_10263() + i, origin.method_10264() + y, origin.method_10260() + (int) wobble + w);
					if (inLimit(world, m)) {
						world.method_8652(m, class_2246.field_10124.method_9564(), class_2248.field_31028);
						if (Math.abs(w) == width && random.method_43048(5) == 0) {
							world.method_8652(m, class_2246.field_23869.method_9564(), class_2248.field_31028);
						}
					}
				}
			}
		}
		MacroEntry e = entry(MacroEntry.Kind.RIFT, WorldRules.Layer.SURFACE, origin, length, depth * 2, width * 4, 0x442222, "Rift");
		MacroWorld.put(e);
		return e;
	}

	/** Endless-feeling vertical canyon corridor. */
	public static MacroEntry canyon(class_1936 world, class_2338 origin, class_5819 random) {
		int length = 120 + random.method_43048(100);
		int height = 50 + random.method_43048(40);
		int width = 10 + random.method_43048(10);
		class_2338.class_2339 m = new class_2338.class_2339();
		for (int z = -length / 2; z <= length / 2; z++) {
			double curve = Math.sin(z * 0.05) * 12;
			for (int y = 0; y < height; y++) {
				for (int x = -width; x <= width; x++) {
					m.method_10103(origin.method_10263() + (int) curve + x, origin.method_10264() + y - height / 3, origin.method_10260() + z);
					if (!inLimit(world, m)) continue;
					if (Math.abs(x) < width - 1) {
						world.method_8652(m, class_2246.field_10124.method_9564(), class_2248.field_31028);
					} else {
						world.method_8652(m, class_2246.field_10340.method_9564(), class_2248.field_31028);
					}
				}
			}
		}
		MacroEntry e = entry(MacroEntry.Kind.CANYON, WorldRules.Layer.SURFACE, origin, width * 3, height, length, 0x665544, "Vertical Canyon");
		MacroWorld.put(e);
		return e;
	}

	/** Multi-kilometre-feel natural arch (scaled to practical chunk budget). */
	public static MacroEntry arch(class_1936 world, class_2338 origin, class_5819 random) {
		int radius = 28 + random.method_43048(24);
		int thickness = 4 + random.method_43048(3);
		class_2680 mat = class_2246.field_27114.method_9564();
		class_2338.class_2339 m = new class_2338.class_2339();
		for (int a = 0; a <= 180; a++) {
			double rad = Math.toRadians(a);
			int x = (int) (Math.cos(rad) * radius);
			int y = (int) (Math.sin(rad) * radius);
			for (int t = -thickness; t <= thickness; t++) {
				for (int d = -thickness; d <= thickness; d++) {
					if (t * t + d * d > thickness * thickness) continue;
					m.method_10103(origin.method_10263() + x + t, origin.method_10264() + y + d, origin.method_10260());
					if (inLimit(world, m)) world.method_8652(m, mat, class_2248.field_31028);
					// Extrude arch depth
					for (int z = -6; z <= 6; z++) {
						m.method_10103(origin.method_10263() + x + t, origin.method_10264() + y + d, origin.method_10260() + z);
						if (inLimit(world, m) && Math.abs(z) <= 4) {
							world.method_8652(m, mat, class_2248.field_31028);
						}
					}
				}
			}
		}
		MacroEntry e = entry(MacroEntry.Kind.ARCH, WorldRules.Layer.SKY_ARCHIPELAGO, origin, radius * 2, radius + 10, 16, 0xE8E0D0, "Sky Arch");
		MacroWorld.put(e);
		return e;
	}

	/** Natural torus / ring in the sky. */
	public static MacroEntry naturalRing(class_1936 world, class_2338 origin, class_5819 random) {
		int major = 36 + random.method_43048(20);
		int minor = 5 + random.method_43048(4);
		class_2680 mat = class_2246.field_10471.method_9564();
		class_2338.class_2339 m = new class_2338.class_2339();
		for (int a = 0; a < 360; a += 2) {
			double rad = Math.toRadians(a);
			double cx = Math.cos(rad) * major;
			double cz = Math.sin(rad) * major;
			for (int b = 0; b < 360; b += 15) {
				double br = Math.toRadians(b);
				int x = (int) (cx + Math.cos(br) * minor * Math.cos(rad));
				int y = (int) (Math.sin(br) * minor);
				int z = (int) (cz + Math.cos(br) * minor * Math.sin(rad));
				m.method_10103(origin.method_10263() + x, origin.method_10264() + y, origin.method_10260() + z);
				if (inLimit(world, m)) world.method_8652(m, mat, class_2248.field_31028);
			}
		}
		MacroEntry e = entry(MacroEntry.Kind.RING, WorldRules.Layer.SKY_ARCHIPELAGO, origin, major * 2, minor * 3, major * 2, 0xC8C090, "Celestial Ring");
		MacroWorld.put(e);
		return e;
	}

	/** Floating continent slab with underside stalactites. */
	public static MacroEntry floatingContinent(class_1936 world, class_2338 origin, class_5819 random) {
		int rx = 40 + random.method_43048(30);
		int rz = 40 + random.method_43048(30);
		int thick = 8 + random.method_43048(6);
		class_2338.class_2339 m = new class_2338.class_2339();
		for (int x = -rx; x <= rx; x++) {
			for (int z = -rz; z <= rz; z++) {
				double nx = x / (double) rx;
				double nz = z / (double) rz;
				if (nx * nx + nz * nz > 1.0) continue;
				int h = thick - (int) ((nx * nx + nz * nz) * thick * 0.6);
				for (int y = 0; y < h; y++) {
					m.method_10103(origin.method_10263() + x, origin.method_10264() - y, origin.method_10260() + z);
					if (!inLimit(world, m)) continue;
					class_2680 mat = y == 0 ? class_2246.field_10219.method_9564()
							: y < 3 ? class_2246.field_10566.method_9564()
							: class_2246.field_10340.method_9564();
					world.method_8652(m, mat, class_2248.field_31028);
				}
				if (random.method_43048(12) == 0) {
					int len = 3 + random.method_43048(8);
					for (int y = h; y < h + len; y++) {
						m.method_10103(origin.method_10263() + x, origin.method_10264() - y, origin.method_10260() + z);
						if (inLimit(world, m)) world.method_8652(m, class_2246.field_28048.method_9564(), class_2248.field_31028);
					}
				}
			}
		}
		MacroEntry e = entry(MacroEntry.Kind.FLOATING_CONTINENT, WorldRules.Layer.SKY_ARCHIPELAGO, origin, rx * 2, thick + 20, rz * 2, 0x4A8F3C, "Floating Continent");
		MacroWorld.put(e);
		return e;
	}

	/** Spiral mountain / ridge system rising through altitude. */
	public static MacroEntry spiralRange(class_1936 world, class_2338 origin, class_5819 random) {
		int turns = 4 + random.method_43048(3);
		int height = 60 + random.method_43048(40);
		int radius = 20;
		class_2338.class_2339 m = new class_2338.class_2339();
		int steps = turns * 40;
		for (int i = 0; i < steps; i++) {
			double t = i / (double) steps;
			double ang = t * turns * Math.PI * 2;
			int y = (int) (t * height);
			int x = (int) (Math.cos(ang) * radius);
			int z = (int) (Math.sin(ang) * radius);
			for (int ox = -4; ox <= 4; ox++) {
				for (int oz = -4; oz <= 4; oz++) {
					for (int oy = -2; oy <= 6; oy++) {
						if (ox * ox + oz * oz > 16) continue;
						m.method_10103(origin.method_10263() + x + ox, origin.method_10264() + y + oy, origin.method_10260() + z + oz);
						if (inLimit(world, m)) {
							world.method_8652(m, oy > 4 ? class_2246.field_10491.method_9564() : class_2246.field_10340.method_9564(), class_2248.field_31028);
						}
					}
				}
			}
		}
		MacroEntry e = entry(MacroEntry.Kind.SPIRAL_RANGE, WorldRules.Layer.SKY_ARCHIPELAGO, origin, radius * 3, height + 10, radius * 3, 0x8899AA, "Spiral Range");
		MacroWorld.put(e);
		return e;
	}

	/** Inverted island — flat underside, peaks pointing down. */
	public static MacroEntry invertedIsland(class_1936 world, class_2338 origin, class_5819 random) {
		int r = 24 + random.method_43048(16);
		class_2338.class_2339 m = new class_2338.class_2339();
		for (int x = -r; x <= r; x++) {
			for (int z = -r; z <= r; z++) {
				double d = Math.sqrt(x * x + z * z) / r;
				if (d > 1) continue;
				int depth = (int) ((1 - d) * (12 + random.method_43048(8)));
				// Flat top (actually the "ceiling" walkable surface from below)
				m.method_10103(origin.method_10263() + x, origin.method_10264(), origin.method_10260() + z);
				if (inLimit(world, m)) world.method_8652(m, class_2246.field_28681.method_9564(), class_2248.field_31028);
				for (int y = 1; y <= depth; y++) {
					m.method_10103(origin.method_10263() + x, origin.method_10264() - y, origin.method_10260() + z);
					if (inLimit(world, m)) {
						world.method_8652(m, y == depth ? class_2246.field_28048.method_9564() : class_2246.field_28888.method_9564(), class_2248.field_31028);
					}
				}
			}
		}
		MacroEntry e = entry(MacroEntry.Kind.INVERTED_ISLAND, WorldRules.Layer.SKY_ARCHIPELAGO, origin, r * 2, 20, r * 2, 0x3A5A40, "Inverted Island");
		MacroWorld.put(e);
		return e;
	}

	private static MacroEntry entry(MacroEntry.Kind kind, WorldRules.Layer layer, class_2338 c,
									int sx, int sy, int sz, int color, String label) {
		return new MacroEntry(UUID.randomUUID(), kind, layer, c.method_10062(), sx, sy, sz, color, label);
	}

	private static boolean inLimit(class_1936 world, class_2338 pos) {
		int y = pos.method_10264();
		return y >= world.method_31607() && y < world.method_31607() + world.method_31605();
	}
}
