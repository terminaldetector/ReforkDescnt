package com.terminaldetector.drmd.world.gen2;

import com.terminaldetector.drmd.entity.ModEntities;
import com.terminaldetector.drmd.entity.ModWorldBlocks;
import com.terminaldetector.drmd.entity.ReactorDisplayEntity;
import com.terminaldetector.drmd.world.WorldRules;
import com.terminaldetector.drmd.world.mega.ReactorKeeperEntity;
import java.util.UUID;
import net.minecraft.class_1511;
import net.minecraft.class_1936;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_5819;

/**
 * Abandoned Descent 1 lunar base — grey hull, force-shield crystals,
 * trap corridors, micro-reactor chamber + Reactor Keeper bossfight.
 */
public final class LunarBaseGenerator {
	private LunarBaseGenerator() {}

	public static MacroEntry generate(class_1936 world, class_2338 origin, class_5819 random) {
		if (world.method_8320(origin).method_27852(class_2246.field_23261)) {
			return new MacroEntry(UUID.randomUUID(), MacroEntry.Kind.LUNAR_BASE,
					WorldRules.Layer.SKY_ARCHIPELAGO, origin.method_10062(), 48, 24, 48, 0xAAB8C8, "Lunar Base");
		}

		int radius = 22;
		class_2338.class_2339 m = new class_2338.class_2339();

		// Disc hull (lunar grey)
		for (int x = -radius; x <= radius; x++) {
			for (int z = -radius; z <= radius; z++) {
				int d2 = x * x + z * z;
				if (d2 > radius * radius) continue;
				for (int y = -2; y <= 6; y++) {
					m.method_10103(origin.method_10263() + x, origin.method_10264() + y, origin.method_10260() + z);
					if (!inLimit(world, m)) continue;
					boolean rim = d2 > (radius - 2) * (radius - 2);
					boolean floor = y == -2 || y == 0;
					boolean roof = y == 6;
					if (rim || floor || roof) {
						world.method_8652(m, (rim ? class_2246.field_10093 : class_2246.field_10172).method_9564(),
								class_2248.field_31028);
					} else if (y > 0 && y < 6 && d2 < (radius - 3) * (radius - 3)) {
						world.method_8652(m, class_2246.field_10124.method_9564(), class_2248.field_31028);
					}
				}
				// Outer walkway lip
				if (d2 > (radius - 1) * (radius - 1)) {
					m.method_10103(origin.method_10263() + x, origin.method_10264() + 1, origin.method_10260() + z);
					if (inLimit(world, m)) {
						world.method_8652(m, class_2246.field_10576.method_9564(), class_2248.field_31028);
					}
				}
			}
		}

		// Spoke corridors + hermetic gates
		int[][] spokes = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}};
		for (int[] s : spokes) {
			for (int d = 4; d <= radius - 3; d++) {
				class_2338 p = origin.method_10069(s[0] * d, 1, s[1] * d);
				clearChamber(world, p, 1);
				if (d == 8 || d == 14) {
					world.method_8652(p, ModWorldBlocks.HERMETIC_GATE.method_9564(), class_2248.field_31036);
				}
				if (d == 11) {
					world.method_8652(p.method_10086(2), ModWorldBlocks.LASER_BARRIER.method_9564(), class_2248.field_31036);
				}
			}
			// Turret pads at mid-spoke
			class_2338 pad = origin.method_10069(s[0] * 12, 0, s[1] * 12);
			world.method_8652(pad.method_10084(), class_2246.field_10093.method_9564(), class_2248.field_31028);
			class_2248 turret = switch (Math.abs(s[0] + 2 * s[1])) {
				case 1 -> ModWorldBlocks.LASER_TURRET;
				case 2 -> ModWorldBlocks.PLASMA_TURRET;
				default -> ModWorldBlocks.POINT_DEFENSE_TURRET;
			};
			world.method_8652(pad.method_10086(2), turret.method_9564(), class_2248.field_31036);
		}

		// Magnetic anomalies in side bays
		place(world, origin.method_10069(10, 1, 10), ModWorldBlocks.MAGNETIC_ANOMALY);
		place(world, origin.method_10069(-10, 1, -10), ModWorldBlocks.MAGNETIC_ANOMALY);

		// Central micro-reactor chamber
		for (int x = -5; x <= 5; x++) {
			for (int z = -5; z <= 5; z++) {
				if (x * x + z * z > 25) continue;
				m.method_10103(origin.method_10263() + x, origin.method_10264() + 1, origin.method_10260() + z);
				if (inLimit(world, m)) world.method_8652(m, class_2246.field_10124.method_9564(), class_2248.field_31028);
				world.method_8652(origin.method_10069(x, 0, z), class_2246.field_10540.method_9564(), class_2248.field_31028);
			}
		}
		for (int y = 1; y <= 4; y++) {
			world.method_8652(origin.method_10086(y), class_2246.field_23152.method_9564(), class_2248.field_31036);
		}
		world.method_8652(origin.method_10086(5), ModWorldBlocks.UNSTABLE_REACTOR.method_9564(), class_2248.field_31036);
		world.method_8652(origin, class_2246.field_23261.method_9564(), class_2248.field_31028);

		// Force-shield crystals (Descent shield nodes analogue)
		class_2338[] nodes = {
				origin.method_10069(7, 0, 0), origin.method_10069(-7, 0, 0),
				origin.method_10069(0, 0, 7), origin.method_10069(0, 0, -7)
		};
		for (class_2338 n : nodes) {
			for (int y = 1; y <= 4; y++) {
				world.method_8652(n.method_10086(y), class_2246.field_10085.method_9564(), class_2248.field_31028);
			}
			world.method_8652(n.method_10086(5), class_2246.field_10174.method_9564(), class_2248.field_31036);
			if (world instanceof class_3218 sw) {
				class_1511 crystal = net.minecraft.class_1299.field_6110.method_5883(sw);
				if (crystal != null) {
					crystal.method_5808(n.method_10263() + 0.5, n.method_10264() + 6.0, n.method_10260() + 0.5, 0, 0);
					crystal.method_6839(false);
					sw.method_8649(crystal);
				}
			}
			world.method_8652(n.method_10069(2, 2, 0), ModWorldBlocks.VOLUME_TURRET.method_9564(), class_2248.field_31036);
		}

		if (world instanceof class_3218 sw) {
			ReactorDisplayEntity core = ModEntities.REACTOR_DISPLAY.method_5883(sw);
			if (core != null) {
				core.method_5808(origin.method_10263() + 0.5, origin.method_10264() + 7.0, origin.method_10260() + 0.5, 0, 0);
				sw.method_8649(core);
			}
			ReactorKeeperEntity keeper = ModEntities.REACTOR_KEEPER.method_5883(sw);
			if (keeper != null) {
				class_243 anchor = new class_243(origin.method_10263() + 0.5, origin.method_10264() + 8.0, origin.method_10260() + 0.5);
				keeper.method_5808(anchor.field_1352 + 8, anchor.field_1351, anchor.field_1350, 0, 0);
				keeper.setAnchor(anchor);
				sw.method_8649(keeper);
			}
		}

		MacroEntry e = new MacroEntry(UUID.randomUUID(), MacroEntry.Kind.LUNAR_BASE,
				WorldRules.Layer.SKY_ARCHIPELAGO, origin.method_10062(),
				radius * 2 + 8, 18, radius * 2 + 8, 0xAAB8C8, "Abandoned Lunar Base");
		MacroWorld.put(e);
		return e;
	}

	private static void clearChamber(class_1936 world, class_2338 c, int r) {
		class_2338.class_2339 m = new class_2338.class_2339();
		for (int x = -r; x <= r; x++) {
			for (int y = 0; y <= 3; y++) {
				for (int z = -r; z <= r; z++) {
					m.method_10103(c.method_10263() + x, c.method_10264() + y, c.method_10260() + z);
					if (inLimit(world, m)) {
						world.method_8652(m, class_2246.field_10124.method_9564(), class_2248.field_31028);
					}
				}
			}
		}
	}

	private static void place(class_1936 world, class_2338 pos, class_2248 block) {
		if (inLimit(world, pos)) {
			world.method_8652(pos, block.method_9564(), class_2248.field_31036);
		}
	}

	private static boolean inLimit(class_1936 world, class_2338 pos) {
		int y = pos.method_10264();
		return y >= world.method_31607() && y < world.method_31607() + world.method_31605();
	}
}
