package com.terminaldetector.drmd.world;

import net.minecraft.class_18;
import net.minecraft.class_2487;
import net.minecraft.class_26;
import net.minecraft.class_3218;
import net.minecraft.class_7225;

/**
 * Per-world Descent integration flags — spawn hub and stock megastructure seeding.
 */
public class DescentWorldState extends class_18 {
	public static final String ID = "drmd_world";

	private boolean spawnHubGenerated;
	private boolean stockSeeded;

	public static DescentWorldState get(class_3218 world) {
		class_26 mgr = world.method_17983();
		return mgr.method_17924(new class_8645<>(DescentWorldState::new, DescentWorldState::fromNbt, null), ID);
	}

	public DescentWorldState() {}

	public static DescentWorldState fromNbt(class_2487 nbt, class_7225.class_7874 lookup) {
		DescentWorldState s = new DescentWorldState();
		s.spawnHubGenerated = nbt.method_10577("spawnHubGenerated");
		s.stockSeeded = nbt.method_10577("stockSeeded");
		return s;
	}

	@Override
	public class_2487 method_75(class_2487 nbt, class_7225.class_7874 registryLookup) {
		nbt.method_10556("spawnHubGenerated", spawnHubGenerated);
		nbt.method_10556("stockSeeded", stockSeeded);
		return nbt;
	}

	public boolean isSpawnHubGenerated() { return spawnHubGenerated; }
	public void setSpawnHubGenerated(boolean v) { this.spawnHubGenerated = v; method_80(); }

	public boolean isStockSeeded() { return stockSeeded; }
	public void setStockSeeded(boolean v) { this.stockSeeded = v; method_80(); }
}
