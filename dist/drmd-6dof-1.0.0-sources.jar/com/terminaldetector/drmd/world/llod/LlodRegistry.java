package com.terminaldetector.drmd.world.llod;

import com.terminaldetector.drmd.world.gen2.MacroEntry;
import com.terminaldetector.drmd.world.gen2.MacroWorld;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.UUID;
import net.minecraft.class_2338;
import net.minecraft.class_243;

/**
 * Server-side Voxel LLOD catalogue query.
 * Sends compact macro descriptors; client expands LLOD0/1/2 into voxel meshes.
 */
public final class LlodRegistry {
	private LlodRegistry() {}

	public record Silhouette(
		UUID id,
		MacroEntry.Kind kind,
		class_243 center,
		float radiusX,
		float radiusY,
		float radiusZ,
		LlodLevel level,
		int colorRgb,
		String label,
		long seed
	) {}

	public static List<Silhouette> queryVisible(class_2338 viewer, int max) {
		List<MacroEntry> near = new ArrayList<>(MacroWorld.all());
		near.sort(Comparator.comparingDouble(e -> e.distanceSq(viewer)));
		List<Silhouette> out = new ArrayList<>();
		int llod0 = 0;
		for (MacroEntry e : near) {
			double d = Math.sqrt(e.distanceSq(viewer));
			LlodLevel level = LlodLevel.of(d);
			if (!level.drawsVoxels()) continue;
			// Cap farthest dense silhouettes so frame stays playable
			if (level == LlodLevel.LLOD0 && ++llod0 > 6) continue;
			long seed = e.id.getMostSignificantBits() ^ e.id.getLeastSignificantBits()
					^ (((long) e.center.method_10263()) << 20) ^ e.center.method_10260();
			out.add(new Silhouette(
					e.id,
					e.kind,
					class_243.method_24953(e.center),
					e.sizeX / 2f,
					e.sizeY / 2f,
					e.sizeZ / 2f,
					level,
					e.colorRgb,
					e.label,
					seed
			));
			if (out.size() >= max) break;
		}
		return out;
	}
}
