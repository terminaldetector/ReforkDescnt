package com.terminaldetector.drmd.world.bombardment;

import com.terminaldetector.drmd.world.atmosphere.AtmosphereBand;
import com.terminaldetector.drmd.world.atmosphere.AtmosphereRules;
import com.terminaldetector.drmd.world.fire.FireSystem;
import com.terminaldetector.drmd.world.smoke.SmokeSystem;
import org.joml.Vector3f;

import java.util.UUID;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_239;
import net.minecraft.class_2390;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_3218;
import net.minecraft.class_3965;

/**
 * Falling aerial bomb — long smoke trail, accelerates in thin air, crater on impact.
 */
public class AerialBombEntity extends class_1297 {
	private OrdnanceType type = OrdnanceType.TNT_BOMB;
	private UUID ownerId;
	private class_2338 laserTarget;
	private int ageTicks;

	public AerialBombEntity(class_1299<? extends AerialBombEntity> type, class_1937 world) {
		super(type, world);
		this.field_5960 = false;
	}

	public void configure(OrdnanceType ordnance, class_1309 owner, class_2338 laserTarget) {
		this.type = ordnance;
		if (owner != null) this.ownerId = owner.method_5667();
		this.laserTarget = laserTarget;
	}

	public OrdnanceType getOrdnance() {
		return type;
	}

	@Override
	protected void method_5693(net.minecraft.class_2945.class_9222 builder) {}

	@Override
	public void method_5773() {
		super.method_5773();
		ageTicks++;
		if (method_37908().field_9236) {
			float r = ((type.trailColor >> 16) & 0xFF) / 255f;
			float g = ((type.trailColor >> 8) & 0xFF) / 255f;
			float b = (type.trailColor & 0xFF) / 255f;
			method_37908().method_8406(new class_2390(new Vector3f(r, g, b), 1.4f),
					method_23317(), method_23318(), method_23321(), 0, 0.05, 0);
			method_37908().method_8406(class_2398.field_11237, method_23317(), method_23318() + 0.2, method_23321(), 0, 0.02, 0);
			if (ageTicks % 2 == 0) {
				SmokeSystem.emit(method_19538(), SmokeSystem.Source.BOMB_TRAIL, 0.6f, 0.45f, 50);
			}
			return;
		}

		AtmosphereBand band = AtmosphereBand.at(method_23318());
		class_243 vel = method_18798();

		// Gravity + thin-air acceleration (almost no drag)
		double grav = 0.04 + (1.0 - band.airDrag) * 0.03;
		vel = vel.method_1031(0, -grav, 0);
		vel = vel.method_1021(0.99 + (1.0 - band.airDrag) * 0.008);

		// Laser guidance — gentle steer toward mark
		if (type == OrdnanceType.LASER_GUIDED && laserTarget != null) {
			class_243 target = class_243.method_24953(laserTarget);
			class_243 to = target.method_1020(method_19538());
			if (to.method_1027() > 1e-6) {
				vel = vel.method_1019(to.method_1029().method_1021(0.03));
			}
		}

		method_18799(vel);
		class_243 from = method_19538();
		class_243 next = from.method_1019(vel);
		class_243 lookAhead = vel.method_1027() > 1e-8
				? next.method_1019(vel.method_1029().method_1021(0.5))
				: next.method_1031(0, -0.5, 0);

		if (ageTicks % 2 == 0) {
			SmokeSystem.emit(from, SmokeSystem.Source.BOMB_TRAIL, 0.6f, 0.45f, 50);
		}

		class_3965 hit = method_37908().method_17742(new net.minecraft.class_3959(
				from, lookAhead,
				net.minecraft.class_3959.class_3960.field_17558,
				net.minecraft.class_3959.class_242.field_1348, this));
		method_33574(next);

		boolean grounded = hit.method_17783() == class_239.class_240.field_1332
				|| field_5992 || field_5976
				|| (!method_37908().method_8320(method_24515().method_10074()).method_26215() && vel.field_1351 < 0 && (method_23318() - Math.floor(method_23318())) < 0.35);

		if (grounded || ageTicks > 20 * 90) {
			detonate();
		}
	}

	private void detonate() {
		if (!(method_37908() instanceof class_3218 sw)) {
			method_31472();
			return;
		}
		float power = AtmosphereRules.scaleBlast(method_23318(), 4.0f * type.blastPower);
		sw.method_8537(this, method_23317(), method_23318(), method_23321(), power, true, class_1937.class_7867.field_40891);
		SmokeSystem.emitExplosion(method_19538(), power);
		class_2338 at = method_24515();
		com.terminaldetector.drmd.world.mega.SkyUfoEntity.notifyBombDetonation(sw, at, power);

		if (type.incendiary || type == OrdnanceType.TNT_BOMB) {
			FireSystem.igniteBlast(sw, at, type.incendiary ? 18 : 6, type.incendiary ? 6 : 3);
		}
		if (type.cluster) {
			for (int i = 0; i < 5; i++) {
				double ox = (sw.method_8409().method_43058() - 0.5) * 8;
				double oz = (sw.method_8409().method_43058() - 0.5) * 8;
				sw.method_8537(this, method_23317() + ox, method_23318(), method_23321() + oz,
						AtmosphereRules.scaleBlast(method_23318(), 2.2f), true, class_1937.class_7867.field_40891);
				SmokeSystem.emitExplosion(method_19538().method_1031(ox, 0, oz), 2.2f);
				FireSystem.igniteBlast(sw, at.method_10069((int) ox, 0, (int) oz), 3, 2);
			}
		}
		// Deep pressure: extra tunnel shock puff
		if (AtmosphereBand.at(method_23318()).highPressure) {
			SmokeSystem.emit(method_19538(), SmokeSystem.Source.TNT, 4f, 0.9f, 120);
		}
		method_31472();
	}

	@Override
	protected void method_5749(class_2487 nbt) {
		try {
			type = OrdnanceType.valueOf(nbt.method_10558("ordnance"));
		} catch (Exception e) {
			type = OrdnanceType.TNT_BOMB;
		}
		if (nbt.method_25928("owner")) ownerId = nbt.method_25926("owner");
		if (nbt.method_10545("tx")) laserTarget = new class_2338(nbt.method_10550("tx"), nbt.method_10550("ty"), nbt.method_10550("tz"));
	}

	@Override
	protected void method_5652(class_2487 nbt) {
		nbt.method_10582("ordnance", type.name());
		if (ownerId != null) nbt.method_25927("owner", ownerId);
		if (laserTarget != null) {
			nbt.method_10569("tx", laserTarget.method_10263());
			nbt.method_10569("ty", laserTarget.method_10264());
			nbt.method_10569("tz", laserTarget.method_10260());
		}
	}
}
