package com.terminaldetector.drmd.world.bombardment;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3959;
import net.minecraft.class_3965;

/**
 * Bomb bay / laser designator items for high-altitude bombardment.
 */
public final class BombardmentItems {
	/** Last laser mark per player. */
	private static final Map<UUID, class_2338> LASER_MARKS = new ConcurrentHashMap<>();

	private BombardmentItems() {}

	public static class_2338 getLaserMark(UUID id) {
		return LASER_MARKS.get(id);
	}

	public static class BombBayItem extends class_1792 {
		private final OrdnanceType ordnance;

		public BombBayItem(OrdnanceType ordnance, class_1793 settings) {
			super(settings.method_7889(16));
			this.ordnance = ordnance;
		}

		public OrdnanceType getOrdnance() {
			return ordnance;
		}

		@Override
		public class_1271<class_1799> method_7836(class_1937 world, class_1657 user, class_1268 hand) {
			class_1799 stack = user.method_5998(hand);
			if (world.field_9236) return class_1271.method_22427(stack);
			if (!(world instanceof class_3218 sw) || !(user instanceof class_3222 sp)) {
				return class_1271.method_22431(stack);
			}
			var bomb = com.terminaldetector.drmd.entity.ModEntities.AERIAL_BOMB.method_5883(sw);
			if (bomb == null) return class_1271.method_22431(stack);
			class_243 drop = user.method_19538().method_1019(user.method_5828(1f).method_1021(2)).method_1031(0, -1.2, 0);
			bomb.method_5808(drop.field_1352, drop.field_1351, drop.field_1350, user.method_36454(), 90);
			bomb.method_18799(user.method_18798().method_1031(0, -0.2, 0));
			bomb.configure(ordnance, user, LASER_MARKS.get(user.method_5667()));
			sw.method_8649(bomb);
			SmokeSystemTrail(user);
			if (!user.method_31549().field_7477) stack.method_7934(1);
			user.method_7353(class_2561.method_43470("§cOrdnance away: §f" + ordnance.name()
					+ " §7@ Y=" + (int) user.method_23318()), true);
			return class_1271.method_22427(stack);
		}

		private static void SmokeSystemTrail(class_1657 user) {
			com.terminaldetector.drmd.world.smoke.SmokeSystem.emit(
					user.method_19538(), com.terminaldetector.drmd.world.smoke.SmokeSystem.Source.ENGINE, 0.5f, 0.3f, 20);
		}
	}

	public static class LaserDesignatorItem extends class_1792 {
		public LaserDesignatorItem(class_1793 settings) {
			super(settings.method_7889(1));
		}

		@Override
		public class_1271<class_1799> method_7836(class_1937 world, class_1657 user, class_1268 hand) {
			class_1799 stack = user.method_5998(hand);
			if (world.field_9236) return class_1271.method_22427(stack);
			class_243 eye = user.method_33571();
			class_243 end = eye.method_1019(user.method_5828(1f).method_1021(256));
			class_3965 hit = world.method_17742(new class_3959(eye, end,
					class_3959.class_3960.field_17558, class_3959.class_242.field_1348, user));
			if (hit.method_17783() == class_239.class_240.field_1332) {
				class_2338 mark = hit.method_17777();
				LASER_MARKS.put(user.method_5667(), mark);
				user.method_7353(class_2561.method_43470("§aLaser mark §f" + mark.method_23854()), true);
				if (world instanceof class_3218 sw) {
					sw.method_14199(net.minecraft.class_2398.field_11207,
							mark.method_10263() + 0.5, mark.method_10264() + 1.2, mark.method_10260() + 0.5,
							16, 0.2, 0.4, 0.2, 0.02);
				}
			} else {
				user.method_7353(class_2561.method_43470("§7No laser lock"), true);
			}
			return class_1271.method_22427(stack);
		}
	}
}
