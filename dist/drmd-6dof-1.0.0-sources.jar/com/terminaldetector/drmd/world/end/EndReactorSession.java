package com.terminaldetector.drmd.world.end;

import com.terminaldetector.drmd.DescentMod;
import com.terminaldetector.drmd.entity.ModEntities;
import com.terminaldetector.drmd.entity.ModWorldBlocks;
import com.terminaldetector.drmd.entity.ReactorDisplayEntity;
import com.terminaldetector.drmd.world.mega.ReactorKeeperEntity;
import net.minecraft.class_1510;
import net.minecraft.class_1511;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2586;
import net.minecraft.class_2643;
import net.minecraft.class_2902;
import net.minecraft.class_3218;
import net.minecraft.server.MinecraftServer;

/**
 * Replaces the vanilla Ender Dragon fight with a Descent mega-reactor base.
 * Shield crystals (End crystals on pillars) → exposed giga-core → destroy for exit gateways.
 */
public final class EndReactorSession {
	private static boolean seededThisRun;

	private EndReactorSession() {}

	public static void onServerTick(MinecraftServer server) {
		class_3218 end = server.method_3847(class_1937.field_25181);
		if (end == null) return;
		suppressDragons(end);
		if (!seededThisRun) {
			ensureBase(end);
			seededThisRun = true;
		}
	}

	public static void onServerStarted(MinecraftServer server) {
		seededThisRun = false;
		class_3218 end = server.method_3847(class_1937.field_25181);
		if (end != null) {
			server.execute(() -> {
				suppressDragons(end);
				ensureBase(end);
				seededThisRun = true;
			});
		}
	}

	/** Called each dragon-fight tick — remove dragons, keep our fight. */
	public static void suppressDragons(class_3218 end) {
		for (class_1510 dragon : end.method_18776()) {
			dragon.method_31472();
		}
	}

	public static void ensureBase(class_3218 end) {
		EndReactorState state = EndReactorState.get(end);
		if (state.isBaseGenerated()) {
			ensureBossAlive(end, state);
			return;
		}
		class_2338 center = resolveCenter(end);
		generateBase(end, center);
		spawnBoss(end, center);
		state.setBaseGenerated(true);
		state.setPhase(EndReactorState.Phase.SHIELDED);
		DescentMod.LOGGER.info("End mega-reactor base generated at {}", center.method_23854());
	}

	/** Prefer island surface near 0,0 so portal arrival stays contiguous. */
	private static class_2338 resolveCenter(class_3218 end) {
		int y = end.method_8624(class_2902.class_2903.field_13203, 0, 0);
		if (y < 40 || y > 120) y = 72;
		return new class_2338(0, y, 0);
	}

	private static void ensureBossAlive(class_3218 end, EndReactorState state) {
		if (state.isDefeated()) return;
		boolean alive = !end.method_18198(ModEntities.END_REACTOR_BOSS, e -> e.method_5805()).isEmpty();
		if (!alive && state.getPhase() != EndReactorState.Phase.DEFEATED) {
			class_2338 center = resolveCenter(end);
			spawnBoss(end, center);
		}
	}

	public static void generateBase(class_3218 world, class_2338 center) {
		// Clear a working volume so the base replaces the stock podium without leftover clutter
		for (int x = -30; x <= 30; x++) {
			for (int z = -30; z <= 30; z++) {
				if (x * x + z * z > 30 * 30) continue;
				for (int y = 1; y <= 22; y++) {
					world.method_8652(center.method_10069(x, y, z), class_2246.field_10124.method_9564(), class_2248.field_31028);
				}
			}
		}

		// Central platform
		for (int x = -28; x <= 28; x++) {
			for (int z = -28; z <= 28; z++) {
				if (x * x + z * z > 28 * 28) continue;
				class_2338 p = center.method_10069(x, 0, z);
				world.method_8652(p, class_2246.field_10540.method_9564(), class_2248.field_31028);
				if (x * x + z * z > 22 * 22) {
					world.method_8652(p.method_10084(), class_2246.field_10462.method_9564(), class_2248.field_31028);
				} else if ((x + z) % 5 == 0) {
					world.method_8652(p.method_10084(), class_2246.field_10286.method_9564(), class_2248.field_31028);
				}
			}
		}
		// Reactor ring
		for (int a = 0; a < 360; a += 8) {
			double rad = Math.toRadians(a);
			int x = (int) (Math.cos(rad) * 10);
			int z = (int) (Math.sin(rad) * 10);
			for (int y = 1; y <= 8; y++) {
				world.method_8652(center.method_10069(x, y, z), class_2246.field_22423.method_9564(), class_2248.field_31028);
			}
		}
		// Core pedestal
		for (int y = 1; y <= 6; y++) {
			world.method_8652(center.method_10086(y), class_2246.field_23152.method_9564(), class_2248.field_31036);
		}
		world.method_8652(center.method_10086(7), ModWorldBlocks.UNSTABLE_REACTOR.method_9564(), class_2248.field_31036);

		ReactorDisplayEntity core = ModEntities.REACTOR_DISPLAY.method_5883(world);
		if (core != null) {
			core.method_5808(center.method_10263() + 0.5, center.method_10264() + 9.0, center.method_10260() + 0.5, 0, 0);
			world.method_8649(core);
		}

		// Shield crystal pillars (dragon-analogue) — 4 towers with End crystals
		class_2338[] pillars = {
				center.method_10069(22, 0, 0), center.method_10069(-22, 0, 0),
				center.method_10069(0, 0, 22), center.method_10069(0, 0, -22)
		};
		for (class_2338 base : pillars) {
			for (int y = 1; y <= 14; y++) {
				world.method_8652(base.method_10086(y), class_2246.field_10540.method_9564(), class_2248.field_31028);
				if (y % 3 == 0) {
					world.method_8652(base.method_10086(y).method_10078(), class_2246.field_10576.method_9564(), class_2248.field_31028);
					world.method_8652(base.method_10086(y).method_10067(), class_2246.field_10576.method_9564(), class_2248.field_31028);
				}
			}
			world.method_8652(base.method_10086(15), class_2246.field_9987.method_9564(), class_2248.field_31028);
			class_1511 crystal = spawnCrystal(world, base.method_10086(16));
			if (crystal != null) world.method_8649(crystal);

			// Defense turrets on mid platforms
			placeTurretPad(world, base.method_10069(3, 8, 0), ModWorldBlocks.LASER_TURRET);
			placeTurretPad(world, base.method_10069(-3, 8, 0), ModWorldBlocks.PLASMA_TURRET);
			placeTurretPad(world, base.method_10069(0, 8, 3), ModWorldBlocks.POINT_DEFENSE_TURRET);
		}

		// Inner ring volume turrets
		for (int i = 0; i < 6; i++) {
			double ang = i * Math.PI * 2 / 6;
			class_2338 t = center.method_10069((int) (Math.cos(ang) * 14), 2, (int) (Math.sin(ang) * 14));
			placeTurretPad(world, t, ModWorldBlocks.VOLUME_TURRET);
		}

		// Approach bridges toward outer islands
		for (int d = 28; d <= 48; d++) {
			world.method_8652(center.method_10069(d, 0, 0), class_2246.field_10462.method_9564(), class_2248.field_31028);
			world.method_8652(center.method_10069(-d, 0, 0), class_2246.field_10462.method_9564(), class_2248.field_31028);
			world.method_8652(center.method_10069(0, 0, d), class_2246.field_10462.method_9564(), class_2248.field_31028);
			world.method_8652(center.method_10069(0, 0, -d), class_2246.field_10462.method_9564(), class_2248.field_31028);
		}
	}

	private static void placeTurretPad(class_3218 world, class_2338 pad, class_2248 turret) {
		world.method_8652(pad, class_2246.field_10462.method_9564(), class_2248.field_31028);
		world.method_8652(pad.method_10084(), turret.method_9564(), class_2248.field_31036);
	}

	private static class_1511 spawnCrystal(class_3218 world, class_2338 at) {
		class_1511 c = net.minecraft.class_1299.field_6110.method_5883(world);
		if (c == null) return null;
		c.method_5808(at.method_10263() + 0.5, at.method_10264(), at.method_10260() + 0.5, 0, 0);
		c.method_6839(false);
		return c;
	}

	private static void spawnBoss(class_3218 world, class_2338 center) {
		EndReactorBossEntity boss = ModEntities.END_REACTOR_BOSS.method_5883(world);
		if (boss == null) return;
		boss.method_5808(center.method_10263() + 0.5, center.method_10264() + 10.0, center.method_10260() + 0.5, 0, 0);
		boss.setAnchor(new class_243(center.method_10263() + 0.5, center.method_10264() + 12.0, center.method_10260() + 0.5));
		world.method_8649(boss);

		ReactorKeeperEntity keeper = ModEntities.REACTOR_KEEPER.method_5883(world);
		if (keeper != null) {
			keeper.method_5808(center.method_10263() + 8.5, center.method_10264() + 12, center.method_10260() + 0.5, 0, 0);
			world.method_8649(keeper);
		}
	}

	/** Place exit gateways linked to Overworld spawn (dragon-analogue victory). */
	public static void placeExitGateways(class_3218 end, class_2338 at) {
		end.method_8652(at, class_2246.field_10081.method_9564(), class_2248.field_31036);
		class_3218 overworld = end.method_8503().method_3847(class_1937.field_25179);
		class_2338 exit = overworld != null ? overworld.method_43126() : class_2338.field_10980;
		for (int i = 0; i < 4; i++) {
			double ang = i * Math.PI * 0.5;
			class_2338 g = at.method_10069((int) (Math.cos(ang) * 6), 0, (int) (Math.sin(ang) * 6));
			end.method_8652(g, class_2246.field_10613.method_9564(), class_2248.field_31036);
			class_2586 be = end.method_8321(g);
			if (be instanceof class_2643 gateway) {
				gateway.method_11418(exit, true);
			}
		}
	}

	/** Count living End crystals near the island — shield while > 0. */
	public static int countShieldCrystals(class_3218 world) {
		return world.method_8390(class_1511.class,
				new net.minecraft.class_238(-40, 40, -40, 40, 120, 40),
				class_1511::method_5805).size();
	}
}
