package com.terminaldetector.drmd.world.end;

import com.terminaldetector.drmd.entity.ModEntities;
import com.terminaldetector.drmd.weapon.core.DamageClass;
import com.terminaldetector.drmd.weapon.core.WeaponCore;
import com.terminaldetector.drmd.weapon.fx.WeaponFx;
import com.terminaldetector.drmd.world.WorldRules;
import com.terminaldetector.drmd.world.fire.FireSystem;
import com.terminaldetector.drmd.world.gen2.MacroEntry;
import com.terminaldetector.drmd.world.gen2.MacroWorld;
import com.terminaldetector.drmd.world.smoke.SmokeSystem;
import java.util.UUID;
import net.minecraft.class_1259;
import net.minecraft.class_1282;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1588;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_3213;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3532;
import net.minecraft.class_5132;
import net.minecraft.class_5134;

/**
 * End mega-reactor core — dragon-analogue phases:
 * SHIELDED (invulnerable while End crystals alive) → EXPOSED → CRITICAL → DEFEATED.
 */
public class EndReactorBossEntity extends class_1588 {
	private final class_3213 bossBar = new class_3213(
			class_2561.method_43470("Giga-Reactor Core"), class_1259.class_1260.field_5783, class_1259.class_1261.field_5791);

	private UUID macroId;
	private class_243 anchor = class_243.field_1353;
	private float orbit;
	private int beamCd;
	private int pulseCd;

	public EndReactorBossEntity(class_1299<? extends EndReactorBossEntity> type, class_1937 world) {
		super(type, world);
		method_5875(true);
		method_5971();
	}

	public static class_5132.class_5133 createAttributes() {
		return class_1588.method_26918()
				.method_26868(class_5134.field_23716, 800)
				.method_26868(class_5134.field_23719, 0.15)
				.method_26868(class_5134.field_23717, 128)
				.method_26868(class_5134.field_23721, 22)
				.method_26868(class_5134.field_23718, 1.0)
				.method_26868(class_5134.field_23720, 0.2)
				.method_26868(class_5134.field_23724, 12);
	}

	public void setAnchor(class_243 a) { this.anchor = a; }

	@Override
	protected void method_5959() {}

	@Override
	public void method_5773() {
		super.method_5773();
		method_5875(true);
		if (!(method_37908() instanceof class_3218 sw)) return;

		if (anchor == class_243.field_1353) anchor = method_19538();
		EndReactorState state = EndReactorState.get(sw);
		int crystals = EndReactorSession.countShieldCrystals(sw);

		if (state.getPhase() != EndReactorState.Phase.DEFEATED) {
			if (crystals > 0) {
				if (state.getPhase() != EndReactorState.Phase.SHIELDED) state.setPhase(EndReactorState.Phase.SHIELDED);
			} else if (method_6032() / method_6063() < 0.35f) {
				state.setPhase(EndReactorState.Phase.CRITICAL);
			} else {
				state.setPhase(EndReactorState.Phase.EXPOSED);
			}
		}

		boolean shielded = crystals > 0;
		bossBar.method_5413(class_2561.method_43470(shielded
				? "Giga-Reactor · SHIELD (" + crystals + " crystals)"
				: (state.getPhase() == EndReactorState.Phase.CRITICAL
				? "Giga-Reactor · CRITICAL"
				: "Giga-Reactor · CORE EXPOSED")));
		bossBar.method_5408(class_3532.method_15363(method_6032() / method_6063(), 0f, 1f));
		bossBar.method_5416(shielded ? class_1259.class_1260.field_5780
				: (state.getPhase() == EndReactorState.Phase.CRITICAL ? class_1259.class_1260.field_5784 : class_1259.class_1260.field_5783));

		orbit += shielded ? 0.008f : 0.02f;
		double r = shielded ? 4.0 : 7.0;
		class_243 target = anchor.method_1031(Math.cos(orbit) * r, Math.sin(orbit * 0.7) * 2.5, Math.sin(orbit) * r);
		method_18799(target.method_1020(method_19538()).method_1021(0.08));
		field_6037 = true;

		if (beamCd > 0) beamCd--;
		if (pulseCd > 0) pulseCd--;

		class_1657 near = sw.method_18460(this, 64);
		if (near != null) {
			method_5980(near);
			lookAt(near);
			if (!shielded && beamCd <= 0 && method_5858(near) < 48 * 48) {
				fireBeam(sw, near);
				beamCd = state.getPhase() == EndReactorState.Phase.CRITICAL ? 18 : 32;
			}
			if (!shielded && pulseCd <= 0) {
				pulse(sw);
				pulseCd = state.getPhase() == EndReactorState.Phase.CRITICAL ? 60 : 100;
			}
		}

		if (field_6012 % 20 == 0) {
			sw.method_14199(shielded ? class_2398.field_11207 : class_2398.field_22246,
					method_23317(), method_23318() + 1.5, method_23321(), shielded ? 8 : 16, 1.2, 1.2, 1.2, 0.02);
		}

		if (macroId == null) macroId = UUID.randomUUID();
		MacroWorld.put(new MacroEntry(macroId, MacroEntry.Kind.KEEPER, WorldRules.Layer.END_SPACE,
				method_24515(), 32, 28, 32, 0xAA44FF, "End Giga-Reactor"));

		for (class_3222 p : bossBar.method_14092().toArray(new class_3222[0])) {
			if (!p.method_5805() || p.method_37908() != sw || method_5858(p) > 96 * 96) bossBar.method_14089(p);
		}
		for (class_3222 p : sw.method_18456()) {
			if (method_5858(p) < 80 * 80) bossBar.method_14088(p);
		}
	}

	private void lookAt(class_1309 e) {
		class_243 look = e.method_19538().method_1031(0, e.method_17682() * 0.5, 0).method_1020(method_19538());
		if (look.method_1027() < 1e-4) return;
		method_36456((float) (class_3532.method_15349(-look.field_1352, look.field_1350) * (180.0 / Math.PI)));
		method_36457((float) (class_3532.method_15349(-look.field_1351, Math.sqrt(look.field_1352 * look.field_1352 + look.field_1350 * look.field_1350)) * (180.0 / Math.PI)));
	}

	private void fireBeam(class_3218 sw, class_1309 target) {
		class_243 from = method_19538().method_1031(0, 1.5, 0);
		class_243 to = target.method_19538().method_1031(0, target.method_17682() * 0.5, 0);
		WeaponFx.beamExotic(sw, from, to);
		WeaponCore.directDamage(this, target, 14f, DamageClass.ENERGY);
		sw.method_8396(null, method_24515(), class_3417.field_19344, class_3419.field_15251, 1.2f, 0.6f);
	}

	private void pulse(class_3218 sw) {
		WeaponFx.explode(this, sw, method_19538(), 40f, 6f, DamageClass.EXPLOSIVE, false);
		FireSystem.igniteBlast(sw, method_24515(), 6, 4);
		SmokeSystem.emit(method_19538(), SmokeSystem.Source.REACTOR, 3f, 0.7f, 80);
		sw.method_60511(null, method_23317(), method_23318(), method_23321(), class_3417.field_15152, class_3419.field_15251, 1.5f, 0.5f);
	}

	@Override
	public boolean method_5643(class_1282 source, float amount) {
		if (!(method_37908() instanceof class_3218 sw)) return false;
		if (EndReactorSession.countShieldCrystals(sw) > 0) {
			if (field_6012 % 10 == 0) {
				sw.method_14199(class_2398.field_11208, method_23317(), method_23318() + 1, method_23321(), 12, 1, 1, 1, 0.1);
			}
			return false; // shield up — dragon crystal analogue
		}
		return super.method_5643(source, amount);
	}

	@Override
	public void method_6078(class_1282 damageSource) {
		super.method_6078(damageSource);
		if (!(method_37908() instanceof class_3218 sw)) return;
		EndReactorState state = EndReactorState.get(sw);
		state.setPhase(EndReactorState.Phase.DEFEATED);
		WeaponFx.explode(this, sw, method_19538(), 120f, 10f, DamageClass.EXPLOSIVE, true);
		SmokeSystem.emitExplosion(method_19538(), 6f);
		class_243 core = anchor.equals(class_243.field_1353) ? method_19538() : anchor;
		class_2338 pad = class_2338.method_49637(core.field_1352, core.field_1351 - 12.0, core.field_1350);
		EndReactorSession.placeExitGateways(sw, pad);
		for (class_3222 p : sw.method_18456()) {
			p.method_7353(class_2561.method_43470("§dGiga-Reactor destroyed §7— End exit gateways online."), false);
		}
		bossBar.method_14094();
	}

	@Override
	public void method_5650(class_5529 reason) {
		bossBar.method_14094();
		if (macroId != null) MacroWorld.remove(macroId);
		super.method_5650(reason);
	}

	@Override
	public void method_5652(class_2487 nbt) {
		super.method_5652(nbt);
		nbt.method_10549("ax", anchor.field_1352);
		nbt.method_10549("ay", anchor.field_1351);
		nbt.method_10549("az", anchor.field_1350);
		if (macroId != null) nbt.method_25927("macro", macroId);
	}

	@Override
	public void method_5749(class_2487 nbt) {
		super.method_5749(nbt);
		anchor = new class_243(nbt.method_10574("ax"), nbt.method_10574("ay"), nbt.method_10574("az"));
		if (nbt.method_25928("macro")) macroId = nbt.method_25926("macro");
	}

	@Override
	public boolean method_5753() { return true; }

	@Override
	public boolean method_17326() { return true; }
}
