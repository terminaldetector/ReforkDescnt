package com.terminaldetector.drmd.world.end;

import net.minecraft.class_18;
import net.minecraft.class_2487;
import net.minecraft.class_26;
import net.minecraft.class_3218;
import net.minecraft.class_7225;

/** Persistent End mega-reactor fight flags. */
public class EndReactorState extends class_18 {
	public static final String ID = "drmd_end_reactor";

	public enum Phase { SHIELDED, EXPOSED, CRITICAL, DEFEATED }

	private boolean baseGenerated;
	private Phase phase = Phase.SHIELDED;

	public static EndReactorState get(class_3218 world) {
		class_26 mgr = world.method_17983();
		return mgr.method_17924(new class_8645<>(EndReactorState::new, EndReactorState::fromNbt, null), ID);
	}

	public EndReactorState() {}

	public static EndReactorState fromNbt(class_2487 nbt, class_7225.class_7874 lookup) {
		EndReactorState s = new EndReactorState();
		s.baseGenerated = nbt.method_10577("base");
		try {
			s.phase = Phase.valueOf(nbt.method_10558("phase"));
		} catch (Exception e) {
			s.phase = Phase.SHIELDED;
		}
		return s;
	}

	@Override
	public class_2487 method_75(class_2487 nbt, class_7225.class_7874 registryLookup) {
		nbt.method_10556("base", baseGenerated);
		nbt.method_10582("phase", phase.name());
		return nbt;
	}

	public boolean isBaseGenerated() { return baseGenerated; }
	public void setBaseGenerated(boolean v) { this.baseGenerated = v; method_80(); }

	public Phase getPhase() { return phase; }
	public void setPhase(Phase p) { this.phase = p; method_80(); }

	public boolean isDefeated() { return phase == Phase.DEFEATED; }
}
