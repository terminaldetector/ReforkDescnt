package com.terminaldetector.drmd.world.atmosphere;

import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_3218;

/**
 * Lightweight atmospheric rules applied near players / bombs — keep MC recognizable.
 */
public final class AtmosphereRules {
	private AtmosphereRules() {}

	/** Near-space: convert free water sources to vapor particles / air (game rule). */
	public static void tickWaterSuppression(class_3218 world, class_2338 center, int radius) {
		AtmosphereBand band = AtmosphereBand.at(center.method_10264());
		if (!band.suppressFreeWater) return;
		class_2338.class_2339 m = new class_2338.class_2339();
		for (int dx = -radius; dx <= radius; dx++) {
			for (int dy = -2; dy <= 2; dy++) {
				for (int dz = -radius; dz <= radius; dz++) {
					m.method_10103(center.method_10263() + dx, center.method_10264() + dy, center.method_10260() + dz);
					if (world.method_8320(m).method_27852(class_2246.field_10382)) {
						world.method_8501(m, class_2246.field_10124.method_9564());
						world.method_14199(net.minecraft.class_2398.field_11204,
								m.method_10263() + 0.5, m.method_10264() + 0.5, m.method_10260() + 0.5,
								4, 0.2, 0.2, 0.2, 0.01);
					}
				}
			}
		}
	}

	/** Deep pressure: occasional steam vents near magma. */
	public static void tickDeepPressure(class_3218 world, class_2338 center) {
		if (AtmosphereBand.at(center.method_10264()) != AtmosphereBand.DEEP_PRESSURE) return;
		if (world.method_8409().method_43048(40) != 0) return;
		class_2338.class_2339 m = new class_2338.class_2339();
		for (int i = 0; i < 8; i++) {
			m.method_10103(center.method_10263() + world.method_8409().method_43048(9) - 4,
					center.method_10264() + world.method_8409().method_43048(5) - 2,
					center.method_10260() + world.method_8409().method_43048(9) - 4);
			if (world.method_8320(m).method_27852(class_2246.field_10164) || world.method_8320(m).method_27852(class_2246.field_10092)) {
				class_2338 above = m.method_10084();
				if (world.method_8320(above).method_26215()) {
					world.method_14199(net.minecraft.class_2398.field_11237,
							above.method_10263() + 0.5, above.method_10264(), above.method_10260() + 0.5,
							8, 0.3, 0.5, 0.3, 0.02);
					world.method_14199(net.minecraft.class_2398.field_11204,
							above.method_10263() + 0.5, above.method_10264() + 0.5, above.method_10260() + 0.5,
							6, 0.2, 0.3, 0.2, 0.01);
				}
				return;
			}
		}
	}

	/** Amplify explosion power by band (tunnel shockwaves in deep pressure). */
	public static float scaleBlast(double y, float base) {
		return base * AtmosphereBand.at(y).blastScale;
	}
}
