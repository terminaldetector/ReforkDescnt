package com.terminaldetector.drmd.world.gen;

import com.mojang.serialization.Codec;
import com.terminaldetector.drmd.world.WorldRules;
import net.minecraft.class_1923;
import net.minecraft.class_2338;
import net.minecraft.class_3031;
import net.minecraft.class_3111;
import net.minecraft.class_5281;
import net.minecraft.class_5821;

/**
 * Chunk feature: rare Industrial Underground complexes.
 * Volume-first cavities + artificial modules — no privileged floor.
 */
public class IndustrialUndergroundFeature extends class_3031<class_3111> {
	public IndustrialUndergroundFeature(Codec<class_3111> codec) {
		super(codec);
	}

	@Override
	public boolean method_13151(class_5821<class_3111> context) {
		class_5281 world = context.method_33652();
		class_2338 origin = context.method_33655();
		class_1923 chunk = new class_1923(origin);

		if ((Math.floorMod(chunk.field_9181 * 734287 + chunk.field_9180 * 912391, 24)) != 0) return false;

		int y = WorldRules.INDUSTRIAL_Y_MIN + 20 + world.method_8409().method_43048(24);
		class_2338 center = new class_2338(chunk.method_8326() + 8, y, chunk.method_8328() + 8);

		WorldRules.ComplexStyle[] styles = WorldRules.ComplexStyle.values();
		WorldRules.ComplexStyle style = styles[world.method_8409().method_43048(styles.length)];

		IndustrialComplexGenerator.generateAt(world, center, style, world.method_8409());
		return true;
	}
}
