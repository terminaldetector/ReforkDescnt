package com.terminaldetector.drmd.world.gen;

import com.terminaldetector.drmd.DescentMod;
import com.terminaldetector.drmd.ai.AiRole;
import com.terminaldetector.drmd.entity.DroneEntity;
import com.terminaldetector.drmd.entity.ModEntities;
import com.terminaldetector.drmd.world.WorldRules;
import com.terminaldetector.drmd.world.gen2.MacroEntry;
import com.terminaldetector.drmd.world.gen2.MacroWorld;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerChunkEvents;
import net.minecraft.class_1923;
import net.minecraft.class_2338;
import net.minecraft.class_2378;
import net.minecraft.class_2818;
import net.minecraft.class_2960;
import net.minecraft.class_3031;
import net.minecraft.class_3111;
import net.minecraft.class_3218;
import net.minecraft.class_7923;
import java.util.UUID;

/**
 * Industrial Underground — stock worldgen (~1 complex / 12 chunks) + garrison drones.
 */
public final class ModWorldgen {
	public static final class_3031<class_3111> INDUSTRIAL =
			new IndustrialUndergroundFeature(class_3111.field_24893);

	private static final AiRole[] GARRISON = {
			AiRole.ASSAULT, AiRole.INTERCEPTOR, AiRole.MG, AiRole.LASER, AiRole.RPG,
			AiRole.ARTILLERY, AiRole.SUPPORT, AiRole.HEAVY, AiRole.SEEKER, AiRole.HEAVY_ELITE
	};

	private ModWorldgen() {}

	public static void register() {
		class_2378.method_10230(class_7923.field_41144, class_2960.method_60655(DescentMod.MOD_ID, "industrial_underground"), INDUSTRIAL);
		ServerChunkEvents.CHUNK_LOAD.register(ModWorldgen::onChunkLoad);
		DescentMod.LOGGER.info("Registered Industrial Underground worldgen (stock density)");
	}

	private static void onChunkLoad(class_3218 world, class_2818 chunk) {
		if (world.method_27983() != class_3218.field_25179) return;
		class_1923 cp = chunk.method_12004();
		long seed = world.method_8412() ^ (((long) cp.field_9181) << 32) ^ cp.field_9180;
		// Stock density: ~1 complex per 12 chunks
		if (Math.floorMod(seed * 31L, 12L) != 0L) return;
		int y = WorldRules.INDUSTRIAL_Y_MIN + 24 + (int) Math.floorMod(seed, 16L);
		class_2338 center = new class_2338(cp.method_8326() + 8, y, cp.method_8328() + 8);
		if (world.method_8320(center).method_27852(net.minecraft.class_2246.field_10327)) return;
		if (!world.method_8320(center).method_26215() && world.method_8320(center).method_26212(world, center)) {
			WorldRules.ComplexStyle[] styles = WorldRules.ComplexStyle.values();
			WorldRules.ComplexStyle style = styles[(int) Math.floorMod(seed, styles.length)];
			world.method_8503().execute(() -> forceGenerate(world, center, style));
		}
	}

	public static void forceGenerate(class_3218 world, class_2338 pos, WorldRules.ComplexStyle style) {
		IndustrialComplexGenerator.generateAt(world, pos, style, world.method_8409());
		MacroWorld.put(new MacroEntry(UUID.randomUUID(), MacroEntry.Kind.INDUSTRIAL_COMPLEX,
				WorldRules.Layer.DEPTH_REACTORS, pos.method_10062(), 56, 48, 56, 0x6688AA, "Industrial " + style));
		spawnGarrison(world, pos);
	}

	private static void spawnGarrison(class_3218 world, class_2338 center) {
		int n = 3 + world.method_8409().method_43048(3);
		for (int i = 0; i < n; i++) {
			DroneEntity drone = ModEntities.DRONE.method_5883(world);
			if (drone == null) continue;
			AiRole role = GARRISON[world.method_8409().method_43048(GARRISON.length)];
			double ang = world.method_8409().method_43058() * Math.PI * 2;
			drone.method_5808(
					center.method_10263() + Math.cos(ang) * 10,
					center.method_10264() + (world.method_8409().method_43058() - 0.5) * 8,
					center.method_10260() + Math.sin(ang) * 10,
					0, 0);
			drone.applyRole(role);
			world.method_8649(drone);
		}
	}
}
