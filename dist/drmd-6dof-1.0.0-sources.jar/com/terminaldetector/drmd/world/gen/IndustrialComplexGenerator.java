package com.terminaldetector.drmd.world.gen;

import com.terminaldetector.drmd.world.WorldRules;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_5819;

/**
 * Industrial Underground — modular 6DoF complexes.
 * Cavities first: spheres, cylinders, rings, vertical shafts, multi-node intersections.
 * No privileged floor — every surface is traversable in flight.
 */
public final class IndustrialComplexGenerator {
	private IndustrialComplexGenerator() {}

	private static boolean inLimit(net.minecraft.class_1936 world, class_2338 pos) {
		int y = pos.method_10264();
		return y >= world.method_31607() && y < world.method_31607() + world.method_31605();
	}


	public static void generateAt(net.minecraft.class_1936 world, class_2338 origin, WorldRules.ComplexStyle style, class_5819 random) {
		clearVolume(world, origin, 28);
		carveSphere(world, origin, 18 + random.method_43048(6));
		placeReactorCore(world, origin, style);
		placeSpinRings(world, origin, 12, 2);
		placeCoolingChannels(world, origin, random);
		placeTechnicalBridges(world, origin, random);
		placeModuleSpokes(world, origin, random);
		placeEntrances(world, origin);

		// Satellite nodes for 3D route choice
		for (class_2350 dir : class_2350.values()) {
			if (random.method_43057() < 0.55f) {
				class_2338 node = origin.method_10079(dir, 22 + random.method_43048(8));
				carveSphere(world, node, 8 + random.method_43048(4));
				carveCylinder(world, origin, node, 3);
				if (random.method_43056()) placeHabitationCube(world, node, style);
				else placeStorageHoneycomb(world, node, random);
			}
		}

		// Vertical shaft + spiral for multilayer movement
		carveVerticalShaft(world, origin, 40);
		carveSpiral(world, origin.method_10069(8, -10, 8), 10, 24);
	}

	public static void clearVolume(net.minecraft.class_1936 world, class_2338 c, int r) {
		class_2338.class_2339 m = new class_2338.class_2339();
		for (int x = -r; x <= r; x++) {
			for (int y = -r; y <= r; y++) {
				for (int z = -r; z <= r; z++) {
					if (x * x + y * y + z * z > r * r) continue;
					m.method_10103(c.method_10263() + x, c.method_10264() + y, c.method_10260() + z);
					if (inLimit(world, m)) world.method_8652(m, class_2246.field_10124.method_9564(), class_2248.field_31028);
				}
			}
		}
	}

	public static void carveSphere(net.minecraft.class_1936 world, class_2338 c, int r) {
		class_2338.class_2339 m = new class_2338.class_2339();
		int r2 = r * r;
		int shell = (r - 1) * (r - 1);
		class_2680 wall = class_2246.field_28900.method_9564();
		class_2680 lamp = class_2246.field_10174.method_9564();
		for (int x = -r; x <= r; x++) {
			for (int y = -r; y <= r; y++) {
				for (int z = -r; z <= r; z++) {
					int d = x * x + y * y + z * z;
					if (d > r2) continue;
					m.method_10103(c.method_10263() + x, c.method_10264() + y, c.method_10260() + z);
					if (!inLimit(world, m)) continue;
					if (d >= shell) {
						world.method_8652(m, wall, class_2248.field_31028);
						if ((x + y + z) % 7 == 0) world.method_8652(m, lamp, class_2248.field_31028);
					} else {
						world.method_8652(m, class_2246.field_10124.method_9564(), class_2248.field_31028);
					}
				}
			}
		}
	}

	public static void carveCylinder(net.minecraft.class_1936 world, class_2338 a, class_2338 b, int radius) {
		VecLine line = VecLine.of(a, b);
		class_2338.class_2339 m = new class_2338.class_2339();
		class_2680 wall = class_2246.field_28892.method_9564();
		for (float t = 0; t <= 1f; t += 1f / Math.max(1, line.length())) {
			class_2338 c = line.at(t);
			for (int x = -radius; x <= radius; x++) {
				for (int y = -radius; y <= radius; y++) {
					for (int z = -radius; z <= radius; z++) {
						if (x * x + y * y + z * z > radius * radius) continue;
						// Keep tube hollow along dominant axis of travel
						m.method_10103(c.method_10263() + x, c.method_10264() + y, c.method_10260() + z);
						if (!inLimit(world, m)) continue;
						int d = x * x + y * y + z * z;
						if (d >= (radius - 1) * (radius - 1) && d <= radius * radius) {
							world.method_8652(m, wall, class_2248.field_31028);
						} else {
							world.method_8652(m, class_2246.field_10124.method_9564(), class_2248.field_31028);
						}
					}
				}
			}
		}
	}

	public static void carveVerticalShaft(net.minecraft.class_1936 world, class_2338 c, int halfHeight) {
		class_2338.class_2339 m = new class_2338.class_2339();
		for (int y = -halfHeight; y <= halfHeight; y++) {
			for (int x = -3; x <= 3; x++) {
				for (int z = -3; z <= 3; z++) {
					m.method_10103(c.method_10263() + x, c.method_10264() + y, c.method_10260() + z);
					if (!inLimit(world, m)) continue;
					int d = x * x + z * z;
					if (d <= 4) world.method_8652(m, class_2246.field_10124.method_9564(), class_2248.field_31028);
					else if (d <= 9) world.method_8652(m, class_2246.field_28896.method_9564(), class_2248.field_31028);
				}
			}
		}
	}

	public static void carveSpiral(net.minecraft.class_1936 world, class_2338 base, int radius, int height) {
		class_2338.class_2339 m = new class_2338.class_2339();
		for (int i = 0; i < height * 8; i++) {
			double ang = i * 0.35;
			int y = i / 4;
			int x = (int) (Math.cos(ang) * radius);
			int z = (int) (Math.sin(ang) * radius);
			for (int ox = -2; ox <= 2; ox++) {
				for (int oz = -2; oz <= 2; oz++) {
					m.method_10103(base.method_10263() + x + ox, base.method_10264() + y, base.method_10260() + z + oz);
					if (inLimit(world, m)) {
						world.method_8652(m, class_2246.field_10124.method_9564(), class_2248.field_31028);
					}
				}
			}
			m.method_10103(base.method_10263() + x, base.method_10264() + y - 1, base.method_10260() + z);
			if (inLimit(world, m)) {
				world.method_8652(m, class_2246.field_27119.method_9564(), class_2248.field_31028);
			}
		}
	}

	private static void placeReactorCore(net.minecraft.class_1936 world, class_2338 c, WorldRules.ComplexStyle style) {
		class_2680 core = switch (style) {
			case CRYSTAL_REACTOR -> class_2246.field_27159.method_9564();
			case ANCIENT_POWER -> class_2246.field_22423.method_9564();
			case SMELTERY -> class_2246.field_10092.method_9564();
			default -> class_2246.field_23152.method_9564();
		};
		class_2338.class_2339 m = new class_2338.class_2339();
		for (int x = -2; x <= 2; x++) {
			for (int y = -2; y <= 2; y++) {
				for (int z = -2; z <= 2; z++) {
					if (x * x + y * y + z * z <= 6) {
						m.method_10103(c.method_10263() + x, c.method_10264() + y, c.method_10260() + z);
						world.method_8652(m, core, class_2248.field_31028);
					}
				}
			}
		}
		world.method_8652(c, class_2246.field_10327.method_9564(), class_2248.field_31036);
	}

	private static void placeSpinRings(net.minecraft.class_1936 world, class_2338 c, int radius, int thickness) {
		class_2338.class_2339 m = new class_2338.class_2339();
		class_2680 ring = class_2246.field_10085.method_9564();
		for (int a = 0; a < 360; a += 3) {
			double rad = Math.toRadians(a);
			for (int t = 0; t < thickness; t++) {
				int x = (int) (Math.cos(rad) * (radius + t));
				int z = (int) (Math.sin(rad) * (radius + t));
				m.method_10103(c.method_10263() + x, c.method_10264(), c.method_10260() + z);
				world.method_8652(m, ring, class_2248.field_31028);
				m.method_10103(c.method_10263() + x, c.method_10264() + 1, c.method_10260() + z);
				world.method_8652(m, ring, class_2248.field_31028);
			}
		}
	}

	private static void placeCoolingChannels(net.minecraft.class_1936 world, class_2338 c, class_5819 random) {
		for (int i = 0; i < 4; i++) {
			class_2350 d = class_2350.class_2353.field_11062.method_10183(random);
			class_2338 start = c.method_10079(d, 4).method_10086(random.method_43048(3) - 1);
			for (int s = 0; s < 14; s++) {
				class_2338 p = start.method_10079(d, s);
				world.method_8652(p, class_2246.field_10384.method_9564(), class_2248.field_31028);
				world.method_8652(p.method_10084(), class_2246.field_10124.method_9564(), class_2248.field_31028);
			}
		}
	}

	private static void placeTechnicalBridges(net.minecraft.class_1936 world, class_2338 c, class_5819 random) {
		for (class_2350 d : class_2350.class_2353.field_11062) {
			for (int i = 4; i < 16; i++) {
				class_2338 p = c.method_10079(d, i);
				world.method_8652(p, class_2246.field_10576.method_9564(), class_2248.field_31028);
				if (i % 4 == 0) {
					world.method_8652(p.method_10084(), class_2246.field_16541.method_9564(), class_2248.field_31028);
				}
			}
		}
	}

	private static void placeModuleSpokes(net.minecraft.class_1936 world, class_2338 c, class_5819 random) {
		WorldRules.ModuleType[] mods = WorldRules.ModuleType.values();
		for (int i = 0; i < 3; i++) {
			class_2350 d = class_2350.class_2353.field_11062.method_10183(random);
			class_2338 node = c.method_10079(d, 18).method_10086(random.method_43048(5) - 2);
			carveSphere(world, node, 6);
			carveCylinder(world, c, node, 2);
			WorldRules.ModuleType type = mods[random.method_43048(mods.length)];
			class_2680 fill = switch (type) {
				case HABITATION -> class_2246.field_10107.method_9564();
				case STORAGE -> class_2246.field_16328.method_9564();
				case COMMAND -> class_2246.field_10525.method_9564();
				case COOLING -> class_2246.field_10225.method_9564();
				case REPAIR_HANGAR -> class_2246.field_10535.method_9564();
				case POWER_SPINE -> class_2246.field_10002.method_9564();
				case EVAC_TUNNEL -> class_2246.field_10421.method_9564();
				default -> class_2246.field_47072.method_9564();
			};
			world.method_8652(node, fill, class_2248.field_31028);
		}
	}

	private static void placeEntrances(net.minecraft.class_1936 world, class_2338 c) {
		for (class_2350 d : class_2350.values()) {
			class_2338 p = c.method_10079(d, 17);
			carveCylinder(world, p, p.method_10079(d, 6), 3);
		}
	}

	private static void placeHabitationCube(net.minecraft.class_1936 world, class_2338 c, WorldRules.ComplexStyle style) {
		class_2338.class_2339 m = new class_2338.class_2339();
		for (int x = -4; x <= 4; x++) {
			for (int y = -4; y <= 4; y++) {
				for (int z = -4; z <= 4; z++) {
					m.method_10103(c.method_10263() + x, c.method_10264() + y, c.method_10260() + z);
					boolean shell = Math.abs(x) == 4 || Math.abs(y) == 4 || Math.abs(z) == 4;
					if (shell) world.method_8652(m, class_2246.field_10172.method_9564(), class_2248.field_31028);
					else world.method_8652(m, class_2246.field_10124.method_9564(), class_2248.field_31028);
				}
			}
		}
	}

	private static void placeStorageHoneycomb(net.minecraft.class_1936 world, class_2338 c, class_5819 random) {
		for (int i = 0; i < 7; i++) {
			double ang = i * (Math.PI * 2 / 7);
			class_2338 p = c.method_10069((int) (Math.cos(ang) * 4), (i % 3) - 1, (int) (Math.sin(ang) * 4));
			carveSphere(world, p, 3);
			world.method_8652(p, class_2246.field_16328.method_9564(), class_2248.field_31028);
		}
	}

	private record VecLine(class_2338 a, class_2338 b) {
		static VecLine of(class_2338 a, class_2338 b) { return new VecLine(a, b); }
		int length() {
			return (int) Math.sqrt(a.method_10262(b));
		}
		class_2338 at(float t) {
			return class_2338.method_49637(
					a.method_10263() + (b.method_10263() - a.method_10263()) * t,
					a.method_10264() + (b.method_10264() - a.method_10264()) * t,
					a.method_10260() + (b.method_10260() - a.method_10260()) * t);
		}
	}
}
