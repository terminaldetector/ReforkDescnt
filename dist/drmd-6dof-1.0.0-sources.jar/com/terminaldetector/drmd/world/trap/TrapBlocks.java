package com.terminaldetector.drmd.world.trap;

import com.terminaldetector.drmd.DescentPlayerData;
import com.terminaldetector.drmd.world.LocalOrientation;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2746;
import net.minecraft.class_2758;
import net.minecraft.class_3218;
import net.minecraft.class_5819;

/**
 * Navigation-centric traps for Industrial Underground:
 * hermetic gates, laser barriers, volume turrets, magnetic anomalies.
 */
public final class TrapBlocks {
	private TrapBlocks() {}

	/** Closing hermetic blast door — toggles solid/open on schedule. */
	public static class HermeticGateBlock extends class_2248 {
		public static final class_2746 OPEN = class_2746.method_11825("open");
		public static final class_2758 CYCLE = class_2758.method_11867("cycle", 0, 15);

		public HermeticGateBlock(class_2251 settings) {
			super(settings);
			method_9590(method_9595().method_11664().method_11657(OPEN, true).method_11657(CYCLE, 0));
		}

		@Override
		protected void method_9515(class_2689.class_2690<class_2248, class_2680> b) {
			b.method_11667(OPEN, CYCLE);
		}

		@Override
		protected boolean method_9542(class_2680 state) { return true; }

		@Override
		protected void method_9514(class_2680 state, class_3218 world, class_2338 pos, class_5819 random) {
			boolean open = !state.method_11654(OPEN);
			world.method_8652(pos, state.method_11657(OPEN, open).method_11657(CYCLE, (state.method_11654(CYCLE) + 1) & 15), class_2248.field_31036);
			// Expand gate plane
			class_2350.class_2351 axis = class_2350.class_2351.field_11048;
			for (int i = -2; i <= 2; i++) {
				for (int j = -2; j <= 2; j++) {
					class_2338 p = pos.method_10069(0, i, j);
					if (p.equals(pos)) continue;
					if (open) world.method_8652(p, class_2246.field_10124.method_9564(), class_2248.field_31028);
					else if (world.method_8320(p).method_26215()) {
						world.method_8652(p, class_2246.field_10085.method_9564(), class_2248.field_31028);
					}
				}
			}
		}
	}

	/** Laser barrier — damages entities crossing the volume along a line. */
	public static class LaserBarrierBlock extends class_2248 {
		public LaserBarrierBlock(class_2251 settings) {
			super(settings.method_22488().method_9634());
		}

		@Override
		protected void method_9548(class_2680 state, class_1937 world, class_2338 pos, class_1297 entity) {
			if (!world.field_9236 && entity instanceof class_1309 living) {
				living.method_5643(world.method_48963().method_48831(), 4f);
				if (world instanceof class_3218 sw) {
					sw.method_14199(class_2398.field_11207, pos.method_10263() + 0.5, pos.method_10264() + 0.5, pos.method_10260() + 0.5,
							4, 0.2, 0.2, 0.2, 0.01);
				}
			}
		}

		@Override
		protected boolean method_9542(class_2680 state) { return true; }

		@Override
		protected void method_9514(class_2680 state, class_3218 world, class_2338 pos, class_5819 random) {
			// Extend laser beam through air along local look of placement (Y axis default)
			for (int i = 1; i <= 8; i++) {
				class_2338 p = pos.method_10086(i);
				if (!world.method_8320(p).method_26215()) break;
				class_238 box = new class_238(p);
				for (class_1309 e : world.method_8390(class_1309.class, box, class_1309::method_5805)) {
					e.method_5643(world.method_48963().method_48831(), 3f);
				}
				world.method_14199(class_2398.field_11205, p.method_10263() + 0.5, p.method_10264() + 0.5, p.method_10260() + 0.5, 1, 0, 0, 0, 0);
			}
		}
	}

	/** Volume turret — periodically damages nearest flyer in a spherical radius. */
	public static class VolumeTurretBlock extends class_2248 {
		public VolumeTurretBlock(class_2251 settings) {
			super(settings);
		}

		@Override
		protected boolean method_9542(class_2680 state) { return true; }

		@Override
		protected void method_9514(class_2680 state, class_3218 world, class_2338 pos, class_5819 random) {
			class_238 volume = new class_238(pos).method_1014(12);
			class_1309 target = null;
			double best = Double.MAX_VALUE;
			for (class_1309 e : world.method_8390(class_1309.class, volume, class_1309::method_5805)) {
				double d = e.method_5707(class_243.method_24953(pos));
				if (d < best) { best = d; target = e; }
			}
			if (target != null) {
				target.method_5643(world.method_48963().method_48831(), 6f);
				world.method_14199(class_2398.field_11240,
						target.method_23317(), target.method_23318() + target.method_17682() * 0.5, target.method_23321(),
						8, 0.2, 0.2, 0.2, 0.02);
			}
		}
	}

	/**
	 * Magnetic anomaly — redefines local UP for nearby 6DoF players.
	 * Navigation hazard: orientation flips, not just damage.
	 */
	public static class MagneticAnomalyBlock extends class_2248 {
		public MagneticAnomalyBlock(class_2251 settings) {
			super(settings.method_9631(s -> 8));
		}

		@Override
		protected void method_9548(class_2680 state, class_1937 world, class_2338 pos, class_1297 entity) {
			if (world.field_9236 || !(entity instanceof class_1657 player)) return;
			DescentPlayerData data = DescentPlayerData.get(player);
			if (!data.isEnabled()) return;
			// Pull local up toward vector from player to block (attract) or away (repel)
			class_243 to = class_243.method_24953(pos).method_1020(player.method_19538()).method_1029();
			LocalOrientation.setUp(player.method_5667(), to);
			player.method_5762(to.field_1352 * 0.15, to.field_1351 * 0.15, to.field_1350 * 0.15);
			player.field_6037 = true;
		}

		@Override
		protected boolean method_9542(class_2680 state) { return true; }

		@Override
		protected void method_9514(class_2680 state, class_3218 world, class_2338 pos, class_5819 random) {
			class_238 volume = new class_238(pos).method_1014(8);
			class_2350 dir = class_2350.method_10162(random);
			for (class_1657 p : world.method_8390(class_1657.class, volume, class_1657::method_5805)) {
				if (DescentPlayerData.get(p).isEnabled()) {
					LocalOrientation.setFromDirection(p.method_5667(), dir);
					world.method_14199(class_2398.field_23190,
							p.method_23317(), p.method_23318(), p.method_23321(), 6, 0.3, 0.3, 0.3, 0.02);
				}
			}
		}
	}

	/** Unstable reactor zone — periodic knockback + light damage in volume. */
	public static class UnstableReactorBlock extends class_2248 {
		public UnstableReactorBlock(class_2251 settings) {
			super(settings.method_9631(s -> 12));
		}

		@Override
		protected boolean method_9542(class_2680 state) { return true; }

		@Override
		protected void method_9514(class_2680 state, class_3218 world, class_2338 pos, class_5819 random) {
			class_238 volume = new class_238(pos).method_1014(6);
			world.method_14199(class_2398.field_17909, pos.method_10263() + 0.5, pos.method_10264() + 0.5, pos.method_10260() + 0.5, 1, 0, 0, 0, 0);
			com.terminaldetector.drmd.world.smoke.SmokeSystem.emit(
					class_243.method_24953(pos), com.terminaldetector.drmd.world.smoke.SmokeSystem.Source.REACTOR, 2.5f, 0.85f, 100);
			if (random.method_43048(3) == 0) {
				com.terminaldetector.drmd.world.fire.FireSystem.igniteBlast(world, pos, 4, 3);
			}
			world.method_14199(class_2398.field_11237,
					pos.method_10263() + 0.5, pos.method_10264() + 1, pos.method_10260() + 0.5, 20, 1.5, 1.0, 1.5, 0.02);
			for (class_1309 e : world.method_8390(class_1309.class, volume, class_1309::method_5805)) {
				e.method_5643(world.method_48963().method_48819(null, null), 8f);
				class_243 push = e.method_19538().method_1020(class_243.method_24953(pos)).method_1029().method_1021(1.2);
				e.method_5762(push.field_1352, push.field_1351, push.field_1350);
				e.field_6037 = true;
			}
			// Emergency lighting cue — redstone lamp flash nearby
			for (class_2338 p : class_2338.method_10097(pos.method_10069(-4, -2, -4), pos.method_10069(4, 4, 4))) {
				if (world.method_8320(p).method_27852(class_2246.field_10524) && random.method_43056()) {
					world.method_14199(class_2398.field_11240,
							p.method_10263() + 0.5, p.method_10264() + 0.5, p.method_10260() + 0.5, 2, 0.1, 0.1, 0.1, 0.01);
				}
			}
		}
	}
}
