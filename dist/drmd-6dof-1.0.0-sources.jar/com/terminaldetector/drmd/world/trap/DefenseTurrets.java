package com.terminaldetector.drmd.world.trap;

import com.terminaldetector.drmd.entity.PyroShipEntity;
import com.terminaldetector.drmd.weapon.core.DamageClass;
import com.terminaldetector.drmd.weapon.core.WeaponCore;
import com.terminaldetector.drmd.weapon.fx.WeaponFx;
import com.terminaldetector.drmd.world.end.EndReactorBossEntity;
import com.terminaldetector.drmd.world.mega.ReactorKeeperEntity;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_4538;
import net.minecraft.class_5819;
import org.joml.Vector3f;

/**
 * Active defense turrets — scheduled ticks for reliable RoF; prioritize intruders (players).
 * Skips Pyro GX and base allies (giga-reactor / keepers).
 */
public final class DefenseTurrets {
	private DefenseTurrets() {}

	public abstract static class BaseTurretBlock extends class_2248 {
		protected final float damage;
		protected final double range;
		protected final Vector3f beamColor;
		protected final DamageClass dmgClass;
		protected final int interval;

		protected BaseTurretBlock(class_2251 settings, float damage, double range, Vector3f beamColor,
								  DamageClass dmgClass, int intervalTicks) {
			super(settings);
			this.damage = damage;
			this.range = range;
			this.beamColor = beamColor;
			this.dmgClass = dmgClass;
			this.interval = intervalTicks;
		}

		@Override
		protected void method_9615(class_2680 state, class_1937 world, class_2338 pos, class_2680 oldState, boolean notify) {
			super.method_9615(state, world, pos, oldState, notify);
			if (!world.field_9236) world.method_39279(pos, this, interval);
		}

		@Override
		protected void method_9588(class_2680 state, class_3218 world, class_2338 pos, class_5819 random) {
			fire(world, pos);
			world.method_39279(pos, this, interval);
		}

		@Override
		protected boolean method_9542(class_2680 state) { return true; }

		@Override
		protected void method_9514(class_2680 state, class_3218 world, class_2338 pos, class_5819 random) {
			// Backup if schedule was lost (chunk reload edge cases)
			fire(world, pos);
			world.method_39279(pos, this, interval);
		}

		protected void fire(class_3218 world, class_2338 pos) {
			class_1309 target = pickTarget(world, pos);
			if (target == null) return;
			class_243 from = class_243.method_24953(pos).method_1031(0, 0.6, 0);
			class_243 to = target.method_19538().method_1031(0, target.method_17682() * 0.5, 0);
			WeaponFx.beam(world, from, to, beamColor, 1.05f);
			target.method_5643(world.method_48963().method_48831(), damage);
			onHit(world, pos, target);
			world.method_8396(null, pos, class_3417.field_14703, class_3419.field_15245, 0.35f, pitch());
		}

		protected void onHit(class_3218 world, class_2338 pos, class_1309 target) {}

		protected float pitch() { return 1.4f; }

		protected class_1309 pickTarget(class_3218 world, class_2338 pos) {
			class_238 box = new class_238(pos).method_1014(range);
			class_1309 bestPlayer = null;
			class_1309 bestOther = null;
			double bestP = Double.MAX_VALUE, bestO = Double.MAX_VALUE;
			class_243 origin = class_243.method_24953(pos);
			for (class_1309 e : world.method_8390(class_1309.class, box, this::isValidTarget)) {
				double d = e.method_5707(origin);
				if (e instanceof class_1657) {
					if (d < bestP) { bestP = d; bestPlayer = e; }
				} else if (d < bestO) {
					bestO = d;
					bestOther = e;
				}
			}
			return bestPlayer != null ? bestPlayer : bestOther;
		}

		protected boolean isValidTarget(class_1309 e) {
			if (!e.method_5805()) return false;
			if (e instanceof PyroShipEntity) return false;
			if (e instanceof EndReactorBossEntity) return false;
			if (e instanceof ReactorKeeperEntity) return false;
			if (e instanceof class_1657 p && (p.method_7337() || p.method_7325())) return false;
			return true;
		}

		@Override
		protected boolean method_9558(class_2680 state, class_4538 world, class_2338 pos) {
			return true;
		}
	}

	/** Long green laser — melts soft blocks on hit. */
	public static class LaserTurretBlock extends BaseTurretBlock {
		public LaserTurretBlock(class_2251 settings) {
			super(settings, 7f, 18, new Vector3f(0.3f, 1f, 0.45f), DamageClass.ENERGY, 12);
		}

		@Override
		protected void onHit(class_3218 world, class_2338 pos, class_1309 target) {
			WeaponFx.melt(world, target.method_24515(), 1, target);
			world.method_14199(class_2398.field_11207, target.method_23317(), target.method_23318() + 1, target.method_23321(),
					4, 0.2, 0.3, 0.2, 0.01);
		}
	}

	/** Purple plasma bolts — splash. */
	public static class PlasmaTurretBlock extends BaseTurretBlock {
		public PlasmaTurretBlock(class_2251 settings) {
			super(settings, 10f, 14, new Vector3f(0.7f, 0.3f, 1f), DamageClass.EXOTIC, 16);
		}

		@Override
		protected void onHit(class_3218 world, class_2338 pos, class_1309 target) {
			WeaponCore.splashDamage(target, world, target.method_19538(), 8f, 2.5f, DamageClass.EXOTIC);
			world.method_14199(class_2398.field_11216, target.method_23317(), target.method_23318() + 1, target.method_23321(),
					8, 0.4, 0.4, 0.4, 0.02);
		}

		@Override
		protected float pitch() { return 0.85f; }
	}

	/** Fast amber point-defense — high RoF. */
	public static class PointDefenseTurretBlock extends BaseTurretBlock {
		public PointDefenseTurretBlock(class_2251 settings) {
			super(settings, 4f, 12, new Vector3f(1f, 0.7f, 0.2f), DamageClass.KINETIC, 6);
		}

		@Override
		protected void method_9588(class_2680 state, class_3218 world, class_2338 pos, class_5819 random) {
			fire(world, pos);
			if (random.method_43056()) fire(world, pos);
			world.method_39279(pos, this, interval);
		}

		@Override
		protected void onHit(class_3218 world, class_2338 pos, class_1309 target) {
			world.method_14199(class_2398.field_11205, target.method_23317(), target.method_23318() + 1, target.method_23321(),
					6, 0.2, 0.2, 0.2, 0.05);
		}

		@Override
		protected float pitch() { return 1.9f; }
	}
}
