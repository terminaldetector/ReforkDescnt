package com.terminaldetector.drmd.world.fire;

import com.terminaldetector.drmd.world.smoke.SmokeSystem;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_3218;

/**
 * Advanced Fire — 3D volume spread (ceilings, walls, industrial halls).
 * Multi-level with smoke: local fire blocks + tracked foci for secondary ignition.
 */
public final class FireSystem {
	public static final class Focus {
		public class_2338 pos;
		public int intensity;
		public int life;

		Focus(class_2338 pos, int intensity, int life) {
			this.pos = pos.method_10062();
			this.intensity = intensity;
			this.life = life;
		}
	}

	private static final Map<Long, Focus> FOCI = new ConcurrentHashMap<>();

	private FireSystem() {}

	public static void clear() {
		FOCI.clear();
	}

	public static void ignite(class_3218 world, class_2338 pos, int intensity) {
		FOCI.put(pos.method_10063(), new Focus(pos, intensity, 100 + intensity * 20));
		if (world.method_8320(pos).method_26215() || world.method_8320(pos).method_45474()) {
			world.method_8652(pos, class_2246.field_10036.method_9564(), class_2248.field_31036);
		}
		SmokeSystem.emit(class_243.method_24953(pos), SmokeSystem.Source.FIRE, 1.2f, 0.7f, 80);
	}

	/** Bombardment / explosion aftermath — multiple foci. */
	public static void igniteBlast(class_3218 world, class_2338 center, int count, int radius) {
		for (int i = 0; i < count; i++) {
			int dx = world.method_8409().method_43048(radius * 2 + 1) - radius;
			int dy = world.method_8409().method_43048(Math.max(1, radius)) - radius / 2;
			int dz = world.method_8409().method_43048(radius * 2 + 1) - radius;
			class_2338 p = center.method_10069(dx, dy, dz);
			if (isFlammable(world, p) || world.method_8320(p).method_26215()) {
				ignite(world, p, 2 + world.method_8409().method_43048(3));
			}
		}
	}

	public static void tick(class_3218 world) {
		List<Long> dead = new ArrayList<>();
		List<Focus> spread = new ArrayList<>();
		for (Focus f : FOCI.values()) {
			f.life--;
			if (f.life <= 0) {
				dead.add(f.pos.method_10063());
				continue;
			}
			if (world.method_8510() % 10 == 0) {
				SmokeSystem.emit(class_243.method_24953(f.pos).method_1031(0, 0.5, 0),
						SmokeSystem.Source.FIRE, 0.8f + f.intensity * 0.3f, 0.5f, 40);
			}
			// 3D spread: all 6 directions including ceilings
			if (world.method_8409().method_43048(12) == 0) {
				class_2350 dir = class_2350.method_10162(world.method_8409());
				class_2338 next = f.pos.method_10093(dir);
				if (isFlammable(world, next) || (dir == class_2350.field_11036 && world.method_8320(next).method_26215()
						&& isFlammable(world, next.method_10084()))) {
					spread.add(new Focus(next, Math.max(1, f.intensity - 1), 60 + f.intensity * 10));
				}
			}
		}
		dead.forEach(FOCI::remove);
		for (Focus f : spread) {
			if (FOCI.size() < 200) ignite(world, f.pos, f.intensity);
		}
	}

	private static boolean isFlammable(class_3218 world, class_2338 pos) {
		var st = world.method_8320(pos);
		return st.method_27852(class_2246.field_10431) || st.method_27852(class_2246.field_10037) || st.method_27852(class_2246.field_10511)
				|| st.method_27852(class_2246.field_10306) || st.method_27852(class_2246.field_10533) || st.method_27852(class_2246.field_10010)
				|| st.method_27852(class_2246.field_10161) || st.method_27852(class_2246.field_9975) || st.method_27852(class_2246.field_10148)
				|| st.method_27852(class_2246.field_10503) || st.method_27852(class_2246.field_9988) || st.method_27852(class_2246.field_10539)
				|| st.method_27852(class_2246.field_10446) || st.method_27852(class_2246.field_10359) || st.method_27852(class_2246.field_10504)
				|| st.method_27852(class_2246.field_16328) || st.method_27852(class_2246.field_9980) || st.method_27852(class_2246.field_10034)
				|| (st.method_26204().method_9520() < 1.5f && !st.method_26215() && !st.method_51176());
	}

	public static int focusCount() {
		return FOCI.size();
	}
}
