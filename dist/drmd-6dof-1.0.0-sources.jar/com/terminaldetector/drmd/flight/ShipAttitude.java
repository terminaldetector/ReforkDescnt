package com.terminaldetector.drmd.flight;

import net.minecraft.class_243;
import net.minecraft.class_3532;

/**
 * Descent ship basis — local pitch / yaw / roll around Right / Up / Forward
 * (port of d6_client.lua Ang:RotateAroundAxis).
 */
public final class ShipAttitude {
	public double fx = 0, fy = 0, fz = 1;
	public double ux = 0, uy = 1, uz = 0;

	public ShipAttitude() {}

	public ShipAttitude copy() {
		ShipAttitude a = new ShipAttitude();
		a.fx = fx; a.fy = fy; a.fz = fz;
		a.ux = ux; a.uy = uy; a.uz = uz;
		return a;
	}

	public class_243 forward() { return new class_243(fx, fy, fz); }
	public class_243 up() { return new class_243(ux, uy, uz); }
	public class_243 right() { return forward().method_1036(up()).method_1029(); }

	public void setForwardUp(class_243 f, class_243 u) {
		f = f.method_1029();
		u = u.method_1020(f.method_1021(u.method_1026(f)));
		if (u.method_1027() < 1e-8) u = new class_243(0, 1, 0);
		u = u.method_1029();
		fx = f.field_1352; fy = f.field_1351; fz = f.field_1350;
		ux = u.field_1352; uy = u.field_1351; uz = u.field_1350;
	}

	public void fromLook(class_243 look) {
		class_243 f = look.method_1029();
		class_243 r = f.method_1036(new class_243(0, 1, 0));
		if (r.method_1027() < 1e-8) r = new class_243(1, 0, 0);
		r = r.method_1029();
		setForwardUp(f, r.method_1036(f).method_1029());
	}

	/** Pitch: rotate around local Right (nose up = negative Minecraft pitch). */
	public void pitchLocal(double deg) {
		class_243 r = right();
		setForwardUp(rotate(forward(), r, deg), rotate(up(), r, deg));
	}

	/** Yaw: rotate around local Up. */
	public void yawLocal(double deg) {
		class_243 u = up();
		setForwardUp(rotate(forward(), u, deg), u);
	}

	/** Barrel roll: rotate around local Forward. */
	public void rollLocal(double deg) {
		class_243 f = forward();
		setForwardUp(f, rotate(up(), f, deg));
	}

	/** Level bank while keeping nose direction. */
	public void levelRoll() {
		class_243 f = forward();
		class_243 r = f.method_1036(new class_243(0, 1, 0));
		if (r.method_1027() < 1e-8) r = new class_243(1, 0, 0);
		r = r.method_1029();
		setForwardUp(f, r.method_1036(f).method_1029());
	}

	public float pitchDegrees() {
		return (float) (-Math.toDegrees(Math.asin(class_3532.method_15350(fy, -1, 1))));
	}

	public float yawDegrees() {
		return (float) Math.toDegrees(Math.atan2(-fx, fz));
	}

	/** Bank angle vs world-level horizon. */
	public float bankDegrees() {
		class_243 f = forward();
		class_243 u = up();
		class_243 worldUp = Math.abs(f.field_1351) > 0.95 ? new class_243(0, 0, 1) : new class_243(0, 1, 0);
		class_243 levelRight = f.method_1036(worldUp);
		if (levelRight.method_1027() < 1e-8) return 0;
		levelRight = levelRight.method_1029();
		class_243 levelUp = levelRight.method_1036(f).method_1029();
		class_243 r = right();
		return (float) Math.toDegrees(Math.atan2(u.method_1026(levelRight), u.method_1026(levelUp)));
	}

	public static class_243 rotate(class_243 v, class_243 axis, double deg) {
		class_243 k = axis.method_1029();
		double rad = Math.toRadians(deg);
		double c = Math.cos(rad);
		double s = Math.sin(rad);
		class_243 kxv = k.method_1036(v);
		double kdv = k.method_1026(v);
		return v.method_1021(c).method_1019(kxv.method_1021(s)).method_1019(k.method_1021(kdv * (1 - c)));
	}
}
