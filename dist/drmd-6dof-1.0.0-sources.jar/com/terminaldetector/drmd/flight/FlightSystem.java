package com.terminaldetector.drmd.flight;

import com.terminaldetector.drmd.DescentMod;
import com.terminaldetector.drmd.DescentPlayerData;
import com.terminaldetector.drmd.energy.EnergySystem;
import com.terminaldetector.drmd.network.ModNetworking;
import com.terminaldetector.drmd.world.atmosphere.AtmosphereBand;
import com.terminaldetector.drmd.world.gravity.GravityFields;
import net.minecraft.class_1657;
import net.minecraft.class_243;
import net.minecraft.class_3222;
import net.minecraft.class_3532;

/**
 * 6DOF flight integrator — port of d6_core.lua CFG + spool + FA + idle gravity + dash + grapple.
 * Source units are scaled via DescentMod.UNIT_SCALE for Minecraft playability.
 */
public final class FlightSystem {
	public static final float INERTIA = 0.968f;
	public static final float BRAKE_MULT = 0.020f;
	public static final float SPOOL_UP = 15f;
	public static final float SPOOL_DOWN = 4f;
	public static final float STRAFE_MULT = 0.72f;
	public static final float VERT_MULT = 0.65f;
	public static final float WALL_BOUNCE = 0.5f;
	public static final float IDLE_GRAV_SEC = 45f;
	public static final float IDLE_GRAV_RAMP = 5f;
	public static final float MICRO_GRAV = 20f;
	public static final float DASH_VEL = 3200f;
	public static final float DASH_DUR = 0.18f;
	public static final float DASH_CD = 1.8f;
	public static final float HOOK_DIST = 2500f;
	public static final float HOOK_PULL = 3800f;
	public static final float ROLL_ACCEL = 220f;
	public static final float ROLL_DRAG = 4.5f;

	/** Client-side input snapshot synced each tick while flying. */
	public static final class InputState {
		public float forward, strafe, vertical, roll;
		public boolean dash, hook, alwaysRunToggle;
	}

	private static final java.util.Map<java.util.UUID, InputState> INPUTS = new java.util.concurrent.ConcurrentHashMap<>();

	private FlightSystem() {}

	public static InputState input(class_1657 player) {
		return INPUTS.computeIfAbsent(player.method_5667(), id -> new InputState());
	}

	public static void clearInput(java.util.UUID id) {
		INPUTS.remove(id);
	}

	public static void tick(class_3222 player, DescentPlayerData data) {
		float dt = 1f / 20f;
		InputState in = input(player);

		if (data.getDashCooldown() > 0) data.setDashCooldown(data.getDashCooldown() - dt);
		if (data.getDashTimer() > 0) data.setDashTimer(data.getDashTimer() - dt);

		boolean hasInput = Math.abs(in.forward) > 0.01f || Math.abs(in.strafe) > 0.01f
				|| Math.abs(in.vertical) > 0.01f || Math.abs(in.roll) > 0.01f
				|| in.dash || player.field_6252;

		if (hasInput) {
			data.setIdleTimer(0f);
			data.setGravityFactor(0f);
		} else {
			data.setIdleTimer(data.getIdleTimer() + dt);
			if (data.getIdleTimer() >= IDLE_GRAV_SEC) {
				float t = Math.min(1f, (data.getIdleTimer() - IDLE_GRAV_SEC) / IDLE_GRAV_RAMP);
				data.setGravityFactor(t);
			}
		}

		// Always-Run energy drain
		if (data.isAlwaysRun()) {
			if (!EnergySystem.tryConsume(data, "engines", EnergySystem.ALWAYS_RUN_COST_PER_SEC * dt)) {
				data.setAlwaysRun(false);
			}
		}

		// Roll rate (client applies local roll into synced ship attitude)
		float rollVel = data.getRollVel() + in.roll * ROLL_ACCEL * dt;
		rollVel *= Math.pow(class_3532.method_15363(1f - ROLL_DRAG * dt, 0f, 1f), 1);
		data.setRollVel(rollVel);
		if (!data.hasShipAttitude()) {
			float roll = data.getRoll() + rollVel * dt;
			while (roll > 180f) roll -= 360f;
			while (roll < -180f) roll += 360f;
			data.setRoll(roll);
		}

		class_243 look = data.shipForward(player);
		class_243 rolledUp = data.shipUp(player);
		class_243 rolledRight = look.method_1036(rolledUp);
		if (rolledRight.method_1027() < 1e-8) {
			rolledRight = new class_243(1, 0, 0);
			rolledUp = rolledRight.method_1036(look).method_1029();
		} else {
			rolledRight = rolledRight.method_1029();
		}

		boolean thrusting = Math.abs(in.forward) > 0.01f || Math.abs(in.strafe) > 0.01f || Math.abs(in.vertical) > 0.01f;
		if (thrusting && player.method_5682().method_3780() % 4 == 0) {
			com.terminaldetector.drmd.world.smoke.SmokeSystem.emit(
					player.method_19538().method_1020(look.method_1021(0.8)),
					com.terminaldetector.drmd.world.smoke.SmokeSystem.Source.ENGINE,
					0.4f, 0.25f, 18);
		}
		float spool = data.getThrustSpool();
		if (thrusting) spool = Math.min(1f, spool + SPOOL_UP * dt);
		else spool = Math.max(0f, spool - SPOOL_DOWN * dt);
		data.setThrustSpool(spool);

		float engAlloc = data.getAllocEngines();
		float accelMult = data.isAlwaysRun() ? class_3532.method_16439(engAlloc, 1.3f, 1.9f) : 1f;
		float speedMult = data.isAlwaysRun() ? class_3532.method_16439(engAlloc, 1.3f, 1.8f) : 1f;

		// Atmospheric bands: thin air / near-space → less drag, more thrust reliance
		AtmosphereBand band = AtmosphereBand.at(player.method_23318());
		accelMult *= band.thrustScale;
		speedMult *= class_3532.method_16439(1f - band.airDrag, 1f, 1.15f);

		double accel = DescentMod.su(data.getAccel()) * accelMult * spool;
		class_243 wish = look.method_1021(in.forward)
				.method_1019(rolledRight.method_1021(in.strafe * STRAFE_MULT))
				.method_1019(rolledUp.method_1021(in.vertical * VERT_MULT));
		if (wish.method_1027() > 1e-6) wish = wish.method_1029().method_1021(accel * dt);

		class_243 vel = data.getFlightVelocity().method_1019(wish);

		// Micro gravity + idle gravity + local GravityFields (generators / torches / stations)
		GravityFields.Sample field = GravityFields.sample(player.method_37908(), player.method_19538());
		class_243 gravDir;
		double g = DescentMod.su(MICRO_GRAV) + DescentMod.su(data.getGravity()) * data.getGravityFactor();
		if (field != null) {
			gravDir = field.downDir();
			g += DescentMod.su(data.getGravity()) * field.strength() * 0.55;
			// Smoothly adopt field UP for construction / station sections
			com.terminaldetector.drmd.world.LocalOrientation.setUp(player.method_5667(), field.upDir());
		} else {
			gravDir = com.terminaldetector.drmd.world.LocalOrientation.gravityDir(player.method_5667());
		}
		vel = vel.method_1019(gravDir.method_1021(g * dt));

		// Dash
		if (in.dash && data.getDashCooldown() <= 0 && EnergySystem.tryConsume(data, "engines", EnergySystem.DASH_COST)) {
			class_243 dashDir = wish.method_1027() > 1e-6 ? wish.method_1029() : look;
			vel = vel.method_1019(dashDir.method_1021(DescentMod.su(DASH_VEL)));
			data.setDashCooldown(DASH_CD);
			data.setDashTimer(DASH_DUR);
			in.dash = false;
		}

		// Grapple / hook
		if (in.hook && !data.isHookActive()) {
			class_243 eye = player.method_33571();
			var hit = player.method_37908().method_17742(new net.minecraft.class_3959(
					eye, eye.method_1019(look.method_1021(DescentMod.su(HOOK_DIST))),
					net.minecraft.class_3959.class_3960.field_17558,
					net.minecraft.class_3959.class_242.field_1348, player));
			if (hit.method_17783() != net.minecraft.class_239.class_240.field_1333) {
				data.setHookActive(true);
				data.setHookPos(hit.method_17784());
			}
			in.hook = false;
		} else if (!in.hook && data.isHookActive()) {
			// release when key up handled via packet toggle; keep pull while active
		}

		if (data.isHookActive()) {
			class_243 to = data.getHookPos().method_1020(player.method_19538());
			double dist = to.method_1033();
			double maxDist = DescentMod.su(HOOK_DIST);
			if (dist < DescentMod.su(55) || dist > maxDist * 1.2) {
				data.setHookActive(false);
			} else {
				vel = vel.method_1019(to.method_1029().method_1021(DescentMod.su(HOOK_PULL) * dt));
			}
		}

		// Drag / Flight Assist — scaled by atmosphere air density
		double speed = vel.method_1033();
		double dragK = data.getDrag() * band.airDrag;
		if (data.isFlightAssist()) {
			// Quadratic drag + linear brake when no input
			if (speed > 1e-4) {
				double qDrag = dragK * speed * speed * DescentMod.UNIT_SCALE * dt;
				vel = vel.method_1021(Math.max(0, 1.0 - qDrag / speed));
			}
			if (!thrusting) {
				vel = vel.method_1021(Math.max(0, 1.0 - BRAKE_MULT * 60 * dt));
			}
		} else {
			if (speed > 1e-4) {
				double qDrag = dragK * speed * speed * DescentMod.UNIT_SCALE * dt;
				vel = vel.method_1021(Math.max(0, 1.0 - qDrag / speed));
			}
		}

		// Inertia retention (Source tick-rate based)
		double inertiaKeep = Math.pow(INERTIA, dt * 60.0);
		vel = vel.method_1021(inertiaKeep);

		// Soft speed cap
		double maxSpd = DescentMod.su(data.getMaxSpeed()) * speedMult;
		if (vel.method_1033() > maxSpd) vel = vel.method_1029().method_1021(maxSpd);

		data.setFlightVelocity(vel);

		// Apply to player — disable vanilla gravity while 6DOF on
		player.method_5875(true);
		player.method_18799(vel);
		player.field_6037 = true;
		player.field_6017 = 0f;

		// Simple wall bounce
		if (player.field_5976 || player.field_5992) {
			class_243 bounced = data.getFlightVelocity().method_1021(-WALL_BOUNCE);
			if (player.field_5976) {
				bounced = new class_243(bounced.field_1352, data.getFlightVelocity().field_1351 * WALL_BOUNCE, bounced.field_1350);
			}
			if (player.field_5992) {
				bounced = new class_243(data.getFlightVelocity().field_1352 * WALL_BOUNCE, -Math.abs(data.getFlightVelocity().field_1351) * WALL_BOUNCE, data.getFlightVelocity().field_1350 * WALL_BOUNCE);
			}
			data.setFlightVelocity(data.getFlightVelocity().method_1021(WALL_BOUNCE).method_1019(bounced).method_1021(0.5));
		}

		ModNetworking.syncPlayer(player, data);
	}

	public static void disable(class_3222 player, DescentPlayerData data) {
		data.setEnabled(false);
		data.clearShipAttitude();
		data.setRoll(0);
		data.setRollVel(0);
		player.method_5875(false);
		data.setFlightVelocity(class_243.field_1353);
		data.setHookActive(false);
		ModNetworking.syncPlayer(player, data);
	}

	public static void toggle(class_3222 player) {
		DescentPlayerData data = DescentPlayerData.get(player);
		if (data.isEnabled()) disable(player, data);
		else {
			data.setEnabled(true);
			data.ensureInit();
			ModNetworking.syncPlayer(player, data);
		}
	}

	public static void tryDash(class_3222 player) {
		input(player).dash = true;
	}

	public static void toggleHook(class_3222 player) {
		DescentPlayerData data = DescentPlayerData.get(player);
		if (data.isHookActive()) {
			data.setHookActive(false);
		} else {
			input(player).hook = true;
		}
	}
}
