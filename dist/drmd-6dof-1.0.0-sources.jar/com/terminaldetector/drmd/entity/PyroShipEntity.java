package com.terminaldetector.drmd.entity;

import com.terminaldetector.drmd.DescentPlayerData;
import com.terminaldetector.drmd.world.LocalOrientation;
import com.terminaldetector.drmd.world.build.ConstructionMode;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1314;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_5132;
import net.minecraft.class_5134;

/**
 * Pyro GX transport — 6DoF while piloted; landing / dismount enters Construction Mode.
 */
public class PyroShipEntity extends class_1314 {
	private boolean wasPiloted;
	private int landTicks;

	public PyroShipEntity(class_1299<? extends PyroShipEntity> type, class_1937 world) {
		super(type, world);
		this.method_5875(true);
	}

	public static class_5132.class_5133 createAttributes() {
		return class_1314.method_26828()
				.method_26868(class_5134.field_23716, 120)
				.method_26868(class_5134.field_23719, 0.8)
				.method_26868(class_5134.field_23720, 1.2)
				.method_26868(class_5134.field_23717, 32);
	}

	@Override
	protected void method_5959() {}

	@Override
	public void method_5773() {
		super.method_5773();
		this.method_5875(true);
		if (method_37908().field_9236) return;

		if (method_31483() instanceof class_3222 pilot) {
			wasPiloted = true;
			landTicks = 0;
			DescentPlayerData data = DescentPlayerData.get(pilot);
			if (!data.isEnabled()) data.setEnabled(true);
			class_243 vel = data.getFlightVelocity();
			this.method_18799(vel);
			this.field_6037 = true;
			this.method_36456(pilot.method_36454());
			this.method_36457(pilot.method_36455());
			this.field_6283 = pilot.method_36454();
		} else {
			this.method_18799(method_18798().method_1021(0.88));
			if (wasPiloted && method_18798().method_1027() < 0.04) {
				landTicks++;
				if (landTicks > 8) wasPiloted = false;
			}
		}
	}

	@Override
	protected void method_5793(class_1297 passenger) {
		super.method_5793(passenger);
		if (!method_37908().field_9236 && passenger instanceof class_3222 sp) {
			class_2350 floor = class_2350.field_11036;
			for (class_2350 d : class_2350.values()) {
				class_2338 p = method_24515().method_10093(d.method_10153());
				if (method_37908().method_8320(p).method_26212(method_37908(), p)) {
					floor = d;
					break;
				}
			}
			LocalOrientation.setFromDirection(sp.method_5667(), floor);
			ConstructionMode.onShipLanded(sp);
			sp.method_7353(class_2561.method_43470("§7Local floor locked to §f" + floor.method_15434()), false);
		}
	}

	@Override
	public class_1269 method_5992(class_1657 player, class_1268 hand) {
		if (!method_37908().field_9236 && !method_5782()) {
			player.method_5804(this);
			if (player instanceof class_3222 sp) {
			DescentPlayerData data = DescentPlayerData.get(sp);
			data.setEnabled(true);
			data.ensureInit();
			ConstructionMode.set(sp, false);
			sp.method_7353(class_2561.method_43470("§bPyro GX §7— Tab+H · 3D terrain map"), false);
		}
			return class_1269.field_5812;
		}
		return class_1269.field_5812;
	}

	@Override
	protected boolean method_5818(class_1297 passenger) {
		return method_5685().isEmpty();
	}

	@Override
	protected class_243 method_52533(class_1297 passenger, net.minecraft.class_4048 dimensions, float scaleFactor) {
		return new class_243(0, 0.35, 0);
	}

	@Override
	public boolean method_5810() {
		return false;
	}

	@Override
	public boolean method_30949(class_1297 other) {
		return true;
	}

	@Override
	public void method_5652(class_2487 nbt) {
		super.method_5652(nbt);
		nbt.method_10582("hull", "pyro");
	}

	@Override
	public void method_5749(class_2487 nbt) {
		super.method_5749(nbt);
	}
}
