package com.terminaldetector.drmd.entity;

import com.terminaldetector.drmd.ai.AiRole;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_243;
import net.minecraft.class_3218;

/**
 * Creative/quick spawn egg for a specific drone role (10 combat loadouts).
 */
public class DroneSpawnEggItem extends class_1792 {
	private final AiRole role;
	private final int primaryColor;
	private final int secondaryColor;

	public DroneSpawnEggItem(AiRole role, int primaryColor, int secondaryColor, class_1793 settings) {
		super(settings);
		this.role = role;
		this.primaryColor = primaryColor;
		this.secondaryColor = secondaryColor;
	}

	public AiRole getRole() { return role; }
	public int getPrimaryColor() { return primaryColor; }
	public int getSecondaryColor() { return secondaryColor; }

	@Override
	public class_1271<class_1799> method_7836(class_1937 world, class_1657 user, class_1268 hand) {
		class_1799 stack = user.method_5998(hand);
		if (world.field_9236) return class_1271.method_22427(stack);
		if (!(world instanceof class_3218 sw)) return class_1271.method_22431(stack);

		DroneEntity drone = ModEntities.DRONE.method_5883(sw);
		if (drone == null) return class_1271.method_22431(stack);
		class_243 look = user.method_5828(1f);
		class_243 pos = user.method_19538().method_1019(look.method_1021(4)).method_1031(0, 1, 0);
		drone.method_5808(pos.field_1352, pos.field_1351, pos.field_1350, user.method_36454(), 0);
		drone.applyRole(role);
		sw.method_8649(drone);
		if (!user.method_31549().field_7477) stack.method_7934(1);
		return class_1271.method_22427(stack);
	}
}
