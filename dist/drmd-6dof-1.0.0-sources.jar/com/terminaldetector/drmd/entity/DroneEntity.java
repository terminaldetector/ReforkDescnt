package com.terminaldetector.drmd.entity;

import com.terminaldetector.drmd.DescentMod;
import com.terminaldetector.drmd.ai.AiRole;
import com.terminaldetector.drmd.ai.DroneAi;
import com.terminaldetector.drmd.weapon.core.DamageClass;
import com.terminaldetector.drmd.weapon.core.WeaponCore;
import net.minecraft.class_1282;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1361;
import net.minecraft.class_1400;
import net.minecraft.class_1588;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2940;
import net.minecraft.class_2943;
import net.minecraft.class_2945;
import net.minecraft.class_3218;
import net.minecraft.class_5132;
import net.minecraft.class_5134;

/**
 * Enemy drone — port of D6_BuildDrone / SpawnEnemyDrone with role loadouts.
 */
public class DroneEntity extends class_1588 {
	private static final class_2940<String> ROLE = class_2945.method_12791(DroneEntity.class, class_2943.field_13326);
	private static final class_2940<Float> SHIELD = class_2945.method_12791(DroneEntity.class, class_2943.field_13320);
	private static final class_2940<Float> ARMOR = class_2945.method_12791(DroneEntity.class, class_2943.field_13320);
	private static final class_2940<Float> FLIGHT_ROLL = class_2945.method_12791(DroneEntity.class, class_2943.field_13320);

	private AiRole role = AiRole.ASSAULT;
	private float shield;
	private float armor;
	private float modEnergy = 100f;
	private float attackCooldown;
	private DroneAi.Phase phase = DroneAi.Phase.ORBIT;
	private float phaseTimer;
	private float resistK, resistE, resistX;

	public DroneEntity(class_1299<? extends DroneEntity> type, class_1937 world) {
		super(type, world);
		this.method_5875(true);
		applyRole(AiRole.ASSAULT);
	}

	public static class_5132.class_5133 createDroneAttributes() {
		return class_1588.method_26918()
				.method_26868(class_5134.field_23716, 200)
				.method_26868(class_5134.field_23719, 0.5)
				.method_26868(class_5134.field_23721, 10)
				.method_26868(class_5134.field_23717, 64)
				.method_26868(class_5134.field_23720, 0.8);
	}

	public void applyRole(AiRole role) {
		this.role = role;
		this.shield = role.shield;
		this.armor = role.armor;
		this.resistK = role.resistKinetic;
		this.resistE = role.resistEnergy;
		this.resistX = role.resistExplosive;
		if (!method_37908().field_9236) {
			method_6033(role.hullHp);
			method_5996(class_5134.field_23716).method_6192(role.hullHp);
			field_6011.method_12778(ROLE, role.id);
			field_6011.method_12778(SHIELD, shield);
			field_6011.method_12778(ARMOR, armor);
		}
	}

	public AiRole getRole() { return role; }
	public float getDroneShield() { return shield; }
	public float getDroneArmor() { return armor; }
	public float getFlightRoll() { return field_6011.method_12789(FLIGHT_ROLL); }
	public void setFlightRoll(float roll) {
		if (!method_37908().field_9236) field_6011.method_12778(FLIGHT_ROLL, roll);
	}

	@Override
	protected void method_5693(class_2945.class_9222 builder) {
		super.method_5693(builder);
		builder.method_56912(ROLE, AiRole.ASSAULT.id);
		builder.method_56912(SHIELD, 50f);
		builder.method_56912(ARMOR, 0f);
		builder.method_56912(FLIGHT_ROLL, 0f);
	}

	@Override
	protected void method_5959() {
		this.field_6201.method_6277(1, new DroneAi.CombatGoal(this));
		this.field_6201.method_6277(8, new class_1361(this, class_1657.class, 16f));
		this.field_6185.method_6277(1, new class_1400<>(this, class_1657.class, true));
	}

	@Override
	public void method_5773() {
		super.method_5773();
		this.method_5875(true);
		if (!method_37908().field_9236) {
			modEnergy = Math.min(100f, modEnergy + 20f / 20f);
			if (attackCooldown > 0) attackCooldown -= 1f / 20f;
			field_6011.method_12778(SHIELD, shield);
			field_6011.method_12778(ARMOR, armor);
			// Passive shield regen for roles with ShieldGen (heavy_elite / support)
			if ((role == AiRole.HEAVY_ELITE || role == AiRole.SUPPORT) && field_6012 % 20 > 10) {
				shield = Math.min(role.shield, shield + 8f / 20f);
			}
		}
	}

	@Override
	public boolean method_5643(class_1282 source, float amount) {
		DamageClass cls = DamageClass.KINETIC;
		String name = source.method_5525();
		if (name.contains("magic") || name.contains("lightning")) cls = DamageClass.ENERGY;
		else if (name.contains("explosion")) cls = DamageClass.EXPLOSIVE;

		float resist = switch (cls) {
			case KINETIC -> resistK;
			case ENERGY, EXOTIC -> resistE;
			case EXPLOSIVE -> resistX;
		};
		resist = Math.min(0.9f, Math.max(0f, resist));
		amount *= (1f - resist);

		// Shield → Armor → Hull
		if (shield > 0) {
			float abs = Math.min(shield, amount);
			shield -= abs;
			amount -= abs;
		}
		if (amount > 0 && armor > 0) {
			float abs = Math.min(armor, amount);
			armor -= abs;
			amount -= abs;
		}
		if (amount <= 0) {
			this.method_5785();
			return false;
		}
		return super.method_5643(source, amount);
	}

	@Override
	public void method_6078(class_1282 damageSource) {
		super.method_6078(damageSource);
		if (!method_37908().field_9236 && role == AiRole.HEAVY_ELITE && field_5974.method_43057() < 0.35f) {
			// Reactor death boom 35%: rad 340 → ~4.25 blocks, dmg 200
			if (method_37908() instanceof class_3218 sw) {
				WeaponCore.splashDamage(this, sw, method_19538(), 200f, (float) DescentMod.su(340), DamageClass.EXPLOSIVE);
				sw.method_14199(class_2398.field_11221, method_23317(), method_23318(), method_23321(), 1, 0, 0, 0, 0);
			}
		}
	}

	public boolean tryFireAt(class_1309 target) {
		if (attackCooldown > 0 || target == null) return false;
		if (modEnergy < role.weaponCost) return false;
		modEnergy -= role.weaponCost;
		attackCooldown = role.weaponCooldown;

		class_243 from = method_19538().method_1031(0, method_17682() * 0.5, 0);
		class_243 dir = target.method_19538().method_1031(0, target.method_17682() * 0.5, 0).method_1020(from).method_1029();

		WeaponCore.FireConfig cfg = new WeaponCore.FireConfig();
		cfg.owner = this;
		cfg.pos = from;
		cfg.dir = dir;
		cfg.speed = role.weaponSpeed;
		cfg.directDamage = role.weaponDamage;
		cfg.splashDamage = role.weaponSplash;
		cfg.splashRadius = role.weaponSplashRadius;
		cfg.dmgClass = role.weaponClass;
		cfg.homing = role.weaponHoming;
		cfg.homeTarget = role.weaponHoming ? target : null;
		cfg.life = 4f;
		WeaponCore.fireProjectile(cfg);
		return true;
	}

	public DroneAi.Phase getPhase() { return phase; }
	public void setPhase(DroneAi.Phase p) { this.phase = p; this.phaseTimer = 0; }
	public float getPhaseTimer() { return phaseTimer; }
	public void addPhaseTimer(float dt) { phaseTimer += dt; }
	public float getModEnergy() { return modEnergy; }

	@Override
	public void method_5652(class_2487 nbt) {
		super.method_5652(nbt);
		nbt.method_10582("role", role.id);
		nbt.method_10548("shield", shield);
		nbt.method_10548("armor", armor);
	}

	@Override
	public void method_5749(class_2487 nbt) {
		super.method_5749(nbt);
		applyRole(AiRole.fromId(nbt.method_10558("role")));
		shield = nbt.method_10583("shield");
		armor = nbt.method_10583("armor");
	}
}
