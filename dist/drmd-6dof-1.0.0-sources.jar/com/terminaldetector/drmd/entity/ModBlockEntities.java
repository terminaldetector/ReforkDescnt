package com.terminaldetector.drmd.entity;

import com.terminaldetector.drmd.DescentMod;
import com.terminaldetector.drmd.world.gravity.GravityGeneratorBlockEntity;
import com.terminaldetector.drmd.world.soil.SixDSoilBlockEntity;
import net.minecraft.class_2378;
import net.minecraft.class_2591;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public final class ModBlockEntities {
	public static class_2591<SixDSoilBlockEntity> SIX_D_SOIL;
	public static class_2591<GravityGeneratorBlockEntity> GRAVITY_GENERATOR;

	private ModBlockEntities() {}

	public static void register() {
		SIX_D_SOIL = class_2378.method_10230(class_7923.field_41181,
				class_2960.method_60655(DescentMod.MOD_ID, "six_d_soil"),
				class_2591.class_2592.method_20528(SixDSoilBlockEntity::new, ModWorldBlocks.SIX_D_SOIL).build());
		GRAVITY_GENERATOR = class_2378.method_10230(class_7923.field_41181,
				class_2960.method_60655(DescentMod.MOD_ID, "gravity_generator"),
				class_2591.class_2592.method_20528(GravityGeneratorBlockEntity::new, ModWorldBlocks.GRAVITY_GENERATOR).build());
		DescentMod.LOGGER.info("Registered DRMD block entities");
	}
}
