package com.terminaldetector.drmd.entity;

import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1937;
import net.minecraft.class_2487;
import net.minecraft.class_2604;
import net.minecraft.class_2945;

/** Decorative rotating reactor core marker for Descent-like reactor rooms. */
public class ReactorDisplayEntity extends class_1297 {
	public ReactorDisplayEntity(class_1299<? extends ReactorDisplayEntity> type, class_1937 world) {
		super(type, world);
		this.field_5960 = true;
	}

	@Override
	protected void method_5693(class_2945.class_9222 builder) {}

	@Override
	public void method_5773() {
		super.method_5773();
		// visual spin handled in model
	}

	@Override
	protected void method_5749(class_2487 nbt) {}

	@Override
	protected void method_5652(class_2487 nbt) {}

	@Override
	public void method_31471(class_2604 packet) {
		super.method_31471(packet);
	}

	@Override
	public boolean method_30948() {
		return false;
	}
}
