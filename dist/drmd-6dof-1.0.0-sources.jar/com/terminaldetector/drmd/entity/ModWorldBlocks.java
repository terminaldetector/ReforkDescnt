package com.terminaldetector.drmd.entity;

import com.terminaldetector.drmd.DescentMod;
import com.terminaldetector.drmd.weapon.items.ModItems;
import com.terminaldetector.drmd.world.build.BuildToolItem;
import com.terminaldetector.drmd.world.soil.SixDSoilBlock;
import com.terminaldetector.drmd.world.trap.TrapBlocks;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3620;
import net.minecraft.class_4970;
import net.minecraft.class_7923;

/**
 * World-design blocks & tools — 6D Soil, traps, build tool.
 */
public final class ModWorldBlocks {
	public static final class_2248 SIX_D_SOIL = registerBlock("six_d_soil",
			new SixDSoilBlock(class_4970.class_2251.method_9630(class_2246.field_10219).method_31710(class_3620.field_15995)));

	public static final class_2248 HERMETIC_GATE = registerBlock("hermetic_gate",
			new TrapBlocks.HermeticGateBlock(class_4970.class_2251.method_9630(class_2246.field_10085).method_9640()));

	public static final class_2248 LASER_BARRIER = registerBlock("laser_barrier",
			new TrapBlocks.LaserBarrierBlock(class_4970.class_2251.method_9630(class_2246.field_10033).method_9640().method_9631(s -> 10)));

	public static final class_2248 VOLUME_TURRET = registerBlock("volume_turret",
			new TrapBlocks.VolumeTurretBlock(class_4970.class_2251.method_9630(class_2246.field_10200).method_9640()));

	public static final class_2248 MAGNETIC_ANOMALY = registerBlock("magnetic_anomaly",
			new TrapBlocks.MagneticAnomalyBlock(class_4970.class_2251.method_9630(class_2246.field_23261).method_9640()));

	public static final class_2248 UNSTABLE_REACTOR = registerBlock("unstable_reactor",
			new TrapBlocks.UnstableReactorBlock(class_4970.class_2251.method_9630(class_2246.field_23152).method_9640()));

	public static final class_2248 GRAVITY_GENERATOR = registerBlock("gravity_generator",
			new com.terminaldetector.drmd.world.gravity.GravityGeneratorBlock(
					class_4970.class_2251.method_9630(class_2246.field_23261).method_9631(s -> 8).method_9632(4f)));

	public static final class_2248 GRAVITY_TORCH = registerBlock("gravity_torch",
			new com.terminaldetector.drmd.world.gravity.GravityTorchBlock(
					class_4970.class_2251.method_9630(class_2246.field_10336).method_9631(s -> 12).method_9640().method_22488()));

	public static class_1792 BUILD_TOOL;
	public static class_1792 CONSTRUCTION_LASER;
	public static class_1792 REPAIR_LASER;
	public static class_1792 MINING_LASER;
	public static class_1792 GRAVITY_SCANNER;

	private ModWorldBlocks() {}

	private static class_2248 registerBlock(String id, class_2248 block) {
		class_2960 ident = class_2960.method_60655(DescentMod.MOD_ID, id);
		class_2378.method_10230(class_7923.field_41175, ident, block);
		class_2378.method_10230(class_7923.field_41178, ident, new class_1747(block, new class_1792.class_1793()));
		return block;
	}

	public static void register() {
		BUILD_TOOL = class_2378.method_10230(class_7923.field_41178,
				class_2960.method_60655(DescentMod.MOD_ID, "build_tool"),
				new BuildToolItem(new class_1792.class_1793()));
		CONSTRUCTION_LASER = class_2378.method_10230(class_7923.field_41178,
				class_2960.method_60655(DescentMod.MOD_ID, "construction_laser"),
				new com.terminaldetector.drmd.world.engineer.EngineerTools.ConstructionLaserItem(new class_1792.class_1793()));
		REPAIR_LASER = class_2378.method_10230(class_7923.field_41178,
				class_2960.method_60655(DescentMod.MOD_ID, "repair_laser"),
				new com.terminaldetector.drmd.world.engineer.EngineerTools.RepairLaserItem(new class_1792.class_1793()));
		MINING_LASER = class_2378.method_10230(class_7923.field_41178,
				class_2960.method_60655(DescentMod.MOD_ID, "mining_laser"),
				new com.terminaldetector.drmd.world.engineer.EngineerTools.MiningLaserItem(new class_1792.class_1793()));
		GRAVITY_SCANNER = class_2378.method_10230(class_7923.field_41178,
				class_2960.method_60655(DescentMod.MOD_ID, "gravity_scanner"),
				new com.terminaldetector.drmd.world.engineer.EngineerTools.GravityScannerItem(new class_1792.class_1793()));

		ItemGroupEvents.modifyEntriesEvent(ModItems.GROUP_KEY).register(entries -> {
			entries.method_45421(SIX_D_SOIL);
			entries.method_45421(HERMETIC_GATE);
			entries.method_45421(LASER_BARRIER);
			entries.method_45421(VOLUME_TURRET);
			entries.method_45421(MAGNETIC_ANOMALY);
			entries.method_45421(UNSTABLE_REACTOR);
			entries.method_45421(GRAVITY_GENERATOR);
			entries.method_45421(GRAVITY_TORCH);
			entries.method_45421(BUILD_TOOL);
			entries.method_45421(CONSTRUCTION_LASER);
			entries.method_45421(REPAIR_LASER);
			entries.method_45421(MINING_LASER);
			entries.method_45421(GRAVITY_SCANNER);
		});

		DescentMod.LOGGER.info("Registered Phase3 world blocks & engineer tools");
	}
}
