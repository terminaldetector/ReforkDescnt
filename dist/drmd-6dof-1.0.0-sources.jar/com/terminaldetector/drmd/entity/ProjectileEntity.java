package com.terminaldetector.drmd.entity;

import com.terminaldetector.drmd.weapon.core.DamageClass;
import com.terminaldetector.drmd.weapon.core.WeaponCore;
import com.terminaldetector.drmd.world.LocalOrientation;
import org.joml.Vector3f;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;
import java.util.function.Consumer;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_239;
import net.minecraft.class_2390;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2604;
import net.minecraft.class_3218;
import net.minecraft.class_3965;
import net.minecraft.class_3966;

/**
 * Physical projectile — port of prop_physics projectiles from D6_Wep.FireProjectile.
 */
public class ProjectileEntity extends class_1297 {
	private UUID ownerUuid;
	private class_1309 owner;
	private DamageClass dmgClass = DamageClass.KINETIC;
	private float directDamage;
	private float splashDamage;
	private float splashRadius;
	private int lifeTicks = 100;
	private float gravityStrength;
	private float drag;
	private boolean homing;
	private float turnRate = 90f;
	private class_1297 homeTarget;
	private int pierceCount;
	private int colorR = 180, colorG = 220, colorB = 255;
	private Consumer<WeaponCore.HitContext> onHit;
	private final Set<Integer> pierced = new HashSet<>();

	public ProjectileEntity(class_1299<? extends ProjectileEntity> type, class_1937 world) {
		super(type, world);
		this.field_5960 = false;
	}

	public void setOwner(class_1309 owner) {
		this.owner = owner;
		this.ownerUuid = owner.method_5667();
	}

	public class_1309 getOwnerLiving() {
		if (owner != null && owner.method_5805()) return owner;
		if (ownerUuid != null && method_37908() instanceof class_3218 sw) {
			class_1297 e = sw.method_14190(ownerUuid);
			if (e instanceof class_1309 le) {
				owner = le;
				return le;
			}
		}
		return null;
	}

	public void setDamageClass(DamageClass c) { this.dmgClass = c; colorR = c.r; colorG = c.g; colorB = c.b; }
	public void setDirectDamage(float v) { this.directDamage = v; }
	public void setSplashDamage(float v) { this.splashDamage = v; }
	public void setSplashRadius(float v) { this.splashRadius = v; }
	public void setLifeTicks(int v) { this.lifeTicks = v; }
	public void setGravityStrength(float v) { this.gravityStrength = v; }
	public void setDrag(float v) { this.drag = v; }
	public void setHoming(boolean h, float turn, class_1297 target) { this.homing = h; this.turnRate = turn; this.homeTarget = target; }
	public void setPierceCount(int v) { this.pierceCount = v; }
	public void setColor(int r, int g, int b) { colorR = r; colorG = g; colorB = b; }
	public void setOnHit(Consumer<WeaponCore.HitContext> cb) { this.onHit = cb; }
	public int getColorR() { return colorR; }
	public int getColorG() { return colorG; }
	public int getColorB() { return colorB; }

	@Override
	public void method_5773() {
		super.method_5773();
		if (method_37908().field_9236) {
			method_37908().method_8406(new class_2390(new Vector3f(colorR / 255f, colorG / 255f, colorB / 255f), 1.0f),
					method_23317(), method_23318(), method_23321(), 0, 0, 0);
			return;
		}

		lifeTicks--;
		if (lifeTicks <= 0) {
			method_31472();
			return;
		}

		class_243 vel = method_18798();

		if (homing) {
			class_1297 target = homeTarget;
			if (target == null || !target.method_5805()) {
				target = findTarget();
				homeTarget = target;
			}
			if (target != null) {
				class_243 desired = target.method_19538().method_1031(0, target.method_17682() * 0.5, 0).method_1020(method_19538()).method_1029();
				class_243 cur = vel.method_1027() > 1e-6 ? vel.method_1029() : desired;
				double maxRad = Math.toRadians(turnRate / 20.0);
				class_243 blended = cur.method_1019(desired.method_1020(cur).method_1021(Math.min(1.0, maxRad * 3))).method_1029();
				vel = blended.method_1021(vel.method_1033());
			}
		}

		if (gravityStrength != 0) {
			class_1309 own = getOwnerLiving();
			class_243 gdir = own instanceof class_1657
					? LocalOrientation.gravityDir(own.method_5667())
					: new class_243(0, -1, 0);
			vel = vel.method_1019(gdir.method_1021(gravityStrength * 0.05));
		}
		if (drag > 0 && vel.method_1027() > 1e-6) {
			vel = vel.method_1021(Math.max(0, 1.0 - drag * 0.02));
		}
		method_18799(vel);

		class_243 next = method_19538().method_1019(vel);
		class_239 hit = method_37908().method_17742(new net.minecraft.class_3959(
				method_19538(), next,
				net.minecraft.class_3959.class_3960.field_17558,
				net.minecraft.class_3959.class_242.field_1348, this));

		class_3966 eHit = raycastEntity(method_19538(), next);
		if (eHit != null && (hit.method_17783() == class_239.class_240.field_1333 || eHit.method_17784().method_1025(method_19538()) < hit.method_17784().method_1025(method_19538()))) {
			onEntityHit(eHit);
			return;
		}
		if (hit.method_17783() == class_239.class_240.field_1332) {
			onBlockHit((class_3965) hit);
			return;
		}
		method_33574(next);
	}

	private class_1297 findTarget() {
		class_1309 own = getOwnerLiving();
		double best = 64 * 64;
		class_1297 found = null;
		for (class_1297 e : method_37908().method_8333(this, method_5829().method_1014(48),
				ent -> ent instanceof class_1309 && ent.method_5805() && ent != own)) {
			double d = e.method_5858(this);
			if (d < best) { best = d; found = e; }
		}
		return found;
	}

	private class_3966 raycastEntity(class_243 start, class_243 end) {
		class_1309 own = getOwnerLiving();
		class_3966 best = null;
		double bestDist = Double.MAX_VALUE;
		for (class_1297 e : method_37908().method_8333(this, method_5829().method_18804(end.method_1020(start)).method_1014(0.5),
				ent -> ent instanceof class_1309 && ent.method_5805() && ent != own && !pierced.contains(ent.method_5628()))) {
			var opt = e.method_5829().method_1014(0.3).method_992(start, end);
			if (opt.isPresent()) {
				double d = start.method_1025(opt.get());
				if (d < bestDist) {
					bestDist = d;
					best = new class_3966(e, opt.get());
				}
			}
		}
		return best;
	}

	private void onEntityHit(class_3966 hit) {
		class_1309 own = getOwnerLiving();
		if (own != null) {
			WeaponCore.directDamage(own, hit.method_17782(), directDamage, dmgClass);
			if (splashRadius > 0 && method_37908() instanceof class_3218 sw) {
				WeaponCore.splashDamage(own, sw, hit.method_17784(), splashDamage, splashRadius, dmgClass);
			}
		}
		if (onHit != null) onHit.accept(new WeaponCore.HitContext(this, hit.method_17782(), hit.method_17784(), method_18798().method_22882().method_1029(), false));
		pierced.add(hit.method_17782().method_5628());
		if (pierceCount > 0) {
			pierceCount--;
			method_33574(hit.method_17784().method_1019(method_18798().method_1029().method_1021(0.5)));
		} else {
			method_31472();
		}
	}

	private void onBlockHit(class_3965 hit) {
		class_1309 own = getOwnerLiving();
		if (own != null && splashRadius > 0 && method_37908() instanceof class_3218 sw) {
			WeaponCore.splashDamage(own, sw, hit.method_17784(), splashDamage > 0 ? splashDamage : directDamage * 0.5f, splashRadius, dmgClass);
		}
		if (onHit != null) onHit.accept(new WeaponCore.HitContext(this, null, hit.method_17784(), class_243.method_24954(hit.method_17780().method_10163()), true));
		method_31472();
	}

	@Override
	protected void method_5693(net.minecraft.class_2945.class_9222 builder) {}

	@Override
	protected void method_5749(class_2487 nbt) {
		lifeTicks = nbt.method_10550("life");
		directDamage = nbt.method_10583("dmg");
		splashDamage = nbt.method_10583("splash");
		splashRadius = nbt.method_10583("radius");
		dmgClass = DamageClass.fromId(nbt.method_10558("class"));
	}

	@Override
	protected void method_5652(class_2487 nbt) {
		nbt.method_10569("life", lifeTicks);
		nbt.method_10548("dmg", directDamage);
		nbt.method_10548("splash", splashDamage);
		nbt.method_10548("radius", splashRadius);
		nbt.method_10582("class", dmgClass.id);
	}

	@Override
	public void method_31471(class_2604 packet) {
		super.method_31471(packet);
	}
}
