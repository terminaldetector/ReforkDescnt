package com.terminaldetector.drmd.entity;

import com.terminaldetector.drmd.DescentMod;
import com.terminaldetector.drmd.world.bombardment.AerialBombEntity;
import com.terminaldetector.drmd.world.mega.DroneSwarmEntity;
import com.terminaldetector.drmd.world.mega.MegaWormEntity;
import com.terminaldetector.drmd.world.mega.ReactorKeeperEntity;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public final class ModEntities {
	public static final class_1299<ProjectileEntity> PROJECTILE = class_2378.method_10230(
			class_7923.field_41177,
			class_2960.method_60655(DescentMod.MOD_ID, "projectile"),
			class_1299.class_1300.<ProjectileEntity>method_5903(ProjectileEntity::new, class_1311.field_17715)
					.method_17687(0.35f, 0.35f)
					.method_27299(128)
					.method_27300(1)
					.build()
	);

	public static final class_1299<DroneEntity> DRONE = class_2378.method_10230(
			class_7923.field_41177,
			class_2960.method_60655(DescentMod.MOD_ID, "drone"),
			class_1299.class_1300.<DroneEntity>method_5903(DroneEntity::new, class_1311.field_6302)
					.method_17687(0.9f, 0.9f)
					.method_27299(96)
					.build()
	);

	public static final class_1299<AirMineEntity> AIR_MINE = class_2378.method_10230(
			class_7923.field_41177,
			class_2960.method_60655(DescentMod.MOD_ID, "air_mine"),
			class_1299.class_1300.<AirMineEntity>method_5903(AirMineEntity::new, class_1311.field_6302)
					.method_17687(0.6f, 0.6f)
					.method_27299(64)
					.build()
	);

	public static final class_1299<PyroShipEntity> PYRO_SHIP = class_2378.method_10230(
			class_7923.field_41177,
			class_2960.method_60655(DescentMod.MOD_ID, "pyro_ship"),
			class_1299.class_1300.<PyroShipEntity>method_5903(PyroShipEntity::new, class_1311.field_17715)
					.method_17687(2.2f, 1.2f)
					.method_27299(96)
					.method_27300(1)
					.build()
	);

	public static final class_1299<ReactorDisplayEntity> REACTOR_DISPLAY = class_2378.method_10230(
			class_7923.field_41177,
			class_2960.method_60655(DescentMod.MOD_ID, "reactor_display"),
			class_1299.class_1300.<ReactorDisplayEntity>method_5903(ReactorDisplayEntity::new, class_1311.field_17715)
					.method_17687(1.5f, 1.5f)
					.method_27299(64)
					.build()
	);

	public static final class_1299<MegaWormEntity> MEGA_WORM = class_2378.method_10230(
			class_7923.field_41177,
			class_2960.method_60655(DescentMod.MOD_ID, "mega_worm"),
			class_1299.class_1300.<MegaWormEntity>method_5903(MegaWormEntity::new, class_1311.field_6302)
					.method_17687(3.0f, 3.0f)
					.method_27299(256)
					.method_27300(2)
					.build()
	);

	public static final class_1299<DroneSwarmEntity> DRONE_SWARM = class_2378.method_10230(
			class_7923.field_41177,
			class_2960.method_60655(DescentMod.MOD_ID, "drone_swarm"),
			class_1299.class_1300.<DroneSwarmEntity>method_5903(DroneSwarmEntity::new, class_1311.field_17715)
					.method_17687(4.0f, 4.0f)
					.method_27299(256)
					.method_27300(5)
					.build()
	);

	public static final class_1299<ReactorKeeperEntity> REACTOR_KEEPER = class_2378.method_10230(
			class_7923.field_41177,
			class_2960.method_60655(DescentMod.MOD_ID, "reactor_keeper"),
			class_1299.class_1300.<ReactorKeeperEntity>method_5903(ReactorKeeperEntity::new, class_1311.field_6302)
					.method_17687(4.5f, 4.5f)
					.method_27299(160)
					.method_27300(2)
					.build()
	);

	public static final class_1299<AerialBombEntity> AERIAL_BOMB = class_2378.method_10230(
			class_7923.field_41177,
			class_2960.method_60655(DescentMod.MOD_ID, "aerial_bomb"),
			class_1299.class_1300.<AerialBombEntity>method_5903(AerialBombEntity::new, class_1311.field_17715)
					.method_17687(0.55f, 0.55f)
					.method_27299(256)
					.method_27300(1)
					.build()
	);

	public static final class_1299<com.terminaldetector.drmd.world.end.EndReactorBossEntity> END_REACTOR_BOSS = class_2378.method_10230(
			class_7923.field_41177,
			class_2960.method_60655(DescentMod.MOD_ID, "end_reactor_boss"),
			class_1299.class_1300.<com.terminaldetector.drmd.world.end.EndReactorBossEntity>method_5903(
							com.terminaldetector.drmd.world.end.EndReactorBossEntity::new, class_1311.field_6302)
					.method_17687(3.5f, 3.5f)
					.method_27299(160)
					.method_27300(2)
					.build()
	);

	private ModEntities() {}

	public static void register() {
		FabricDefaultAttributeRegistry.register(DRONE, DroneEntity.createDroneAttributes());
		FabricDefaultAttributeRegistry.register(AIR_MINE, AirMineEntity.createAttributes());
		FabricDefaultAttributeRegistry.register(PYRO_SHIP, PyroShipEntity.createAttributes());
		FabricDefaultAttributeRegistry.register(MEGA_WORM, MegaWormEntity.createAttributes());
		FabricDefaultAttributeRegistry.register(REACTOR_KEEPER, ReactorKeeperEntity.createAttributes());
		FabricDefaultAttributeRegistry.register(END_REACTOR_BOSS,
				com.terminaldetector.drmd.world.end.EndReactorBossEntity.createAttributes());
		DescentMod.LOGGER.info("Registered DRMD entities (incl. End giga-reactor boss)");
	}
}
