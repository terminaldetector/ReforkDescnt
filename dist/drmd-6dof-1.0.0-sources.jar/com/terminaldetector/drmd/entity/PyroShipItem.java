package com.terminaldetector.drmd.entity;

import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3959;

/**
 * Pyro GX — placeable Descent transport for survival craft + creative quick deploy.
 */
public class PyroShipItem extends class_1792 {
	public PyroShipItem(class_1793 settings) {
		super(settings);
	}

	@Override
	public class_1271<class_1799> method_7836(class_1937 world, class_1657 user, class_1268 hand) {
		class_1799 stack = user.method_5998(hand);
		if (world.field_9236) return class_1271.method_22427(stack);

		class_243 eye = user.method_33571();
		class_243 end = eye.method_1019(user.method_5828(1f).method_1021(8));
		var hit = world.method_17742(new class_3959(eye, end,
				class_3959.class_3960.field_17558, class_3959.class_242.field_1348, user));
		class_243 spawnAt = hit.method_17783() == class_239.class_240.field_1333
				? eye.method_1019(user.method_5828(1f).method_1021(3))
				: hit.method_17784().method_1031(0, 1.2, 0);

		return spawn(world, user, stack, spawnAt, user.method_36454())
				? class_1271.method_22427(stack)
				: class_1271.method_22431(stack);
	}

	@Override
	public class_1269 method_7884(class_1838 context) {
		class_1937 world = context.method_8045();
		if (world.field_9236) return class_1269.field_5812;
		class_2338 pos = context.method_8037().method_10093(context.method_8038());
		class_1657 user = context.method_8036();
		if (user == null) return class_1269.field_5814;
		class_243 at = class_243.method_24955(pos).method_1031(0, 0.5, 0);
		return spawn(world, user, context.method_8041(), at, user.method_36454())
				? class_1269.field_5812
				: class_1269.field_5814;
	}

	private boolean spawn(class_1937 world, class_1657 user, class_1799 stack, class_243 at, float yaw) {
		if (!(world instanceof class_3218 sw)) return false;
		PyroShipEntity ship = ModEntities.PYRO_SHIP.method_5883(sw);
		if (ship == null) return false;
		ship.method_5808(at.field_1352, at.field_1351, at.field_1350, yaw, 0);
		sw.method_8649(ship);
		world.method_43128(null, at.field_1352, at.field_1351, at.field_1350, class_3417.field_14785, class_3419.field_15248, 0.7f, 1.2f);
		if (!user.method_31549().field_7477) {
			stack.method_7934(1);
		}
		return true;
	}
}
