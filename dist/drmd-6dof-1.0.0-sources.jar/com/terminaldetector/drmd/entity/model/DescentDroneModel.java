package com.terminaldetector.drmd.entity.model;

import net.minecraft.class_1297;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_5603;
import net.minecraft.class_5606;
import net.minecraft.class_5607;
import net.minecraft.class_5609;
import net.minecraft.class_5610;
import net.minecraft.class_583;
import net.minecraft.class_630;
import net.minecraft.client.model.*;

/** Placeholder Descent scout drone — core + 4 spars. */
public class DescentDroneModel<T extends class_1297> extends class_583<T> {
	private final class_630 root;

	public DescentDroneModel(class_630 root) {
		this.root = root;
	}

	public static class_5607 getTexturedModelData() {
		class_5609 data = new class_5609();
		class_5610 root = data.method_32111();
		root.method_32117("core", class_5606.method_32108()
						.method_32101(0, 0).method_32097(-3f, -3f, -3f, 6f, 6f, 6f),
				class_5603.method_32090(0, 0, 0));
		root.method_32117("spar_n", class_5606.method_32108()
						.method_32101(0, 16).method_32097(-1f, -1f, -8f, 2f, 2f, 5f),
				class_5603.method_32090(0, 0, 0));
		root.method_32117("spar_s", class_5606.method_32108()
						.method_32101(0, 16).method_32097(-1f, -1f, 3f, 2f, 2f, 5f),
				class_5603.method_32090(0, 0, 0));
		root.method_32117("spar_e", class_5606.method_32108()
						.method_32101(16, 16).method_32097(3f, -1f, -1f, 5f, 2f, 2f),
				class_5603.method_32090(0, 0, 0));
		root.method_32117("spar_w", class_5606.method_32108()
						.method_32101(16, 16).method_32097(-8f, -1f, -1f, 5f, 2f, 2f),
				class_5603.method_32090(0, 0, 0));
		root.method_32117("eye", class_5606.method_32108()
						.method_32101(24, 0).method_32097(-1.5f, -1.5f, -4.5f, 3f, 3f, 2f),
				class_5603.method_32090(0, 0, 0));
		return class_5607.method_32110(data, 64, 64);
	}

	@Override
	public void method_2819(T entity, float limbAngle, float limbDistance, float animationProgress, float headYaw, float headPitch) {
		root.field_3675 = headYaw * ((float) Math.PI / 180f);
		root.field_3654 = headPitch * ((float) Math.PI / 180f);
		float spin = animationProgress * 0.15f;
		var n = root.method_32086("spar_n");
		var s = root.method_32086("spar_s");
		n.field_3674 = spin;
		s.field_3674 = -spin;
	}

	@Override
	public void method_2828(class_4587 matrices, class_4588 vertices, int light, int overlay, int color) {
		root.method_22699(matrices, vertices, light, overlay, color);
	}
}
