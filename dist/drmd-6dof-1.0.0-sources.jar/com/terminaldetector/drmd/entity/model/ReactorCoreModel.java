package com.terminaldetector.drmd.entity.model;

import net.minecraft.class_1297;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_5603;
import net.minecraft.class_5606;
import net.minecraft.class_5607;
import net.minecraft.class_5609;
import net.minecraft.class_5610;
import net.minecraft.class_583;
import net.minecraft.class_630;
import net.minecraft.client.model.*;

/** Placeholder reactor core visual (entity marker / display). */
public class ReactorCoreModel<T extends class_1297> extends class_583<T> {
	private final class_630 root;

	public ReactorCoreModel(class_630 root) {
		this.root = root;
	}

	public static class_5607 getTexturedModelData() {
		class_5609 data = new class_5609();
		class_5610 root = data.method_32111();
		root.method_32117("core", class_5606.method_32108()
						.method_32101(0, 0).method_32097(-4f, -4f, -4f, 8f, 8f, 8f),
				class_5603.method_32090(0, 0, 0));
		root.method_32117("ring", class_5606.method_32108()
						.method_32101(0, 16).method_32097(-8f, -1f, -8f, 16f, 2f, 16f),
				class_5603.method_32090(0, 0, 0));
		root.method_32117("pillar_a", class_5606.method_32108()
						.method_32101(32, 0).method_32097(-1f, -10f, -1f, 2f, 20f, 2f),
				class_5603.method_32090(6, 0, 6));
		root.method_32117("pillar_b", class_5606.method_32108()
						.method_32101(32, 0).method_32097(-1f, -10f, -1f, 2f, 20f, 2f),
				class_5603.method_32090(-6, 0, 6));
		root.method_32117("pillar_c", class_5606.method_32108()
						.method_32101(32, 0).method_32097(-1f, -10f, -1f, 2f, 20f, 2f),
				class_5603.method_32090(6, 0, -6));
		root.method_32117("pillar_d", class_5606.method_32108()
						.method_32101(32, 0).method_32097(-1f, -10f, -1f, 2f, 20f, 2f),
				class_5603.method_32090(-6, 0, -6));
		return class_5607.method_32110(data, 64, 64);
	}

	@Override
	public void method_2819(T entity, float limbAngle, float limbDistance, float animationProgress, float headYaw, float headPitch) {
		root.method_32086("ring").field_3675 = animationProgress * 0.05f;
		root.method_32086("core").field_3675 = -animationProgress * 0.03f;
	}

	@Override
	public void method_2828(class_4587 matrices, class_4588 vertices, int light, int overlay, int color) {
		root.method_22699(matrices, vertices, light, overlay, color);
	}
}
