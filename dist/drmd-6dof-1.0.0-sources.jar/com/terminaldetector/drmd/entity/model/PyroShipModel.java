package com.terminaldetector.drmd.entity.model;

import net.minecraft.class_1297;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_5603;
import net.minecraft.class_5606;
import net.minecraft.class_5607;
import net.minecraft.class_5609;
import net.minecraft.class_5610;
import net.minecraft.class_583;
import net.minecraft.class_630;
import net.minecraft.client.model.*;

/**
 * Placeholder Descent Pyro-class ship — elongated fuselage + wings + thruster.
 */
public class PyroShipModel<T extends class_1297> extends class_583<T> {
	private final class_630 root;

	public PyroShipModel(class_630 root) {
		this.root = root;
	}

	public static class_5607 getTexturedModelData() {
		class_5609 data = new class_5609();
		class_5610 root = data.method_32111();

		root.method_32117("fuselage", class_5606.method_32108()
						.method_32101(0, 0).method_32097(-2f, -2f, -10f, 4f, 4f, 16f)
						.method_32101(0, 20).method_32097(-1.5f, -1.5f, -12f, 3f, 3f, 3f),
				class_5603.method_32090(0, 0, 0));

		root.method_32117("wing_l", class_5606.method_32108()
						.method_32101(24, 0).method_32097(-10f, -0.5f, -2f, 8f, 1f, 6f),
				class_5603.method_32090(0, 0, 0));

		root.method_32117("wing_r", class_5606.method_32108()
						.method_32101(24, 8).method_32097(2f, -0.5f, -2f, 8f, 1f, 6f),
				class_5603.method_32090(0, 0, 0));

		root.method_32117("fin", class_5606.method_32108()
						.method_32101(40, 20).method_32097(-0.5f, -6f, 2f, 1f, 5f, 4f),
				class_5603.method_32090(0, 0, 0));

		root.method_32117("thruster", class_5606.method_32108()
						.method_32101(0, 28).method_32097(-1.5f, -1.5f, 6f, 3f, 3f, 3f),
				class_5603.method_32090(0, 0, 0));

		return class_5607.method_32110(data, 64, 64);
	}

	@Override
	public void method_2819(T entity, float limbAngle, float limbDistance, float animationProgress, float headYaw, float headPitch) {
		root.field_3675 = headYaw * ((float) Math.PI / 180f);
		root.field_3654 = headPitch * ((float) Math.PI / 180f);
	}

	@Override
	public void method_2828(class_4587 matrices, class_4588 vertices, int light, int overlay, int color) {
		root.method_22699(matrices, vertices, light, overlay, color);
	}
}
