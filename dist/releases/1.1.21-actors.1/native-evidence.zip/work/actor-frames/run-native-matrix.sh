#!/usr/bin/env bash
set -euo pipefail
cd /workspace/ungravity-v5/actor-frames
for scenario in release-actors-gl32 release-actors-sodium release-mirror-gl32 release-baseline-sodium release-mirror-sodium; do
  bash work/actor-frames/run-native.sh "$scenario"
done
