from pathlib import Path
import subprocess,importlib.util,json,os,shutil,zipfile,hashlib,re,csv,xml.etree.ElementTree as ET

r=Path('/workspace/ungravity-v5/actor-frames');os.chdir(r)
out=Path('/workspace/ungravity-v5/checkpoints/actor-frames-1.1.21');out.mkdir(exist_ok=True)
sha=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert sha.startswith('92d0d5b')
assert not subprocess.check_output(['git','diff','--stat'],text=True).strip()
s=importlib.util.spec_from_file_location('checkpoint_report',r/'scripts/checkpoint_report.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
with (r/'build/checkpoint/logs/verify.log').open('w') as stream:
    subprocess.run(['python3','scripts/checkpoint_report.py','--verify'],check=True,stdout=stream)
t=int((r/'build/checkpoint/started-at.txt').read_text())
audit=m.verify_audit(r,t);m.verify_native_audit(r,t)
p=json.loads((r/'build/checkpoint/verified.json').read_text());assert p['source_sha']==sha
expected=json.loads((r/'build/checkpoint/inputs-expected.json').read_text())
assert expected=={'sourceSha':sha,'jarSha256':p['sha256']}
shotproof=json.loads((r/'build/shootcheck/shootcheck-ok.json').read_text())
assert shotproof['fastTickStepped'] is True and shotproof['fastServerTicks']>=3 and shotproof['fastServerTravel']>=24
assert '\nOK\n' in (r/'build/checkpoint/logs/python-tests.log').read_text()
assert p['unit']['tests']==567 and p['gametest']['tests']==117
cases=ET.parse(r/'build/gametest/reports/gametest-results.xml').findall('.//testcase')
actorcases=[c.attrib['name'] for c in cases if c.attrib['name'].startswith(('actorframegametests.','flyingrostergravitygametests.','surfacecombatgametests.','droneloadoutgametests.'))]
assert len(actorcases)==10 and all(c.find('failure') is None for c in cases)
native={'status':'NATIVE_SUBSET_PASS_FULL_MASTER_V5_PENDING','sourceSha':sha,'jarSha256':p['sha256'],'softwareGraphics':True,'scenarios':[]}
scenarios=('release-actors-gl32','release-actors-sodium','release-mirror-gl32','release-baseline-sodium','release-mirror-sodium')
for scenario in scenarios:
    d=r/f'build/cubic-client-final-{scenario}';meta=json.loads((d/'inputs.json').read_text())
    assert meta['sourceSha']==sha and meta['uncommittedDiff']=='' and not meta['experimental_native_relight_probe']
    game=next(v for v in meta['artifacts'] if v['path']==f'mods/drmd-6dof-{p["version"]}.jar')
    assert game['sha256']==p['sha256']
    assert (r/f'work/actor-frames/final-{scenario}.exit').read_text().strip()=='0'
    marker='actor-frames-ok.json' if 'actors' in scenario else 'cubic-client-ok.json' if 'baseline' in scenario else 'native-mirror-ok.json'
    m.fresh(d/marker,t);result=json.loads((d/marker).read_text())
    if 'actors' in scenario:
        assert len(result['scenes'])==6 and [v['stage'] for v in result['scenes']]==list(range(6))
        assert all(v['models']==6 and v['renderedFrames']>=90 for v in result['scenes'])
    elif 'baseline' in scenario:assert len(result['checks'])==14 and result['warpedVertices']>0
    else:assert result['frames']==14 and len(result['scenes'])==7
    log=(r/f'work/actor-frames/final-{scenario}.log').read_text();assert 'DUMMY' not in log
    native['scenarios'].append({'name':scenario,'gl':meta['glOverride'],'dummyMessages':0,'result':result})
out.joinpath('NATIVE_MATRIX_VERIFIED.json').write_text(json.dumps(native,indent=2))
out.joinpath('FULL_AUDIT_VERIFIED.json').write_text(json.dumps(audit,indent=2))
out.joinpath('ACTOR_CASES_VERIFIED.json').write_text(json.dumps({'sourceSha':sha,'cases':actorcases},indent=2))
for phase in ('unit-gametest-build','rendercheck','shootcheck'):
    assert (r/f'build/checkpoint/logs/{phase}.exit').read_text().strip()=='0'
for phase in ('unit','gametest','build','rendercheck','shootcheck','verify'):os.environ[phase.upper()+'_OUTCOME']='success'
m.report(r)
shutil.copy2(r/'build/checkpoint/REPORT.md',out/'AUTOMATED_REPORT.md')
shutil.copy2(r/'build/checkpoint/screenshots.zip',out/'regression-frames.zip')
jar=r/'build/checkpoint/distribution'/p['jar']
with zipfile.ZipFile(jar) as z:
    assert not [n for n in z.namelist() if '/gate/' in n or n.startswith('dev/fallingcloud/') or 'NativeActorFrameCheck' in n]
shutil.copy2(jar,out/p['jar'])
subprocess.run(['git','archive','--format=tar.gz',f'--prefix=ungravity-{sha[:7]}/','-o',str(out/f'source-{sha[:7]}.tar.gz'),'HEAD'],check=True)
subprocess.run(['git','bundle','create',str(out/'changes.bundle'),'ba8de3f..HEAD'],check=True)
subprocess.run(['git','bundle','verify',str(out/'changes.bundle')],check=True,stdout=subprocess.DEVNULL)
with zipfile.ZipFile(out/'regression-evidence.zip','w',compression=zipfile.ZIP_DEFLATED) as z:
    for pattern in ('build/checkpoint/logs/*','build/checkpoint/resources/*','build/test-results/test/*.xml','build/gametest/reports/*.xml','build/rendercheck/*ok.txt','build/shootcheck/*ok.json','build/shootcheck/swarm-profile.csv','build/shootcheck/inventory-models.tsv','build/gametest/item-resource-inventory.tsv','build/checkpoint/verified.json','build/checkpoint/SOURCE_SHA.txt','build/checkpoint/started-at.txt','build/checkpoint/inputs-expected.json'):
        for f in r.glob(pattern):
            if f.is_file():z.write(f,f.relative_to(r))
with zipfile.ZipFile(out/'native-evidence.zip','w',compression=zipfile.ZIP_DEFLATED) as z:
    for scenario in scenarios:
        d=r/f'build/cubic-client-final-{scenario}'
        for pattern in ('inputs.json','*ok.json','actor-frames/*.png','gate-frames/*.png','native-mirror-frames/*.png','logs/latest.log','options.txt','config/*.json','config/drmd/*.json'):
            for f in d.glob(pattern):
                if f.is_file():z.write(f,f.relative_to(r))
        for suffix in ('log','exit'):
            f=r/f'work/actor-frames/final-{scenario}.{suffix}';z.write(f,f.relative_to(r))
    for name in ('run-native.sh','run-native-matrix.sh','run-regression-clients.sh','finalize.py'):
        f=r/'work/actor-frames'/name;z.write(f,f.relative_to(r))
with zipfile.ZipFile(out/'failed-checks.zip','w',compression=zipfile.ZIP_DEFLATED) as z:
    for pattern in ('work/actor-frames/first-runtime.log','work/actor-frames/first-compile.log','work/actor-frames/failed-first/**/*','work/actor-frames/failed-fast-tracking/**/*','work/actor-frames/failed-step-clock/**/*','build/cubic-client-failed-actors-gl32-first/crash-reports/*.txt'):
        for f in r.glob(pattern):
            if f.is_file():z.write(f,f.relative_to(r))
out.joinpath('INSTALL_TLAUNCHER.txt').write_text(f'''UNGRAVITY / DRMD {p['version']} — Minecraft 1.21.1 / Fabric / Java 21
Установочный JAR: {p['jar']}
SHA-256: {p['sha256']}

Отдельный профиль Fabric 1.21.1 + Fabric API 0.116.15+1.21.1. Один DRMD JAR в mods.
Immersive Portals для DRMD не требуется. Не устанавливать sources/dev/cubiccheck JAR.
Исходные сохранения сохранить отдельно. Для экспериментального кубического мира:
Fabric Loader 0.19.5+, Better Cubic Chunks 0.1.1+mc1.21.1 и НОВЫЙ мир с preset
bettercubicchunks:cubic_default. Исходный обычный мир не превращать в кубический.
BCC/Sodium в пакет не входят. Проверено на llvmpipe: без Sodium GL3.2/GLSL150,
с Sodium0.8.13 GL3.3/GLSL330. Физическая Intel HD4400 здесь не проверена.
Встроенные адаптеры дронов/бестиария включены по умолчанию. Полное Master v5
ещё не выполнено; физические коллайдеры летающих корпусов/3D AI остаются в работе.
''')
out.joinpath('RESTORE.md').write_text(f'''Source: {sha}. source-{sha[:7]}.tar.gz contains the complete tracked source.
changes.bundle is incremental and requires baseline ba8de3f. Restore into a new branch/worktree.
Do not reset, merge or force-update the original integration branch or PR #9.
GitHub push/Actions remain paused by the recovery instructions. This is a local backup.
Current code/roster ledger: docs/v5/ACTOR_FRAMES.md. See REPORT.md for acceptance limits.
''')
lag=[]
for name in ('rendercheck','shootcheck'):
    lag += [int(v) for v in re.findall(r'Running (\d+)ms or',(r/f'build/checkpoint/logs/{name}.log').read_text())]
profiles=list(csv.DictReader((r/'build/shootcheck/swarm-profile.csv').open()))
profile_table='\n'.join(f"| {v['requested']} | {v['moving']} | {v['fps']} |" for v in profiles)
shutil.copy2(r/'build/shootcheck/swarm-profile.csv',out/'swarm-profile.csv')
out.joinpath('REPORT.md').write_text(f'''# UNGRAVITY — дроны и локальная ориентация, этап 1.1.21

Исходники `{sha}`. Версия `{p['version']}`; Minecraft 1.21.1 / Fabric / Java 21.
JAR `{p['jar']}`. SHA-256 `{p['sha256']}`.
Локальный контрольный пакет: GitHub/Actions остаются на паузе. Старые ветки и сохранения сохранены.
**Полное Master ТЗ v5 ещё не выполнено.**

## Что изменено

- Дроны, Scanner, Seeker, Keeper, босс и воздушная мина получили отдельную обработку полей:
  притяжение добавляет силу и сохраняет тягу/направление. Пешеходная посадка, сброс скорости,
  искусственное касание земли и прижим к поверхности для них не вызываются.
- Drone/Scanner/Seeker рисуются по полной базе направления и крена, включая вертикальный
  полёт и переворот. Удалён крен вокруг мировой Z и двойное применение pitch к DroneModel.
- У Tripod/Spider Turret единая локальная вертикаль для тела, глаз, взгляда, дула и модели.
  Преследование/отступление идут по касательной поверхности; головное наведение турели
  учитывает локальную систему координат. Дроны целятся в центр фактического тела цели.
- Состояние передаётся штатными метаданными Minecraft, включая начальный spawn/late join,
  и сохраняется в версионированном NBT. Ошибочные данные отклоняются.
- Поворот проверяет свободное место только в загруженных FULL-объёмах. Небезопасный поворот
  отклоняется, заблокированный выход в мировую вертикаль откладывается без телепорта.
  Слабый индекс не удерживает мобов/миры; не добавленная в мир NBT-копия не получает lease.
- Реализованные адаптеры работают по умолчанию, без дополнительного экспериментального флага.

Все 11 ролей дронов проверены на полный запас HP/защиты. Исправлены 200/800 HP у Heavy Elite,
лечение при загрузке и клиентские значения роли/щита/брони из значений конструктора.

## Свежие проверки этой ревизии

| Проверка | Результат |
|---|---|
| Модульные Java / Python | 567 / 27 PASS |
| Серверные GameTests | 117 обязательных PASS, без пропусков |
| Новые проверки актёров | 10 PASS: 6 осей, тело/глаза/лучи, препятствие/выход, NBT, зарегистрированный объект, наземный и летающий бестиарий |
| Живой бой | Tripod с обычным AI преследует цель по стене и стреляет своим снарядом |
| Общая регрессия | 5 свежих маркеров terrain/collapse/ragdoll/gravity/swarm; {p['swarm']} |
| Оружие / Workshop | 10 сцен, быстрый выстрел8 блоков/тик с пошаговыми часами fixture, FOV70/80/90, 3 модели, сохранение и загрузка |
| Расширенный видеоаудит | Свежая полная матрица принята отдельным verify_audit; см. FULL_AUDIT_VERIFIED.json |
| Реальный кубический клиент: бестиарий | 6 сцен × 6 моделей, включая вертикаль ±90° и крен180°; без Sodium GL3.2 и с Sodium GL3.3 |
| Нативная регрессия | 14 базовых проверок с Sodium и по14 кадров зеркал/порталов с Sodium и без него |
| Источник/JAR | Все финальные нативные сценарии используют этот SHA и один проверенный JAR |

Оригиналы кадров и XML сохранены. Модели в новых кадрах просмотрены вручную.
В нативных логах пяти сценариев нет DUMMY. Это не доказательство устранения всех исторических
причин DUMMY/задержек. Максимальное сообщение задержки в свежих обычных клиентах: {max(lag,default=0)} мс.
Профили роя — контролируемый тест на программной графике, не обещание производительности.

| Дронов | Двигалось | FPS llvmpipe |
|---|---|---|
{profile_table}

Это не A/B-сравнение с предыдущим JAR и не доказательство ускорения. Все актёры в профиле
контролируемые/неуязвимые; бой в Survival и целевой аппаратный бюджет ещё не приняты.

## Ограничения и следующий этап

Это ещё не полная универсальная физика 6DoF. Коллизия стоящего тела — консервативный AABB;
летающим корпусам ещё нужны отдельные ориентированные коллайдеры и угловая динамика.
Водная физика, трение/шаг/навигация ванильных мобов глобально не заменены. При заблокированном
возврате к мировой вертикали моб остаётся в безопасной позе и ждёт свободного места.
Наземный бестиарий умеет прямое преследование по поверхности, но полноценного обхода препятствий
по стенам/потолкам и маршрутизации в 3D ещё нет. Keeper/босс пока имеют только адаптер силы;
их процедурные рендеры, виртуальный swarm anchor и Sky UFO требуют отдельных адаптеров.
Общий ragdoll всего бестиария, автономная охота в Survival, корабли, большие городские разрушения,
полная cubic/worldgen/content parity, прогоны давления памяти8/12/24 и 3D LOD остаются открытыми пунктами Master v5.
Также ещё нужна привязка применения сил к native entity-ticking, чтобы замороженный загруженный
актёр не накапливал ускорение между собственными тиками; этот этап её не сертифицирует.
Физическая HD4400 не доступна; Sodium0.8.13 со строгим GL3.2 ранее не прошёл из-за GLSL330.

## Сохранённые сбои

Первый серверный запуск: проверка направления ошибочно сравнивала знаковые нули через
Vec3d.equals. Заменена сравнением геометрического расстояния; порог направления не ослаблялся.
Первый клиентский измеритель снимал матрицу до production-обработчика RETURN. Теперь проверяет
результат после полного setupTransforms. Сбой и crash report сохранены в failed-checks.zip.
Отдельный полный оружейный прогон потерял быстрый снаряд за радиусом отслеживания между
измерениями: сервер успел пройти18 тиков. Снаряд был виден на клиенте до этого. Сцена теперь
шагает по одному обычному тику на измеренный кадр в своём disposable-мире. Скорость spawn/metadata
остаётся8 блоков/тик; минимум3 кадра,3 серверных тика,24 блока и прежние пороги пикселей сохранены.
Это проверка движения/метаданных, не тест производительности в реальном времени. Лог, первый
кадр и crash report сохранены. Первый пошаговый прототип ошибочно запрещал обычную
сетевую коррекцию с нулевым продвижением в соседних кадрах. Измерение заменено на итоговое
продвижение от первого кадра, чтобы коррекции не прибавляли фиктивный пробег. Проверяются
реальный серверный пробег8×число тиков и предел клиентского предсказания4 тика.
Промежуточные запуски не заменяют доказательство этого SHA.
''')
for f in out.glob('*.zip'):
    with zipfile.ZipFile(f) as z:assert z.testzip() is None
out.joinpath('SHA256SUMS').write_text(''.join(f'{hashlib.sha256(f.read_bytes()).hexdigest()}  {f.name}\n' for f in sorted(out.iterdir()) if f.is_file() and f.name!='SHA256SUMS'))
print('Verified checkpoint:',out,sha,p['sha256'])
