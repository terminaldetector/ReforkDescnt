#!/usr/bin/env python3
"""Offline assembly of one explicitly qualified development RC. No builds/publication.
Existing scripts/checkpoint_report.py rejects -dev versions and verifies its historical
marker matrix. This post-verification assembler does not forge those markers or bypass
that verifier; its distinct scope is the final-local receipts named in its frozen config.
"""
from pathlib import Path,PurePosixPath
import argparse,hashlib,json,os,shutil,stat,subprocess,sys,tempfile,uuid,xml.etree.ElementTree as ET,zipfile
SOURCE=TEST_SOURCE=GAME_SHA=None
ACK_SOURCE='0178e6c841d25f489f6be612b9e16cfdcb391be1'
ACK_GAME_SHA='c381db97961597ff64ba5bd49e2ed3055d205bed6eb5444323d72926572eb713'
HIST_SOURCE='6877d3c64b6a6a6ea4910cbf89d9d010a927a068'
HIST_GAME_SHA='947bf4c3d55113fb3656b92278b05d5b1fbb3f3afedf90824c8dda652f392198'
VERSION='1.1.35-ufo-dev.1'
EXPECTED_TESTS=None
EXPECTED_CLASSES=117
REPO=Path('/workspace/ungravity-v5/ufo-body-physics')
class Invalid(ValueError):pass
def require(ok,msg):
 if not ok:raise Invalid(msg)
def sha(p):
 with Path(p).open('rb') as f:
  require(stat.S_ISREG(os.fstat(f.fileno()).st_mode),f'Not a regular file: {p}')
  return hashlib.file_digest(f,'sha256').hexdigest()
def pairs(items):
 d={}
 for k,v in items:
  require(k not in d,f'Duplicate JSON key: {k}');d[k]=v
 return d
def read(p):return json.loads(Path(p).read_text(),object_pairs_hook=pairs,parse_constant=lambda x:(_ for _ in ()).throw(Invalid('Nonfinite JSON:'+x)))
def emit(p,d):
 with Path(p).open('x') as f:json.dump(d,f,indent=2,ensure_ascii=False);f.write('\n')
def git_blob(rev,path):return subprocess.run(['git','show',rev+':'+path],cwd=REPO,check=True,capture_output=True).stdout
def native_inputs(root,source=HIST_SOURCE,game=HIST_GAME_SHA):
 d=read(root/'cubic-client-automation/inputs.json')
 require(d['sourceSha']==source,f'Wrong native source: {root}')
 a=[x for x in d['artifacts'] if x['path'].startswith('mods/drmd-') and x['path'].endswith('-dev.1.jar')]
 require(len(a)==1 and a[0]['sha256']==game,f'Wrong native game: {root}')
 require((root/'native.exit').read_text().strip()=='0',f'Nonzero/missing native exit: {root}')
 return d

def load_identity(config):
 import provenance
 global SOURCE,TEST_SOURCE,GAME_SHA,EXPECTED_TESTS,EXPECTED_CLASSES
 d=provenance.valid_identity(read(config['producer']))
 require(d['source']=='9cdb8dd48ed84ac850547fdeb309688a8bb2ee05','This successor is reviewed for exact portal-roster producer9cdb only')
 require(SOURCE is None or (SOURCE,TEST_SOURCE,GAME_SHA)==(d['source'],d['testSource'],d['gameSha256']),'Cannot mix producer identities in one process')
 SOURCE,TEST_SOURCE,GAME_SHA=d['source'],d['testSource'],d['gameSha256']
 EXPECTED_TESTS,EXPECTED_CLASSES=d['ordinaryTests'],d['ordinaryClasses']
 require(EXPECTED_TESTS==713 and EXPECTED_CLASSES==117,'Frozen new full scope must be713/117')
 require(Path(config['game']).resolve()==Path(d['game']).resolve(),'Config names another actual game path')
 return d

def ordinary(config):
 receipt_path=Path(config['ordinary_receipt']);r=read(receipt_path);base=receipt_path.parent
 require(r.get('source')==TEST_SOURCE,'Ordinary gate has wrong test source')
 require(r.get('namedGameSource')==SOURCE,'Ordinary gate has wrong actual named game producer')
 require(type(r.get('exit')) is int and r['exit']==0 and r.get('validatedAfterRun') is True,'Ordinary process/post-input check did not pass')
 p=base/'runtime/reports/gametest-results.xml';require(sha(p)==r.get('junitSHA256'),'Ordinary XML SHA not bound to actual receipt')
 cases=list(ET.parse(p).getroot().iter('testcase'));require(len(cases)==EXPECTED_TESTS,'Expected actual713 ordinary cases')
 require(all(not any(c.find(k) is not None for k in ('failure','error','skipped')) for c in cases),'Ordinary XML contains failure/error/skipped')
 require(len(cases)==r.get('tests') and all(type(r.get(k)) is int and r[k]==0 for k in ('failures','errors','skips')),'Ordinary actual counts disagree')
 manifest=json.loads(git_blob(TEST_SOURCE,'src/gametest/resources/fabric.mod.json'))
 expected=manifest['entrypoints']['fabric-gametest'];require(len(set(expected))==len(expected),'Duplicate registered class')
 names=[c.get('name','').lower() for c in cases];require(len(names)==len(set(names)),'Duplicate ordinary case names');require(len(expected)==EXPECTED_CLASSES,'Expected actual117 registered classes')
 missing=[n for n in expected if not any(x.startswith(n.rsplit('.',1)[-1].lower()+'.') for x in names)]
 require(not missing,'Ordinary registered classes absent from actual cases: '+str(missing))
 inp=read(base/'inputs.json');require(inp.get('source')==TEST_SOURCE and inp.get('entrypoints')==expected,'Ordinary manifest/source tuple differs')
 require(r.get('registeredEntrypoints')==len(expected),'Ordinary class count differs')
 require((base/'game.log').stat().st_size>0,'Missing ordinary raw process log')
 changed=subprocess.run(['git','diff','--name-only',SOURCE,TEST_SOURCE],cwd=REPO,check=True,capture_output=True,text=True).stdout.splitlines()
 require(all(x.startswith(('docs/','src/gametest/','src/test/','src/cubiccheck/')) for x in changed),'Game/build source changed between producer and ordinary test source')
 return {'source':TEST_SOURCE,'tests':len(cases),'classes':len(expected),'failures':0,'errors':0,'skips':0,'receiptSha256':sha(receipt_path),'xmlSha256':sha(p),'gameLogSha256':sha(base/'game.log')},[(receipt_path,'ordinary-receipt.json'),(p,'ordinary-junit.xml'),(base/'game.log','ordinary-game.log')]

def archived_proof(path):
 d=read(path);archive=Path(path).with_name(d['archive']);require(sha(archive)==d['archiveSha256'],'Proof archive hash differs')
 with zipfile.ZipFile(archive) as z:
  require(z.testzip() is None,'Proof archive CRC differs');require({n:hashlib.sha256(z.read(n)).hexdigest() for n in z.namelist()}==d['memberSha256'],'Proof archive member bytes differ')
 return d,archive

def source_bridge(config):
 import provenance
 identity=provenance.valid_identity(read(config['producer']))
 require(identity['source']==SOURCE and identity['testSource']==TEST_SOURCE and identity['gameSha256']==GAME_SHA,'Frozen identity differs from actual package tool')
 p=Path(config['component_applicability']);recorded=read(p)
 actual=provenance.assess(identity,read(config['delta_review']),REPO)
 require(actual==recorded,'Scoped applicability receipt differs from actual final bytes/source')
 return actual,[(p,'component-applicability.json'),(Path(config['delta_review']),'reviewed-final-delta.json'),(Path(config['producer']),'final-producer.json')]

def units(config):
 p=Path(config['unit_receipt']);d,z=archived_proof(p)
 require(d['source']==SOURCE and d['gameSha256']==GAME_SHA and d['actualUnitBuildExit']==0 and d['actualGradleTestTaskRan'] is True,'Unit source/process differs')
 require(d['suites']==213 and d['tests']==1248 and d['failures']==d['errors']==d['skips']==0,'Unit results not actual1248/213 clean')
 return {'source':SOURCE,'tests':1248,'suites':213,'failures':0,'errors':0,'skips':0,'receiptSha256':sha(p),'archiveSha256':d['archiveSha256']},[(p,'unit-closed-results.json'),(z,'unit-closed-results.zip')]

def ack_regression(config):
 p=Path(config['ack_regression']);d=read(p);z=p.with_suffix('.zip');require(d['source']==ACK_SOURCE and d['jarSha256']==ACK_GAME_SHA and sha(z)==d['archiveSha256'],'ACK sealed archive identity differs')
 with zipfile.ZipFile(z) as archive:require(archive.testzip() is None,'ACK sealed archive CRC differs')
 # Canonical sealed index is not a new game launch. Its precise fields are bound
 # through the complete archive; the original before/after receipts are checked below.
 base=Path(config['ack_regression_base']);files=[(p,'boarding-ack-regression.json'),(z,'boarding-ack-regression.zip')];out={}
 for name,named,exitcode,failures in [('boarding-before',HIST_SOURCE,1,1),('boarding-after',ACK_SOURCE,0,0)]:
  rp=base/name/'receipt.json';r=read(rp);xp=rp.parent/'runtime/reports/gametest-results.xml'
  require(r['source']==ACK_SOURCE and r['namedGameSource']==named and r['exit']==exitcode and r['tests']==3 and r['failures']==failures and r['errors']==r['skips']==0 and r['validatedAfterRun'] is True,'Actual ACK control result differs:'+name)
  require(sha(xp)==r['junitSHA256'],'ACK actual XML differs')
  cases=list(ET.parse(xp).getroot().iter('testcase'));bad=[c.get('name') for c in cases if c.find('failure') is not None]
  require(len(cases)==3 and len(bad)==failures and (not bad or bad==['boardingvelocitygametests.reconnectafterarotateddeckleavesthesavedworldpositionrestoresitsrealsupport']),'Wrong delayed-ACK negative/control')
  out[name]={'namedGameSource':named,'exit':exitcode,'tests':3,'failures':failures,'receiptSha256':sha(rp),'xmlSha256':sha(xp)}
 return {'executedSource':ACK_SOURCE,'executedGameSha256':ACK_GAME_SHA,'historicalExecution':True,'componentApplicabilityGroup':'boardingAck','actualCases':out},files

def native_close(proof_path,d):
 raw=proof_path.parent/'actual-close.json';r=read(raw)
 require({k:v['exit'] for k,v in r['children'].items()}=={'server':0,'crew':0,'late':0},'Actual native children were not all0')
 require(r['children']['server']['pid']==d['serverPid'],'Actual native close belongs to another server PID')
 replay=d.get('qualificationReplay')
 result={'actualCloseSha256':sha(raw),'initialQualifierQualified':r.get('qualified'),'qualificationReplay':replay}
 if replay:
  require(replay['actualCloseSha256']==sha(raw) and isinstance(replay.get('reason'),str) and replay['reason'],'Unbound qualification replay')
  result['scope']='Original native exits preserved; initial Python qualification was not clean. Recorded qualification replay/correction is disclosed verbatim.'
 else:require(r.get('qualified') is True,'Original native qualifier failed without an explicit bound replay')
 return result,raw

def reader(config):
 wp=Path(config['writer_proof']);rp=Path(config['reader_proof']);w=read(wp);r=read(rp)
 require(w.get('qualified') is True and r.get('qualified') is True and w.get('mode')=='writer' and r.get('mode')=='reader','Native writer/reader not qualified')
 for d in (w,r):
  require(d.get('source')==ACK_SOURCE and d.get('modHashes',{}).get('game')==ACK_GAME_SHA,'Wrong actual historical native reader/writer producer')
  require(d.get('children')=={'server':0,'crew':0,'late':0},'Native reader/writer child exits not all0')
 require(w['serverPid']!=r['serverPid'] and r['originalWriter']['writerServerPid']==w['serverPid'],'Reader did not reopen the actual separate writer')
 p=r['proof'];require(p['serverSidePlacementCalls']==1 and p['realLocalWalk']>=.32 and p['acceptedForwardPackets']>=3,'Actual restored-body placement/walk/input missing')
 require(p['bothTCPPlayersConcurrent'] is True and p['exactOriginalIds'] is True and p['manualBodyTicks']==0,'Reader physical/native identity predicate missing')
 require(len(r['reciprocalNativeFrames'])==2,'Two actual reciprocal native frames missing')
 wclose,wraw=native_close(wp,w);rclose,rraw=native_close(rp,r)
 return {'source':ACK_SOURCE,'gameSha256':ACK_GAME_SHA,'historicalExecution':True,'componentApplicabilityGroup':'boardingAck','applicableFinalSource':SOURCE,'writerQualification':wclose,'readerQualification':rclose,'writerReceiptSha256':sha(wp),'readerReceiptSha256':sha(rp),'writerServerPid':w['serverPid'],'readerServerPid':r['serverPid'],'children':r['children'],'proof':p,'scope':'Dedicated real TCP writer/fresh reader with original saved bodies and two actual native clients'},[(wp,'native-writer-qualified.json'),(rp,'native-reader-qualified.json'),(wraw,'native-writer-original-actual-close.json'),(rraw,'native-reader-original-actual-close.json')]

def save_check(archive,receipt):
 d=read(receipt);require(sha(archive)==d['archiveSha256'],'Test-save archive SHA mismatch')
 require(Path(archive).stat().st_size==d['archiveBytes'],'Test-save archive size mismatch')
 with zipfile.ZipFile(archive) as z:
  names=z.namelist();require(len(names)==len(set(names)),'Duplicate world ZIP members')
  require(z.testzip() is None,'World ZIP CRC failure')
  files={}
  require(sum(x.file_size for x in z.infolist())<=512*2**20,'World uncompressed size exceeds512MiB')
  for i in z.infolist():
   p=PurePosixPath(i.filename)
   require(not p.is_absolute() and '..' not in p.parts and '\\' not in i.filename and p.parts[0]=='Cubic-Gate','Unsafe/non-Cubic-Gate world member')
   require(not stat.S_ISLNK(i.external_attr>>16),'Symlink world member')
   if not i.is_dir():files[i.filename]=hashlib.sha256(z.read(i)).hexdigest()
  require(files==d['files'],'Every world file must match the actual closed-save receipt')
 require('Cubic-Gate/level.dat' in files,'Missing actual level.dat')
 return {'sha256':d['archiveSha256'],'bytes':d['archiveBytes'],'fileCount':len(files),'scope':'Exact closed ring-ascent world; native S09 reader is a separate saved-body scenario, not a claim this same ring save was the reader input'}

def ring(config):
 root=Path(config['ring']);native_inputs(root);p=root/'cubic-client-automation/high-altitude-lod-outcome.json';d=read(p);r=d['ringAscent']
 require(d['status']=='PASS' and d['maximumMissingHorizonFrames']==0 and r['firstUncoveredFrame']=={} and r['maximumMissingFrames']==0,'Ring ascent actual continuity failed')
 frames=r['actualCompletedWorldFrames'];require(isinstance(frames,list) and len(frames)>=507 and all(f['uncoveredPixels']==0 for f in frames),'Missing actual507-frame continuous ring sequence')
 require(r['authoredWorldWrites']==0 and r['actualRingDeckFrames']>=3 and r['admittedStationaryNativeSurface']['surfacePixelsAtNativeDepth']>0,'Missing real unedited surface/deck admission')
 return {'source':HIST_SOURCE,'gameSha256':HIST_GAME_SHA,'historicalExecution':True,'componentApplicabilityGroup':'renderBDH','outcomeSha256':sha(p),'completedFrames':len(frames),'scope':'Actual normal-input surface→ring ascent with sampled retained ground'},[(p,'ring-outcome.json'),(root/'native.log','ring-native.log'),(root/'native.exit','ring-native.exit')]

def portal(config):
 root=Path(config['portal']);native_inputs(root,SOURCE,GAME_SHA);p=root/'cubic-client-automation/portal-gun-ok.json';d=read(p)
 require(d.get('actualMouseEntry') is True and d.get('packetPlacement') is True,'Portal gun normal input missing')
 require([s['scene'] for s in d['scenes']]==['blue-only','paired-blue-orange','blue-replaced','pair-cleared','container-protected'] and all(s['frames']>=60 for s in d['scenes']),'Portal gun scenes incomplete')
 files=[(p,'portal-gun-outcome.json'),(root/'native.log','portal-native.log'),(root/'native.exit','portal-native.exit')];crossings={}
 for key,flight in [('portal_walking',False),('portal_sixdof',True)]:
  case=Path(config[key]);native_inputs(case,SOURCE,GAME_SHA);rp=case/'cubic-client-automation/gun-traversal-outcome.json';q=read(rp)
  require(q['status']=='PASS' and q['flight'] is flight and q['crossings']==1 and q['cameraStateChanges']==0 and q['nearFrames']>=3,'Actual portal walking/6DoF case failed:'+key)
  crossings[key]={'outcomeSha256':sha(rp),'flight':flight,'crossings':q['crossings']};files.extend([(rp,key+'-outcome.json'),(case/'native.log',key+'-native.log'),(case/'native.exit',key+'-native.exit')])
 index_path=Path(config['portal_index']);index=read(index_path);require(index['status']=='PASS' and index['source']==SOURCE and index['jarSha256']==GAME_SHA,'Fresh portal sealed index differs');files.append((index_path,'fresh-portal-native-index.json'))
 return {'source':SOURCE,'gameSha256':GAME_SHA,'freshActualExecution':True,'outcomeSha256':sha(p),'sceneCount':5,'crossings':crossings,'scope':'Latest actual portal-gun input plus walking and banked6DoF crossings'},files

def bdh(config):
 p=Path(config['bdh_receipt']);d=read(p);require(d['status']=='PASS' and d['nativeExit']==0 and len(d['frames'])==3,'Separate BDH proof incomplete')
 z=p.with_name(d['archive']);require(sha(z)==d['archiveSha256'],'Separate BDH archive hash mismatch')
 with zipfile.ZipFile(z) as a:
  require(a.testzip() is None,'BDH proof archive CRC failure');require({n:hashlib.sha256(a.read(n)).hexdigest() for n in a.namelist()}==d['memberSha256'],'BDH member hashes differ')
 return {'source':d['source'],'gameSha256':d['passedJarSha256'],'scope':d['scope'],'separateProducer':True,'componentApplicabilityGroup':'renderBDH','notFreshFinalExecution':True,'receiptSha256':sha(p),'archiveSha256':d['archiveSha256']},[(p,'separate-bdh-proof.json')]

def preserved_nonpass(config):
 p=Path(config['original_nonpass']);d=read(p);z=p.with_suffix('.zip');require(sha(z)==d['archiveSha256'],'Original nonpass archive changed')
 with zipfile.ZipFile(z) as archive:require(archive.testzip() is None,'Original nonpass archive CRC failed')
 original=d['receipt'];require(original['source']==ACK_SOURCE and original['tests']==711 and original['failures']==7 and original['exit']==7,'Original711/7 nonpass identity differs')
 files=[(p,'original-full-0178-nonpass.json'),(z,'original-full-0178-nonpass.zip')]
 focused=Path(config['original_repair_receipt']);first=read(focused)
 require(first['source']=='4d96f3c65386d64de0b98283e40058ec88318d88' and first['failures']==1 and first['validatedAfterRun'] is True,'Original focused repair nonpass changed')
 xml=focused.parent/'runtime/reports/gametest-results.xml';require(sha(xml)==first['junitSHA256'],'First focused XML changed')
 files.extend([(focused,'first-focused-repair-nonpass.json'),(xml,'first-focused-repair-nonpass.xml'),(focused.parent/'game.log','first-focused-repair-nonpass.log')])
 second=Path(config['second_full_nonpass']);sd=read(second);sz=second.with_suffix('.zip');require(sha(sz)==sd['archiveSha256'],'Second full archive changed')
 with zipfile.ZipFile(sz) as archive:require(archive.testzip() is None,'Second full archive CRC failed')
 sr=sd['receipt'];require(sr['source']=='94625ec262d75084543e447b64bd11b159bee016' and sr['namedGameSource']=='4d96f3c65386d64de0b98283e40058ec88318d88' and sr['tests']==712 and sr['failures']==2 and sr['exit']==2,'Second712/2 nonpass must remain exact and unpromoted')
 files.extend([(second,'second-full-4d96-two-failures.json'),(sz,'second-full-4d96-two-failures.zip')])
 return {'state':'TWO_ORIGINAL_FULL_NONPASSES_NOT_PROMOTED','receiptSha256':sha(p),'archiveSha256':sha(z),'firstFocused':first,'secondFull':sr},files

def require_fresh_portal_frames(config):
 fresh=[i for i in config['screenshots'] if i.get('freshPortal') is True]
 require(len(fresh)>=2 and all(i.get('executedSource')==SOURCE and i.get('executedGameSha256')==GAME_SHA for i in fresh),'Fresh exact-final portal PNG identities absent')
 require(all(isinstance(i.get('sha256'),str) and len(i['sha256'])==64 for i in fresh),'Fresh actual portal frame hashes are not frozen')
 return {'freshActualFrames':len(fresh),'executedSource':SOURCE,'executedGameSha256':GAME_SHA}

def cold_roster_regression(config):
 before=Path(config['portal_prefix_before']);after=Path(config['portal_prefix_after']);files=[];observed={};case_sets=[]
 failure='portalpendingtravelgametests.bothlateconnecteduserskeeptheircoldportalbehaviourafterretiredrosterrows'
 for label,base,test_source,game_source,expected_exit,expected_fail in [('before',before,'58657fb2fd07cc7f30005840b28e230024346af1','4d96f3c65386d64de0b98283e40058ec88318d88',1,1),('after',after,TEST_SOURCE,SOURCE,0,0)]:
  rp=base/'receipt.json';r=read(rp);xp=base/'runtime/reports/gametest-results.xml'
  require(r['source']==test_source and r['namedGameSource']==game_source and r['validatedAfterRun'] is True and r['exit']==expected_exit and r['tests']==5 and r['failures']==expected_fail and r['errors']==r['skips']==0,'Cold129 actual paired result differs:'+label)
  require(sha(xp)==r['junitSHA256'],'Cold129 actual XML bytes differ')
  cases=list(ET.parse(xp).getroot().iter('testcase'));names={c.get('name') for c in cases};bad=[c for c in cases if c.find('failure') is not None]
  require(len(cases)==len(names)==5 and len(bad)==expected_fail,'Cold129 case set/count differs')
  if expected_fail:
   require(bad[0].get('name')==failure,'Wrong cold129 pre-fix failure')
   text=ET.tostring(bad[0].find('failure'),encoding='unicode');require('waiterIndex=129' in text and 'heldColumns=0' in text and 'exitReady=false' in text,'Missing actual pre-fix eligibility/held0/unknown premise')
  observed[label]={'testSource':test_source,'namedGameSource':game_source,'exit':expected_exit,'tests':5,'failures':expected_fail,'receiptSha256':sha(rp),'xmlSha256':sha(xp)};case_sets.append(names)
  files.extend([(rp,'cold-roster-'+label+'-receipt.json'),(xp,'cold-roster-'+label+'-junit.xml'),(base/'game.log','cold-roster-'+label+'-game.log')])
 require(case_sets[0]==case_sets[1] and failure in case_sets[1],'Cold129 did not rerun the same real cases')
 for path in ['src/gametest/java/com/terminaldetector/drmd/PortalExitInterestGameTests.java','src/gametest/java/com/terminaldetector/drmd/PortalPendingTravelGameTests.java']:
  require(git_blob('58657fb2fd07cc7f30005840b28e230024346af1',path)==git_blob(TEST_SOURCE,path),'Cold129 fixture changed between actual before/after:'+path)
 return {'sameActualFiveCases':True,'sameFixtureSource':True,'originalFailure':failure,'originalWaiterIndex':129,'originalHeldColumns':0,'actual':observed,'doesNotInferGenericPlayerLimitPerformance':True},files

def mods(config):
 run=Path(config['ring'])/'cubic-client-automation';inp=read(run/'inputs.json');items=[]
 for a in inp['artifacts']:
  if not (a['path'].startswith('mods/') or 'fabric-loader/' in a['path'] or '/minecraft/1.21.1/' in a['path']):continue
  p=run/a['path'];require(sha(p)==a['sha256'],'Actual runtime library/mod changed:'+str(p))
  item={'file':p.name,'sha256':a['sha256'],'bytes':p.stat().st_size,'role':'observer-test-only-DO-NOT-INSTALL' if '-cubiccheck.jar' in p.name else 'runtime'}
  with zipfile.ZipFile(p) as z:
   require(z.testzip() is None,'Runtime JAR CRC failure:'+p.name)
   if 'fabric.mod.json' in z.namelist():
    m=json.loads(z.read('fabric.mod.json'));item.update(id=m['id'],version=m['version'],depends=m.get('depends',{}))
  items.append(item)
 require(any(i.get('id')=='drmd' and i['sha256']==HIST_GAME_SHA for i in items),'No actual production drmd mod')
 install=[dict(i) for i in items if i['role']!='observer-test-only-DO-NOT-INSTALL']
 for i in install:
  if i.get('id')=='drmd':i.update(sha256=GAME_SHA,bytes=Path(config['game']).stat().st_size,role='final9cdb-package-game;historical-ring-used947b')
 return {'minecraft':'1.21.1','javaMajor':21,'actualHistoricalRingSource':HIST_SOURCE,'packageProductionSource':SOURCE,'packageInstallMods':install,'actualRingRuntime':items,'thirdPartyJarsBundled':False,'testOnlyObserverBundled':False,'optionalBDH':'Separate isolated comparison profile; not required for this ring test save.'}

def main():
 a=argparse.ArgumentParser(description=__doc__);a.add_argument('--config',required=True,type=Path);a.add_argument('--out',required=True,type=Path);a.add_argument('--check',action='store_true');a.add_argument('--compress-verification',action='store_true');args=a.parse_args()
 out=args.out.resolve();require(out.is_relative_to(Path('/tmp')) and out!=Path('/tmp'),'Only scratch /tmp output permitted')
 require(not out.exists(),'Output already exists; preserve original attempts')
 c=read(args.config);load_identity(c);info={'state':'INCOMPLETE','productionSource':SOURCE,'testSource':TEST_SOURCE,'gameSha256':GAME_SHA,'version':VERSION,'toolSha256':sha(Path(__file__)),'configSha256':sha(args.config),'consumerPath':'dist/releases/'+VERSION+'/','gates':{},'blocked':[]};proof_files=[]
 def gate(name,fn):
  try:
   result=fn();info['gates'][name]=result[0] if isinstance(result,tuple) else result
   if isinstance(result,tuple):proof_files.extend((p,name,sha(p)) for p,name in result[1])
  except (OSError,ValueError,KeyError,TypeError,ET.ParseError,subprocess.CalledProcessError,zipfile.BadZipFile) as e:info['blocked'].append({'gate':name,'reason':type(e).__name__+': '+str(e)})
 game=Path(c['game'])
 def game_check():
  require(sha(game)==GAME_SHA,'Wrong production JAR SHA')
  with zipfile.ZipFile(game) as z:
   require(z.testzip() is None,'Game JAR CRC failure');m=json.loads(z.read('fabric.mod.json'));require(m['id']=='drmd' and m['version']==VERSION,'Wrong actual game metadata')
  return {'sha256':GAME_SHA,'bytes':game.stat().st_size,'id':'drmd','version':VERSION}
 gate('game',game_check);gate('sourceBridge',lambda:source_bridge(c));gate('unit',lambda:units(c));gate('ackRegression',lambda:ack_regression(c));gate('cold129Regression',lambda:cold_roster_regression(c));gate('ordinary',lambda:ordinary(c));gate('nativeReader',lambda:reader(c));gate('ring',lambda:ring(c));gate('portalGun',lambda:portal(c));gate('separateBDH',lambda:bdh(c));gate('testSave',lambda:save_check(c['save'],c['save_receipt']));gate('modlist',lambda:mods(c))
 gate('originalFullNonpass',lambda:preserved_nonpass(c))
 gate('freshPortalFrames',lambda:require_fresh_portal_frames(c))
 for item in c['screenshots']:
  def png_check(item=item):
   p=Path(item['path']);name=PurePosixPath(item['name']);require(not name.is_absolute() and '..' not in name.parts and '\\' not in item['name'],'Unsafe screenshot package name');require(sha(p)==item['sha256'],'Frozen screenshot bytes changed');header=p.read_bytes()[:24];require(header[:8]==b'\x89PNG\r\n\x1a\n' and len(header)==24,'Not a genuine PNG');require(int.from_bytes(header[16:20],'big')>0 and int.from_bytes(header[20:24],'big')>0,'Empty PNG');return {'path':item['name'],'sha256':sha(p),'scope':item['scope']}
  gate('image:'+item['name'],png_check)
 for key in ('release_notes','install'):
  gate(key,lambda key=key:{'sha256':sha(c[key])})
 if info['blocked'] or args.check:
  out.mkdir(parents=True);info['state']='INCOMPLETE' if info['blocked'] else 'QUALIFIED_INPUTS_CHECKED_NOT_PACKAGED';emit(out/'READINESS.json',info);print(json.dumps({'state':info['state'],'blocked':info['blocked'],'readiness':str(out/'READINESS.json')},ensure_ascii=False));return 2 if info['blocked'] else 0
 # Every required real gate succeeded. Copy only admitted files to a fresh private directory.
 out.parent.mkdir(parents=True,exist_ok=True);tmp=Path(tempfile.mkdtemp(prefix=out.name+'.assembling-',dir=out.parent))
 try:
  def copy(p,rel,expected=None):
   target=tmp/rel;target.parent.mkdir(parents=True,exist_ok=True);h=sha(p);require(expected is None or h==expected,'Input changed before copy:'+str(p));shutil.copyfile(p,target);require(sha(target)==h and sha(p)==h,'Input changed during copy:'+str(p));return target
  copy(game,'drmd-'+VERSION+'-fabric-1.21.1.jar',GAME_SHA)
  copy(c['save'],'test-save.zip',info['gates']['testSave']['sha256']);copy(c['save_receipt'],'verification/closed-test-save-receipt.json')
  copy(c['release_notes'],'RELEASE_NOTES_RU.md',info['gates']['release_notes']['sha256']);copy(c['install'],'INSTALL_RU.txt',info['gates']['install']['sha256'])
  for p,name,h in proof_files:copy(p,'verification/'+name,h)
  copy(args.config,'verification/package-inputs.json',info['configSha256']);copy(Path(__file__),'verification/package_release.py',info['toolSha256']);copy(Path(__file__).with_name('provenance.py'),'verification/provenance.py')
  for item in c['screenshots']:copy(item['path'],'screenshots/'+item['name'],info['gates']['image:'+item['name']]['sha256'])
  emit(tmp/'MODLIST.json',info['gates']['modlist']);(tmp/'MODLIST.txt').write_text('Minecraft1.21.1 / Java21\n'+'\n'.join(i['file']+' | '+i.get('id','platform')+' '+i.get('version','')+' | '+i['role']+' | SHA256 '+i['sha256'] for i in info['gates']['modlist']['packageInstallMods'])+'\nThird-party mod JARs are listed, not bundled. Test-only observer is omitted from installation.\n');info['state']='QUALIFIED_DEVELOPMENT_RC_PACKAGE';info['notStableVersionRename']=True;info['publicationPerformed']=False
  emit(tmp/'verification/VERIFIED.json',info)
  counts=info['gates']['ordinary']; boarding=info['gates']['nativeReader']['proof']
  report=f'''# Проверка Ungravity {VERSION}

Игровые исходники {SOURCE}. SHA-256 JAR {GAME_SHA}. Серверные тесты собраны из {TEST_SOURCE}.

- Прошли {counts['tests']} серверных сценариев из {counts['classes']} зарегистрированных классов и {info['gates']['unit']['tests']} модульных тестов. Ошибок и пропусков нет.
- Пять сценариев портальной пушки, пеший проход и проход в 6DoF проверены на этом JAR в трёх запусках игрового клиента.
- В парной проверке холодного выхода тот же игрок с индексом 129 раньше оставался у входа, потому что сервер не запрашивал чанк выхода. После исправления все пять серверных сценариев прошли. Один игрок пересёк портал один раз после загрузки выхода, второй отошёл и остался у входа.
- На сборке 0178e6c два клиента подключились после перезапуска выделенного сервера с сохранённой палубой. Второй игрок прошёл по той же палубе {boarding['realLocalWalk']:.2f} м за {boarding['acceptedForwardPackets']} применённых сервером команд. Пакет сохраняет исходные записи этих запусков, сравнение 300 элементов JAR, относящихся к абордажу, и проверку общего пути для игрока без транспорта.
- На сборке 6877d3c сняты 507 кадров подъёма к кольцу и выполнена отдельная проверка Better Distant Horizons. Сравнение зафиксировало 734 совпадающих элемента рендера, материалов и геометрии мира. Исходные профили и кадры включены в пакет.

Серверный стенд завершил полный прогон с 2 432 МиБ Java heap. Исходный запуск с 1 856 МиБ завершился с ошибкой Java heap space во время последнего сценария. [Отчёт об аварии и журнал](../../../docs/v8/EVIDENCE/finish36-20261119/whole-9cdb-heap1856-crash.zip)

Два предыдущих полных прогона с семью и двумя сбоями сохранены вместе с целевыми повторными проверками. В test-save.zip лежит мир орбитального кольца. Для сетевого абордажа использовалось отдельное сохранение. Итоговые контрольные суммы находятся в SHA256SUMS.
'''

  if args.compress_verification:
   raw_target=out.parent/(out.name+'.verification-raw');require(not raw_target.exists(),'Raw proof output already exists')
   raw_files=sorted(p for p in (tmp/'verification').rglob('*') if p.is_file());members={p.relative_to(tmp).as_posix():sha(p) for p in raw_files}
   archive=tmp/'verification-proofs.zip'
   with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED) as z:
    for p in raw_files:z.write(p,p.relative_to(tmp).as_posix())
   with zipfile.ZipFile(archive) as z:require(z.testzip() is None and {n:hashlib.sha256(z.read(n)).hexdigest() for n in z.namelist()}==members,'Compressed proof member bytes differ')
   emit(tmp/'verification-proof-manifest.json',{'archive':archive.name,'sha256':sha(archive),'members':members,'uncompressedBytes':sum(p.stat().st_size for p in raw_files),'retainedRawScratch':str(raw_target)})
   os.rename(tmp/'verification',raw_target)
   report+='\nВ verification-proofs.zip находятся исходные журналы, результаты тестов и сводный JSON. Файл verification-proof-manifest.json содержит контрольные суммы всех файлов архива.\n'
  (tmp/'VERIFICATION_RU.md').write_text(report)
  sums=''.join(sha(p)+'  '+p.relative_to(tmp).as_posix()+'\n' for p in sorted(tmp.rglob('*')) if p.is_file());(tmp/'SHA256SUMS').write_text(sums)
  require(not out.exists(),'Output appeared during assembly');os.rename(tmp,out)
 except BaseException:
  # Retain incomplete bytes and the exception for review. Never leave them at the final output path.
  emit(tmp/'ASSEMBLY_INCOMPLETE.json',{'state':'INCOMPLETE_COPY','finalOutput':str(out),'exception':str(sys.exc_info()[1])});raise
 sections={}
 for p in out.rglob('*'):
  if not p.is_file():continue
  name=p.relative_to(out).as_posix();category='jar' if name.endswith('.jar') else 'testSave' if name=='test-save.zip' else 'screenshots' if name.startswith('screenshots/') else 'verification' if name.startswith('verification/') or name.startswith('verification-') else 'metadata'
  sections[category]=sections.get(category,0)+p.stat().st_size
 print(json.dumps({'state':info['state'],'out':str(out),'fileCount':sum(p.is_file() for p in out.rglob('*')),'sectionBytes':sections,'totalBytes':sum(sections.values())},ensure_ascii=False));return 0
if __name__=='__main__':
 try:raise SystemExit(main())
 except (Invalid,OSError,ValueError,KeyError,TypeError) as e:print(type(e).__name__+': '+str(e),file=sys.stderr);raise SystemExit(2)
