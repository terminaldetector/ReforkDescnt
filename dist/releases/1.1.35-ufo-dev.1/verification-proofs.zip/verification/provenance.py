"""Strict source/class applicability for existing evidence, never a new native pass."""
from pathlib import Path
import hashlib,json,re,subprocess,zipfile
BASE_6877={'source':'6877d3c64b6a6a6ea4910cbf89d9d010a927a068','sha256':'947bf4c3d55113fb3656b92278b05d5b1fbb3f3afedf90824c8dda652f392198','path':'/tmp/ungravity-remaining-round/ninth-build/jars/drmd-6dof-1.1.35-ufo-dev.1.jar'}
BASE_0178={'source':'0178e6c841d25f489f6be612b9e16cfdcb391be1','sha256':'c381db97961597ff64ba5bd49e2ed3055d205bed6eb5444323d72926572eb713','path':'/tmp/ungravity-finish-36/final-local/boarding-ack-fixed-build/jars/drmd-6dof-1.1.35-ufo-dev.1.jar'}
BASE_4D96={'source':'4d96f3c65386d64de0b98283e40058ec88318d88','sha256':'318c50ad86bee443621dcd405ae2d6ae14a5dd7b143bf90129dc76b9bc5de806','path':'/tmp/ungravity-finish-36/final-local/distribution-fix-build/jars/drmd-6dof-1.1.35-ufo-dev.1.jar'}
BOARDING_PREFIXES=('com/terminaldetector/drmd/world/contraption/','com/terminaldetector/drmd/world/gravity/','com/terminaldetector/drmd/physics/','com/terminaldetector/drmd/network/')
BOARDING_EXACT=()
SOURCE_REVIEW_EXCLUDED={'com/terminaldetector/drmd/world/gravity/GravityMount.class'}
RENDER_PREFIXES=('com/terminaldetector/drmd/client/','com/terminaldetector/drmd/world/planet/','com/terminaldetector/drmd/world/cubic/','assets/drmd/')
MIXIN='com/terminaldetector/drmd/mixin/'
def require(v,m):
 if not v:raise ValueError(m)
def digest(b):return hashlib.sha256(b).hexdigest()
def sha(p):return digest(Path(p).read_bytes())
def valid_identity(d):
 for key,n in [('source',40),('testSource',40),('gameSha256',64)]:require(isinstance(d.get(key),str) and re.fullmatch('[0-9a-f]{'+str(n)+'}',d[key]),'Final producer not frozen: '+key)
 require(Path(d['game']).is_file(),'Final game path is not a real file')
 require(sha(d['game'])==d['gameSha256'],'Final game SHA mismatch')
 for key,floor in [('ordinaryTests',713),('ordinaryClasses',117),('unitTests',1248),('unitSuites',213)]:require(type(d.get(key)) is int and d[key]>=floor,'Expected real new count missing/below prior scope: '+key)
 require(d.get('version')=='1.1.35-ufo-dev.1','Do not silently rename the real version')
 return d

def archive(path,expected):
 require(sha(path)==expected,'JAR byte hash differs: '+str(path));z=zipfile.ZipFile(path);names=z.namelist()
 require(len(names)==len(set(names)) and z.testzip() is None,'JAR duplicate members/CRC invalid')
 return z

def changed_payloads(a,b):
 an=set(a.namelist());bn=set(b.namelist())
 return {'added':sorted(bn-an),'removed':sorted(an-bn),'changed':[{'member':n,'oldSha256':digest(a.read(n)),'newSha256':digest(b.read(n))} for n in sorted(an&bn) if a.read(n)!=b.read(n)],'unchangedCount':sum(a.read(n)==b.read(n) for n in an&bn)}

def selected_refmaps(ref,keys):
 out={'mappings':{k:ref['mappings'][k] for k in keys},'data':{}}
 for namespace,rows in ref.get('data',{}).items():
  out['data'][namespace]={k:rows[k] for k in keys if k in rows}
 return out

def component(baseline_path,final_path,members,refmap_keys):
 """All selected complete payloads must match; no raw-Code-only method shortcut."""
 with zipfile.ZipFile(baseline_path) as a,zipfile.ZipFile(final_path) as b:
  require(members and len(set(members))==len(members),'Empty/duplicate applicability closure')
  require(all(n in a.namelist() and n in b.namelist() for n in members),'Required component payload missing')
  differing=[n for n in members if a.read(n)!=b.read(n)]
  require(not differing,'Historical component changed; fresh evidence or separate reviewed method proof required: '+str(differing))
  x=json.loads(a.read('drmd-6dof-refmap.json'));y=json.loads(b.read('drmd-6dof-refmap.json'))
  try:rx=selected_refmaps(x,refmap_keys);ry=selected_refmaps(y,refmap_keys)
  except KeyError as e:raise ValueError('Required per-mixin refmap disappeared:'+str(e))
  require(rx==ry,'Historical component refmap changed')
  return {'kind':'COMPONENT_BYTE_IDENTITY_ONLY','requiredMembers':{n:digest(a.read(n)) for n in sorted(members)},'requiredMixinKeys':refmap_keys,'selectedRefmapSha256':digest(json.dumps(rx,sort_keys=True,separators=(',',':')).encode()),'notANewExecution':True}

def assess(final,policy,repo):
 """Policy must be independently reviewed against the exact final artifact tuple."""
 require(policy.get('reviewed') is True,'Exact final delta is not reviewed')
 require(policy.get('source')==final['source'] and policy.get('gameSha256')==final['gameSha256'],'Delta review is for another producer')
 require(isinstance(policy.get('rationale'),dict) and all(isinstance(policy['rationale'].get(k),str) and policy['rationale'][k] for k in ('boardingAck','renderBDH')),'Missing source/call-path applicability rationale')
 with archive(BASE_0178['path'],BASE_0178['sha256']) as a,archive(final['game'],final['gameSha256']) as b:
  actual=changed_payloads(a,b)
  require(actual['added']==policy['added'] and actual['removed']==policy['removed'] and [x['member'] for x in actual['changed']]==policy['changedMembers'],'Final payload delta differs from reviewed inventory')
  actual['oldSource']=BASE_0178['source'];actual['oldGameSha256']=BASE_0178['sha256'];actual['newSource']=final['source'];actual['newGameSha256']=final['gameSha256']
 with archive(BASE_4D96['path'],BASE_4D96['sha256']) as a,archive(final['game'],final['gameSha256']) as b:
  adjacent=changed_payloads(a,b)
  require(not adjacent['added'] and not adjacent['removed'] and [x['member'] for x in adjacent['changed']]==['com/terminaldetector/drmd/world/portal/PortalExitInterest.class'],'Adjacent4d96 delta changed beyond the reviewed outer portal-interest class')
 adjacent['oldSource']=BASE_4D96['source'];adjacent['oldGameSha256']=BASE_4D96['sha256'];adjacent['newSource']=final['source'];adjacent['newGameSha256']=final['gameSha256']
 adjacent_source=subprocess.run(['git','diff','--name-only',BASE_4D96['source'],final['source'],'--','src/main'],cwd=repo,capture_output=True,text=True,check=True).stdout.splitlines()
 require(adjacent_source==['src/main/java/com/terminaldetector/drmd/world/portal/PortalExitInterest.java'],'Adjacent source changed outside the portal roster snapshot')
 paths=subprocess.run(['git','diff','--name-only',BASE_0178['source'],final['source'],'--','src/main'],cwd=repo,capture_output=True,text=True,check=True).stdout.splitlines()
 require(paths==policy['mainSourceFiles'],'Final production source delta differs from review')
 groups={}
 for name,base in [('boardingAck',BASE_0178),('renderBDH',BASE_6877)]:
  with archive(base['path'],base['sha256']) as old:
   names=old.namelist();ref=json.loads(old.read('drmd-6dof-refmap.json'))
   if name=='boardingAck':
    members=sorted(n for n in names if n not in SOURCE_REVIEW_EXCLUDED and (n.startswith(BOARDING_PREFIXES) or n in BOARDING_EXACT or (n.startswith(MIXIN) and any(k in n for k in ('/Boarding','/FootGravity','/PlayerManagerGravity','/ServerPlayerFlight')))))
    keys=sorted(k for k in ref['mappings'] if k.startswith(MIXIN) and any(t in k for t in ('/Boarding','/FootGravity','/PlayerManagerGravity','/ServerPlayerFlight')))
   else:
    members=sorted(n for n in names if n.startswith(RENDER_PREFIXES))
    keys=sorted(k for k in ref['mappings'] if k.startswith(MIXIN+'client/'))
  c=component(base['path'],final['game'],members,keys)
  if name=='boardingAck':c['sourcePathException']=unmounted_source_equivalence(base['source'],final['source'],repo)
  c.update(executedSource=base['source'],executedGameSha256=base['sha256'],applicableFinalSource=final['source'],applicableFinalGameSha256=final['gameSha256'],rationale=policy['rationale'][name] if isinstance(policy['rationale'],dict) else policy['rationale'])
  groups[name]=c
 return {'state':'SCOPED_COMPONENT_APPLICABILITY_NOT_BLANKET_QUALIFICATION','actualDelta':actual,'adjacentDelta':adjacent,'adjacentMainSourceFiles':adjacent_source,'actualMainSourceFiles':paths,'groups':groups,'requiresActualNewFullGate':True,'requiresFreshPortalNative':True}

def source_body(text,marker):
 start=text.index(marker);left=text.index('{',start);depth=0
 # Java string literals/comments are treated atomically, so their braces cannot
 # close a real method. The method body itself is retained, not interpreted.
 for m in re.finditer(r'/\*.*?\*/|//[^\n]*|"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'|[{}]',text[left:],re.S):
  token=m.group()
  if token=='{':depth+=1
  elif token=='}':
   depth-=1
   if depth==0:return text[left+1:left+m.start()]
 raise ValueError('Unterminated source method:'+marker)

def tokens(text):
 return [m.group() for m in re.finditer(r'/\*.*?\*/|//[^\n]*|"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'|[A-Za-z_$][\w$]*|\d+|[^\s]',text,re.S) if not m.group().startswith(('//','/*'))]

def unmounted_source_equivalence(old_source,new_source,repo):
 def blob(rev,name):return subprocess.run(['git','show',rev+':'+name],cwd=repo,capture_output=True,text=True,check=True).stdout
 g='src/main/java/com/terminaldetector/drmd/world/gravity/GravityMount.java';o=blob(old_source,g);n=blob(new_source,g)
 start=n.index('    /** One native upright vehicle exit.');end=n.index('    private static boolean clear',start)
 require(n[:start]+n[end:]==o,'GravityMount existing source changed beyond the reviewed additive helper')
 flight='src/main/java/com/terminaldetector/drmd/flight/FlightSystem.java';old=blob(old_source,flight);new=blob(new_source,flight)
 old_body=source_body(old,'public static void disable(');new_body=source_body(new,'private static void disable(')
 guard_start=new_body.index('        // A native upright exit');guard_end=new_body.index('        // Clear authority',guard_start);guard=new_body[guard_start:guard_end]
 require('if(ordinaryExit&&exitHull!=null&&player.isAlive()&&!player.isSpectator()' in guard,'New ordinary-exit admission is not exclusively a live Pyro path')
 new_body=new_body[:guard_start]+new_body[guard_end:]
 mount_start=new_body.index('        if(exitHull!=null){');mount_end=new_body.index('        clearInput(',mount_start)
 new_body=new_body[:mount_start]+new_body[mount_end:]
 old_mount='if(player.getVehicle() instanceof PyroShipEntity) player.stopRiding();';require(old_mount in old_body,'Original mount statement changed')
 old_body=old_body.replace(old_mount,'')
 require(tokens(old_body)==tokens(new_body),'Unmounted disable cleanup source behavior differs')
 require(tokens(source_body(new,'public static void disable('))==tokens('disable(player,data,true);'),'Public disable wrapper changed')
 require(tokens(source_body(new,'public static void forceDisable('))==tokens('disable(player,data,false);'),'Force-disable wrapper changed')
 return {'kind':'REVIEWED_UNMOUNTED_SOURCE_PATH_NOT_WHOLE_CLASS_BYTE_IDENTITY','oldSource':old_source,'newSource':new_source,'precondition':'Actual dedicated scene has no Pyro vehicle; this does not cover the changed Pyro refusal/dismount path.','gravityMountExistingSourceRestoredByRemovingOnlyAdditiveHelper':True,'gravityMountNewHelperSha256':digest(n[start:end].encode()),'normalizedUnmountedCleanupTokensSha256':digest(json.dumps(tokens(old_body)).encode()),'ordinaryPyroGuardSourceSha256':digest(guard.encode()),'newUnitAndFullNativeGatesStillRequired':True}
