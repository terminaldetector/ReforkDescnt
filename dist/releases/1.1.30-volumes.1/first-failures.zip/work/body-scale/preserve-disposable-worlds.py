from pathlib import Path
import hashlib,json,zipfile,shutil,datetime
root=Path.cwd().resolve();out=root/'work/preserved-disposable-worlds';out.mkdir(exist_ok=True)
report=[]
for name in ['bodyindexcheck','boardingcheck','bodyeditcheck','shipboardingcheck']:
 source=root/'build'/name/'saves'
 if not source.is_dir():continue
 target=out/f'{name}-before-volume-leases.zip'
 if target.exists():raise RuntimeError(f'Preserved archive already exists: {target}')
 files=sorted(p for p in source.rglob('*') if p.is_file()); manifest={str(p.relative_to(source)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
 with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
  for p in files:z.write(p,str(p.relative_to(source)))
  z.writestr('PRESERVED_WORLD_MANIFEST.json',json.dumps(dict(original=str(source),sourceSha='79f61aa22cd03e40b0557502bdcd2afe69746e78',files=manifest,restore='Extract entries into original path; manifest is archival metadata'),indent=2))
 with zipfile.ZipFile(target) as z:
  assert z.testzip() is None
  for name,digest in manifest.items():assert hashlib.sha256(z.read(name)).hexdigest()==digest,name
 before=sum(p.stat().st_size for p in files); after=target.stat().st_size
 # Only verified disposable build/test save paths, never user profiles, source, logs or frames.
 assert source==root/'build'/source.parent.name/'saves' and source.parent.name in ['bodyindexcheck','boardingcheck','bodyeditcheck','shipboardingcheck']
 shutil.rmtree(source)
 item=dict(original=str(source),archive=str(target),files=len(files),originalBytes=before,archiveBytes=after,archiveSha256=hashlib.sha256(target.read_bytes()).hexdigest(),fullFileHashAndZipCrcVerified=True);report.append(item);print(json.dumps(item),flush=True)
(out/'PRESERVATION.json').write_text(json.dumps(report,indent=2)+'\n')
