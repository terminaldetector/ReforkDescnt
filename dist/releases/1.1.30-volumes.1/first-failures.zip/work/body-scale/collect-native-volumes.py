from pathlib import Path
import hashlib,json,zipfile,shutil
root=Path.cwd();out=Path('/workspace/ungravity-v5/checkpoints/body-volumes-1.1.30.1');out.mkdir(parents=True,exist_ok=True)
source='45b11218e6189bdc65e43b3de34d525f3afe5819';digest='6265b0f4f969c58f96a83f65064f4ee7358711a0370031284b473277b97d0c95'
runs={};gallery=out/'native-frames';gallery.mkdir(exist_ok=True)
with zipfile.ZipFile(out/'native-evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
 for name,kind,count in [('body-scale-volumes-final-gl32','body-scale',6),('body-scale-volumes-final-sodium','body-scale',6),('body-edit-volumes-final-gl32','body-edit',5),('ship-volumes-final-gl32','ship-boarding',13),('boarding-volumes-final-gl32','boarding',5)]:
  base=root/f'build/cubic-client-final-{name}';inputs=json.loads((base/'inputs.json').read_text());assert inputs['sourceSha']==source and not inputs['uncommittedDiff']
  jar=next(a for a in inputs['artifacts'] if a['path']=='mods/drmd-6dof-1.1.30-volumes.1.jar');assert jar['sha256']==digest
  assert hashlib.sha256((base/jar['path']).read_bytes()).hexdigest()==digest
  marker=json.loads((base/f'{kind}-ok.json').read_text());assert marker['actualInputs'] and len(marker['scenes'])==count and marker['predictionSamples']>=30 and marker['maxPredictionError']<.8
  if kind=='body-scale':
   assert marker['bodyBlocks']==32768 and marker['localEdge']==128 and marker['journalEdits']==300 and marker['maxLeasedColumns']>=27
   assert marker['volumeLeasesReleased'] and marker['actualFeetError']<1e-6
   assert all(marker[k] for k in ('legacyMissClient','legacyMissServer','edgePicked','holeClear','materialCharged'))
   assert marker['teleportFollow'] is False and marker['revisionChanges']>=3 and marker['travelDistance']>=1
   assert [a['scene'] for a in marker['scenes']]==['edge-intact','edge-cut','edge-patched','edge-hole','edge-rebased','edge-released']
  elif kind=='body-edit':
   assert all(marker[k] for k in ('survivalMining','materialCharged','savedState','comRebased'))
   assert marker['revisions']>=3 and marker['dropStacks']==marker['toolDamage']==1 and marker['maxPivotStep']<.8
  else:
   assert not marker['teleportFollow']
   if kind=='boarding':assert marker['sameStepJump'] is True and marker['jumpReleaseNetworkError']<1e-8
  log=root/f'work/body-scale/final-{name}.log';assert log.is_file() and (root/f'work/body-scale/final-{name}.exit').read_text().strip()=='0'
  for pattern in ('inputs.json',f'{kind}-ok.json',f'{kind}-frames/*.png','logs/latest.log','options.txt'):
   for p in base.glob(pattern):z.write(p,f'{name}/{p.relative_to(base)}')
  z.write(log,f'{name}/launcher.log')
  for scene in marker['scenes']:
   assert scene['frames']>=3
   p=base/f'{kind}-frames/{scene["scene"]}.png';assert p.read_bytes().startswith(b'\x89PNG\r\n\x1a\n') and p.stat().st_mtime>=(root/f'work/body-scale/final-{name}-prepare.log').stat().st_mtime
   shutil.copy2(p,gallery/f'{name}-{p.name}')
  runs[name]=marker
 assert z.testzip() is None
with zipfile.ZipFile(out/'first-failures.zip','w',zipfile.ZIP_DEFLATED) as z:
 for pattern in ('work/body-scale/**/*.log','work/body-scale/**/*.xml','work/body-scale/**/*.txt','work/body-scale/**/*.json','work/body-scale/**/*.png','work/body-scale/*.sh','work/body-scale/*.py'):
  for p in root.glob(pattern):
   if p.is_file():z.write(p,p.relative_to(root))
 assert z.testzip() is None
assert len(list(gallery.glob('*.png')))==35
(out/'NATIVE_VERIFIED.json').write_text(json.dumps(dict(sourceSha=source,jarSha256=digest,nativeFrames=35,nativeClients=runs,scope='32768-cell hull, full-volume leases with removal, remote-edge input and prior boarding regression',fullBoarding=False,dedicatedTwoClient=False,cellBudget=32768,initialEdge=128,fullVolumeLeases=True,fullUfo=False),indent=2)+'\n')
print({k:(len(v['scenes']),v['predictionSamples'],v['maxPredictionError']) for k,v in runs.items()});print(out)
