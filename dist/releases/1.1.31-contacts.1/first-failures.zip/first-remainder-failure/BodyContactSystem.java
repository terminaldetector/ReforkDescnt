package com.terminaldetector.drmd.world.contraption;

import com.terminaldetector.drmd.client.portal.PortalTransform.*;
import com.terminaldetector.drmd.d6.D6PhysicsBody;
import com.terminaldetector.drmd.physics.collision.*;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.Box;
import java.util.*;

/** Common hull/hull contact phase, AFTER both trajectories and BEFORE the passenger motor.
 * Uses the existing D6 bodies and local collider BVHs; a compound stays one rigid body.
 * A paused/unavailable support acts as an immovable participant until its volume is ready. */
public final class BodyContactSystem {
    private BodyContactSystem(){}
    public static void register(){ServerTickEvents.END_WORLD_TICK.register(BodyContactSystem::solve);}
    private static BodyPairQuery.Motion motion(BlockBodyEntity body,boolean sweep) {
        var m=body.boardingMotion();
        return new BodyPairQuery.Motion(body.collider(),body.localCentre(),m.position(sweep?0:1),m.rotation(sweep?0:1),m.position(1),m.rotation(1));
    }
    /** Also callable by the existing disposable world tests, with actual entities/physics. */
    public static int solve(ServerWorld world) {
        if(!world.getServer().isOnThread())throw new IllegalStateException("Hull contacts belong to the server world thread");
        var changed=new LinkedHashSet<BlockBodyEntity>();int contacts=0;
        // The second pass resolves contacts created by a bounded penetration correction.
        for(int pass=0;pass<2;pass++)for(var a:BodySpatialIndex.loaded(world)) {
            if(a.cells().isEmpty())continue;var ma=motion(a,pass==0);var area=ma.sweptBounds();if(area.isEmpty())continue;
            var b=area.get();var box=new Box(b.min().x(),b.min().y(),b.min().z(),b.max().x(),b.max().y(),b.max().z());
            for(var other:BodySpatialIndex.query(world,box)) {
                if(other.getId()<=a.getId()||other.cells().isEmpty()||a.boardingMotionPaused()&&other.boardingMotionPaused())continue;
                var impact=BodyPairQuery.impact(ma,motion(other,pass==0));if(impact.isEmpty())continue;
                if(resolve(a,other,ma,motion(other,pass==0),impact.get())) {changed.add(a);changed.add(other);contacts++;ma=motion(a,pass==0);}
            }
        }
        changed.forEach(BlockBodyEntity::publishPhysicsState);return contacts;
    }
    private static boolean resolve(BlockBodyEntity a,BlockBodyEntity b,BodyPairQuery.Motion ma,BodyPairQuery.Motion mb,BodyPairQuery.Impact impact) {
        boolean movingA=!a.boardingMotionPaused(),movingB=!b.boardingMotionPaused();
        Vec3 atA=a.massPosition(),atB=b.massPosition();Quat qA=a.rotation(),qB=b.rotation();
        if(movingA&&!a.resolveContactPose(ma.position(impact.fraction()),ma.rotation(impact.fraction())))return false;
        if(movingB&&!b.resolveContactPose(mb.position(impact.fraction()),mb.rotation(impact.fraction()))) {
            if(movingA)a.resolveContactPose(atA,qA);return false;
        }
        D6PhysicsBody pa=movingA?a.physics():fixed(a),pb=movingB?b.physics():fixed(b);
        var constraints=impact.contacts().stream().map(c->new BodyContactConstraint(pa,pb,c.point(),c.normal(),.65)).toList();
        for(int iteration=0;iteration<8;iteration++)for(var constraint:constraints)constraint.solve();
        // Split positional correction does not replace the contact impulse or erase momentum.
        var deepest=impact.contacts().stream().max(Comparator.comparingDouble(BodyPairQuery.Contact::penetration)).orElseThrow();
        if(deepest.penetration()>1e-7) {
            double ia=movingA?1/Math.max(1e-9,pa.mass()):0,ib=movingB?1/Math.max(1e-9,pb.mass()):0;
            if(ia+ib>0) {
                Vec3 correction=deepest.normal().scaled(Math.min(.25,deepest.penetration()+.0005)/(ia+ib));
                if(movingA)a.resolveContactPose(a.massPosition().plus(correction.scaled(ia)),a.rotation());
                if(movingB)b.resolveContactPose(b.massPosition().minus(correction.scaled(ib)),b.rotation());
            }
        }
        return true;
    }
    private static D6PhysicsBody fixed(BlockBodyEntity b){return new D6PhysicsBody().withPosition(b.massPosition()).withRotation(b.rotation());}
}
