package com.terminaldetector.drmd;

import com.terminaldetector.drmd.client.portal.PortalTransform.*;
import com.terminaldetector.drmd.world.contraption.*;
import com.terminaldetector.drmd.vendor.immptl.ImmPtlQuaternions;
import net.fabricmc.fabric.api.gametest.v1.FabricGameTest;
import net.minecraft.block.Blocks;
import net.minecraft.test.*;
import net.minecraft.util.math.*;
import java.util.*;

public final class HullContactGameTests implements FabricGameTest {
    private Vec3d arena(TestContext c) {
        var at=c.getAbsolutePos(new BlockPos(8,150,8));var w=c.getWorld();
        for(int x=-1;x<=8;x++)for(int z=-1;z<=1;z++)w.getChunk((at.getX()>>4)+x,(at.getZ()>>4)+z);
        for(var p:BlockPos.iterate(at.add(-4,-4,-4),at.add(14,8,10)))w.setBlockState(p,Blocks.AIR.getDefaultState(),2);
        return Vec3d.of(at);
    }
    private List<BlockBodyEntity.Cell> cube(){return List.of(new BlockBodyEntity.Cell(BlockPos.ORIGIN,Blocks.IRON_BLOCK.getDefaultState()));}
    private Vec3 momentum(BlockBodyEntity b){return b.physics().linearVelocity().scaled(b.physicsMass());}
    private Vec3 angular(BlockBodyEntity b){return b.physics().angularMomentum().plus(b.massPosition().cross(momentum(b)));}
    @GameTest(templateName=EMPTY_STRUCTURE,batchId="hull-pair-fast")
    public void twoActualFastHullsCannotSwapSidesAndTheirContactConservesMomentum(TestContext c) {
        var at=arena(c);var w=c.getWorld();var a=BlockBodyEntity.createLocal(w,cube(),at);var b=BlockBodyEntity.createLocal(w,cube(),at.add(3,0,0));
        try {
            a.physics().withLinearVelocity(new Vec3(50,0,0));b.physics().withLinearVelocity(new Vec3(-50,0,0));var initial=momentum(a).plus(momentum(b));
            a.tick();b.tick();c.assertTrue(a.getX()>b.getX(),"both clear end poses already crossed, so endpoint overlap cannot detect the hit");
            c.assertTrue(BodyContactSystem.solve(w)>0,"shared world phase finds the actual continuous hull contact");
            c.assertTrue(a.getX()<b.getX()&&b.getX()-a.getX()>=.999,"CCD leaves the real hulls on their original sides");
            c.assertTrue(momentum(a).plus(momentum(b)).minus(initial).length()<1e-7,"two-sided contact conserves linear momentum");
            c.assertTrue(Math.abs(a.physics().linearVelocity().x())<1e-6&&Math.abs(b.physics().linearVelocity().x())<1e-6,"inelastic equal-mass impact cancels relative closing velocity");
        }finally{a.discard();b.discard();}c.complete();
    }
    @GameTest(templateName=EMPTY_STRUCTURE,batchId="hull-pair-hole")
    public void anotherFlyingBodyCanPassThroughARotatedHullsActualHole(TestContext c) {
        var at=arena(c);var w=c.getWorld();var frame=BlockBodyEntity.createLocal(w,List.of(new BlockBodyEntity.Cell(BlockPos.ORIGIN,Blocks.IRON_BLOCK.getDefaultState()),new BlockBodyEntity.Cell(new BlockPos(3,0,0),Blocks.IRON_BLOCK.getDefaultState())),at);
        var q=ImmPtlQuaternions.rotationByRadians(new Vec3(0,1,0),.8);frame.physics().withRotation(q);frame.tick();
        var start=frame.localToWorld(new Vec3d(1.8,.5,-1.5));var mover=BlockBodyEntity.createLocal(w,cube(),start.subtract(.5,.5,.5));
        try {
            mover.physics().withRotation(q).withLinearVelocity(q.rotate(new Vec3(0,0,50)));mover.tick();
            c.assertTrue(BodyContactSystem.solve(w)==0,"composite broadphase empty corner cannot become a phantom wall");
            c.assertTrue(mover.physics().linearVelocity().minus(q.rotate(new Vec3(0,0,50))).length()<1e-7,"free motion through the opening is retained");
        }finally{frame.discard();mover.discard();}c.complete();
    }
    @GameTest(templateName=EMPTY_STRUCTURE,batchId="hull-pair-torque")
    public void anOffCentreRealHullStrikeTransfersTorqueWithoutLosingTotalAngularMomentum(TestContext c) {
        var at=arena(c);var w=c.getWorld();var a=BlockBodyEntity.createLocal(w,List.of(cube().getFirst(),new BlockBodyEntity.Cell(new BlockPos(0,1,0),Blocks.IRON_BLOCK.getDefaultState())),at);
        var b=BlockBodyEntity.createLocal(w,cube(),at.add(3,1.25,0));
        try {
            b.physics().withLinearVelocity(new Vec3(-50,0,0));var p=momentum(a).plus(momentum(b));var l=angular(a).plus(angular(b));
            a.tick();b.tick();c.assertTrue(BodyContactSystem.solve(w)>0,"actual offset contact occurs");
            c.assertTrue(a.physics().angularVelocity().length()>1e-4&&b.physics().angularVelocity().length()>1e-4,"the same physical contact spins both inertial hulls");
            c.assertTrue(momentum(a).plus(momentum(b)).minus(p).length()<1e-7,"linear momentum is conserved");
            c.assertTrue(angular(a).plus(angular(b)).minus(l).length()<1e-6,"spin plus orbital world angular momentum is conserved");
        }finally{a.discard();b.discard();}c.complete();
    }
    @GameTest(templateName=EMPTY_STRUCTURE,batchId="hull-pair-teleport")
    public void explicitPlacementIsNotAFlightThroughInterveningHulls(TestContext c) {
        var at=arena(c);var w=c.getWorld();var a=BlockBodyEntity.createLocal(w,cube(),at);var b=BlockBodyEntity.createLocal(w,cube(),at.add(50,0,0));
        try {
            a.tick();b.tick();var target=a.getPos().add(100,0,0);a.setPosition(target);
            c.assertTrue(BodyContactSystem.solve(w)==0&&a.getPos().distanceTo(target)<1e-7,"authoritative placement resets trajectory instead of colliding across a100-block teleport");
        }finally{a.discard();b.discard();}c.complete();
    }
    @GameTest(templateName=EMPTY_STRUCTURE,batchId="hull-pair-paused")
    public void anUnavailablePausedHullCannotAcquireSpuriousContactMomentum(TestContext c) {
        var at=arena(c);var w=c.getWorld();var a=BlockBodyEntity.createLocal(w,cube(),at);var b=BlockBodyEntity.createLocal(w,cube(),at.add(2,0,0));
        try {
            b.physics().withLinearVelocity(new Vec3(7,0,0));a.physics().withLinearVelocity(new Vec3(50,0,0));a.tick();
            c.assertTrue(b.boardingMotionPaused(),"second entity has no physical trajectory in this tick");
            c.assertTrue(BodyContactSystem.solve(w)>0&&Math.abs(a.physics().linearVelocity().x())<1e-7,"active hull collides with the still contact support");
            c.assertTrue(b.physics().linearVelocity().equals(new Vec3(7,0,0)),"paused hull retains its saved resume momentum");
        }finally{a.discard();b.discard();}c.complete();
    }
}
