#!/usr/bin/env bash
set -euo pipefail
cd /workspace/ungravity-v5/boarding-attachment
name=${1:-ordinary-debug}
f=work/ship-up/${name}-display.txt
: > "$f"
/workspace/xvfb/usr/bin/Xvfb -displayfd 3 -screen 0 1280x1024x24 3> "$f" > work/ship-up/${name}-xvfb.log 2>&1 &
pid=$!
trap 'kill "$pid" 2>/dev/null || true; wait "$pid" 2>/dev/null || true' EXIT
for i in {1..100}; do if [ -s "$f" ]; then break; fi; sleep .1; done
read -r number < "$f"
DRMD_HORIZON_CHECK=1 DISPLAY=:$number LIBGL_ALWAYS_SOFTWARE=1 JAVA_HOME=/workspace/jdk21-complete GRADLE_USER_HOME=/workspace/.gradle timeout --foreground 360 ./gradlew --offline runShootcheck -x runGametest --no-daemon --console=plain > work/ship-up/${name}.log 2>&1
test -s build/shootcheck/horizon-anchor-ok.json
cat build/shootcheck/horizon-anchor-ok.json
