from pathlib import Path
import hashlib,json,zipfile,shutil
root=Path.cwd(); out=Path('/workspace/ungravity-v5/checkpoints/block-access-1.1.27.1');out.mkdir(parents=True,exist_ok=True)
source='ae5b2e9b761d693d904db5c7c3cf69fb35af0f34';digest='f4c6ac85013aec5d5ea460123b6eb09fec0449b90c82b27791a1a495b2febfa7'
runs={};gallery=out/'native-frames';gallery.mkdir(exist_ok=True)
with zipfile.ZipFile(out/'native-evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
 for name,kind,count in [('body-edit-verified-gl32','body-edit',5),('body-edit-verified-sodium','body-edit',5),('ship-verified-gl32','ship-boarding',13),('boarding-verified-gl32','boarding',5)]:
  base=root/f'build/cubic-client-final-{name}';inputs=json.loads((base/'inputs.json').read_text());assert inputs['sourceSha']==source and not inputs['uncommittedDiff']
  jar=next(a for a in inputs['artifacts'] if a['path']=='mods/drmd-6dof-1.1.27-blocks.1.jar');assert jar['sha256']==digest
  assert hashlib.sha256((base/jar['path']).read_bytes()).hexdigest()==digest
  marker=json.loads((base/f'{kind}-ok.json').read_text());assert marker['actualInputs'] and len(marker['scenes'])==count and marker['predictionSamples']>=30 and marker['maxPredictionError']<.8
  if kind=='body-edit':
   assert all(marker[k] for k in ('survivalMining','materialCharged','savedState','comRebased'))
   assert marker['revisions']>=3 and marker['dropStacks']==marker['toolDamage']==1 and marker['maxPivotStep']<.8
   assert [a['scene'] for a in marker['scenes']]==['hull-intact','hull-cut','hull-patched','survival-cut','saved-state']
  else:assert not marker['teleportFollow']
  log=root/f'work/block-access/final-{name}.log';assert log.is_file() and (root/f'work/block-access/final-{name}.exit').read_text().strip()=='0'
  for pattern in ('inputs.json',f'{kind}-ok.json',f'{kind}-frames/*.png','logs/latest.log','options.txt'):
   for p in base.glob(pattern):z.write(p,f'{name}/{p.relative_to(base)}')
  z.write(log,f'{name}/launcher.log')
  for scene in marker['scenes']:
   assert scene['frames']>=3
   p=base/f'{kind}-frames/{scene["scene"]}.png';assert p.read_bytes().startswith(b'\x89PNG\r\n\x1a\n') and p.stat().st_mtime>=(root/f'work/block-access/final-{name}-prepare.log').stat().st_mtime
   shutil.copy2(p,gallery/f'{name}-{p.name}')
  runs[name]=marker
 assert z.testzip() is None
with zipfile.ZipFile(out/'first-failures.zip','w',zipfile.ZIP_DEFLATED) as z:
 for pattern in ('work/block-access/*.log','work/block-access/*inputs.json','work/block-access/*.xml','work/block-access/ci-*-*.txt','work/block-access/run-*.sh','work/block-access/collect-native.py','work/block-access/ci-lod-failure/**/*.png','work/block-access/horizon-original-ok.json','build/shootcheck/horizon-anchor-ok.json','build/shootcheck/horizon-anchor-frames/*.png','build/shootcheck/repair-visual-ok.json','build/shootcheck/repair-visual-frames/*.png','build/bodyeditcheck/body-edit-ok.json','build/bodyeditcheck/body-edit-frames/*.png'):
  for p in root.glob(pattern):z.write(p,p.relative_to(root))
 assert z.testzip() is None
assert len(list(gallery.glob('*.png')))==28, 'Gallery contains evidence from a different source run'
(out/'NATIVE_VERIFIED.json').write_text(json.dumps(dict(sourceSha=source,jarSha256=digest,nativeFrames=28,nativeClients=runs,scope='Inert local hull blocks, COM continuity and prior boarding regression',fullBoarding=False,dedicatedTwoClient=False,saveProof='NBT roundtrip only; full world reload remains open'),indent=2)+'\n')
print({k:(len(v['scenes']),v['predictionSamples'],v['maxPredictionError']) for k,v in runs.items()})
print(out)
