#!/usr/bin/env bash
set -euo pipefail
cd /workspace/ungravity-v5/portal-gun
export JAVA_HOME=/workspace/jdk21-complete GRADLE_USER_HOME=/workspace/.gradle
export LIBGL_ALWAYS_SOFTWARE=1
display_file=build/checkpoint/logs/display.txt
: > "$display_file"
/workspace/xvfb/usr/bin/Xvfb -displayfd 3 -screen 0 1920x1080x24 3> "$display_file" > build/checkpoint/logs/xvfb.log 2>&1 &
display_pid=$!
trap 'kill "$display_pid" 2>/dev/null || true; wait "$display_pid" 2>/dev/null || true' EXIT
for attempt in {1..100}; do
  kill -0 "$display_pid"
  if [ -s "$display_file" ]; then break; fi
  sleep .1
done
test -s "$display_file"
read -r display_number < "$display_file"
export DISPLAY=:$display_number
set +e
timeout --foreground 900 ./gradlew --offline runShootcheck -x runGametest --no-daemon --console=plain < /dev/null > build/checkpoint/logs/shootcheck.log 2>&1
stage_code=$?
set -e
echo "$stage_code" > build/checkpoint/logs/shootcheck.exit
if [ "$stage_code" -ne 0 ]; then exit "$stage_code"; fi
set +e
timeout --foreground 360 ./gradlew --offline runRendercheck -x runGametest --no-daemon --console=plain < /dev/null > build/checkpoint/logs/rendercheck.log 2>&1
stage_code=$?
set -e
echo "$stage_code" > build/checkpoint/logs/rendercheck.exit
exit "$stage_code"
