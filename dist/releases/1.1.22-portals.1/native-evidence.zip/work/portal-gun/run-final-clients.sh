#!/usr/bin/env bash
set -euo pipefail
cd /workspace/ungravity-v5/portal-gun
export JAVA_HOME=/workspace/jdk21-complete GRADLE_USER_HOME=/workspace/.gradle
./gradlew --offline test --rerun runGametest build remapCubiccheckJar --no-daemon > build/checkpoint/logs/unit-gametest-build.log 2>&1
echo 0 > build/checkpoint/logs/unit-gametest-build.exit
./gradlew --offline runGametest --no-daemon > build/checkpoint/logs/repeated-gametest.log 2>&1
echo 0 > build/checkpoint/logs/repeated-gametest.exit
./gradlew --offline remapJar --rerun --no-daemon > build/checkpoint/logs/fresh-remap.log 2>&1
git restore -- dist/INSTALL_TLAUNCHER.txt
python3 - <<'PY'
from pathlib import Path
import json,subprocess,hashlib
p=Path('build/libs/drmd-6dof-1.1.22-portals.1.jar')
Path('build/checkpoint/inputs-expected.json').write_text(json.dumps({'sourceSha':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'jarSha256':hashlib.sha256(p.read_bytes()).hexdigest()},indent=2))
PY
bash work/portal-gun/run-native.sh release-gun-gl32
bash work/portal-gun/run-native.sh release-gun-sodium
bash work/portal-gun/run-regression-clients.sh
for scenario in release-actors-gl32 release-actors-sodium release-mirror-gl32 release-baseline-sodium release-mirror-sodium; do
  bash work/portal-gun/run-native.sh "$scenario"
done
