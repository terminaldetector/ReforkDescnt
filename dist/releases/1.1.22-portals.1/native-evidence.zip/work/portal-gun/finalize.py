from pathlib import Path
import subprocess,importlib.util,json,os,shutil,zipfile,hashlib,xml.etree.ElementTree as ET
r=Path('/workspace/ungravity-v5/portal-gun');os.chdir(r)
sha=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert sha=='36797d1ec60ad366df1d86061e69f2d749e27633'
assert not subprocess.check_output(['git','diff','--stat'],text=True).strip()
s=importlib.util.spec_from_file_location('checkpoint_report',r/'scripts/checkpoint_report.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
with (r/'build/checkpoint/logs/verify.log').open('w') as f:subprocess.run(['python3','scripts/checkpoint_report.py','--verify'],check=True,stdout=f)
t=int((r/'build/checkpoint/started-at.txt').read_text());audit=m.verify_audit(r,t);m.verify_native_audit(r,t)
p=json.loads((r/'build/checkpoint/verified.json').read_text());assert p['source_sha']==sha
assert json.loads((r/'build/checkpoint/inputs-expected.json').read_text())=={'sourceSha':sha,'jarSha256':p['sha256']}
assert p['unit']['tests']==567 and p['gametest']['tests']==131
assert '\nOK\n' in (r/'build/checkpoint/logs/python-tests.log').read_text()
shot=json.loads((r/'build/shootcheck/shootcheck-ok.json').read_text())
assert shot['fastTickStepped'] and shot['fastServerTicks']>=3 and shot['fastServerTravel']>=24
cases=ET.parse(r/'build/gametest/reports/gametest-results.xml').findall('.//testcase')
guns=[c.attrib['name'] for c in cases if c.attrib['name'].startswith('portalprojectorgametests.')]
assert len(guns)==14 and all(c.find('failure') is None for c in cases)
scenarios=('release-gun-gl32','release-gun-sodium','release-actors-gl32','release-actors-sodium','release-mirror-gl32','release-baseline-sodium','release-mirror-sodium')
native={'sourceSha':sha,'jarSha256':p['sha256'],'status':'PORTAL_MODULE_PASS_FULL_MASTER_V5_PENDING','softwareGraphics':True,'scenarios':[]}
for scenario in scenarios:
    d=r/f'build/cubic-client-final-{scenario}';meta=json.loads((d/'inputs.json').read_text())
    assert meta['sourceSha']==sha and meta['uncommittedDiff']=='' and not meta['experimental_native_relight_probe']
    game=next(a for a in meta['artifacts'] if a['path']==f'mods/drmd-6dof-{p["version"]}.jar');assert game['sha256']==p['sha256']
    assert (r/f'work/portal-gun/final-{scenario}.exit').read_text().strip()=='0'
    marker='portal-gun-ok.json' if 'gun' in scenario else 'actor-frames-ok.json' if 'actors' in scenario else 'cubic-client-ok.json' if 'baseline' in scenario else 'native-mirror-ok.json'
    m.fresh(d/marker,t);result=json.loads((d/marker).read_text())
    if 'gun' in scenario:
        assert result['actualMouseEntry'] and result['packetPlacement'] and len(result['scenes'])==5
        assert [s['scene'] for s in result['scenes']]==['blue-only','paired-blue-orange','blue-replaced','pair-cleared','container-protected']
        assert result['scenes'][1]['bluePixels']>=80 and result['scenes'][1]['orangePixels']>=80
        for a in result['scenes']:m.fresh_png(d/f'portal-gun-frames/{a["scene"]}.png',t)
    elif 'actors' in scenario:assert len(result['scenes'])==6 and all(a['models']==6 and a['renderedFrames']>=90 for a in result['scenes'])
    elif 'baseline' in scenario:assert len(result['checks'])==14 and result['warpedVertices']>0
    else:assert result['frames']==14 and len(result['scenes'])==7
    assert 'DUMMY' not in (r/f'work/portal-gun/final-{scenario}.log').read_text()
    native['scenarios'].append({'name':scenario,'gl':meta['glOverride'],'result':result,'dummyMessages':0})
for phase in ('unit-gametest-build','repeated-gametest','rendercheck','shootcheck'):assert (r/f'build/checkpoint/logs/{phase}.exit').read_text().strip()=='0'
for phase in ('unit','gametest','build','rendercheck','shootcheck','verify'):os.environ[phase.upper()+'_OUTCOME']='success'
m.report(r)
out=Path('/workspace/ungravity-v5/checkpoints/portal-gun-1.1.22');out.mkdir(exist_ok=True)
for name,data in [('NATIVE_MATRIX_VERIFIED.json',native),('FULL_AUDIT_VERIFIED.json',audit),('PORTAL_CASES_VERIFIED.json',{'sourceSha':sha,'cases':guns})]:out.joinpath(name).write_text(json.dumps(data,indent=2))
for a,b in [('build/checkpoint/REPORT.md','AUTOMATED_REPORT.md'),('build/checkpoint/screenshots.zip','regression-frames.zip')]:shutil.copy2(r/a,out/b)
jar=r/'build/checkpoint/distribution'/p['jar']
with zipfile.ZipFile(jar) as z:assert not any('/gate/' in n or n.startswith('dev/fallingcloud/') or 'PortalProjectorGameTests' in n for n in z.namelist())
shutil.copy2(jar,out/p['jar'])
subprocess.run(['git','archive','--format=tar.gz','--prefix=ungravity-'+sha[:7]+'/','-o',str(out/f'source-{sha[:7]}.tar.gz'),'HEAD'],check=True)
with zipfile.ZipFile(out/'regression-evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
    for pattern in ('build/checkpoint/logs/*','build/checkpoint/resources/*','build/test-results/test/*.xml','build/gametest/reports/*.xml','build/gametest/item-resource-inventory.tsv','build/rendercheck/*ok.txt','build/shootcheck/*ok.json','build/shootcheck/*.csv','build/shootcheck/*.tsv','build/checkpoint/verified.json','build/checkpoint/SOURCE_SHA.txt','build/checkpoint/started-at.txt','build/checkpoint/inputs-expected.json'):
        for f in r.glob(pattern):
            if f.is_file():z.write(f,f.relative_to(r))
with zipfile.ZipFile(out/'native-evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
    for scenario in scenarios:
        d=r/f'build/cubic-client-final-{scenario}'
        for pattern in ('inputs.json','*ok.json','portal-gun-frames/*.png','actor-frames/*.png','gate-frames/*.png','native-mirror-frames/*.png','logs/latest.log','options.txt','config/*.json','config/drmd/*.json'):
            for f in d.glob(pattern):
                if f.is_file():z.write(f,f.relative_to(r))
        for suffix in ('log','exit'):
            f=r/f'work/portal-gun/final-{scenario}.{suffix}';z.write(f,f.relative_to(r))
    for name in ('run-native.sh','run-final-clients.sh','run-regression-clients.sh','finalize.py'):
        f=r/'work/portal-gun'/name;z.write(f,f.relative_to(r))
with zipfile.ZipFile(out/'failed-checks.zip','w',zipfile.ZIP_DEFLATED) as z:
    for pattern in ('work/portal-gun/first-*.log','work/portal-gun/second-*.log','work/portal-gun/third-*.log','work/portal-gun/fourth-*.log','work/portal-gun/fifth-*.log','work/portal-gun/frame-debug.log','work/portal-gun/observed-*.log','work/portal-gun/tripod-*.log','work/portal-gun/entity-clock-*.log','work/portal-gun/failed-*/**/*','work/portal-gun/final-first*','build/cubic-client-failed-*/portal-gun-frames/*.png','build/cubic-client-failed-*/logs/latest.log'):
        for f in r.glob(pattern):
            if f.is_file():z.write(f,f.relative_to(r))
install=f'''UNGRAVITY / DRMD {p['version']} — Minecraft 1.21.1 / Fabric / Java 21
Установочный JAR: {p['jar']}
SHA-256: {p['sha256']}
Исходная ревизия: {sha}

Отдельный профиль Fabric 1.21.1 + Fabric API 0.116.15+1.21.1. Один DRMD JAR в mods.
Immersive Portals не требуется. Не устанавливать sources/dev/cubiccheck JAR.
Для экспериментального кубического мира: Fabric Loader 0.19.5+, отдельно установленный
Better Cubic Chunks 0.1.1+mc1.21.1 и НОВЫЙ мир с preset bettercubicchunks:cubic_overworld.
Закрытый сторонний BCC не включён в пакет. Исходные сохранения сохранить отдельно.
Строгий OpenGL3.2 проверен без Sodium; Sodium0.8.13 проверен с GL3.3/GLSL330.
Физическая Intel HD4400 недоступна, аппаратная производительность не подтверждена.

Пушка drmd:portal_projector: ЛКМ синий / ПКМ оранжевый / Shift+ПКМ удалить пару.
Ровная опора5×5, пустое место перед ней; дальность48. Стены не вырезаются.
Ориентированные коллайдеры летающих корпусов и полный3D AI остаются в работе.
'''
out.joinpath('INSTALL_TLAUNCHER.txt').write_text(install)
report=f'''# UNGRAVITY — портальная пушка, 1.1.22-portals.1

Проверенная исходная ревизия `{sha}`; SHA-256 JAR `{p['sha256']}`.
Это локальная проверка отдельного модуля; статус GitHub Actions проверяется отдельно.
В отдельном коммите2a91159 изменены только старые тесты Fusion: вместо проверки через
пять мировых тиков они ждут реального связывания или фактических тиков снаряда с
ограничением200. Ранний отказ в Actions сохранён. src/main, build.gradle и
версия идентичны36797d1; этот отдельный CI-коммит не выдаётся за исходную ревизию
локальных кадров. Actions: https://github.com/terminaldetector/ReforkDescnt/actions/runs/40557960963 .
Полное Master ТЗ v5 не закрыто.

Пушка использует существующие нативные PortalPanel/PortalTravel/PortalTransform: два
цвета, автоматическое связывание, перенос одного конца, очистка, рецепт Survival,
3D-модель, луч через активные пары и серверная проверка разрешений/загруженности.
ЛКМ/ПКМ не ломают блоки и не открывают контейнеры. Пары сохраняются по UUID/XYZ.
Для управляемых пушкой панелей проверяется, что всё тело помещается в проём.
Переход сохраняет импульс при столкновении с опорой и поворачивает существующий
локальный кадр моба. Нет новых portal entities или зависимости от Immersive Portals.

Локальные проверки этой ревизии: 567 Java unit / 27 Python / 131 обязательный GameTest,
включая14 новых проверок пушки. Свежие реальные клиенты: пять сцен пушки без Sodium
GL3.2 и с Sodium GL3.3; шесть сцен бестиария по шесть моделей в обеих конфигурациях;
по14 кадров зеркал/порталов;14 базовых нативных проверок с Sodium. Все используют
один исходный SHA и один JAR. В семи нативных сценариях нет DUMMY сообщений.
Общая регрессия: пять маркеров физики/местности/роя,10 оружейных сцен,3 Workshop-модели,
полная матрица видеоаудита369 кадров. Рой — контролируемая нагрузка на программной
графике, не обещание производительности в Survival. XML, логи и оригиналы кадров
сохранены в отдельных архивах. Результаты см. VERIFIED JSON и AUTOMATED_REPORT.md.

Сохранённые сбои: повторный GameTest в Actions выявил неполную загрузку комнаты
за выходным порталом. Тест явно загружает коридор с halo и проверяет его доступность;
производственный запрет чтения неизвестных кубов сохранён.

Старый тест боя Tripod также завершался после70 мировых тиков, когда сам моб
получил только38 тиков из-за асинхронного включения entity-ticking у forced chunks.
Диагностическая серия это воспроизвела (заряд0.8636, выстрел ещё не произошёл).
Проверка теперь требует70 настоящих тиков моба с жёстким общим пределом ожидания300,
сохраняя прежние требования к преследованию, поверхности, глазам и реальному выстрелу.
Событийный наблюдатель спавна использовался только при диагностике и не включён
в окончательный тест или установочный мод.

Сохранённые сбои реализации: первоначальная проверка реального столкновения выявила потерю
скорости о заднюю опору — добавлена память только потерянного при move компонента.
Обратный пересчёт направления теперь использует atan2; числовая проверка учитывает
один шаг штатной таблицы sin/cos Minecraft (65536 значений). Параллельные тестовые
комнаты пересекались — новые сцены выполняются разными последовательными batch.
Первый клиентский перенос целился в воздух, а косой луч попадал в соседний блок:
тест теперь целится в фактическую поверхность опоры. Сброс проверяется через input.sneaking,
поскольку ClientPlayerEntity читает Shift из ввода, а не флага сущности. Отдельный запуск
прервался из-за занятого X-дисплея; теперь Xvfb выделяет свободный дисплей и ожидает
завершения собственного процесса. Порог синего цвета исключает
голубое небо. Старые логи/кадры сохранены в failed-checks.zip, это не финальный PASS.

Открыто: ориентированные коллайдеры летающих корпусов, угловая динамика, полноценный
3D AI/поиск маршрута и обход препятствий, общий ragdoll, автономный Survival, корабли,
городские разрушения, полная cubic/worldgen/content parity,3D LOD и давление памяти.
Пушка работает в одном измерении, деревья пассажиров отклоняются; луч проходит только
через индекс управляемых пушкой панелей, максимум4 перехода. Новая пушка не означает
завершения физики или AI. Описание управления: docs/v5/PORTAL_GUN.md.
'''
out.joinpath('REPORT.md').write_text(report)
for f in out.glob('*.zip'):
    with zipfile.ZipFile(f) as z:assert z.testzip() is None
out.joinpath('SHA256SUMS').write_text(''.join(f'{hashlib.sha256(f.read_bytes()).hexdigest()}  {f.name}\n' for f in sorted(out.iterdir()) if f.is_file() and f.name!='SHA256SUMS'))
print('Verified checkpoint:',out,sha,p['sha256'])
