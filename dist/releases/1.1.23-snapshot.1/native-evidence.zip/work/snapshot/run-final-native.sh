#!/usr/bin/env bash
set -euo pipefail
cd /workspace/ungravity-v5/snapshot-ci
export JAVA_HOME=/workspace/jdk21-complete GRADLE_USER_HOME=/workspace/.gradle
mkdir -p build/checkpoint/logs
date +%s > build/checkpoint/started-at.txt
git rev-parse HEAD > build/checkpoint/SOURCE_SHA.txt
./gradlew --offline test --rerun runGametest build remapCubiccheckJar --no-daemon > build/checkpoint/logs/final-unit-world-build.log 2>&1
./gradlew --offline remapJar --rerun --no-daemon > build/checkpoint/logs/final-remap.log 2>&1
git restore -- dist/INSTALL_TLAUNCHER.txt
python3 - <<'PY'
import json,hashlib,subprocess
from pathlib import Path
p=Path('build/libs/drmd-6dof-1.1.23-snapshot.1.jar');Path('build/checkpoint/FINAL_NATIVE_INPUTS.json').write_text(json.dumps({'sourceSha':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'jarSha256':hashlib.sha256(p.read_bytes()).hexdigest()},indent=2))
PY
for scenario in release-snapshot-gl32 release-snapshot-sodium release-gun-gl32 release-gun-sodium release-mirror-gl32 release-mirror-sodium release-actors-gl32 release-actors-sodium release-contacts-gl32 release-contacts-sodium release-baseline-sodium release-mirror-fabulous-gl32; do
 bash work/snapshot/run-native.sh "$scenario"
done
