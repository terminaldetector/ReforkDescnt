from pathlib import Path
import json,hashlib,subprocess,zipfile,xml.etree.ElementTree as ET,shutil,time
r=Path('/workspace/ungravity-v5/snapshot-ci')
sha=subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip()
assert sha=='e800b439decc7070ecaa1e72c9216b72f40f70db'
assert not subprocess.check_output(['git','diff','--stat'],cwd=r,text=True).strip()
inputs=json.loads((r/'build/checkpoint/FINAL_NATIVE_INPUTS.json').read_text());assert inputs['sourceSha']==sha
jar=r/'build/libs/drmd-6dof-1.1.23-snapshot.1.jar';assert hashlib.sha256(jar.read_bytes()).hexdigest()==inputs['jarSha256']
started=int((r/'build/checkpoint/started-at.txt').read_text())
def fresh(p):assert p.is_file() and p.stat().st_size and p.stat().st_mtime>=started,str(p)
scenarios=['release-snapshot-gl32','release-snapshot-sodium','release-gun-gl32','release-gun-sodium','release-mirror-gl32','release-mirror-sodium','release-actors-gl32','release-actors-sodium','release-contacts-gl32','release-contacts-sodium','release-baseline-sodium','release-mirror-fabulous-gl32']
proof={**inputs,'softwareGraphics':True,'bccVersion':'0.1.1+mc1.21.1','scope':'native client snapshot input, models, mirrors, portal gun and contact regression; full Dynamic Boarding/3D AI pending','scenarios':[]}
for name in scenarios:
 d=r/f'build/cubic-client-final-{name}';fresh(d/'inputs.json');meta=json.loads((d/'inputs.json').read_text())
 assert meta['sourceSha']==sha and meta['uncommittedDiff']=='' and not meta['experimental_native_relight_probe']
 assert next(a['sha256'] for a in meta['artifacts'] if a['path']=='mods/drmd-6dof-1.1.23-snapshot.1.jar')==inputs['jarSha256']
 fresh(r/f'work/snapshot/final-{name}.exit');assert (r/f'work/snapshot/final-{name}.exit').read_text().strip()=='0'
 log=(r/f'work/snapshot/final-{name}.log').read_text();assert 'DUMMY' not in log
 marker='snapshot-ok.json' if 'snapshot' in name else 'portal-gun-ok.json' if 'gun' in name else 'body-contacts-ok.json' if 'contacts' in name else 'actor-frames-ok.json' if 'actors' in name else 'cubic-client-ok.json' if 'baseline' in name else 'native-mirror-ok.json'
 fresh(d/marker);result=json.loads((d/marker).read_text())
 if 'snapshot' in name:
  assert all(result.get(k) is True for k in ('actualWeaponInput','stableToolRoll','actualDroneInventory'))
  assert len(result['scenes'])==5 and all(s['frames']>=90 for s in result['scenes'])
 elif 'gun' in name:
  assert result['actualMouseEntry'] and result['packetPlacement'] and len(result['scenes'])==5
  assert result['scenes'][1]['bluePixels']>=80 and result['scenes'][1]['orangePixels']>=80
 elif 'actors' in name:assert len(result['scenes'])==6 and all(s['models']==6 and s['renderedFrames']>=90 for s in result['scenes'])
 elif 'contacts' in name:assert all(result.get(k) is True for k in ('orientedTerrain','hollowRay','unknownNativeYRejected','actualRenderer')) and len(result['scenes'])==3 and all(s['renderedFrames']>=90 for s in result['scenes'])
 elif 'baseline' in name:assert len(result['checks'])==14 and result['warpedVertices']>0
 else:assert result['frames']==14 and len(result['scenes'])==7
 if 'fabulous' in name:assert 'graphicsMode:2' in (d/'options.txt').read_text()
 frames=[]
 for folder in ('snapshot-frames','portal-gun-frames','actor-frames','body-contact-frames','gate-frames','native-mirror-frames'):
  for f in (d/folder).glob('*.png'):fresh(f);assert f.read_bytes()[:8]==b'\x89PNG\r\n\x1a\n';frames.append(str(f.relative_to(r)))
 assert frames
 proof['scenarios'].append({'name':name,'gl':meta['glOverride'],'result':result,'frames':frames,'dummyMessages':0})
for folder,total in [('build/test-results/test',578),('build/gametest/reports',144)]:
 cases=[]
 for f in (r/folder).glob('**/*.xml'):fresh(f);cases.extend(ET.parse(f).getroot().iter('testcase'))
 assert len(cases)==total and all(c.find(k) is None for c in cases for k in ('failure','error','skipped'))
with zipfile.ZipFile(jar) as z:assert not any('/gate/' in n or 'SnapshotFixCheck' in n or 'DroneInventoryGameTests' in n or n.startswith('dev/fallingcloud/') for n in z.namelist())
out=Path('/workspace/ungravity-v5/checkpoints/snapshot-fix-1.1.23');out.mkdir(exist_ok=True)
(out/'NATIVE_VERIFIED.json').write_text(json.dumps(proof,indent=2))
with zipfile.ZipFile(out/'native-evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
 for name in scenarios:
  d=r/f'build/cubic-client-final-{name}'
  for pattern in ('inputs.json','*ok.json','options.txt','logs/latest.log','snapshot-frames/*.png','portal-gun-frames/*.png','actor-frames/*.png','body-contact-frames/*.png','gate-frames/*.png','native-mirror-frames/*.png','config/*.json','config/drmd/*.json'):
   for f in d.glob(pattern):
    if f.is_file():z.write(f,f.relative_to(r))
  for suffix in ('log','exit'):f=r/f'work/snapshot/final-{name}.{suffix}';z.write(f,f.relative_to(r))
 for name in ('run-native.sh','run-final-native.sh','verify-native.py'):
  f=r/'work/snapshot'/name;z.write(f,f.relative_to(r))
 for pattern in ('build/test-results/test/*.xml','build/gametest/reports/*.xml','build/checkpoint/logs/final-*.log','build/checkpoint/FINAL_NATIVE_INPUTS.json','build/checkpoint/SOURCE_SHA.txt','build/checkpoint/started-at.txt'):
  for f in r.glob(pattern):
   if f.is_file():z.write(f,f.relative_to(r))
with zipfile.ZipFile(out/'preserved-failures.zip','w',zipfile.ZIP_DEFLATED) as z:
 for pattern in ('work/snapshot/failed-first-client/*','work/snapshot/mining-build*.log','work/snapshot/intermediate-da001ec/final-release-snapshot-sodium.log','work/snapshot/first-ci-evidence/shootcheck/mirror-join-frames/*.png','build/cubic-client-failed-first-snapshot/crash-reports/*.txt','build/cubic-client-failed-first-snapshot/snapshot-frames/*.png'):
  for f in r.glob(pattern):
   if f.is_file():z.write(f,f.relative_to(r))
print('PASS:',len(scenarios),'native configurations, source',sha,'JAR',inputs['jarSha256'])
