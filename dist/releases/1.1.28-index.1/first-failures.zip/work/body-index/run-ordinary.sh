#!/usr/bin/env bash
set -euo pipefail
cd /workspace/ungravity-v5/boarding-attachment
name=${1:-ordinary-debug}
f=work/body-index/${name}-display.txt
: > "$f"
/workspace/xvfb/usr/bin/Xvfb -displayfd 3 -screen 0 1280x1024x24 3> "$f" > work/body-index/${name}-xvfb.log 2>&1 &
pid=$!
trap 'kill "$pid" 2>/dev/null || true; wait "$pid" 2>/dev/null || true' EXIT
for i in {1..100}; do if [ -s "$f" ]; then break; fi; sleep .1; done
read -r number < "$f"
DISPLAY=:$number LIBGL_ALWAYS_SOFTWARE=1 JAVA_HOME=/workspace/jdk21-complete GRADLE_USER_HOME=/workspace/.gradle timeout --foreground 360 ./gradlew --offline runBodyindexcheck -x runGametest --no-daemon --console=plain > work/body-index/${name}.log 2>&1
test -s build/bodyindexcheck/body-index-ok.json
cat build/bodyindexcheck/body-index-ok.json
