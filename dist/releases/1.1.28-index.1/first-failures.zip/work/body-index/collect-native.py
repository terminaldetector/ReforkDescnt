from pathlib import Path
import hashlib,json,zipfile,shutil
root=Path.cwd();out=Path('/workspace/ungravity-v5/checkpoints/body-index-1.1.28.1');out.mkdir(parents=True,exist_ok=True)
source='3dd80e1ddd60903b1582b81a6f909936869c0c9e';digest='60cc81079d077fa909946cdfe3c2984feb61be6c7484691ef0d51a0bcb5dc737'
runs={};gallery=out/'native-frames';gallery.mkdir(exist_ok=True)
with zipfile.ZipFile(out/'native-evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
 for name,kind,count in [('body-index-final-gl32','body-index',4),('body-index-final-sodium','body-index',4),('body-edit-index128final-gl32','body-edit',5),('ship-index128final-gl32','ship-boarding',13),('boarding-index128final-gl32','boarding',5)]:
  base=root/f'build/cubic-client-final-{name}';inputs=json.loads((base/'inputs.json').read_text());assert inputs['sourceSha']==source and not inputs['uncommittedDiff']
  jar=next(a for a in inputs['artifacts'] if a['path']=='mods/drmd-6dof-1.1.28-index.1.jar');assert jar['sha256']==digest
  assert hashlib.sha256((base/jar['path']).read_bytes()).hexdigest()==digest
  marker=json.loads((base/f'{kind}-ok.json').read_text());assert marker['actualInputs'] and len(marker['scenes'])==count and marker['predictionSamples']>=30 and marker['maxPredictionError']<.8
  if kind=='body-index':
   assert all(marker[k] for k in ('legacyMissClient','legacyMissServer','edgePicked','holeClear','materialCharged'))
   assert marker['teleportFollow'] is False and marker['revisionChanges']>=3 and marker['travelDistance']>=1
   assert [a['scene'] for a in marker['scenes']]==['edge-intact','edge-cut','edge-patched','edge-hole']
  elif kind=='body-edit':
   assert all(marker[k] for k in ('survivalMining','materialCharged','savedState','comRebased'))
   assert marker['revisions']>=3 and marker['dropStacks']==marker['toolDamage']==1 and marker['maxPivotStep']<.8
  else:
   assert not marker['teleportFollow']
   if kind=='boarding':assert marker['sameStepJump'] is True and marker['jumpReleaseNetworkError']<1e-8
  log=root/f'work/body-index/final-{name}.log';assert log.is_file() and (root/f'work/body-index/final-{name}.exit').read_text().strip()=='0'
  for pattern in ('inputs.json',f'{kind}-ok.json',f'{kind}-frames/*.png','logs/latest.log','options.txt'):
   for p in base.glob(pattern):z.write(p,f'{name}/{p.relative_to(base)}')
  z.write(log,f'{name}/launcher.log')
  for scene in marker['scenes']:
   assert scene['frames']>=3
   p=base/f'{kind}-frames/{scene["scene"]}.png';assert p.read_bytes().startswith(b'\x89PNG\r\n\x1a\n') and p.stat().st_mtime>=(root/f'work/body-index/final-{name}-prepare.log').stat().st_mtime
   shutil.copy2(p,gallery/f'{name}-{p.name}')
  runs[name]=marker
 assert z.testzip() is None
with zipfile.ZipFile(out/'first-failures.zip','w',zipfile.ZIP_DEFLATED) as z:
 for pattern in ('work/body-index/*.log','work/body-index/*.xml','work/body-index/*.java','work/body-index/ci-b2c0c5d-failure/**/*.png','work/body-index/ci-b2c0c5d-failure/**/*.log','work/body-index/run-*.sh','work/body-index/collect-native.py','build/bodyindexcheck/body-index-ok.json','build/bodyindexcheck/body-index-frames/*.png'):
  for p in root.glob(pattern):z.write(p,p.relative_to(root))
 assert z.testzip() is None
assert len(list(gallery.glob('*.png')))==31
(out/'NATIVE_VERIFIED.json').write_text(json.dumps(dict(sourceSha=source,jarSha256=digest,nativeFrames=31,nativeClients=runs,scope='Full loaded-volume hull broadphase, remote-edge input and prior boarding regression',fullBoarding=False,dedicatedTwoClient=False,cellBudget=256,fullUfo=False),indent=2)+'\n')
print({k:(len(v['scenes']),v['predictionSamples'],v['maxPredictionError']) for k,v in runs.items()});print(out)
