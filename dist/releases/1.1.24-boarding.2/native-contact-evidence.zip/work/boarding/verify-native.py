from pathlib import Path
import hashlib,json,subprocess,struct
root=Path('.').resolve();out=Path('/workspace/ungravity-v5/checkpoints/boarding-1.1.24.2');out.mkdir(parents=True,exist_ok=True)
source='a1b045cde046d2a9f3be932eae960ed28bd4e083'
sha='19dbbeb2eacde9d7d587bf77780b6342c2394147d2631a88614c5e3007eb7c6a'
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==source
assert not subprocess.check_output(['git','diff','--stat'],text=True).strip()
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert digest(root/'build/libs/drmd-6dof-1.1.24-boarding.2.jar')==sha
results=[]
for scenario in ('rotation-contacts-gl32','rotation-contacts-sodium'):
 r=root/f'build/cubic-client-final-{scenario}';inputs=json.loads((r/'inputs.json').read_text());proof=json.loads((r/'body-contacts-ok.json').read_text())
 assert inputs['sourceSha']==source and inputs['uncommittedDiff']==''
 assert (root/f'work/boarding/final-{scenario}.exit').read_text().strip()=='0'
 assert all(proof.get(k) is True for k in ('orientedTerrain','hollowRay','unknownNativeYRejected','compoundContactQuery','relativeCCD','pairReaction','nativeGravitySupport','actualRenderer'))
 assert proof['playerBoarding'] is False and proof['stableRenderedRotationFrames']>=50
 assert [x['scene'] for x in proof['scenes']]==['diagonal-corner','terrain-stop','hollow-door','compound-contact-query','gravity-support']
 assert all(x['renderedFrames']>=90 for x in proof['scenes'])
 artifacts={a['path']:a for a in inputs['artifacts']}
 prod=artifacts['mods/drmd-6dof-1.1.24-boarding.2.jar'];assert prod['sha256']==sha
 for name,a in artifacts.items():
  if name.startswith('mods/'):
   assert digest(r/name)==a['sha256'],name
 sodium=list((r/'mods').glob('sodium-*.jar'));assert bool(sodium)==('sodium' in scenario)
 for scene in proof['scenes']:
  p=r/f'body-contact-frames/{scene["scene"]}.png';data=p.read_bytes();assert data[:8]==b'\x89PNG\r\n\x1a\n'
  assert struct.unpack('>II',data[16:24])==(1280,720)
  assert p.stat().st_mtime>=(r/'inputs.json').stat().st_mtime
 logs=(root/f'work/boarding/final-{scenario}.log').read_text(errors='replace')
 assert 'DUMMY' not in logs
 results.append(dict(scenario=scenario,sourceSha=source,jarSha256=sha,gateSha256=artifacts['mods/drmd-6dof-1.1.24-boarding.2-cubiccheck.jar']['sha256'],glOverride=inputs['glOverride'],sodium=bool(sodium),proof=proof,dummyLogLines=0))
control=root/'build/cubic-client-rotation-negative-control';meta=json.loads((control/'inputs.json').read_text())
old=[a for a in meta['artifacts'] if a['path']=='mods/drmd-6dof-1.1.24-boarding.1-fabric-1.21.1.jar'][0]
assert digest(control/old['path'])==old['sha256']=='ddd94a30639af99a39c573354121d97ffb8a200046ae26ead514edd849c695fc'
assert (root/'work/boarding/final-rotation-control-contacts-gl32.exit').read_text().strip()=='255'
assert 'stationary hull replays its old rotation when partial tick wraps' in (root/'work/boarding/final-rotation-control-contacts-gl32.log').read_text(errors='replace')
assert list((control/'crash-reports').glob('*.txt'))
result=dict(sourceSha=source,version='1.1.24-boarding.2',jarSha256=sha,scenarios=results,negativeControl=dict(expectedFailure=True,exitCode=255,oldJarSha256=old['sha256']),playerBoarding=False,full3DAI=False)
(out/'VERIFIED_NATIVE.json').write_text(json.dumps(result,indent=2)+'\n')
print('PASS: exact JAR, 2 native backends, 10 frames, 900 rendered frames, 120 stable rotation frames, expected old-JAR failure')
