package com.terminaldetector.drmd;

import com.terminaldetector.drmd.client.portal.PortalTransform.*;
import com.terminaldetector.drmd.world.contraption.*;
import net.fabricmc.fabric.api.gametest.v1.FabricGameTest;
import net.minecraft.block.Blocks;
import net.minecraft.test.*;
import net.minecraft.util.math.*;
import java.util.*;
import java.util.stream.Collectors;

public final class BodyFractureGameTests implements FabricGameTest {
    private BlockBodyEntity line(TestContext c,int count) {
        var cells=new ArrayList<BlockBodyEntity.Cell>();for(int i=0;i<count;i++)cells.add(new BlockBodyEntity.Cell(new BlockPos(i,0,0),Blocks.IRON_BLOCK.getDefaultState()));
        var w=c.getWorld();for(int x=1023;x<=1025;x++)for(int z=1023;z<=1025;z++)w.getChunk(x,z);
        return BlockBodyEntity.createLocal(w,cells,new Vec3d(16384,150,16384));
    }
    private Set<Integer> ids(TestContext c){return BodySpatialIndex.loaded(c.getWorld()).stream().map(BlockBodyEntity::getId).collect(Collectors.toSet());}
    private List<BlockBodyEntity> children(TestContext c,Set<Integer> before){return BodySpatialIndex.loaded(c.getWorld()).stream().filter(b->!before.contains(b.getId())).toList();}
    private Vec3 momentum(BlockBodyEntity b){return b.physics().linearVelocity().scaled(b.physicsMass());}
    private Vec3 angular(BlockBodyEntity b,Vec3 origin){return b.physics().angularMomentum().plus(b.massPosition().minus(origin).cross(momentum(b)));}
    private Vec3 pure(Vec3d p){return new Vec3(p.x,p.y,p.z);}
    @GameTest(templateName=EMPTY_STRUCTURE,batchId="body-fracture-material")
    public void cuttingABridgeCreatesARealBodyWithContinuousMaterialMotionAndMomentum(TestContext c) {
        var body=line(c,5);var before=ids(c);var q=new Quat(.2,.3,.4,.7).normalized();Vec3 velocity=new Vec3(1.5,-2,.3),spin=new Vec3(.4,.2,-.1);
        body.physics().withRotation(q).withLinearVelocity(velocity).withAngularVelocity(spin);
        var positions=new HashMap<BlockPos,Vec3d>();var speeds=new HashMap<BlockPos,Vec3d>();
        for(var cell:body.cells()){var point=body.localToWorld(Vec3d.ofCenter(cell.pos()));positions.put(cell.pos(),point);speeds.put(cell.pos(),body.surfaceVelocityAt(point));}
        Vec3 origin=body.massPosition(),expectedP=velocity.scaled(4),expectedL=angular(body,origin).minus(spin.scaled(1./6));
        try {
            c.assertTrue(body.setLocalBlock(new BlockPos(2,0,0),Blocks.AIR.getDefaultState()),"bridge damage succeeds");
            var detached=children(c,before);c.assertTrue(detached.size()==1,"two remaining connected halves become exactly two physical bodies");
            var all=new ArrayList<>(detached);all.add(body);var owned=new HashSet<BlockPos>();Vec3 sumP=new Vec3(0,0,0),sumL=sumP;
            for(var part:all) {
                c.assertTrue(part.cells().size()==2,"one body per connected fragment, not per block");
                c.assertTrue(part.physics().angularVelocity().minus(spin).length()<1e-9,"fragment retains the original spin");
                for(var cell:part.cells()) {
                    c.assertTrue(owned.add(cell.pos()),"no local material can exist in both bodies");
                    var point=part.localToWorld(Vec3d.ofCenter(cell.pos()));
                    c.assertTrue(point.distanceTo(positions.get(cell.pos()))<1e-8,"fracture preserves the world pose of every remaining material point");
                    c.assertTrue(part.surfaceVelocityAt(point).distanceTo(speeds.get(cell.pos()))<1e-8,"fragment COM inherits v plus omega cross radius");
                }
                sumP=sumP.plus(momentum(part));sumL=sumL.plus(angular(part,origin));
            }
            c.assertTrue(owned.size()==4&&!owned.contains(new BlockPos(2,0,0)),"only the actual damaged block disappears");
            c.assertTrue(sumP.minus(expectedP).length()<1e-8,"all surviving linear momentum is conserved");
            c.assertTrue(sumL.minus(expectedL).length()<1e-8,"parallel-axis spin plus orbital angular momentum is conserved");
        }finally{children(c,before).forEach(BlockBodyEntity::discard);body.discard();}c.complete();
    }
    @GameTest(templateName=EMPTY_STRUCTURE,batchId="body-fracture-batch")
    public void anAtomicTwoCutBatchDetachesEachComponentExactlyOnce(TestContext c) {
        var body=line(c,9);var before=ids(c);
        try {
            c.assertTrue(body.setLocalBlocks(Map.of(new BlockPos(2,0,0),Blocks.AIR.getDefaultState(),new BlockPos(5,0,0),Blocks.AIR.getDefaultState())),"atomic damage succeeds");
            var parts=children(c,before);c.assertTrue(parts.size()==2&&body.cells().size()==3,"largest component retains the original identity; two smaller bodies detach");
            c.assertTrue(parts.stream().allMatch(b->b.cells().size()==2),"each connected two-block remnant has one rigid body");
            c.assertTrue(!body.setLocalBlocks(Map.of(new BlockPos(2,0,0),Blocks.AIR.getDefaultState(),new BlockPos(5,0,0),Blocks.AIR.getDefaultState())),"replaying the same damage is a no-op");
            c.assertTrue(children(c,before).size()==2,"replayed edit cannot duplicate fragment entities");
        }finally{children(c,before).forEach(BlockBodyEntity::discard);body.discard();}c.complete();
    }
}
