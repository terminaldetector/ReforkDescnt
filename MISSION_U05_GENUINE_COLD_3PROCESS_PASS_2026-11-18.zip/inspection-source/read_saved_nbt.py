from pathlib import Path
import gzip,struct
class Reader:
 def __init__(self,path):self.data=gzip.decompress(Path(path).read_bytes());self.offset=0
 def take(self,n):
  out=self.data[self.offset:self.offset+n];assert len(out)==n;self.offset+=n;return out
 def num(self,f):return struct.unpack('>'+f,self.take(struct.calcsize(f)))[0]
 def text(self):return self.take(self.num('H')).decode('utf-8')
 def tag(self,t):
  if t in (1,2,3,4,5,6):return self.num({1:'b',2:'h',3:'i',4:'q',5:'f',6:'d'}[t])
  if t==7:return list(self.take(self.num('i')))
  if t==8:return self.text()
  if t==9:
   sub=self.num('B');n=self.num('i');assert 0<=n<=65536;return [self.tag(sub) for _ in range(n)]
  if t==10:
   out={}
   while True:
    sub=self.num('B')
    if not sub:return out
    key=self.text();out[key]=self.tag(sub)
  if t in (11,12):
   n=self.num('i');assert 0<=n<=65536;return [self.num('i' if t==11 else 'q') for _ in range(n)]
  raise ValueError(t)
 def root(self):assert self.num('B')==10;self.text();out=self.tag(10);assert self.offset==len(self.data);return out
