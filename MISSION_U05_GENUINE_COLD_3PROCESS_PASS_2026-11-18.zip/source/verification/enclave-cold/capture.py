#!/usr/bin/env python3
"""Cold-stage input guard; shared routines are pinned existing gameplay helpers."""
from pathlib import Path
import argparse,importlib.util,json,sys
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parents[2]
spec=importlib.util.spec_from_file_location('mission_cold_base',ROOT/'verification/enclave-gameplay/capture.py')
base=importlib.util.module_from_spec(spec);spec.loader.exec_module(base)
sha=base.sha;compiled=base.compiled;payload=base.payload
def source():
    frozen=base.source();frozen['files'].update(base.files('verification/enclave-cold'));return frozen
def check(out,before_launch=False):
    if source()!=json.loads((out/'inputs-before.json').read_text()):raise RuntimeError('cold source/JDK/helper changed')
    if compiled()!=json.loads((out/'compiled-subject.json').read_text()):raise RuntimeError('cold stage compiled subject changed')
    for name,value in json.loads((out/'compiler-payloads.json').read_text()).items():
        if payload(Path(name))!=value:raise RuntimeError('cold compiler payload changed: '+name)
    predecessor=out/'predecessor-inputs.json'
    if predecessor.exists():
        inputs=json.loads(predecessor.read_text())
        for name,value in inputs['immutableFiles'].items():
            if sha(Path(name))!=value:raise RuntimeError('closed predecessor evidence changed: '+name)
        if before_launch:
            world=ROOT/'build/gametest/world'
            actual={str(p.relative_to(world)):{'sha256':sha(p),'bytes':p.stat().st_size} for p in world.rglob('*') if p.is_file()}
            if actual!=inputs['rawWorld']:raise RuntimeError('cold reader world bytes differ from admitted actual predecessor')
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--check',type=Path,required=True);p.add_argument('--before-launch',action='store_true');a=p.parse_args();check(a.check,a.before_launch)
