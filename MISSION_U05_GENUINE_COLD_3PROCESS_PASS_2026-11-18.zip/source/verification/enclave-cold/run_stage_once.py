#!/usr/bin/env python3
"""One cold writer OR new-JVM reader; never automatically advances stages/retries."""
from pathlib import Path
import argparse,importlib.util,json,os,sys,xml.etree.ElementTree as ET
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parents[2]
def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module
capture=load('cold_capture',ROOT/'verification/enclave-cold/capture.py')
shared=load('cold_shared_launcher',ROOT/'verification/enclave-gameplay/run_once.py')
write=shared.write;process=shared.process
def main():
    p=argparse.ArgumentParser();p.add_argument('--source',required=True);p.add_argument('--run-dir',type=Path,required=True);p.add_argument('--stage',choices=('writer','finish','claimed'),required=True);p.add_argument('--predecessor',type=Path);a=p.parse_args()
    out=a.run_dir.resolve();world=ROOT/'build/gametest/world'
    if not out.is_relative_to(ROOT/'work/mission-cold') or out.exists():raise RuntimeError('fresh own cold output directory required')
    frozen=capture.source()
    if frozen['head']!=a.source:raise RuntimeError('wrong frozen source HEAD')
    if a.stage=='writer' and (world/'level.dat').exists():raise RuntimeError('writer requires fresh owned world')
    if a.stage!='writer' and (not a.predecessor or not (world/'level.dat').is_file()):raise RuntimeError('reader requires actual predecessor/world')
    out.mkdir(parents=True);write(out/'inputs-before.json',frozen)
    env=dict(os.environ,JAVA_HOME='/workspace/jdk21-complete',GRADLE_USER_HOME='/workspace/.gradle');env['PATH']=env['JAVA_HOME']+'/bin:'+env['PATH']
    base=[str(ROOT/'gradlew'),'--offline','--no-daemon','--max-workers=1','-Dorg.gradle.jvmargs=-Xmx768m','-PmissionRunDir='+str(out),'-PcoldStage='+a.stage,
          '-I','verification/enclave-baseline/inputs.init.gradle','-I','verification/enclave-cold/focus.init.gradle','-I','verification/enclave-cold/runtime.init.gradle']
    result={'source':a.source,'stage':a.stage,'runtimeLaunched':False,'freshXml':False,'tests':0,'scope':'ONE actual cold process-level case; not all3 cold stages/full integrated suite/spec completion'}
    if a.stage=='writer':
        historical=json.loads((ROOT/'work/mission-baseline/runtime-existing-f9-20261117T203330Z/artifact-freeze.json').read_text())
        before={name:capture.payload(Path(name)) for name in historical['compilerJars']};write(out/'known-compiler-payloads-before.json',before)
        first=process(base+['-PmissionStage=compile','compileGametestJava'],out,'compile-first',env);result['compileProcessExit']=first['actualChildExit']
        if first['actualChildExit']!=0 or first['deadlineFired']:
            result['passed']=False;write(out/'result.json',result);print(json.dumps(result,indent=2));return 1
        if capture.source()!=frozen:raise RuntimeError('source/helper/toolchain changed during writer compile')
        task=json.loads((out/'compileGametestJava-actual-inputs.json').read_text());actual={entry['path']:capture.payload(Path(entry['path'])) for entry in task['classpath'] if entry['kind']=='file' and entry['path'].endswith('.jar')}
        if any(name not in before or value!=before[name] for name,value in actual.items()):raise RuntimeError('actual compiler payload differs from frozen known input')
        write(out/'compiled-subject.json',capture.compiled());write(out/'compiler-payloads.json',actual)
    else:
        previous=a.predecessor.resolve();result['predecessor']=str(previous)
        prior=json.loads((previous/'result.json').read_text());expected='writer' if a.stage=='finish' else 'finish'
        if not prior['passed'] or prior['stage']!=expected or prior['source']!=a.source:raise RuntimeError('reader cannot follow failed/wrong-stage/different-source donor')
        if json.loads((previous/'inputs-before.json').read_text())!=frozen:raise RuntimeError('reader source/JDK/helper differs from original writer subject')
        archive=json.loads((previous/'closed-world-archive.json').read_text());raw=json.loads((previous/'closed-world-file-SHA256.json').read_text())
        if archive['world']!=str(world) or archive['source']!=a.source or capture.sha(Path(archive['archive']))!=archive['sha256']:raise RuntimeError('closed archive lineage differs')
        names=['result.json','inputs-before.json','compiled-subject.json','compiler-payloads.json','actual-state-receipt.json','closed-world-archive.json','closed-world-file-SHA256.json']
        immutable={str(previous/name):capture.sha(previous/name) for name in names};immutable[archive['archive']]=archive['sha256']
        write(out/'predecessor-inputs.json',{'immutableFiles':immutable,'rawWorld':raw})
        for name in ('compiled-subject.json','compiler-payloads.json'):write(out/name,json.loads((previous/name).read_text()))
        base+=['-PcoldReceipt='+str(previous/'actual-state-receipt.json')]
    capture.check(out,before_launch=a.stage!='writer')
    game=process(base+['-PmissionStage=gameplay','runGametest'],out,'gameplay-first',env);capture.check(out)
    result.update(runtimeLaunched=True,runtimeProcessExit=game['actualChildExit'],runtimeDeadlineFired=game['deadlineFired'],sourceAndCompiledInputsUnchanged=True)
    runtime=out/'actual-runtime-before-first-launch.json';result['runtimeClasspathUnchanged']=runtime.exists() and shared.runtime_unchanged(json.loads(runtime.read_text()))
    report=ROOT/'build/gametest/reports/gametest-results.xml'
    if report.is_file() and report.stat().st_mtime_ns>=game['startedNs']:
        data=report.read_bytes();(out/'gametest-results-first.xml').write_bytes(data);cases=list(ET.fromstring(data).iter('testcase'))
        result.update(freshXml=True,tests=len(cases),failures=sum(c.find('failure') is not None for c in cases),errors=sum(c.find('error') is not None for c in cases),skipped=sum(c.find('skipped') is not None for c in cases))
    log=(out/'gameplay-first.log').read_text();receipts=[json.loads(line.split('ENCLAVE_MISSION_COLD_RECEIPT=',1)[1]) for line in log.splitlines() if 'ENCLAVE_MISSION_COLD_RECEIPT=' in line]
    closed=[json.loads(line.split('ENCLAVE_MISSION_COLD_CLOSED=',1)[1]) for line in log.splitlines() if 'ENCLAVE_MISSION_COLD_CLOSED=' in line]
    if len(receipts)==1:write(out/'actual-state-receipt.json',receipts[0])
    result['actualReceiptCount']=len(receipts);result['actualClosedCount']=len(closed)
    result['passed']=game['actualChildExit']==0 and not game['deadlineFired'] and result['freshXml'] and result['runtimeClasspathUnchanged'] and result['tests']==1 and all(result.get(k)==0 for k in ('failures','errors','skipped')) and len(receipts)==1 and len(closed)==1 and closed[0]['failure']=='none' and closed[0]['playersRemoved'] and closed[0]['channelsClosed']
    write(out/'result.json',result);print(json.dumps(result,indent=2));return 0 if result['passed'] else 1
if __name__=='__main__':sys.exit(main())
