#!/usr/bin/env python3
"""After the actual process closes, preserve an owned cold save; never delete it."""
from pathlib import Path
import argparse,fcntl,gzip,hashlib,json,zipfile
ROOT=Path(__file__).resolve().parents[2]
def sha(data):return hashlib.sha256(data).hexdigest()
def archive(out):
    result=json.loads((out/'result.json').read_text())
    if not result['passed']:raise RuntimeError('failed first process cannot be an admitted reader donor')
    world=ROOT/'build/gametest/world';target=out/'closed-world.zip'
    if target.exists() or (out/'closed-world-archive.json').exists():raise FileExistsError('first closed archive already exists')
    manifest={};gzip_names=[]
    with (world/'session.lock').open('r+b') as lock:
        fcntl.lockf(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        for p in sorted(world.rglob('*')):
            if p.is_file():
                if p.is_symlink():raise RuntimeError('symlink world payload refused')
                data=p.read_bytes();name=str(p.relative_to(world));manifest[name]={'sha256':sha(data),'bytes':len(data)}
                if data[:2]==b'\x1f\x8b':gzip.decompress(data);gzip_names.append(name)
        if 'data/drmd_faction_memory.dat' not in manifest:raise RuntimeError('no actual saved FactionMemory output')
        with zipfile.ZipFile(target,'x',compression=zipfile.ZIP_DEFLATED) as z:
            for name in manifest:z.writestr('world/'+name,(world/name).read_bytes())
            z.writestr('world-SHA256.json',(json.dumps(manifest,indent=2)+'\n').encode())
        with zipfile.ZipFile(target) as z:
            if z.testzip() is not None:raise RuntimeError('closed world archive CRC failed')
            for name,value in manifest.items():
                if sha(z.read('world/'+name))!=value['sha256'] or sha((world/name).read_bytes())!=value['sha256']:raise RuntimeError('closed world file changed')
    (out/'closed-world-file-SHA256.json').write_text(json.dumps(manifest,indent=2)+'\n')
    receipt={'archive':str(target),'sha256':sha(target.read_bytes()),'world':str(world),'worldFiles':len(manifest),'rawBytes':sum(x['bytes'] for x in manifest.values()),'archiveBytes':target.stat().st_size,'fileManifestSHA256':sha((out/'closed-world-file-SHA256.json').read_bytes()),'exclusiveLockfAndCRCAndAllSHAs':True,'gzipVerified':gzip_names,'rawIntentionallyRetainedForNextReader':True,'source':result['source'],'stage':result['stage'],'actualReceiptSHA256':sha((out/'actual-state-receipt.json').read_bytes())}
    (out/'closed-world-archive.json').write_text(json.dumps(receipt,indent=2)+'\n');return receipt
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--run-dir',type=Path,required=True);a=p.parse_args();print(json.dumps(archive(a.run_dir.resolve()),indent=2))
