# U05 next separate cold gate: proposed contract, not implemented/proven

Keep productionfc54c416 and the now-frozen six-case candidate unchanged. This
proposal follows exact mission contract79bf55a4b2c61910a0fc8124e2bfdbf51bd61b8d.
No Java/IO/state mutation is authorized merely by this doc. First six-case outcome
must be sealed independently. Root reviews this before new cold-test source.

A genuine cold sequence needs THREE separate game JVMs against the same owned
world, with explicit closure and archived snapshots between them. Existing ordinary
fixture cleanup invalidates its Herald sites, so its closed world cannot serve as
a meaningful valid-site cold donor. Do not mistake refusal at an invalidated site
for proof that an intact claimed site prevents duplicate rewards.

1. **Writer** uses the normal production initializer, actual Creative OP2 bind
   command and real Survival owner. Owner accepts outside→enters the authored
   region using normal movement. Verify active cursor1, panel still real iron,
   owner reputation0 and site valid. Stop before mining. Leave the intentionally
   authored laboratory blocks intact (this is the owned cold donor), close actual
   actors/channels/tickets/OP entries, then allow normal server save/close. Emit a
   bounded read-only receipt of actual owner/profile/site/namespace/full XYZ/world
   seed/backend/bounds/hash and expected phase, not a mutation DTO. After JVM close,
   verify real faction DAT/level.dat/playerdata/region files, exclusive lockf,
   gzip/CRC/allSHA and immutable full-world archive. No progress is manufactured by
   deserializing a receipt or changing NBT.

2. **First reader**, a new game JVM, reopens exactly that world without reset or
   blueprint generation. Main code/resource definitions and compiled class files
   stay identical; reader test manifest/explicit stage argument changes are named
   launcher inputs only. Use actual PersistentStateManager disk load, original
   owner profile connection/PlayerManager identity and actual saved inventory.
   Verify namespace/site ID/current context/cursor1/rep0 and intact original Herald
   and panel BEFORE any interaction. Ordinary mining must produce the real AFTER
   callback and READY2/rep0; return and extract exactly once, rep3/CLAIMED, then
   repeat interaction without another reward. Leave original live Herald valid.
   Close actors/channels/tickets/OP entries and server, archive/inspect actual
   saved DAT with claim+rep in the same compound and record exact parent-world
   archive lineage. No writer recreation or direct ledger calls.

3. **Second reader**, another new game JVM, opens that same saved world. Actual
   original owner reconnects. Original site must still be valid, same namespace/
   key/hash/context, claimed cursor2 and rep3. Three real sneak-uses plus normal
   non-sneak status on the SAME live Herald must retain exact claimed receipt and
   rep3 even though the legitimately mined panel remains AIR. This is the actual
   cold duplicate-reward check, rather than a pure NBT roundtrip or an invalid-site
   denial. Close normally; retain full first logs/XML/exit/world/lineage proofs.

Each process gets its own first-only output directory, actual final ordered
classpath/resource/main registration and already-built-output guard. Proposed
physical test budget remains500framework/480driver/80admission/200normal mining;
external launcher180+10 per process. No clocks/budgets are silently suspended or
expanded. Ordinary tests/directors have no startup binding/progress; the only
cold fixture-generated laboratory is the explicit writer action. Readers merely
request bounded test-owned loaded columns around persisted actual coordinates and
interact physically. No duplicate engine/new dimension/retired autogen/tier canon.

Expected scope:3 actual process-level cases, writer/finish reader/claimed reader
reported separately; no hard-power-loss durability, full lab architecture,
additional mission kind, gameplay-spec completion or native performance claim.
First failure (including save/closure/admission) stays original, and all later
stages stop until it is classified. No raw donor or archive is removed while used
as a later reader; only closed verified derivative copies may be reclaimed with
root coordination.

Implemented helper boundary: all source/helpers/compiled outputs retain ONE frozen
HEAD across writer and two readers. Each closes before the next explicit lease;
CPU first logs/archives/receipts may be preserved under work/ without changing HEAD.
No source/docs/evidence commit between the three executions unless a first failure
stops the sequence and a new subject is reviewed. Each reader requires the prior
passed stage's actual receipt/result/source/class hashes plus all current raw-world
file SHA/list exactly matching its verified closed archive. Its actual processed
test manifest selects one stage class and no test main. The recipe resource hashes
and production main stay identical. Changed test-stage manifest/JVM receipt-path
arguments are explicit launch inputs, not a hidden executable change.

The writer equips a normal diamond pickaxe in slot1 and saves the REAL player
inventory/position through PlayerManager removal and ordinary server shutdown.
Readers require that exact existing tool and saved pose; they neither equip a new
tool nor teleport to the receipt coordinates. Contact use selects an existing
empty hotbar slot without clearing saved material/tool stacks. The active writer
and finished reader leave original Herald valid and laboratory intact; cleanup
closes only owned actors/OP entries/channels/tickets. Real mined drops remain normal
world objects. Reader code has no terrain authoring path. Protocol state is only
read from actual save-owned FactionMemory and changed via ordinary events/use.

Actual first compilation/admission/save/reader failure stops immediately. Never
advance readers using a failed donor, direct NBT write/fromNbt/reconstructed owner
DTO, invalidated-contact refusal or expectation of another reward as a fake PASS.
No automatic stage chaining; writer/finish/claimed each needs ROOT's separate Java
lease, same per-process180+10 and unchanged500/480/80/200physical budgets. Full6
ordinary proof836 remains immutable and separate from these three cold outcomes.
