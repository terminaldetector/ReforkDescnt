package com.terminaldetector.drmd;
import net.fabricmc.fabric.api.gametest.v1.FabricGameTest;
import net.minecraft.test.*;
public final class EnclaveMissionColdWriterGameTests implements FabricGameTest {
    @GameTest(templateName=EMPTY_STRUCTURE,batchId="mission-cold-writer",tickLimit=500)
    public void writeIntactActiveMissionThroughActualGameplay(TestContext c){EnclaveMissionColdFixture.start(c,EnclaveMissionColdFixture.Stage.WRITE_IN_PROGRESS);}
}
