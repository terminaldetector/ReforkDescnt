package com.terminaldetector.drmd;
import net.fabricmc.fabric.api.gametest.v1.FabricGameTest;
import net.minecraft.test.*;
public final class EnclaveMissionColdFinishReaderGameTests implements FabricGameTest {
    @GameTest(templateName=EMPTY_STRUCTURE,batchId="mission-cold-finish-reader",tickLimit=500)
    public void reopenActiveAndFinishUsingActualMiningAndExtraction(TestContext c){EnclaveMissionColdFixture.start(c,EnclaveMissionColdFixture.Stage.FINISH_READER);}
}
