package com.terminaldetector.drmd;

import com.google.gson.*;
import com.mojang.authlib.GameProfile;
import com.terminaldetector.drmd.entity.ModWorldBlocks;
import com.terminaldetector.drmd.world.access.WorldAccess;
import com.terminaldetector.drmd.world.edit.WorldEditSafety;
import com.terminaldetector.drmd.world.enclave.*;
import io.netty.channel.embedded.EmbeddedChannel;
import net.minecraft.block.*;
import net.minecraft.entity.MovementType;
import net.minecraft.item.*;
import net.minecraft.nbt.*;
import net.minecraft.network.*;
import net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket;
import net.minecraft.network.packet.s2c.play.GameMessageS2CPacket;
import net.minecraft.server.OperatorEntry;
import net.minecraft.server.network.*;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.test.TestContext;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.*;
import net.minecraft.util.math.*;
import net.minecraft.world.GameMode;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;

/** Three distinct game-JVM stages. Receipts locate/assert actual state; they never reconstruct it. */
final class EnclaveMissionColdFixture {
    enum Stage { WRITE_IN_PROGRESS,FINISH_READER,CLAIMED_READER }
    record Actor(ServerPlayerEntity player,EmbeddedChannel channel,OperatorEntry previousOperator){}
    final TestContext c;final ServerWorld w;final Stage stage;final BlockPos herald,anchor,panel;final UUID ownerId;
    final List<Actor> actors=new ArrayList<>();final JsonObject prior;final String definition="drmd:lab_infiltration";
    AiFixtureChunks chunks;Actor author,owner;FactionMemory memory;UUID namespace,siteId;String claimedReceipt;
    int admission,phase,phaseTicks,miningTicks,sequence,uses;boolean finished,closed,miningStarted;
    static void start(TestContext c,Stage stage){
        var driver=new EnclaveMissionColdFixture(c,stage);
        c.runAtEveryTick(()->{if(driver.finished)return;try{driver.tick();}catch(RuntimeException|Error failure){driver.finished=true;driver.close(failure);throw failure;}});
    }
    private EnclaveMissionColdFixture(TestContext c,Stage stage){
        this.c=c;w=c.getWorld();this.stage=stage;
        if(stage==Stage.WRITE_IN_PROGRESS){
            prior=null;ownerId=UUID.randomUUID();var origin=c.getAbsolutePos(new BlockPos(3,2,3));BlockPos chosen=null;
            int cx=Math.floorDiv(origin.getX(),EnclaveSite.CELL),cz=Math.floorDiv(origin.getZ(),EnclaveSite.CELL);
            for(int dx=-5;dx<=5&&chosen==null;dx++)for(int dz=-5;dz<=5;dz++){
                var pos=new BlockPos((cx+dx)*EnclaveSite.CELL+40,origin.getY(),(cz+dz)*EnclaveSite.CELL+40);
                if(EnclaveSite.generate(w.getSeed(),pos).origin==EnclaveOrigin.MINERS){chosen=pos;break;}
            }
            c.assertTrue(chosen!=null,"cold writer has compatible actual MINERS metadata within121 checks");herald=chosen;anchor=herald.add(10,0,0);
        }else{
            prior=loadReceipt();ownerId=UUID.fromString(prior.get("owner").getAsString());herald=pos(prior.getAsJsonObject("herald"));anchor=pos(prior.getAsJsonObject("anchor"));
            c.assertTrue(prior.get("dimension").getAsString().equals(w.getRegistryKey().getValue().toString())&&prior.get("seed").getAsLong()==w.getSeed(),"new game JVM opens same actual dimension/seed, not a rebuilt writer");
            c.assertTrue(prior.get("bottomY").getAsInt()==w.getBottomY()&&prior.get("topY").getAsInt()==w.getTopY()&&prior.get("backend").getAsString().equals(WorldAccess.of(w).backend().name()),"actual cold world backend and signed Y limits remain identical");
        }
        panel=anchor.east();
    }
    private JsonObject loadReceipt(){
        String property=System.getProperty("drmd.missionColdReceipt");c.assertTrue(property!=null,"reader requires explicit prior actual closed-process receipt path");
        try{
            var file=Path.of(property);c.assertTrue(file.isAbsolute()&&Files.isRegularFile(file)&&Files.size(file)<=16_384,"bounded read-only owned cold receipt");
            var parsed=JsonParser.parseString(Files.readString(file,StandardCharsets.UTF_8)).getAsJsonObject();
            c.assertTrue(parsed.get("stage").getAsString().equals(stage==Stage.FINISH_READER?Stage.WRITE_IN_PROGRESS.name():Stage.FINISH_READER.name()),"reader phase consumes the proper actual predecessor receipt");return parsed;
        }catch(java.io.IOException failure){throw new IllegalStateException("cold predecessor receipt unavailable",failure);}
    }
    private static BlockPos pos(JsonObject value){return new BlockPos(value.get("x").getAsInt(),value.get("y").getAsInt(),value.get("z").getAsInt());}
    private static Map<String,Integer> point(BlockPos value){return Map.of("x",value.getX(),"y",value.getY(),"z",value.getZ());}
    void tick(){
        w.resetIdleTimeout();c.assertTrue(c.getTick()<480,"cold500 framework retains original480 gameplay/cleanup bound; stage="+stage+" phase="+phase);
        if(chunks==null){chunks=new AiFixtureChunks(w,herald.add(7,0,2),1);return;}
        if(!chunks.entityTicking(herald,panel)){c.assertTrue(++admission<80,"bounded80 actual cold world admission: "+chunks.readiness(herald,panel));return;}
        if(owner==null){admit();return;}phaseTicks++;step();
    }
    private Actor connect(UUID id,GameMode mode,boolean operator){
        var profile=new GameProfile(id,"mc-"+id.toString().substring(0,8));var data=ConnectedClientData.createDefault(profile,false);
        var player=new ServerPlayerEntity(w.getServer(),w,profile,data.syncedOptions());var connection=new ClientConnection(NetworkSide.SERVERBOUND);var channel=new EmbeddedChannel(connection);
        var previous=w.getServer().getPlayerManager().getOpList().get(profile);var actor=new Actor(player,channel,previous);actors.add(actor);
        w.getServer().getPlayerManager().onPlayerConnect(connection,player,data);
        if(operator){w.getServer().getPlayerManager().getOpList().add(new OperatorEntry(profile,2,false));w.getServer().getPlayerManager().sendCommandTree(player);}
        player.changeGameMode(mode);DescentPlayerData.get(player).setEnabled(false);player.setNoGravity(true);player.getAbilities().flying=false;player.setVelocity(Vec3d.ZERO);
        if(stage==Stage.WRITE_IN_PROGRESS){player.getInventory().clear();player.setPosition(herald.getX()+.5,herald.getY(),herald.getZ()-1.5);}
        c.assertTrue(w.getServer().getPlayerManager().getPlayer(id)==player&&w.getEntity(id)==player,"actual cold connected owner identity is not a mock or restored DTO");
        c.assertTrue(operator?player.hasPermissionLevel(2):!player.hasPermissionLevel(2),"real OpList authority stays isolated to owned author");return actor;
    }
    private void put(BlockPos pos,BlockState state){
        c.assertTrue(stage==Stage.WRITE_IN_PROGRESS,"cold readers never author or reconstruct world blocks");
        var before=WorldAccess.of(w).readIfLoaded(pos).orElseThrow();c.assertTrue(!before.hasBlockEntity(),"explicit cold authoring never overwrites a preexisting block entity");
        w.setBlockState(pos,state,Block.NOTIFY_ALL);
    }
    private void admit(){
        c.assertTrue(EnclaveMissionCatalog.snapshot().valid()&&EnclaveMissionCatalog.find(definition).isPresent(),"actual production reload registered the same playable data before cold interaction");
        memory=FactionMemory.of(w);
        if(stage==Stage.WRITE_IN_PROGRESS){
            c.assertTrue(!state().contains("missions"),"explicit cold writer starts with no inherited mission ledger");
            for(int x=-2;x<=16;x++)for(int z=-3;z<=7;z++){
                put(herald.add(x,-1,z),Blocks.STONE.getDefaultState());for(int y=0;y<3;y++)put(herald.add(x,y,z),Blocks.AIR.getDefaultState());
            }
            put(herald,ModWorldBlocks.ENCLAVE_HERALD.getDefaultState());put(panel,Blocks.IRON_BLOCK.getDefaultState());
            author=connect(UUID.randomUUID(),GameMode.CREATIVE,true);owner=connect(ownerId,GameMode.SURVIVAL,false);
            author.player.setPosition(herald.getX()-1+.5,herald.getY(),herald.getZ()+6+.5);
            owner.player.getInventory().setStack(1,new ItemStack(Items.DIAMOND_PICKAXE));
            c.assertTrue(rep()==0,"fresh cold owner has no reputation before real acceptance");
        }else{
            // Actual PersistentStateManager loaded disk bytes before any owner interaction.
            var saved=site();namespace=state().getCompound("missions").getUuid("namespace");siteId=saved.getUuid("id");
            c.assertTrue(namespace.toString().equals(prior.get("namespace").getAsString())&&siteId.toString().equals(prior.get("site").getAsString()),"actual disk load preserves original namespace and site identity");
            c.assertTrue(saved.getBoolean("valid")&&saved.getString("hash").equals(prior.get("definitionHash").getAsString())&&saved.getString("hash").equals(EnclaveMissionCatalog.find(definition).orElseThrow().hash()),"same intact valid site and actual resource definition survive cold open");
            c.assertTrue(WorldAccess.of(w).readIfLoaded(herald).orElseThrow().isOf(ModWorldBlocks.ENCLAVE_HERALD),"original live Herald actually exists in saved region, not a recreated copy");
            if(stage==Stage.FINISH_READER){expect(1,"ACTIVE",0,"actual cold in-progress ledger loaded before events");c.assertTrue(w.getBlockState(panel).isOf(Blocks.IRON_BLOCK),"original unmined iron panel survives writer close");}
            else{expect(2,"CLAIMED",3,"actual second cold load has original claim and only one reward");c.assertTrue(w.getBlockState(panel).isAir(),"normal already-mined panel remains absent across cold reopen");claimedReceipt=instance().toString();}
            owner=connect(ownerId,GameMode.SURVIVAL,false);
            c.assertTrue(owner.player.getPos().distanceTo(standing(home()))<.05,"ordinary PlayerManager loads actual saved owner position without a fixture teleport");
            c.assertTrue(owner.player.getInventory().getStack(1).isOf(Items.DIAMOND_PICKAXE),"ordinary saved player inventory retains writer's actual pickaxe");
        }
        c.assertTrue(WorldEditSafety.mayChange(w,herald,owner.player)&&WorldEditSafety.mayChange(w,panel,owner.player),"actual cold owner has available, bounded and permitted interaction positions");
        sample("admitted");
    }
    private NbtCompound state(){return memory.writeNbt(new NbtCompound(),w.getRegistryManager());}
    private NbtCompound site(){
        var list=state().getCompound("missions").getList("sites",NbtElement.COMPOUND_TYPE);
        for(int i=0;i<list.size();i++){var s=list.getCompound(i);var p=s.getCompound("herald");if(p.getInt("x")==herald.getX()&&p.getInt("y")==herald.getY()&&p.getInt("z")==herald.getZ())return s;}
        return new NbtCompound();
    }
    private NbtCompound instance(){
        var list=state().getCompound("missions").getList("instances",NbtElement.COMPOUND_TYPE);
        for(int i=0;i<list.size();i++){var tag=list.getCompound(i);if(tag.getUuid("owner").equals(ownerId)&&siteId!=null&&tag.getUuid("site").equals(siteId))return tag;}
        return new NbtCompound();
    }
    private int rep(){return memory.getRep(ownerId,EnclaveOrigin.MINERS);}
    private void expect(int cursor,String status,int rep,String why){
        var tag=instance();String actual=tag.getString("status");if(actual.equals("ACTIVE")&&tag.getInt("cursor")==2)actual="READY";
        c.assertTrue(!tag.isEmpty()&&tag.getInt("cursor")==cursor&&actual.equals(status)&&rep()==rep,why+" actual="+tag+" rep="+rep());
    }
    private BlockPos home(){return herald.add(0,0,-2);}
    private static Vec3d standing(BlockPos pos){return new Vec3d(pos.getX()+.5,pos.getY(),pos.getZ()+.5);}
    private boolean walk(BlockPos to){
        var p=owner.player;var delta=standing(to).subtract(p.getPos());double length=Math.hypot(delta.x,delta.z);double scale=length>.30?.30/length:1;
        p.setSneaking(false);p.setVelocity(Vec3d.ZERO);p.move(MovementType.SELF,new Vec3d(delta.x*scale,-.08,delta.z*scale));
        c.assertTrue(Math.abs(p.getY()-to.getY())<.01,"normal cold-stage movement retains actual floor collision/height");return p.getPos().squaredDistanceTo(standing(to))<.025*.025;
    }
    private void aim(Vec3d target){
        var p=owner.player;var d=target.subtract(p.getEyePos());p.setYaw((float)(Math.toDegrees(Math.atan2(d.z,d.x))-90));p.setPitch((float)-Math.toDegrees(Math.atan2(d.y,Math.hypot(d.x,d.z))));p.setHeadYaw(p.getYaw());
    }
    private void use(boolean sneak){
        var p=owner.player;int empty=0;
        while(empty<9&&!p.getInventory().getStack(empty).isEmpty())empty++;
        c.assertTrue(empty<9,"normal cold owner retains an actual empty hotbar slot without deleting saved items");
        p.getInventory().selectedSlot=empty;p.setSneaking(sneak);
        c.assertTrue(p.getMainHandStack().isEmpty()&&p.getOffHandStack().isEmpty(),"actual empty-hand slot, without deleting persisted tool/materials");
        var target=Vec3d.ofCenter(herald).add(0,0,-.5);aim(target);
        var hit=w.raycast(new net.minecraft.world.RaycastContext(p.getEyePos(),target.add(0,0,.002),net.minecraft.world.RaycastContext.ShapeType.COLLIDER,net.minecraft.world.RaycastContext.FluidHandling.NONE,p));
        c.assertTrue(hit.getType()==HitResult.Type.BLOCK&&hit.getBlockPos().equals(herald)&&p.getEyePos().distanceTo(target)<=p.getBlockInteractionRange(),"same loaded live original contact is ordinary ray's first collider and within actual reach");
        var result=p.interactionManager.interactBlock(p,w,p.getMainHandStack(),Hand.MAIN_HAND,new BlockHitResult(target,Direction.NORTH,herald,false));
        c.assertTrue(result.isAccepted(),"actual cold Survival Herald path returns accepted");uses++;sample("actual-use:"+result);
    }
    private boolean mine(){
        var p=owner.player;
        if(!miningStarted){
            if(!walk(panel.add(0,0,-2)))return false;p.getInventory().selectedSlot=1;p.setSneaking(false);
            c.assertTrue(p.getMainHandStack().isOf(Items.DIAMOND_PICKAXE)&&p.canHarvest(w.getBlockState(panel))&&p.isOnGround(),"real saved Survival tool mines its actual original panel on the floor");
            var target=Vec3d.ofCenter(panel).add(0,0,-.5);aim(target);
            var hit=w.raycast(new net.minecraft.world.RaycastContext(p.getEyePos(),target.add(0,0,.002),net.minecraft.world.RaycastContext.ShapeType.COLLIDER,net.minecraft.world.RaycastContext.FluidHandling.NONE,p));
            c.assertTrue(hit.getType()==HitResult.Type.BLOCK&&hit.getBlockPos().equals(panel)&&p.getEyePos().distanceTo(target)<=p.getBlockInteractionRange()&&WorldEditSafety.mayChange(w,panel,p)&&WorldEditSafety.loadedSegment(w,p.getEyePos(),target),"ordinary cold mining has actual target/ray/reach/loaded-permission guards");
            miningStarted=true;miningTicks=0;p.interactionManager.processBlockBreakingAction(panel,PlayerActionC2SPacket.Action.START_DESTROY_BLOCK,Direction.NORTH,w.getTopY(),++sequence);sample("mining-start");return false;
        }
        miningTicks++;c.assertTrue(miningTicks<=200,"same200 actual-tick bound for cold normal mining");
        if(w.getBlockState(panel).isAir()){c.assertTrue(miningTicks>1,"cold actual mining uses real duration, no setup/direct break shortcut");sample("mining-real-air");return true;}
        if(miningTicks==20)p.interactionManager.processBlockBreakingAction(panel,PlayerActionC2SPacket.Action.STOP_DESTROY_BLOCK,Direction.NORTH,w.getTopY(),++sequence);return false;
    }
    private void next(int phase){this.phase=phase;phaseTicks=0;sample("phase:"+phase);}
    private void step(){
        if(stage==Stage.WRITE_IN_PROGRESS){
            switch(phase){
                case 0->{
                    String command="ungravitymission bind "+definition+" "+xyz(herald)+" "+xyz(anchor);
                    w.getServer().getCommandManager().executeWithPrefix(author.player.getCommandSource(),command);
                    var bound=site();c.assertTrue(!bound.isEmpty()&&bound.getBoolean("valid"),"real cold writer command binds the existing original site");
                    siteId=bound.getUuid("id");namespace=state().getCompound("missions").getUuid("namespace");
                    c.assertTrue(instance().isEmpty()&&rep()==0,"cold author command does not create owner progress or reward");next(1);
                }
                case 1->{use(true);expect(0,"ACTIVE",0,"real cold acceptance grants no completion or reputation");next(2);}
                case 2->{if(walk(anchor.add(0,0,-1)))next(3);}
                case 3->{expect(1,"ACTIVE",0,"real owner entry creates in-progress disk donor");if(walk(home()))next(4);}
                case 4->{
                    expect(1,"ACTIVE",0,"writer retains incomplete active objective through ordinary return");
                    c.assertTrue(site().getBoolean("valid")&&w.getBlockState(panel).isOf(Blocks.IRON_BLOCK),"writer donor keeps original intact valid contact and unmined panel");
                    emitReceipt();finished=true;close(null);c.complete();
                }
                default->throw new IllegalStateException("unknown cold writer phase "+phase);
            }
        }else if(stage==Stage.FINISH_READER){
            switch(phase){
                case 0->{if(!miningStarted)expect(1,"ACTIVE",0,"actual loaded entry cursor requires real mining after reopen");if(mine())next(1);}
                case 1->{expect(2,"READY",0,"real cold-reader mining completes objective but grants no reward");if(walk(home()))next(2);}
                case 2->{use(true);expect(2,"CLAIMED",3,"actual original-owner extraction commits exactly one reward after cold resume");claimedReceipt=instance().toString();next(3);}
                case 3->{
                    use(phaseTicks<=3);expect(2,"CLAIMED",3,"same cold session repeated use cannot duplicate reward");
                    c.assertTrue(instance().toString().equals(claimedReceipt),"actual repeated interactions retain exact claimed key/cursor/status");if(phaseTicks==4)next(4);
                }
                case 4->{verifyMessages(true);c.assertTrue(site().getBoolean("valid"),"finish reader leaves original site VALID for meaningful next cold denial");emitReceipt();finished=true;close(null);c.complete();}
                default->throw new IllegalStateException("unknown cold finish-reader phase "+phase);
            }
        }else{
            if(phase==0){
                use(phaseTicks<=3);expect(2,"CLAIMED",3,"second game JVM real repeated use retains original claim and reward");
                c.assertTrue(instance().toString().equals(claimedReceipt)&&site().getBoolean("valid"),"cold denial is on original intact VALID site, not invalidated/missing stand-in");if(phaseTicks==4)next(1);
            }else{
                verifyMessages(false);emitReceipt();finished=true;close(null);c.complete();
            }
        }
    }
    private static String xyz(BlockPos p){return p.getX()+" "+p.getY()+" "+p.getZ();}
    private List<String> messages(){
        var list=new ArrayList<String>();int chars=0;
        for(Object raw:owner.channel.outboundMessages())if(raw instanceof GameMessageS2CPacket packet){
            String value=packet.content().getString();if(list.size()>=64||chars+value.length()>65_536)break;list.add(value);chars+=value.length();
        }
        return List.copyOf(list);
    }
    private void verifyMessages(boolean extractionExpected){
        var delivered=messages();long count=delivered.stream().filter(s->s.contains("Extracted "+definition+" (+3 miners)")).count();
        c.assertTrue(count==(extractionExpected?1:0),"normally delivered cold feedback agrees with one total extraction, without flush/pump/injection: "+delivered);
        c.assertTrue(delivered.stream().anyMatch(s->s.contains("Already extracted")),"normal intact-site repeated use explains existing receipt instead of inventing unavailable mission");
        sample("normal-packets:"+delivered);
    }
    private int samples;
    private void sample(String event){
        c.assertTrue(++samples<=64,"bounded64 cold actual event receipts");
        System.out.println("ENCLAVE_MISSION_COLD_EVENT="+new Gson().toJson(Map.of(
            "stage",stage.name(),"event",event,"gameTick",c.getTick(),"serverTick",w.getServer().getTicks(),"phase",phase,
            "owner",ownerId.toString(),"actualInstance",memory==null?"not loaded":instance().toString(),"actualRep",memory==null?-1:rep(),
            "actualPosition",owner==null?"not connected":owner.player.getPos().toString(),"miningTicks",miningTicks)));
    }
    private void emitReceipt(){
        c.assertTrue(site().getBoolean("valid")&&WorldAccess.of(w).readIfLoaded(herald).orElseThrow().isOf(ModWorldBlocks.ENCLAVE_HERALD),"cold process finishes on same intact valid original contact");
        var receipt=new LinkedHashMap<String,Object>();receipt.put("stage",stage.name());receipt.put("owner",ownerId.toString());receipt.put("namespace",namespace.toString());receipt.put("site",siteId.toString());
        receipt.put("dimension",w.getRegistryKey().getValue().toString());receipt.put("seed",w.getSeed());receipt.put("backend",WorldAccess.of(w).backend().name());
        receipt.put("bottomY",w.getBottomY());receipt.put("topY",w.getTopY());receipt.put("herald",point(herald));receipt.put("anchor",point(anchor));
        receipt.put("definition",definition);receipt.put("definitionHash",site().getString("hash"));receipt.put("actualInstance",instance().toString());receipt.put("actualRep",rep());
        receipt.put("actualSiteValid",site().getBoolean("valid"));receipt.put("actualPanel",w.getBlockState(panel).toString());receipt.put("actualOwnerPosition",owner.player.getPos().toString());
        receipt.put("actualGameTick",c.getTick());receipt.put("actualServerTick",w.getServer().getTicks());receipt.put("scope","actual state receipt only; world/ledger/player inventory are NOT restored from this JSON");
        System.out.println("ENCLAVE_MISSION_COLD_RECEIPT="+new Gson().toJson(receipt));
    }
    private void close(Throwable original){
        if(closed)return;closed=true;Throwable failure=original;
        // Intentionally preserve owned authored blocks/actual mining drops and ledger.
        // Normal server shutdown saves their real state; only transient actors/leases close.
        for(var actor:actors){
            try{
                if(actor.previousOperator!=null)w.getServer().getPlayerManager().getOpList().add(actor.previousOperator);
                else if(w.getServer().getPlayerManager().isOperator(actor.player.getGameProfile()))w.getServer().getPlayerManager().removeFromOperators(actor.player.getGameProfile());
            }catch(RuntimeException|Error bad){failure=append(failure,bad);}
            try{if(w.getServer().getPlayerManager().getPlayer(actor.player.getUuid())==actor.player)w.getServer().getPlayerManager().remove(actor.player);actor.player.discard();}
            catch(RuntimeException|Error bad){failure=append(failure,bad);}
            try{actor.channel.finishAndReleaseAll();}catch(RuntimeException|Error bad){failure=append(failure,bad);}
        }
        try{if(chunks!=null)chunks.close();}catch(RuntimeException|Error bad){failure=append(failure,bad);}
        System.out.println("ENCLAVE_MISSION_COLD_CLOSED="+new Gson().toJson(Map.of("stage",stage.name(),"failure",original==null?"none":original.toString(),"playersRemoved",actors.stream().allMatch(a->a.player.isRemoved()),"channelsClosed",actors.stream().allMatch(a->!a.channel.isOpen()),"authoredWorldIntentionallyRetained",true)));
        if(original==null){if(failure instanceof Error error)throw error;if(failure instanceof RuntimeException error)throw error;}
    }
    private static Throwable append(Throwable first,Throwable next){if(first==null)return next;if(first!=next)first.addSuppressed(next);return first;}
}
