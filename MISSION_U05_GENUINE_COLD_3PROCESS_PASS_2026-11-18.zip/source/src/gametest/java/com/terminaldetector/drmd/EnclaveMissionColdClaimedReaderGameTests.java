package com.terminaldetector.drmd;
import net.fabricmc.fabric.api.gametest.v1.FabricGameTest;
import net.minecraft.test.*;
public final class EnclaveMissionColdClaimedReaderGameTests implements FabricGameTest {
    @GameTest(templateName=EMPTY_STRUCTURE,batchId="mission-cold-claimed-reader",tickLimit=500)
    public void reopenedValidClaimedSiteCannotGrantAgain(TestContext c){EnclaveMissionColdFixture.start(c,EnclaveMissionColdFixture.Stage.CLAIMED_READER);}
}
