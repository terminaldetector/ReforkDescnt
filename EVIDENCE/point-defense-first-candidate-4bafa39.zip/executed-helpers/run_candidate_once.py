from pathlib import Path
import hashlib,json,os,subprocess,time,sys,shutil

ROOT=Path(__file__).resolve().parents[2]
SOURCE='4bafa39e142fb9519bba49f4baaaf531c1d6094a'
stage=ROOT/'work/point-defense/first-candidate-4bafa39'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==SOURCE
assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=ROOT,text=True)
assert not (ROOT/'build/gametest/world').exists()
assert not stage.exists()
stage.mkdir()
files=['work/point-defense/focus-positive.init.gradle','build.gradle','gradle.properties',
       'docs/v8/POINT_DEFENSE_INTERCEPTION_2026-11-17.md',
       'src/main/java/com/terminaldetector/drmd/world/trap/PointDefenseInterception.java',
       'src/main/java/com/terminaldetector/drmd/world/trap/DefenseTurrets.java',
       'src/main/java/com/terminaldetector/drmd/entity/ProjectileEntity.java',
       'src/main/java/com/terminaldetector/drmd/weapon/core/WeaponCore.java',
       'src/main/java/com/terminaldetector/drmd/weapon/core/RelativeProjectileSweep.java',
       'src/main/java/com/terminaldetector/drmd/weapon/core/InterceptAim.java',
       'src/main/java/com/terminaldetector/drmd/weapon/projectile/ProjectileFramework.java',
       'src/test/java/com/terminaldetector/drmd/RelativeProjectileSweepTest.java',
       'src/gametest/java/com/terminaldetector/drmd/AiFixtureChunks.java',
       'src/gametest/java/com/terminaldetector/drmd/PointDefenseInterceptionGameTests.java',
       'src/gametest/java/com/terminaldetector/drmd/PointDefenseGuardGameTests.java',
       'src/gametest/java/com/terminaldetector/drmd/ProjectileVisualGameTests.java',
       'src/gametest/java/com/terminaldetector/drmd/UfoWeaponGameTests.java',
       'src/gametest/java/com/terminaldetector/drmd/FusionPortalGameTests.java']
inputs={'source':SOURCE,'startTimeNs':time.time_ns(),'executingRunnerSha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'sha256ByFile':{n:hashlib.sha256((ROOT/n).read_bytes()).hexdigest() for n in files},
        'scope':'FIRST6pureSweep then ifPASS41stockGT(12new+29retained); source-only component bootstrap, no native/fullS12/main-registration acceptance'}
(stage/'inputs.json').write_text(json.dumps(inputs,indent=2)+'\n')
(stage/'executed-runner.py').write_bytes(Path(__file__).read_bytes())
for n in files:
    p=stage/'initial-source'/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((ROOT/n).read_bytes())
env=dict(os.environ,JAVA_HOME='/workspace/jdk21-complete',GRADLE_USER_HOME='/workspace/.gradle')
env['PATH']='/workspace/jdk21-complete/bin:'+env.get('PATH','')
commands=[('unit',['./gradlew','test','--tests','com.terminaldetector.drmd.RelativeProjectileSweepTest','--offline','--no-daemon']),
          ('gametest',['./gradlew','runGametest','--offline','--no-daemon','-I','work/point-defense/focus-positive.init.gradle'])]
for phase,command in commands:
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==SOURCE
    report=ROOT/('build/test-results/test/TEST-com.terminaldetector.drmd.RelativeProjectileSweepTest.xml' if phase=='unit' else 'build/gametest/reports/gametest-results.xml')
    if report.exists():report.unlink()
    started=time.time_ns()
    (stage/(phase+'-start.json')).write_text(json.dumps({'source':SOURCE,'startTimeNs':started,'command':command},indent=2)+'\n')
    with (stage/(phase+'.log')).open('wb') as output:
        child=subprocess.Popen(command,cwd=ROOT,env=env,stdout=output,stderr=subprocess.STDOUT)
        code=child.wait()
    # Immediate actual close before report copies, postchecks or analysis.
    (stage/(phase+'.exit')).write_text(str(code)+'\n')
    (stage/(phase+'-exit.json')).write_text(json.dumps({'source':SOURCE,'pid':child.pid,'exit':code,'closedTimeNs':time.time_ns()},indent=2)+'\n')
    print(phase+' FIRST CLOSED exit='+str(code),flush=True)
    if report.exists():
        target=stage/(phase+'-xml');target.mkdir();shutil.copyfile(report,target/report.name)
    else:(stage/(phase+'-NO_XML.txt')).write_text('No fresh report exists after the first actual child close; preserve raw compiler/runtime log.\n')
    manifest=ROOT/'build/resources/gametest/fabric.mod.json'
    if phase=='gametest' and manifest.exists() and manifest.stat().st_mtime_ns>=started:
        shutil.copyfile(manifest,stage/'actual-focused-manifest.json')
    if code:raise SystemExit(code)
