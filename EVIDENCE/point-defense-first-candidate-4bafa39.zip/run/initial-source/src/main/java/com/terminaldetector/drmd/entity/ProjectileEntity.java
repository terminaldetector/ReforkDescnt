package com.terminaldetector.drmd.entity;

import com.terminaldetector.drmd.physics.PhysicsTarget;
import com.terminaldetector.drmd.weapon.core.DamageClass;
import com.terminaldetector.drmd.weapon.core.MissileSteering;
import com.terminaldetector.drmd.weapon.core.WeaponCore;
import com.terminaldetector.drmd.weapon.fx.WeaponFx;
import com.terminaldetector.drmd.world.LocalOrientation;
import com.terminaldetector.drmd.world.portal.mirror.MirrorReflection;
import com.terminaldetector.drmd.world.portal.mirror.ReflectiveBlock;
import net.minecraft.block.BlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.data.TrackedDataHandlerRegistry;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.network.packet.s2c.play.EntitySpawnS2CPacket;
import net.minecraft.particle.DustParticleEffect;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import org.joml.Vector3f;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;
import java.util.function.Consumer;

/**
 * Physical projectile — port of prop_physics projectiles from D6_Wep.FireProjectile.
 * Client mesh/color synced via DataTracker for 3D projectile silhouettes.
 */
public class ProjectileEntity extends Entity {
	public static final int MESH_BOLT = 0;
	public static final int MESH_ROCKET = 1;
	public static final int MESH_ORB = 2;
	public static final int MESH_DRILL = 3;
	public static final int MESH_MINE = 4;

	private static final TrackedData<Integer> COLOR = DataTracker.registerData(ProjectileEntity.class, TrackedDataHandlerRegistry.INTEGER);
	private static final TrackedData<Float> SCALE = DataTracker.registerData(ProjectileEntity.class, TrackedDataHandlerRegistry.FLOAT);
	private static final TrackedData<Integer> MESH = DataTracker.registerData(ProjectileEntity.class, TrackedDataHandlerRegistry.INTEGER);
	// Vanilla spawn/velocity packets clamp each component to +/-3.9 blocks/tick. Some DRMD
	// weapons exceed that speed. Metadata carries the full vector without changing server physics.
	private static final TrackedData<Vector3f> VISUAL_VELOCITY = DataTracker.registerData(ProjectileEntity.class, TrackedDataHandlerRegistry.VECTOR3F);

	private UUID ownerUuid;
	private Entity owner;
	private DamageClass dmgClass = DamageClass.KINETIC;
	private float directDamage;
	private float splashDamage;
	private float splashRadius;
	private int lifeTicks = 100;
	private float gravityStrength;
	private float drag;
	private boolean homing;
	private boolean pilotGuided;
	private float turnRate = 90f;
	private Entity homeTarget;
	private int pierceCount;
	private boolean worldBlast;
	private boolean fusionPortalCharge;
	private boolean drillCarve;

	public static final int DEFAULT_MAX_BOUNCES = 6;
	private int bounceCount;
	private int maxBounces = DEFAULT_MAX_BOUNCES;
	private Consumer<WeaponCore.HitContext> onHit;
	private final Set<Integer> pierced = new HashSet<>();
	private final com.terminaldetector.drmd.weapon.projectile.ProjectilePrediction visualPrediction =
			new com.terminaldetector.drmd.weapon.projectile.ProjectilePrediction();

	private com.terminaldetector.drmd.weapon.projectile.FuseType fuse =
			com.terminaldetector.drmd.weapon.projectile.FuseType.IMPACT;
	private int fuseTicks;
	private int armTicks;
	private float proximityRadius;
	private int ageTicks;
	private boolean igniteOnHit;

	/** Optional server-only identity for the bounded static defensive round. Old shots have none. */
	public record DefenseSource(BlockPos anchor,UUID target,long bornAt,long eligibleFrom){}
	public record DefenseContact(Vec3d tracePoint,Vec3d materialPoint,UUID entityUuid,int entityId,
			BlockPos block,net.minecraft.util.math.Direction side){}
	private DefenseSource defenseSource;
	private boolean restoredDefense;
	private long lastMissileStep=Long.MIN_VALUE;

	public ProjectileEntity(EntityType<? extends ProjectileEntity> type, World world) {
		super(type, world);
		this.noClip = false;
	}

	public void setOwner(Entity owner) {
		this.owner = owner;
		this.ownerUuid = owner.getUuid();
	}

	public Entity getOwnerEntity() {
		if (owner != null && owner.getWorld()==getWorld()) return owner;
		if (ownerUuid != null && getWorld() instanceof ServerWorld sw) {
			Entity e = sw.getEntity(ownerUuid);
			if(e==null)for(var body:com.terminaldetector.drmd.world.contraption.BodySpatialIndex.loaded(sw))if(body.getUuid().equals(ownerUuid)){e=body;break;}
			if(e!=null){owner=e;return e;}
		}
		return null;
	}
	public LivingEntity getOwnerLiving(){return getOwnerEntity() instanceof LivingEntity living&&living.isAlive()?living:null;}
	/** Identity only: callers needing a loaded living owner need not scan body-owner fallbacks. */
	public UUID getOwnerUuid(){return ownerUuid;}
	public DefenseSource pointDefenseSource(){return defenseSource;}
	public long lastMissileStep(){return lastMissileStep;}
	public int remainingLifeTicks(){return lifeTicks;}
	public float splashRadius(){return splashRadius;}
	public boolean isPointDefenseMissile(){return defenseSource==null&&getMeshKind()==MESH_ROCKET
			&&dmgClass==DamageClass.EXPLOSIVE&&lifeTicks>0&&!fusionPortalCharge
			&&(directDamage>0||splashDamage>0)
			&&(fuse==com.terminaldetector.drmd.weapon.projectile.FuseType.IMPACT
			||fuse==com.terminaldetector.drmd.weapon.projectile.FuseType.DELAYED_IMPACT);}
	public void configurePointDefense(BlockPos anchor,UUID target){
		if(!(getWorld() instanceof ServerWorld world)||ownerUuid!=null||anchor==null||target==null)return;
		long now=world.getTime();
		// Conservative full-frame birth guard: even a just-born round cannot catch
		// a segment already processed earlier in its birth tick, in either order.
		defenseSource=new DefenseSource(anchor.toImmutable(),target,now,now+1);
	}
	/** Exact non-homing step used both for prediction and normal tagged-round integration. */
	public Vec3d pointDefenseStepVelocity(){
		if(defenseSource==null||homing||pilotGuided||ownerUuid!=null)return null;
		Vec3d velocity=getVelocity();
		if(gravityStrength!=0)velocity=velocity.add(0,-gravityStrength*.05,0);
		if(drag>0&&velocity.lengthSquared()>1e-6)velocity=velocity.multiply(Math.max(0,1-drag*.02));
		return velocity;
	}
	/** The service supplies only its already validated real material collision. Normal hit behavior is shared. */
	public void pointDefensePairHit(ProjectileEntity other,Vec3d point){
		if(!isAlive()||other==null||!isArmed()||!(defenseSource!=null||isPointDefenseMissile()))return;
		onEntityHit(new EntityHitResult(other,point));
	}
	public void pointDefenseOrdinaryHit(DefenseContact contact){
		if(defenseSource==null||!isAlive()||contact==null)return;
		if(contact.entityUuid()!=null&&getWorld() instanceof ServerWorld world){
			Entity entity=world.getEntity(contact.entityUuid());
			if(entity==null)entity=com.terminaldetector.drmd.world.contraption.BodySpatialIndex.find(world,contact.entityId()).orElse(null);
			if(entity!=null&&entity.isAlive()&&entity.getUuid().equals(contact.entityUuid()))
				onEntityHit(new MovingBodyHit(entity,new PhysicsTarget.ProjectileHit(contact.tracePoint(),contact.materialPoint())));
			else discard();
		}else if(contact.block()!=null)onBlockHit(new BlockHitResult(contact.tracePoint(),contact.side(),contact.block(),false));
	}

	public void setDamageClass(DamageClass c) {
		this.dmgClass = c;
		setColorRgb(c.r, c.g, c.b);
	}

	public void setDirectDamage(float v) { this.directDamage = v; }
	public void setSplashDamage(float v) { this.splashDamage = v; }
	public void setSplashRadius(float v) { this.splashRadius = v; }
	public void setLifeTicks(int v) { this.lifeTicks = v; }
	public void setFusionPortalCharge(boolean value) { this.fusionPortalCharge = value; }
	public void setGravityStrength(float v) { this.gravityStrength = v; }
	public void setDrag(float v) { this.drag = v; }
	public void setHoming(boolean h, float turn, Entity target) { this.homing = h; this.turnRate = turn; this.homeTarget = target; }

	/**
	 * Fly the owner's aim rather than a target — the Guided Missile.
	 *
	 * <p>Steering to a direction and not to a point is the faithful reading: in Descent the pilot's
	 * stick becomes the missile's stick, so it goes where you are facing, not where you are looking
	 * at. That is what lets it be walked around a corner into a room you cannot see into.
	 */
	public void setPilotGuided(boolean v) { this.pilotGuided = v; }
	public void setPierceCount(int v) { this.pierceCount = v; }
	public void setOnHit(Consumer<WeaponCore.HitContext> cb) { this.onHit = cb; }
	public void setWorldBlast(boolean v) { this.worldBlast = v; }
	public void setDrillCarve(boolean v) { this.drillCarve = v; }

	/** How many {@link ReflectiveBlock} hits this shot can bounce off before it terminates normally. */
	public void setMaxBounces(int v) { this.maxBounces = v; }

	/**
	 * Arm the fuse.
	 *
	 * @param fuse       trigger condition
	 * @param fuseSecs   burn time for {@link com.terminaldetector.drmd.weapon.projectile.FuseType#TIMED}
	 * @param armSecs    dead time after launch during which no fuse can trigger
	 * @param proxRadius trigger radius in blocks for
	 *                   {@link com.terminaldetector.drmd.weapon.projectile.FuseType#PROXIMITY}
	 */
	public void setFuse(com.terminaldetector.drmd.weapon.projectile.FuseType fuse,
						float fuseSecs, float armSecs, float proxRadius) {
		this.fuse = fuse == null ? com.terminaldetector.drmd.weapon.projectile.FuseType.IMPACT : fuse;
		this.fuseTicks = Math.max(0, (int) (fuseSecs * 20));
		this.armTicks = Math.max(0, (int) (armSecs * 20));
		this.proximityRadius = Math.max(0f, proxRadius);
	}

	/** Energy weapons that burn: block hits start a fire focus, entity hits catch light. */
	public void setIgniteOnHit(boolean v) { this.igniteOnHit = v; }

	public com.terminaldetector.drmd.weapon.projectile.FuseType getFuse() { return fuse; }

	/** False while the arming delay is still running — contact and proximity are inert. */
	public boolean isArmed() { return ageTicks >= armTicks; }

	public void setColorRgb(int r, int g, int b) {
		dataTracker.set(COLOR, ((r & 255) << 16) | ((g & 255) << 8) | (b & 255));
	}

	public void setVisualScale(float s) { dataTracker.set(SCALE, s); }
	public void setMeshKind(int kind) { dataTracker.set(MESH, kind); }

	public int getColorRgb() { return dataTracker.get(COLOR); }
	public float getVisualScale() { return dataTracker.get(SCALE); }
	public int getMeshKind() { return dataTracker.get(MESH); }
	public int getColorR() { return (getColorRgb() >> 16) & 255; }
	public int getColorG() { return (getColorRgb() >> 8) & 255; }
	public int getColorB() { return getColorRgb() & 255; }
	public DamageClass getDamageClass() { return dmgClass; }

	public void synchronizeVisualVelocity() {
		if (!getWorld().isClient) {
			Vec3d v = getVelocity();
			dataTracker.set(VISUAL_VELOCITY, new Vector3f((float) v.x, (float) v.y, (float) v.z));
		}
	}

	public Vec3d getVisualVelocity() {
		Vector3f v = dataTracker.get(VISUAL_VELOCITY);
		return new Vec3d(v.x(), v.y(), v.z());
	}

	@Override
	public boolean shouldRender(double squaredDistance) {
		// Entity's default scales range by the tiny collision box (~22 blocks for a shot).
		// Bright projectiles need a visual range independent of their collision dimensions.
		double range = 256 * getRenderDistanceMultiplier();
		return squaredDistance < range * range;
	}

	@Override
	public void tick() {
		super.tick();
		if (getWorld().isClient) {
			setVelocity(getVisualVelocity());
			setPosition(visualPrediction.advance(getPos(), getVelocity()));
			drawTracer();
			return;
		}

		lifeTicks--;
		if (lifeTicks <= 0) {
			discard();
			return;
		}
		ageTicks++;
		if(restoredDefense){
			restoredDefense=false;
			if(!com.terminaldetector.drmd.world.trap.PointDefenseInterception.mayRestore(this))defenseSource=null;
		}
		if(defenseSource!=null){
			com.terminaldetector.drmd.world.trap.PointDefenseInterception.tickRound(this);
			return;
		}

		// Fuses that do not need contact get their chance before the movement trace.
		if (isArmed()) {
			if (fuse == com.terminaldetector.drmd.weapon.projectile.FuseType.TIMED
					&& ageTicks >= armTicks + fuseTicks) {
				detonateInPlace();
				return;
			}
			if (fuse == com.terminaldetector.drmd.weapon.projectile.FuseType.PROXIMITY
					&& proximityRadius > 0 && nearestTriggerWithin(proximityRadius) != null) {
				detonateInPlace();
				return;
			}
		}

		Vec3d vel = getVelocity();

		if (pilotGuided) {
			// No lock to acquire or lose: while the pilot is there to fly it, it turns when they turn.
			// Once they are not — dead, gone, on foot elsewhere — it coasts on its last heading.
			LivingEntity own = getOwnerLiving();
			if (own instanceof PlayerEntity ply) {
				vel = MissileSteering.steer(vel, WeaponCore.aimDir(ply), turnRate);
			}
		} else if (homing) {
			Entity target = homeTarget;
			if (target == null || !target.isAlive()) {
				target = findTarget();
				homeTarget = target;
			}
			if (target != null) {
				vel = MissileSteering.steer(vel,
						(target instanceof PhysicsTarget physics?physics.physicsAimPoint():target.getPos().add(0, target.getHeight() * 0.5, 0)).subtract(getPos()), turnRate);
			}
		}

		if (gravityStrength != 0) {
			LivingEntity own = getOwnerLiving();
			Vec3d gdir = own instanceof PlayerEntity
					? LocalOrientation.gravityDir(own.getUuid())
					: new Vec3d(0, -1, 0);
			vel = vel.add(gdir.multiply(gravityStrength * 0.05));
		}
		if (drag > 0 && vel.lengthSquared() > 1e-6) {
			vel = vel.multiply(Math.max(0, 1.0 - drag * 0.02));
		}
		setVelocity(vel);
		synchronizeVisualVelocity();

		Vec3d next = getPos().add(vel);
		if(isPointDefenseMissile())lastMissileStep=getWorld().getTime();
		HitResult hit = getWorld().raycast(new net.minecraft.world.RaycastContext(
				getPos(), next,
				net.minecraft.world.RaycastContext.ShapeType.COLLIDER,
				net.minecraft.world.RaycastContext.FluidHandling.NONE, this));

		// A mine or an unarmed shell coasts through everything instead of striking it.
		// Portal charging is an energy interaction, independent of the projectile's damage fuse.
		if (fusionPortalCharge && hit instanceof BlockHitResult blockHit
				&& hit.getType() == HitResult.Type.BLOCK
				&& com.terminaldetector.drmd.world.portal.mirror.FusionPortalActivation.isSurface(getWorld().getBlockState(blockHit.getBlockPos()))) {
			onBlockHit(blockHit);
			return;
		}
		boolean contactLive = isArmed()
				&& fuse != com.terminaldetector.drmd.weapon.projectile.FuseType.PROXIMITY
				&& fuse != com.terminaldetector.drmd.weapon.projectile.FuseType.TIMED;
		if (contactLive) {
			EntityHitResult eHit = raycastEntity(getPos(), next);
			boolean entityFirst=eHit!=null&&(hit.getType()==HitResult.Type.MISS
					||eHit.getPos().squaredDistanceTo(getPos())<hit.getPos().squaredDistanceTo(getPos()));
			if(isPointDefenseMissile()&&com.terminaldetector.drmd.world.trap.PointDefenseInterception.intercept(this,getPos(),next,
					entityFirst?eHit:hit.getType()==HitResult.Type.BLOCK?hit:null))return;
			if (entityFirst) {
				onEntityHit(eHit);
				return;
			}
			if (hit.getType() == HitResult.Type.BLOCK) {
				onBlockHit((BlockHitResult) hit);
				return;
			}
		} else if (hit.getType() == HitResult.Type.BLOCK
				&& fuse == com.terminaldetector.drmd.weapon.projectile.FuseType.PROXIMITY) {
			// Mines settle where they land and wait for a customer.
			setPosition(hit.getPos().subtract(getVelocity().normalize().multiply(0.15)));
			setVelocity(Vec3d.ZERO);
			synchronizeVisualVelocity();
			return;
		}
		setPosition(next);
	}

	/**
	 * The visible shot: a bead of light every half block along the ground the round covered this tick.
	 *
	 * <p>This used to drop one particle per tick at the entity's position, which is why the guns
	 * looked like they were firing nothing. A Descent laser moves 6200 source units a second — some
	 * seventy blocks in a tick — so one bead per tick is one dot of light every seventy blocks, and
	 * the round is past the far wall before a second one is drawn. Nothing joins them up, so there is
	 * no bolt on screen at any point in its flight.
	 *
	 * <p>Filling the segment instead gives a continuous streak at any speed, which is what the
	 * original's bolts read as. Spacing is fixed rather than a fixed bead count so a slow rocket does
	 * not get a dense clot of particles around it, and the count is capped so a fast round costs a
	 * bounded amount.
	 */
	private void drawTracer() {
		Vec3d vel = getVelocity();
		float scale = getVisualScale();
		boolean bolt = getMeshKind() == MESH_BOLT;
		Vector3f rgb = new Vector3f(getColorR() / 255f, getColorG() / 255f, getColorB() / 255f);
		float size = (bolt ? 1.5f : 1.15f) * Math.max(0.6f, scale);

		double travel = vel.length();
		if (travel < 1e-3) {
			getWorld().addParticle(new DustParticleEffect(rgb, size), getX(), getY(), getZ(), 0, 0, 0);
			return;
		}

		// Where it was a tick ago: the client has already moved it, so walk back down the velocity.
		Vec3d head = getPos();
		Vec3d back = vel.normalize();
		int beads = (int) Math.min(48, Math.max(2, travel / 0.5));
		for (int i = 0; i < beads; i++) {
			double along = travel * i / (double) beads;
			Vec3d p = head.subtract(back.multiply(along));
			// The head stays brightest; the tail thins out so the streak has a direction.
			float f = size * (1f - 0.55f * i / (float) beads);
			getWorld().addParticle(new DustParticleEffect(rgb, f), p.x, p.y, p.z, 0, 0, 0);
		}
	}

	/** Closest thing the fuse would consider worth going off for, or null. */
	private Entity nearestTriggerWithin(double radius) {
		LivingEntity own = getOwnerLiving();
		Entity best = null;
		double bestDist = radius * radius;
		for (Entity e : com.terminaldetector.drmd.world.contraption.BodySpatialIndex.otherEntities(getWorld(), this, getBoundingBox().expand(radius),
					ent -> (ent instanceof LivingEntity || ent instanceof PhysicsTarget) && ent.isAlive() && ent != own)) {
			double d = (e instanceof PhysicsTarget physics?physics.physicsCentre():e.getPos()).squaredDistanceTo(getPos());
			if (d < bestDist) {
				bestDist = d;
				best = e;
			}
		}
		return best;
	}

	/** Go off where it sits — timed air-burst and proximity trigger both land here. */
	private void detonateInPlace() {
		impactVisual(getPos());
		Entity own = getOwnerEntity();if(own==null)own=this;
		if (own != null) {
			detonate(own, getPos());
		}
		if (onHit != null) {
			onHit.accept(new WeaponCore.HitContext(this, null, getPos(), new Vec3d(0, 1, 0), false));
		}
		discard();
	}

	private Entity findTarget() {
		LivingEntity own = getOwnerLiving();
		double best = 64 * 64;
		Entity found = null;
		for (Entity e : com.terminaldetector.drmd.world.contraption.BodySpatialIndex.otherEntities(getWorld(), this, getBoundingBox().expand(48),
					ent -> (ent instanceof LivingEntity || ent instanceof PhysicsTarget) && ent.isAlive() && ent != own)) {
			double d = (e instanceof PhysicsTarget physics?physics.physicsCentre():e.getPos()).squaredDistanceTo(getPos());
			if (d < best) { best = d; found = e; }
		}
		return found;
	}

    private static final class MovingBodyHit extends EntityHitResult {
        final Vec3d materialPoint;
        MovingBodyHit(Entity body,PhysicsTarget.ProjectileHit hit){super(body,hit.tracePoint());materialPoint=hit.materialPoint();}
    }

	private EntityHitResult raycastEntity(Vec3d start, Vec3d end) {
		LivingEntity own = getOwnerLiving();
		EntityHitResult best = null;
		double bestDist = Double.MAX_VALUE;
		for (Entity e : com.terminaldetector.drmd.world.contraption.BodySpatialIndex.otherEntities(getWorld(), this, getBoundingBox().stretch(end.subtract(start)).expand(0.5),
					ent -> (ent instanceof LivingEntity || ent instanceof PhysicsTarget) && ent.isAlive() && ent != own && !pierced.contains(ent.getId()))) {
			var opt = e instanceof PhysicsTarget target ? target.physicsProjectileRaycast(start,end) : e.getBoundingBox().expand(0.3).raycast(start, end).map(p->new PhysicsTarget.ProjectileHit(p,p));
			if (opt.isPresent()) {
				double d = start.squaredDistanceTo(opt.get().tracePoint());
				if (d < bestDist) {
					bestDist = d;
					best = new MovingBodyHit(e, opt.get());
				}
			}
		}
		return best;
	}

	private void onEntityHit(EntityHitResult hit) {
        Vec3d impact=hit instanceof MovingBodyHit moving?moving.materialPoint:hit.getPos();
		impactVisual(impact);
		Entity own = getOwnerEntity();if(own==null)own=this;
		if (hit.getEntity() instanceof PhysicsTarget target && getVelocity().lengthSquared() > 1.0e-12) {
            target.weaponHit(impact, getVelocity(), directDamage);
		}
		if (own != null) {
			WeaponCore.directDamage(own, hit.getEntity(), directDamage, dmgClass);
			detonate(own, impact);
		}
		if (igniteOnHit) {
			hit.getEntity().setOnFireFor(4);
		}
		if (onHit != null) onHit.accept(new WeaponCore.HitContext(this, hit.getEntity(), impact, getVelocity().negate().normalize(), false));
		pierced.add(hit.getEntity().getId());
		if (pierceCount > 0) {
			pierceCount--;
			setPosition(impact.add(getVelocity().normalize().multiply(0.5)));
		} else {
			discard();
		}
	}

	/**
	 * A mirror block ricochet is resolved here rather than in {@link #tick()}: only the terminal
	 * path needs to change, and {@code tick()} already just calls this and returns, so a shot that
	 * survives is automatically picked up by next tick's raycast with no other change to the movement
	 * logic every other weapon in the mod shares.
	 *
	 * <p>Detonation/melt/ignite FX and the {@code onHit} callback are deliberately skipped on a
	 * bounce — those are terminal-impact effects, wrong to fire against a surface the shot is
	 * continuing past, and no weapon's {@code onHit} callback expects more than one call per shot.
	 * Explosive-class hits still detonate on contact regardless of the struck block: a rocket
	 * ricocheting through a mirror would read as a bug, not a feature.
	 *
	 * <p>Resolves at most one bounce per tick — a shot travelling far enough in one tick to reach a
	 * second mirror before the tick ends instead resumes at full speed from the first bounce point
	 * next tick. A correct fix means looping the raycast within {@code tick()}'s own movement
	 * resolution, which is a materially larger change touching every weapon's shared movement path;
	 * deliberately deferred rather than done here.
	 */
	private void onBlockHit(BlockHitResult hit) {
		if (fusionPortalCharge && getWorld() instanceof ServerWorld sw
				&& com.terminaldetector.drmd.world.portal.mirror.FusionPortalActivation.isSurface(sw.getBlockState(hit.getBlockPos()))) {
			com.terminaldetector.drmd.world.portal.mirror.FusionPortalActivation.activate(sw,hit.getBlockPos(),hit.getSide(),getOwnerLiving());
			discard();
			return;
		}
		boolean explosive = worldBlast || (splashRadius > 0 && dmgClass == DamageClass.EXPLOSIVE);
		BlockState hitState = getWorld().getBlockState(hit.getBlockPos());
        if(explosive && getWorld() instanceof ServerWorld world)
            com.terminaldetector.drmd.world.contraption.StructureCollapse.rocketCut(world,hit.getBlockPos(),hit.getPos(),getVelocity(),directDamage);
		if (!explosive && bounceCount < maxBounces && hitState.getBlock() instanceof ReflectiveBlock rb) {
			bounceCount++;
			Vec3d normal = rb.getReflectionNormal(hitState);
			setVelocity(MirrorReflection.reflect(getVelocity(), normal));
			synchronizeVisualVelocity();
			// Nudge off the surface so this tick doesn't immediately re-resolve the same face at zero
			// distance — same spirit as onEntityHit's pierce reposition above.
			setPosition(hit.getPos().add(normal.multiply(0.05)));
			if (getWorld() instanceof ServerWorld sw) {
				sw.spawnParticles(new DustParticleEffect(new Vector3f(0.7f, 0.9f, 1f), 0.8f),
						hit.getPos().x, hit.getPos().y, hit.getPos().z, 6, 0.05, 0.05, 0.05, 0.02);
			}
			return;
		}

		Entity own = getOwnerEntity();if(own==null)own=this;
		if (own != null && getWorld() instanceof ServerWorld sw) {
			impactVisual(hit.getPos().add(Vec3d.of(hit.getSide().getVector()).multiply(.03)));
			detonate(own, hit.getPos());
			if (drillCarve) {
				WeaponFx.drillCarve(sw, hit.getBlockPos(), own);
			} else if (dmgClass == DamageClass.ENERGY || dmgClass == DamageClass.EXOTIC) {
				WeaponFx.melt(sw, hit.getBlockPos(), splashRadius > 1.5f ? 2 : 1, own);
			}
			if (igniteOnHit) {
				// Seed the shared fire sim on the struck face; it handles spread and smoke.
				BlockPos face = hit.getBlockPos().offset(hit.getSide());
				com.terminaldetector.drmd.world.fire.FireSystem.ignite(sw, face, 3);
			}
		}
		if (onHit != null) onHit.accept(new WeaponCore.HitContext(this, null, hit.getPos(), Vec3d.of(hit.getSide().getVector()), true));
		discard();
	}

	private void detonate(Entity own, Vec3d pos) {
		if (!(getWorld() instanceof ServerWorld sw)) return;
		if (splashRadius <= 0) return;
		float splash = splashDamage > 0 ? splashDamage : directDamage * 0.5f;
		if (worldBlast || dmgClass == DamageClass.EXPLOSIVE) {
			boolean crater = worldBlast || splashRadius >= 3.5f;
			WeaponFx.explode(own, sw, pos, splash, splashRadius, dmgClass, crater);
		} else {
			WeaponCore.splashDamage(own, sw, pos, splash, splashRadius, dmgClass);
		}
	}

	private void impactVisual(Vec3d pos) {
		if (getWorld() instanceof ServerWorld world)
			com.terminaldetector.drmd.network.ModNetworking.shotFx(world, pos, getColorRgb(), getVisualScale(), true);
	}

	@Override
	protected void initDataTracker(DataTracker.Builder builder) {
		builder.add(COLOR, 0xB4DCFF);
		builder.add(SCALE, 1f);
		builder.add(MESH, MESH_BOLT);
		builder.add(VISUAL_VELOCITY, new Vector3f());
	}

	@Override
	protected void readCustomDataFromNbt(NbtCompound nbt) {
		lifeTicks = nbt.getInt("life");
		directDamage = nbt.getFloat("dmg");
		splashDamage = nbt.getFloat("splash");
		splashRadius = nbt.getFloat("radius");
		dmgClass = DamageClass.fromId(nbt.getString("class"));
		worldBlast = nbt.getBoolean("blast");
		fusionPortalCharge = nbt.getBoolean("fusionPortalCharge");
		ownerUuid = nbt.containsUuid("owner") ? nbt.getUuid("owner") : null;
		owner = null;
		drillCarve = nbt.getBoolean("drill");
		setVisualScale(nbt.contains("scale") ? nbt.getFloat("scale") : 1f);
		setMeshKind(nbt.getInt("mesh"));
		setColorRgb(dmgClass.r, dmgClass.g, dmgClass.b);
		defenseSource=null;
		restoredDefense=false;
		if(ownerUuid==null&&dmgClass==DamageClass.KINETIC&&nbt.contains("pdAnchor")&&nbt.containsUuid("pdTarget")){
			float savedGravity=nbt.getFloat("pdGravity"),savedDrag=nbt.getFloat("pdDrag");
			if(Float.isFinite(savedGravity)&&savedGravity>=0&&savedGravity<=1&&Float.isFinite(savedDrag)&&savedDrag>=0&&savedDrag<=1){
				gravityStrength=savedGravity;drag=savedDrag;lifeTicks=Math.min(lifeTicks,10);
				long now=getWorld().getTime();defenseSource=new DefenseSource(BlockPos.fromLong(nbt.getLong("pdAnchor")),nbt.getUuid("pdTarget"),now,now+1);
				restoredDefense=true;
				int color=nbt.getInt("pdColor");setColorRgb((color>>16)&255,(color>>8)&255,color&255);
			}
		}
	}

	@Override
	protected void writeCustomDataToNbt(NbtCompound nbt) {
		nbt.putInt("life", lifeTicks);
		nbt.putFloat("dmg", directDamage);
		nbt.putFloat("splash", splashDamage);
		nbt.putFloat("radius", splashRadius);
		nbt.putString("class", dmgClass.id);
		nbt.putBoolean("blast", worldBlast);
		nbt.putBoolean("fusionPortalCharge", fusionPortalCharge);
		if (ownerUuid != null) nbt.putUuid("owner", ownerUuid);
		nbt.putBoolean("drill", drillCarve);
		nbt.putFloat("scale", getVisualScale());
		nbt.putInt("mesh", getMeshKind());
		if(defenseSource!=null){
			nbt.putLong("pdAnchor",defenseSource.anchor().asLong());nbt.putUuid("pdTarget",defenseSource.target());
			nbt.putFloat("pdGravity",gravityStrength);nbt.putFloat("pdDrag",drag);nbt.putInt("pdColor",getColorRgb());
		}
	}

	@Override
	public void onSpawnPacket(EntitySpawnS2CPacket packet) {
		super.onSpawnPacket(packet);
		visualPrediction.accept(getPos());
	}

	@Override
	public void updateTrackedPositionAndAngles(double x, double y, double z, float yaw, float pitch,
			int interpolationSteps) {
		super.updateTrackedPositionAndAngles(x, y, z, yaw, pitch, interpolationSteps);
		visualPrediction.accept(new Vec3d(x, y, z));
	}
}
