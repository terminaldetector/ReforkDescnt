from pathlib import Path
import hashlib,json,os,subprocess,time,shutil

ROOT=Path(__file__).resolve().parents[2]
SOURCE='83a12773253ca01fa2f9518bc4297a25fde8c675'
stage=ROOT/'work/siege-plan/first-positive-83a1277'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==SOURCE
assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=ROOT,text=True)
assert not subprocess.check_output(['git','ls-files','--others','--exclude-standard','--','src','scripts'],cwd=ROOT,text=True)
assert not (ROOT/'build/gametest/world').exists();assert not stage.exists();stage.mkdir()
files=['work/siege-plan/focus-positive.init.gradle','build.gradle','gradle.properties',
       'docs/v8/SIEGE_PLAN_PROTOCOL_V1_2026-11-17.md','docs/v8/SIEGE_PLAN_INTENT_2026-11-17.md',
       'src/main/java/com/terminaldetector/drmd/world/threat/SiegePlan.java',
       'src/main/java/com/terminaldetector/drmd/world/threat/SiegePlans.java',
       'src/main/java/com/terminaldetector/drmd/world/threat/SurvivalThreatState.java',
       'src/main/java/com/terminaldetector/drmd/world/threat/ThreatProgress.java',
       'src/main/java/com/terminaldetector/drmd/world/threat/SurvivalThreatDirector.java',
       'src/test/java/com/terminaldetector/drmd/world/threat/SiegePlanTest.java',
       'src/test/java/com/terminaldetector/drmd/world/threat/ThreatProgressTest.java',
       'src/gametest/java/com/terminaldetector/drmd/world/threat/SiegePlanCodecBaselineGameTests.java',
       'src/gametest/java/com/terminaldetector/drmd/world/threat/SiegePlanStateGameTests.java',
       'src/gametest/java/com/terminaldetector/drmd/world/threat/SurvivalThreatGameTests.java']
hashes={n:hashlib.sha256((ROOT/n).read_bytes()).hexdigest() for n in files}
build_paths=subprocess.check_output(['git','ls-files','-z','--','src','scripts','build.gradle','gradle.properties','gradle','gradlew','gradlew.bat'],cwd=ROOT).decode().split('\0')
build_hashes={n:hashlib.sha256((ROOT/n).read_bytes()).hexdigest() for n in build_paths if n}
(stage/'source-build-inputs.json').write_text(json.dumps({'source':SOURCE,'sha256ByFile':build_hashes},indent=2)+'\n')
inputs={'source':SOURCE,'startTimeNs':time.time_ns(),'executingRunnerSha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'sha256ByFile':hashes,'scope':'FIRST22units(13new+9old) then ifPASS13stockGT(raw4+state4+old5). Optionalolddca4baselineUNEXECUTED. Non-autostart protocol/persistence/isolation only; no liveSIEGE/native/JAR acceptance.'}
(stage/'inputs.json').write_text(json.dumps(inputs,indent=2)+'\n');(stage/'executed-runner.py').write_bytes(Path(__file__).read_bytes())
for n in files:
    p=stage/'initial-source'/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((ROOT/n).read_bytes())
env=dict(os.environ,JAVA_HOME='/workspace/jdk21-complete',GRADLE_USER_HOME='/workspace/.gradle');env['PATH']='/workspace/jdk21-complete/bin:'+env.get('PATH','')
commands=[('unit',['./gradlew','test','--tests','com.terminaldetector.drmd.world.threat.SiegePlanTest','--tests','com.terminaldetector.drmd.world.threat.ThreatProgressTest','--offline','--no-daemon']),
          ('gametest',['./gradlew','runGametest','--offline','--no-daemon','-I','work/siege-plan/focus-positive.init.gradle'])]
for phase,command in commands:
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==SOURCE
    assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=ROOT,text=True)
    assert not subprocess.check_output(['git','ls-files','--others','--exclude-standard','--','src','scripts'],cwd=ROOT,text=True)
    assert all(hashlib.sha256((ROOT/n).read_bytes()).hexdigest()==h for n,h in dict(build_hashes,**hashes).items())
    reports=[ROOT/'build/test-results/test'/('TEST-com.terminaldetector.drmd.world.threat.'+n+'.xml') for n in ['SiegePlanTest','ThreatProgressTest']] if phase=='unit' else [ROOT/'build/gametest/reports/gametest-results.xml']
    for p in reports:
        if p.exists():p.unlink()
    if phase=='gametest':assert not (stage/'runtime-proof').exists()
    started=time.time_ns();(stage/(phase+'-start.json')).write_text(json.dumps({'source':SOURCE,'startTimeNs':started,'command':command},indent=2)+'\n')
    with (stage/(phase+'.log')).open('wb') as output:
        child=subprocess.Popen(command,cwd=ROOT,env=env,stdout=output,stderr=subprocess.STDOUT);code=child.wait()
    # Record actual child close BEFORE reports, provenance postchecks or cleanup.
    (stage/(phase+'.exit')).write_text(str(code)+'\n')
    (stage/(phase+'-exit.json')).write_text(json.dumps({'source':SOURCE,'pid':child.pid,'exit':code,'closedTimeNs':time.time_ns()},indent=2)+'\n')
    print(phase+' FIRST CLOSED exit='+str(code),flush=True)
    found=[p for p in reports if p.exists()]
    if found:
        target=stage/(phase+'-xml');target.mkdir()
        for p in found:shutil.copyfile(p,target/p.name)
    else:(stage/(phase+'-NO_XML.txt')).write_text('No fresh report after first actual child close; retain raw compiler/runtime log.\n')
    manifest=ROOT/'build/resources/gametest/fabric.mod.json'
    if phase=='gametest' and manifest.exists() and manifest.stat().st_mtime_ns>=started:shutil.copyfile(manifest,stage/'actual-focused-manifest.json')
    if phase=='gametest':
        artifacts={p.relative_to(stage).as_posix():{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in (stage/'runtime-proof').rglob('*') if p.is_file()} if (stage/'runtime-proof').exists() else {}
        (stage/'runtime-proof-manifest.json').write_text(json.dumps(artifacts,indent=2)+'\n')
    (stage/(phase+'-source-unchanged.json')).write_text(json.dumps({'source':SOURCE,'allInputsStillMatch':all(hashlib.sha256((ROOT/n).read_bytes()).hexdigest()==h for n,h in dict(build_hashes,**hashes).items())},indent=2)+'\n')
    if code:raise SystemExit(code)
    if not all(hashlib.sha256((ROOT/n).read_bytes()).hexdigest()==h for n,h in dict(build_hashes,**hashes).items()):raise SystemExit(98)
