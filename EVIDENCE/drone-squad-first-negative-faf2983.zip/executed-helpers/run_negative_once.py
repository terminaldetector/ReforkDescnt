from pathlib import Path
import hashlib,json,os,subprocess,time,sys
ROOT=Path(__file__).resolve().parents[2]
SOURCE='faf2983528d26bcede9f1e0907db1c6b00b07b8f'
stage=ROOT/'work/drone-squad/first-negative-faf2983'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==SOURCE
assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=ROOT,text=True)
assert not (ROOT/'build/gametest/world').exists(),'previous own world must already be preserved/reclaimed'
stage.mkdir()
command=['./gradlew','runGametest','--offline','--no-daemon','-I','work/drone-squad/focus.init.gradle']
files=['work/drone-squad/focus.init.gradle','src/gametest/java/com/terminaldetector/drmd/DroneSquadTaskGameTests.java','src/main/java/com/terminaldetector/drmd/entity/DroneEntity.java','src/main/java/com/terminaldetector/drmd/ai/DroneSwarmAi.java','src/main/java/com/terminaldetector/drmd/ai/HostileEnvironment.java','docs/v8/DRONE_SQUAD_INVESTIGATION_CONTRACT_2026-11-17.md','src/gametest/resources/fabric.mod.json','build.gradle','gradle.properties']
start=time.time_ns()
inputs={'source':SOURCE,'startedNs':start,'trackedClean':True,'command':command,'scope':'two stock natural-AI squad baseline cases; no manual target/mailbox or entity ticks; feature unimplemented','javaHome':'/workspace/jdk21-complete','gradleUserHome':'/workspace/.gradle','executingRunnerSha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'sha256ByFile':{name:hashlib.sha256((ROOT/name).read_bytes()).hexdigest() for name in files},'preexistingReports':{str(q.relative_to(ROOT)):hashlib.sha256(q.read_bytes()).hexdigest() for q in (ROOT/'build/gametest/reports').rglob('*') if q.is_file()}}
(stage/'inputs.json').write_text(json.dumps(inputs,indent=2)+'\n')
(stage/'executed-runner.py').write_bytes(Path(__file__).read_bytes())
for name in files:
 target=stage/'initial-source'/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes((ROOT/name).read_bytes())
env=dict(os.environ,JAVA_HOME='/workspace/jdk21-complete',GRADLE_USER_HOME='/workspace/.gradle');env['PATH']='/workspace/jdk21-complete/bin:'+env.get('PATH','')
with (stage/'negative.log').open('wb') as output:
 child=subprocess.Popen(command,cwd=ROOT,env=env,stdout=output,stderr=subprocess.STDOUT)
 code=child.wait()
(stage/'negative.exit').write_text(str(code)+'\n') # immediate first-close receipt
(stage/'exit.json').write_text(json.dumps({'source':SOURCE,'pid':child.pid,'exit':code,'closedNs':time.time_ns()},indent=2)+'\n')
print('FIRST negative CLOSED exit='+str(code),flush=True)
raise SystemExit(code)
