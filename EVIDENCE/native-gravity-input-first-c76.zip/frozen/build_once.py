from pathlib import Path
import hashlib,json,os,subprocess,sys,zipfile
ROOT=Path(__file__).resolve().parents[3]
EXPECTED='c76c984984b4a601132e9566fcabf64fd3b0f916'
at=Path(sys.argv[1]).resolve()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def head():return subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
assert head()==EXPECTED
assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=ROOT,text=True)
files=[ROOT/'build.gradle',ROOT/'gradle.properties']+list((ROOT/'src/cubiccheck/java/com/terminaldetector/drmd/gate').glob('*GravityInput*java'))+list((ROOT/'src/cubiccheck/java/com/terminaldetector/drmd/gate/mixin').glob('GravityInput*java'))+[ROOT/'src/cubiccheck/resources/drmd.cubiccheck.mixins.json']
helpers=sorted(Path(__file__).resolve().parent.glob('*'))
command=['./gradlew','remapJar','remapCubiccheckJar','--offline','--no-daemon']
inputs={'source':EXPECTED,'trackedClean':True,'command':command,'javaHome':'/workspace/jdk21-complete','gradleUserHome':'/workspace/.gradle','sha256ByFile':{str(p.relative_to(ROOT)):sha(p) for p in files},'executingHelpers':{str(p):sha(p) for p in helpers if p.is_file()}}
(at/'compile-inputs.json').write_text(json.dumps(inputs,indent=2)+'\n')
env=dict(os.environ,JAVA_HOME='/workspace/jdk21-complete',GRADLE_USER_HOME='/workspace/.gradle');env['PATH']='/workspace/jdk21-complete/bin:'+env.get('PATH','')
with (at/'compile.log').open('wb') as output:result=subprocess.run(command,cwd=ROOT,env=env,stdout=output,stderr=subprocess.STDOUT)
(at/'compile.exit').write_text(str(result.returncode)+'\n') # receipt before source/JAR postchecks
if result.returncode:raise SystemExit(result.returncode)
assert head()==EXPECTED
assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=ROOT,text=True)
props={}
for line in (ROOT/'gradle.properties').read_text().splitlines():
 if '=' in line and not line.lstrip().startswith('#'):
  k,v=line.split('=',1);props[k.strip()]=v.strip()
base=props['archives_base_name']+'-'+props['mod_version'];jars=[ROOT/'build/libs'/(base+'.jar'),ROOT/'build/libs'/(base+'-cubiccheck.jar')]
for jar in jars:
 with zipfile.ZipFile(jar) as z:assert z.testzip() is None
with zipfile.ZipFile(jars[1]) as z:
 assert 'com/terminaldetector/drmd/gate/NativeGravityInputRouteCheck.class' in z.namelist()
 data=json.loads(z.read('drmd.cubiccheck.mixins.json'))
 for name in ['GravityInputRouteBootstrapProbe','GravityInputTriggerProbe','GravityInputItemUseProbe','GravityInputSelectionProbe']:assert name in data['client']
(at/'verified-build.json').write_text(json.dumps({'source':EXPECTED,'postSource':head(),'jars':{str(p):sha(p) for p in jars}},indent=2)+'\n')
print('First compile/build closed successfully; source and two candidate JAR hashes preserved')
