#!/usr/bin/env bash
set -euo pipefail
frozen_dir="$(cd "$(dirname "$0")" && pwd)"
task_root="$(cd "$frozen_dir/../../.." && pwd)"
cd "$task_root"
stage_dir="$task_root/work/native-gravity-input/run-c76-first"
mkdir "$stage_dir"
python3 "$frozen_dir/build_once.py" "$stage_dir"
set +e
python3 "$frozen_dir/prepare_once.py" "$stage_dir" > "$stage_dir/prepare.log" 2>&1
prepare_code=$?
set -e
printf '%s\n' "$prepare_code" > "$stage_dir/prepare.exit"
if [ "$prepare_code" -ne 0 ]; then exit "$prepare_code"; fi
: > "$stage_dir/display.txt"
/workspace/xvfb/usr/bin/Xvfb -displayfd 3 -screen 0 1280x1024x24 3> "$stage_dir/display.txt" > "$stage_dir/xvfb.log" 2>&1 &
display_pid=$!
trap 'kill "$display_pid" 2>/dev/null || true; wait "$display_pid" 2>/dev/null || true' EXIT
for attempt in {1..100}; do kill -0 "$display_pid"; if [ -s "$stage_dir/display.txt" ]; then break; fi; sleep .1; done
test -s "$stage_dir/display.txt"
read -r display_number < "$stage_dir/display.txt"
set +e
DISPLAY=:$display_number LIBGL_ALWAYS_SOFTWARE=1 MESA_GL_VERSION_OVERRIDE=3.2 MESA_GLSL_VERSION_OVERRIDE=150 python3 "$frozen_dir/native_child_once.py" "$stage_dir"
native_code=$?
set -e
printf '%s\n' "$native_code" > "$stage_dir/native-wrapper.exit"
if [ "$native_code" -ne 0 ]; then exit "$native_code"; fi
python3 "$frozen_dir/postcheck_once.py" "$stage_dir"
