from pathlib import Path
import hashlib,json,sys
ROOT=Path(__file__).resolve().parents[3];at=Path(sys.argv[1]).resolve();runtime=ROOT/'build/gravity-input-first-c76/gravity-inputcheck'
assert (at/'native-child.exit').read_text().strip()=='0'
started=json.loads((at/'native-start.json').read_text())['startTimeNs'];marker=runtime/'gravity-input-route-ok.json'
assert marker.stat().st_mtime_ns>=started
value=json.loads(marker.read_text());assert value['status']=='PASS' and value['nativeCubic'] and len(value['scenes'])==6 and value['maxLiveBodies']<=4
assert not value['observerDirectItemUse'] and not value['observerDirectTriggerReceive'] and not value['observerEnergyWrites']
assert {s['scene'] for s in value['scenes']}=={'ordinary-swarm-lmb','ordinary-rail-rmb','ordinary-shift-lmb','flight-swarm-lmb','flight-rail-rmb','flight-shift-rmb'}
for scene in value['scenes']:
 assert scene['ownedFieldsRetired'] and scene['normalHoldTicks']>=8
 assert scene['screenClickPackets']>=2 if scene['flight'] else scene['hotbarPackets']>0
assert not list((runtime/'crash-reports').glob('*.txt'))
assert len(value['frames'])==12
for frame in value['frames']:assert (runtime/frame).is_file() and (runtime/frame).stat().st_mtime_ns>=started
(at/'postcheck.json').write_text(json.dumps({'source':'c76c984984b4a601132e9566fcabf64fd3b0f916','status':'PASS','sixActualNativeInputTransactions':True,'markerSha256':hashlib.sha256(marker.read_bytes()).hexdigest(),'freshFrameSha256':{p:hashlib.sha256((runtime/p).read_bytes()).hexdigest() for p in value['frames']}},indent=2)+'\n')
print('Fresh six-transaction native input marker and twelve world frames verified')
