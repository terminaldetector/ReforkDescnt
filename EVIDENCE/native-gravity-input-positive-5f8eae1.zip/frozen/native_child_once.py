from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys,time
ROOT=Path(__file__).resolve().parents[3];at=Path(sys.argv[1]).resolve();runtime=ROOT/'build/gravity-input-first-5f8/gravity-inputcheck'
argv=json.loads((runtime/'launch.json').read_text());started=time.time_ns()
for marker in ['gravity-input-route-ok.json','gravity-input-route-failed.json']:assert not (runtime/marker).exists()
(at/'native-start.json').write_text(json.dumps({'source':'5f8eae13817256fdda4aebad7a57383877feaae5','startTimeNs':started,'executingHelper':str(Path(__file__).resolve()),'helperSha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'externalTimeoutSeconds':360,'terminateGraceSeconds':15,'observerWallSeconds':300,'runtime':str(runtime),'argv':argv},indent=2)+'\n')
with (at/'native.log').open('wb') as output:
 child=subprocess.Popen(argv,cwd=runtime,stdout=output,stderr=subprocess.STDOUT)
 timed_out=False
 try:code=child.wait(timeout=360)
 except subprocess.TimeoutExpired:
  timed_out=True;child.terminate()
  try:code=child.wait(timeout=15)
  except subprocess.TimeoutExpired:child.kill();code=child.wait()
(at/'native-child.exit').write_text(str(code)+'\n') # FIRST receipt, before checks and Xvfb cleanup
(at/'native-exit.json').write_text(json.dumps({'pid':child.pid,'childExit':code,'timedOut':timed_out,'endTimeNs':time.time_ns()},indent=2)+'\n')
print('Native child CLOSED exit='+str(code)+' timedOut='+str(timed_out),flush=True)
raise SystemExit(124 if timed_out else (code if code>=0 else 128-code))
