from pathlib import Path
import hashlib,json,os,subprocess,sys,zipfile
ROOT=Path(__file__).resolve().parents[3]
EXPECTED='5f8eae13817256fdda4aebad7a57383877feaae5'
at=Path(sys.argv[1]).resolve()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def head():return subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
assert head()==EXPECTED
assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=ROOT,text=True)
files=[ROOT/'build.gradle',ROOT/'gradle.properties',ROOT/'src/main/java/com/terminaldetector/drmd/inventory/DroneArsenal.java',ROOT/'src/gametest/java/com/terminaldetector/drmd/DroneTriggerEdgeGameTests.java']+list((ROOT/'src/cubiccheck/java/com/terminaldetector/drmd/gate').glob('*GravityInput*java'))+list((ROOT/'src/cubiccheck/java/com/terminaldetector/drmd/gate/mixin').glob('GravityInput*java'))+[ROOT/'src/cubiccheck/resources/drmd.cubiccheck.mixins.json']
helpers=sorted(Path(__file__).resolve().parent.glob('*'))
command=['./gradlew','remapJar','remapCubiccheckJar','--offline','--no-daemon']
inputs={'source':EXPECTED,'trackedClean':True,'command':command,'javaHome':'/workspace/jdk21-complete','gradleUserHome':'/workspace/.gradle','sha256ByFile':{str(p.relative_to(ROOT)):sha(p) for p in files},'executingHelpers':{str(p):sha(p) for p in helpers if p.is_file()}}
(at/'compile-inputs.json').write_text(json.dumps(inputs,indent=2)+'\n')
env=dict(os.environ,JAVA_HOME='/workspace/jdk21-complete',GRADLE_USER_HOME='/workspace/.gradle');env['PATH']='/workspace/jdk21-complete/bin:'+env.get('PATH','')
with (at/'compile.log').open('wb') as output:result=subprocess.run(command,cwd=ROOT,env=env,stdout=output,stderr=subprocess.STDOUT)
(at/'compile.exit').write_text(str(result.returncode)+'\n') # receipt before source/JAR postchecks
if result.returncode:raise SystemExit(result.returncode)
assert head()==EXPECTED
assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=ROOT,text=True)
props={}
for line in (ROOT/'gradle.properties').read_text().splitlines():
 if '=' in line and not line.lstrip().startswith('#'):
  k,v=line.split('=',1);props[k.strip()]=v.strip()
base=props['archives_base_name']+'-'+props['mod_version'];jars=[ROOT/'build/libs'/(base+'.jar'),ROOT/'build/libs'/(base+'-cubiccheck.jar')]
for jar in jars:
 with zipfile.ZipFile(jar) as z:assert z.testzip() is None
with zipfile.ZipFile(jars[1]) as z:
 assert 'com/terminaldetector/drmd/gate/NativeGravityInputRouteCheck.class' in z.namelist()
 data=json.loads(z.read('drmd.cubiccheck.mixins.json'))
 for name in ['GravityInputRouteBootstrapProbe','GravityInputTriggerProbe','GravityInputItemUseProbe','GravityInputSelectionProbe']:assert name in data['client']
# Check that the observer refmap resolves both required vanilla-use injections
# to the actual remapped override BEFORE granting the single native attempt.
with zipfile.ZipFile(jars[1]) as z:
 refmap=json.loads(z.read('cubiccheck-drmd-6dof-refmap.json'))
 owner='com/terminaldetector/drmd/gate/mixin/GravityInputItemUseProbe'
 selector='use(Lnet/minecraft/world/World;Lnet/minecraft/entity/player/PlayerEntity;Lnet/minecraft/util/Hand;)Lnet/minecraft/util/TypedActionResult;'
 mapped=refmap['mappings'][owner][selector]
 expected='method_7836(Lnet/minecraft/class_1937;Lnet/minecraft/class_1657;Lnet/minecraft/class_1268;)Lnet/minecraft/class_1271;'
 assert mapped.endswith(expected),(selector,mapped)
 observer_class=z.read(owner+'.class')
 assert b'require' in observer_class and b'(Lnet/minecraft/class_1937;Lnet/minecraft/class_1657;Lnet/minecraft/class_1268;' in observer_class
with zipfile.ZipFile(jars[0]) as z:
 target_class=z.read('com/terminaldetector/drmd/weapon/items/DescentWeaponItem.class')
 assert b'method_7836' in target_class and b'(Lnet/minecraft/class_1937;Lnet/minecraft/class_1657;Lnet/minecraft/class_1268;)Lnet/minecraft/class_1271;' in target_class
(at/'observer-mapping.json').write_text(json.dumps({'source':EXPECTED,'selector':selector,'refmapValue':mapped,'expectedTargetMethod':expected,'requiredInjections':2,'staticRemappedEntryAndRefmapVerified':True},indent=2)+'\n')
(at/'verified-build.json').write_text(json.dumps({'source':EXPECTED,'postSource':head(),'jars':{str(p):sha(p) for p in jars}},indent=2)+'\n')
print('First compile/build closed successfully; source and two candidate JAR hashes preserved')
