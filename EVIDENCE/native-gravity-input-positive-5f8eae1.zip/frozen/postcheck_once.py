from pathlib import Path
import hashlib,json,sys
ROOT=Path(__file__).resolve().parents[3];at=Path(sys.argv[1]).resolve();runtime=ROOT/'build/gravity-input-first-5f8/gravity-inputcheck'
assert (at/'native-child.exit').read_text().strip()=='0'
started=json.loads((at/'native-start.json').read_text())['startTimeNs'];marker=runtime/'gravity-input-route-ok.json'
assert marker.stat().st_mtime_ns>=started
value=json.loads(marker.read_text());assert value['status']=='PASS' and value['nativeCubic'] and len(value['scenes'])==6 and value['maxLiveBodies']<=4
assert not value['observerDirectItemUse'] and not value['observerDirectTriggerReceive'] and not value['observerEnergyWrites']
assert {s['scene'] for s in value['scenes']}=={'ordinary-swarm-lmb','ordinary-rail-rmb','ordinary-shift-lmb','flight-swarm-lmb','flight-rail-rmb','flight-shift-rmb'}
for scene in value['scenes']:
 assert scene['ownedFieldsRetired'] and scene['normalHoldTicks']>=8
 assert scene['screenClickPackets']>=2 if scene['flight'] else scene['hotbarPackets']>0
# Paired receipts prove the original one-client-tick key pulses, including
# release before a legitimately deferred server Item.use, without direct APIs.
for phase,scene in enumerate(value['scenes']):
 expected_count=4 if phase%3==0 else 1
 capture_cost=[18,16,20][phase%3];throw_cost=[10,12,18][phase%3]
 assert scene['normalHoldTicks']==scene['throw']['tick']-scene['capture']['tick']>=8
 for pair_key,use_key,cost in [('capturePulse','capture',capture_cost),('throwPulse','throw',throw_cost)]:
  pair=scene[pair_key];use=scene[use_key];press=pair['press'];release=pair['release'];latest=pair['latest']
  assert pair['baseline']<press['sequence']<use['sequence']
  assert press['sequence']<release['sequence']<=latest['sequence']
  assert press['scene']==release['scene']==latest['scene']==use['scene']==phase
  assert press['eligible'] and release['eligible'] and latest['eligible']
  assert press['mask']==scene['mask'] and release['mask']==latest['mask']==0
  assert press['tick']<=use['tick'] and release['tick']>=press['tick']
  assert use['accepted'] and abs(use['before']['energy']-use['after']['energy']-cost)<1e-5
  if scene['flight']:assert press['selectedSlot']==8 and press['hand']=='minecraft:air'
  else:assert press['hand']==use['before']['item']
 assert scene['capture']['before']['grab']['count']==0 and scene['capture']['after']['grab']['count']==expected_count
 assert scene['throw']['before']['grab']['count']==expected_count and scene['throw']['after']['grab']['count']==0
 assert {t['id'] for t in scene['capture']['after']['targets']}=={t['id'] for t in scene['throw']['after']['targets']}
assert not list((runtime/'crash-reports').glob('*.txt'))
assert len(value['frames'])==12
for frame in value['frames']:assert (runtime/frame).is_file() and (runtime/frame).stat().st_mtime_ns>=started
(at/'postcheck.json').write_text(json.dumps({'source':'5f8eae13817256fdda4aebad7a57383877feaae5','status':'PASS','sixActualNativeInputTransactions':True,'markerSha256':hashlib.sha256(marker.read_bytes()).hexdigest(),'freshFrameSha256':{p:hashlib.sha256((runtime/p).read_bytes()).hexdigest() for p in value['frames']}},indent=2)+'\n')
print('Fresh six-transaction native input marker and twelve world frames verified')
