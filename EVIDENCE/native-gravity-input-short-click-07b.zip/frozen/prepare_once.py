from pathlib import Path
import hashlib,importlib.util,json,os,sys,zipfile
ROOT=Path(__file__).resolve().parents[3]
at=Path(sys.argv[1]).resolve();runtime=ROOT/'build/gravity-input-first-07b/gravity-inputcheck'
assert not runtime.exists(),'fresh unique runtime required; never overwrite a previous run'
receipt=json.loads((at/'verified-build.json').read_text());assert receipt['source']=='07b2fa8a999c66bfb38893e276592c0dd959a4ca'
spec=importlib.util.spec_from_file_location('official_native_stager',ROOT/'scripts/v5/prepare_cubic_client.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
original=module.verified_copy
def immutable_library(source,target,expected_sha1=None):
 if 'libraries' in target.parts:
  assert source.is_file() and (expected_sha1 is None or module.digest(source,'sha1')==expected_sha1)
  target.parent.mkdir(parents=True,exist_ok=True);os.link(source,target);assert module.digest(source)==module.digest(target);return target
 return original(source,target,expected_sha1)
module.verified_copy=immutable_library
jars=list(receipt['jars']);main=next(p for p in jars if not p.endswith('-cubiccheck.jar'));gate=next(p for p in jars if p.endswith('-cubiccheck.jar'))
sys.argv=['prepare_cubic_client.py','--server-runtime','/workspace/ungravity-v5/world/build/cubic-seed2-gate','--runtime',str(runtime),'--drmd',main,'--gate',gate,'--bcc','/workspace/Refork-audit/work/master-v5/upstream/bettercubicchunks-fabric-0.1.1+mc1.21.1.jar','--api','/workspace/.gradle/caches/modules-2/files-2.1/net.fabricmc.fabric-api/fabric-api/0.116.15+1.21.1/d25c793833a90cc028c9a61bc4546cd578a70ce1/fabric-api-0.116.15+1.21.1.jar','--java','/workspace/jdk21-complete/bin/java','--copy-test-world']
module.main()
manifest=json.loads((runtime/'inputs.json').read_text())
for path,digest in receipt['jars'].items():assert module.digest(runtime/'mods'/Path(path).name)==digest
# Reuse only the verified Minecraft-only intermediary derivative; never DRMD/classes/markers/worlds.
donor=Path('/workspace/ungravity-v5/ufo-body-physics/build/cubic-client-final-flight-body-current-phase-sodium')
raw_name='libraries/com/mojang/minecraft/1.21.1/minecraft-1.21.1-client.jar'
donor_inputs=json.loads((donor/'inputs.json').read_text())
assert next(a['sha256'] for a in manifest['artifacts'] if a['path']==raw_name)==next(a['sha256'] for a in donor_inputs['artifacts'] if a['path']==raw_name)
assert module.digest(runtime/raw_name)==module.digest(donor/raw_name)
source=donor/'.fabric/remappedJars/minecraft-1.21.1-0.19.5/client-intermediary.jar';target=runtime/source.relative_to(donor)
with zipfile.ZipFile(source) as z:assert z.testzip() is None and not any(n.startswith('com/terminaldetector/') for n in z.namelist())
target.parent.mkdir(parents=True,exist_ok=True);os.link(source,target)
launch=runtime/'launch.json';argv=json.loads(launch.read_text());argv.insert(1,'-Ddrmd.gate.gravityInputRoute=true');launch.write_text(json.dumps(argv,indent=2)+'\n')
manifest.update(sourceSha=receipt['source'],candidateJars=receipt['jars'],observerProperty='drmd.gate.gravityInputRoute=true',scenario='native-gravity-input-first-gl32',glOverride='3.2/150',officialStagerSha256=module.digest(ROOT/'scripts/v5/prepare_cubic_client.py'),derivedMinecraftCache={'source':str(source),'sha256':module.digest(source),'scope':'verified Minecraft intermediary only, equal official raw inputs, no DRMD/classes/saves/markers borrowed'})
(runtime/'inputs.json').write_text(json.dumps(manifest,indent=2)+'\n');(at/'runtime-inputs.json').write_text((runtime/'inputs.json').read_text());(at/'launch.json').write_text(launch.read_text())
assert not (runtime/'gravity-input-route-ok.json').exists() and not (runtime/'gravity-input-route-failed.json').exists()
print('Fresh gravity-inputcheck staged; candidate JARs and immutable libraries/Minecraft cache verified')
