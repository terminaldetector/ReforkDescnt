package com.terminaldetector.drmd.entity;

import com.terminaldetector.drmd.DescentMod;
import com.terminaldetector.drmd.ai.AiRole;
import com.terminaldetector.drmd.ai.BombardVillageGoal;
import com.terminaldetector.drmd.ai.DroneAi;
import com.terminaldetector.drmd.ai.HostileEnvironment;
import com.terminaldetector.drmd.weapon.core.DamageClass;
import com.terminaldetector.drmd.weapon.core.WeaponCore;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.goal.LookAtEntityGoal;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.data.TrackedDataHandlerRegistry;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

/**
 * Enemy drone — port of D6_BuildDrone / SpawnEnemyDrone with role loadouts.
 */
public class DroneEntity extends HostileEntity {
	private static final TrackedData<String> ROLE = DataTracker.registerData(DroneEntity.class, TrackedDataHandlerRegistry.STRING);
	private static final TrackedData<Float> SHIELD = DataTracker.registerData(DroneEntity.class, TrackedDataHandlerRegistry.FLOAT);
	private static final TrackedData<Float> ARMOR = DataTracker.registerData(DroneEntity.class, TrackedDataHandlerRegistry.FLOAT);
	private static final TrackedData<Float> FLIGHT_ROLL = DataTracker.registerData(DroneEntity.class, TrackedDataHandlerRegistry.FLOAT);

	private AiRole role = AiRole.ASSAULT;
	private float shield;
	private float armor;
	private float modEnergy = 100f;
	private float attackCooldown;
	private DroneAi.Phase phase = DroneAi.Phase.ORBIT;
	private float phaseTimer;
	private float resistK, resistE, resistX;
	private boolean ragdollSpawned;

	public DroneEntity(EntityType<? extends DroneEntity> type, World world) {
		super(type, world);
		this.setNoGravity(true);
		applyRole(AiRole.ASSAULT);
	}

	public static DefaultAttributeContainer.Builder createDroneAttributes() {
		return HostileEntity.createHostileAttributes()
				.add(EntityAttributes.GENERIC_MAX_HEALTH, 200)
				.add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.5)
				.add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 10)
				.add(EntityAttributes.GENERIC_FOLLOW_RANGE, 96)
				.add(EntityAttributes.GENERIC_FLYING_SPEED, 0.8);
	}

	public void applyRole(AiRole role) {
		this.role = role;
		this.shield = role.shield;
		this.armor = role.armor;
		this.resistK = role.resistKinetic;
		this.resistE = role.resistEnergy;
		this.resistX = role.resistExplosive;
		if (!getWorld().isClient) {
			getAttributeInstance(EntityAttributes.GENERIC_MAX_HEALTH).setBaseValue(role.hullHp);
			setHealth(role.hullHp);
			dataTracker.set(ROLE, role.id);
			dataTracker.set(SHIELD, shield);
			dataTracker.set(ARMOR, armor);
		}
	}

	protected AiRole defaultRole(){return AiRole.ASSAULT;}

    /** Goal input before navigation; generic drones keep their existing direct steering. */
    public Vec3d steerFlightVelocity(Vec3d desired){return desired;}
    public boolean continuousFlightSteering(){return false;}
	public AiRole getRole() { return getWorld().isClient ? AiRole.fromId(dataTracker.get(ROLE)) : role; }
	public float getDroneShield() { return getWorld().isClient ? dataTracker.get(SHIELD) : shield; }
	public float getDroneArmor() { return getWorld().isClient ? dataTracker.get(ARMOR) : armor; }
	public float getFlightRoll() { return dataTracker.get(FLIGHT_ROLL); }
	public void setFlightRoll(float roll) {
		if (!getWorld().isClient) dataTracker.set(FLIGHT_ROLL, roll);
	}

	@Override
	protected void initDataTracker(DataTracker.Builder builder) {
		super.initDataTracker(builder);
		builder.add(ROLE, AiRole.ASSAULT.id);
		builder.add(SHIELD, 50f);
		builder.add(ARMOR, 0f);
		builder.add(FLIGHT_ROLL, 0f);
	}

	@Override
	protected void initGoals() {
		// Bombers climb the settlement before dogfighting random livestock.
		this.goalSelector.add(0, new BombardVillageGoal(this));
		this.goalSelector.add(1, new DroneAi.CombatGoal(this));
        this.goalSelector.add(2, new com.terminaldetector.drmd.ai.SquadInvestigateGoal(this));
		this.goalSelector.add(8, new LookAtEntityGoal(this, LivingEntity.class, 24f));
		HostileEnvironment.installTargets(this, this.targetSelector);
	}

	@Override
	public void tick() {
		super.tick();
		this.setNoGravity(true);
        com.terminaldetector.drmd.ai.DroneSquadCoordinator.tick(this);
		if (!getWorld().isClient) {
			if(ragdollSpawned&&!isAlive())setInvisible(true);
			modEnergy = Math.min(100f, modEnergy + 20f / 20f);
			if (attackCooldown > 0) attackCooldown -= 1f / 20f;
			dataTracker.set(SHIELD, shield);
			dataTracker.set(ARMOR, armor);
			// Passive shield regen for roles with ShieldGen (heavy_elite / support)
			if ((role == AiRole.HEAVY_ELITE || role == AiRole.SUPPORT) && age % 20 > 10) {
				shield = Math.min(role.shield, shield + 8f / 20f);
			}
		}
	}

	@Override
	public boolean damage(DamageSource source, float amount) {
		DamageClass cls = DamageClass.KINETIC;
		String name = source.getName();
		if (name.contains("magic") || name.contains("lightning")) cls = DamageClass.ENERGY;
		else if (name.contains("explosion")) cls = DamageClass.EXPLOSIVE;

		float resist = switch (cls) {
			case KINETIC -> resistK;
			case ENERGY, EXOTIC -> resistE;
			case EXPLOSIVE -> resistX;
		};
		resist = Math.min(0.9f, Math.max(0f, resist));
		amount *= (1f - resist);

		// Shield → Armor → Hull
		if (shield > 0) {
			float abs = Math.min(shield, amount);
			shield -= abs;
			amount -= abs;
		}
		if (amount > 0 && armor > 0) {
			float abs = Math.min(armor, amount);
			armor -= abs;
			amount -= abs;
		}
		if (amount <= 0) {
			this.scheduleVelocityUpdate();
			return false;
		}
		return super.damage(source, amount);
	}

	@Override
	public void onDeath(DamageSource damageSource) {
		super.onDeath(damageSource);
		if (getWorld().isClient) return;
		if (!ragdollSpawned) {
			ragdollSpawned = true;
			RagdollEntity.spawnFromDrone(this, damageSource);
			// Vanilla keeps a dead mob around for its death animation. The physical replacement owns the
			// visible motion now, so do not draw both bodies on top of each other for twenty ticks.
			setInvisible(true);
		}
		// Descent shield/energy orbs — heavier roles drop more often.
		float shieldChance = switch (role) {
			case HEAVY_ELITE, HEAVY -> 0.55f;
			case ARTILLERY, RPG, SEEKER -> 0.35f;
			default -> 0.22f;
		};
		float energyChance = 0.18f + shieldChance * 0.25f;
		com.terminaldetector.drmd.pickup.EnemyDrops.onDroneDeath(this, damageSource, shieldChance, energyChance);
		if (role == AiRole.HEAVY_ELITE && random.nextFloat() < 0.35f) {
			if (getWorld() instanceof ServerWorld sw) {
				WeaponCore.splashDamage(this, sw, getPos(), 200f, (float) DescentMod.su(340), DamageClass.EXPLOSIVE);
				com.terminaldetector.drmd.network.ModNetworking.shotFx(sw,getPos(),0xffc878,.65f,true);
			}
		}
	}

	public boolean tryFireAt(LivingEntity target) {
		if (attackCooldown > 0 || target == null) return false;
		if (modEnergy < role.weaponCost) return false;
		modEnergy -= role.weaponCost;
		attackCooldown = role.weaponCooldown;

		Vec3d from = getPos().add(0, getHeight() * 0.5, 0);
		Vec3d dir = target.getBoundingBox().getCenter().subtract(from).normalize();

		WeaponCore.FireConfig cfg = new WeaponCore.FireConfig();
		cfg.owner = this;
		cfg.pos = from;
		cfg.dir = dir;
		cfg.speed = role.weaponSpeed;
		cfg.directDamage = role.weaponDamage;
		cfg.splashDamage = role.weaponSplash;
		cfg.splashRadius = role.weaponSplashRadius;
		cfg.dmgClass = role.weaponClass;
		cfg.homing = role.weaponHoming;
		cfg.homeTarget = role.weaponHoming ? target : null;
		cfg.life = 4f;
		cfg.worldBlast = role.villageBomber || role.weaponClass == DamageClass.EXPLOSIVE;
		cfg.meshKind = role.weaponClass == DamageClass.EXPLOSIVE
				? ProjectileEntity.MESH_ROCKET
				: ProjectileEntity.MESH_BOLT;
		WeaponCore.fireProjectile(cfg);
		return true;
	}

	public DroneAi.Phase getPhase() { return phase; }
	public void setPhase(DroneAi.Phase p) { this.phase = p; this.phaseTimer = 0; }
	public float getPhaseTimer() { return phaseTimer; }
	public void addPhaseTimer(float dt) { phaseTimer += dt; }
	public float getModEnergy() { return modEnergy; }

	@Override
	public void writeCustomDataToNbt(NbtCompound nbt) {
		super.writeCustomDataToNbt(nbt);
		nbt.putString("role", role.id);
		nbt.putFloat("shield", shield);
		nbt.putFloat("armor", armor);
        nbt.putFloat("modEnergy",modEnergy);
        nbt.putFloat("attackCooldown",Math.max(0,attackCooldown));
        nbt.putFloat("flightRoll",net.minecraft.util.math.MathHelper.wrapDegrees(getFlightRoll()));
        nbt.putString("aiPhase",phase.name());nbt.putFloat("aiPhaseTime",phaseTimer);
	}

	@Override
	public void readCustomDataFromNbt(NbtCompound nbt) {
		super.readCustomDataFromNbt(nbt);
		float savedHealth=getHealth();
		applyRole(AiRole.fromId(nbt.getString("role"),defaultRole()));
		if(nbt.contains("Health",net.minecraft.nbt.NbtElement.NUMBER_TYPE))setHealth(savedHealth);
		if(nbt.contains("shield",net.minecraft.nbt.NbtElement.NUMBER_TYPE))shield=nbt.getFloat("shield");
		if(nbt.contains("armor",net.minecraft.nbt.NbtElement.NUMBER_TYPE))armor=nbt.getFloat("armor");
        modEnergy=stateFloat(nbt,"modEnergy",100,0,100);
        attackCooldown=stateFloat(nbt,"attackCooldown",0,0,Math.max(0,role.weaponCooldown));
        setFlightRoll(net.minecraft.util.math.MathHelper.wrapDegrees(stateFloat(nbt,"flightRoll",0,-Float.MAX_VALUE,Float.MAX_VALUE)));
        try{phase=DroneAi.Phase.valueOf(nbt.getString("aiPhase"));phaseTimer=stateFloat(nbt,"aiPhaseTime",0,0,Float.MAX_VALUE);}
        catch(IllegalArgumentException unknown){phase=DroneAi.Phase.ORBIT;phaseTimer=0;}
        // Dead drones have already handed visual ownership to their physical corpse.
        // This also repairs old saves whose transient invisible flag was not stored.
        ragdollSpawned=getHealth()<=0;
        if(ragdollSpawned)setInvisible(true);
		if(!getWorld().isClient) {
			dataTracker.set(SHIELD,shield);dataTracker.set(ARMOR,armor);
		}
	}
    private static float stateFloat(NbtCompound tag,String key,float fallback,float min,float max) {
        if(!tag.contains(key,net.minecraft.nbt.NbtElement.NUMBER_TYPE))return fallback;
        float value=tag.getFloat(key);return Float.isFinite(value)?net.minecraft.util.math.MathHelper.clamp(value,min,max):fallback;
    }
}
