from pathlib import Path
import hashlib,json,os,subprocess,time,sys,shutil

ROOT=Path(__file__).resolve().parents[2]
SOURCE='f4a03f76d7b327ebb008d8cda30529313ba3e127'
stage=ROOT/'work/point-defense/first-negative-f4a03f7'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==SOURCE
assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=ROOT,text=True)
assert not (ROOT/'build/gametest/world').exists()
assert not stage.exists()
stage.mkdir()
files=['work/point-defense/focus-negative.init.gradle','build.gradle','gradle.properties',
       'docs/v8/POINT_DEFENSE_INTERCEPTION_CONTRACT_2026-11-17.md',
       'src/gametest/java/com/terminaldetector/drmd/PointDefenseInterceptionGameTests.java',
       'src/gametest/java/com/terminaldetector/drmd/AiFixtureChunks.java',
       'src/main/java/com/terminaldetector/drmd/world/trap/DefenseTurrets.java',
       'src/main/java/com/terminaldetector/drmd/entity/ProjectileEntity.java',
       'src/main/java/com/terminaldetector/drmd/weapon/core/WeaponCore.java',
       'src/main/java/com/terminaldetector/drmd/weapon/core/InterceptAim.java',
       'src/main/java/com/terminaldetector/drmd/weapon/projectile/ProjectileFramework.java',
       'src/main/java/com/terminaldetector/drmd/world/edit/WorldEditSafety.java']
inputs={'source':SOURCE,'startTimeNs':time.time_ns(),'executingRunnerSha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'sha256ByFile':{n:hashlib.sha256((ROOT/n).read_bytes()).hexdigest() for n in files},
        'scope':'FIRST2 stock natural scheduled point-defense baseline. Actual factory missile, normal ticks; no production changes/native/fullS12 claim.'}
(stage/'inputs.json').write_text(json.dumps(inputs,indent=2)+'\n')
(stage/'executed-runner.py').write_bytes(Path(__file__).read_bytes())
for n in files:
    q=stage/'initial-source'/n;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes((ROOT/n).read_bytes())
previous=ROOT/'build/gametest/reports/gametest-results.xml'
if previous.exists():previous.unlink()
env=dict(os.environ,JAVA_HOME='/workspace/jdk21-complete',GRADLE_USER_HOME='/workspace/.gradle')
env['PATH']='/workspace/jdk21-complete/bin:'+env.get('PATH','')
command=['./gradlew','runGametest','--offline','--no-daemon','-I','work/point-defense/focus-negative.init.gradle']
(stage/'gametest-start.json').write_text(json.dumps({'source':SOURCE,'startTimeNs':time.time_ns(),'command':command},indent=2)+'\n')
with (stage/'gametest.log').open('wb') as output:
    child=subprocess.Popen(command,cwd=ROOT,env=env,stdout=output,stderr=subprocess.STDOUT)
    code=child.wait()
# Actual child exit is recorded before copying/analyzing artifacts, including first build failure.
(stage/'gametest.exit').write_text(str(code)+'\n')
(stage/'gametest-exit.json').write_text(json.dumps({'source':SOURCE,'pid':child.pid,'exit':code,'closedTimeNs':time.time_ns()},indent=2)+'\n')
print('gametest FIRST CLOSED exit='+str(code),flush=True)
if previous.exists():
    target=stage/'gametest-xml';target.mkdir();shutil.copyfile(previous,target/previous.name)
else:(stage/'NO_XML.txt').write_text('No fresh GameTest XML existed when the first child closed. Preserve raw build/runtime log.\n')
raise SystemExit(code)
