from pathlib import Path
import hashlib,json,os,subprocess,time,sys
ROOT=Path(__file__).resolve().parents[2]
SOURCE='075c2c1931030b2d68fda06b2e9ed7fd06caa20a'
stage=ROOT/'work/drone-squad/first-narrow-075c2c1'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==SOURCE
assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=ROOT,text=True)
assert not (ROOT/'build/gametest/world').exists()
stage.mkdir()
files=['work/drone-squad/focus-fixed.init.gradle','build.gradle','gradle.properties','src/main/java/com/terminaldetector/drmd/ai/DroneSquadMailbox.java','src/main/java/com/terminaldetector/drmd/ai/DroneSquadCoordinator.java','src/main/java/com/terminaldetector/drmd/ai/SquadInvestigateGoal.java','src/main/java/com/terminaldetector/drmd/ai/DroneSwarmAi.java','src/main/java/com/terminaldetector/drmd/entity/DroneEntity.java','src/test/java/com/terminaldetector/drmd/DroneSquadMailboxTest.java','src/gametest/java/com/terminaldetector/drmd/DroneSquadTaskGameTests.java','src/gametest/java/com/terminaldetector/drmd/DroneSquadGuardGameTests.java','src/gametest/java/com/terminaldetector/drmd/SquadInvestigationTrace.java','src/main/java/com/terminaldetector/drmd/ai/DroneNavigation.java','src/gametest/java/com/terminaldetector/drmd/TypedCombatRouteGameTests.java','src/gametest/java/com/terminaldetector/drmd/SharedCombatPassageGameTests.java','src/gametest/java/com/terminaldetector/drmd/DroneCoverProbeGameTests.java']
inputs={'source':SOURCE,'startTimeNs':time.time_ns(),'executingRunnerSha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'sha256ByFile':{n:hashlib.sha256((ROOT/n).read_bytes()).hexdigest() for n in files},'scope':'first4pureMailboxunit cases then ifPASS20server cases(7new+13retained); no native/wholeS11 claim'}
(stage/'inputs.json').write_text(json.dumps(inputs,indent=2)+'\n');(stage/'executed-runner.py').write_bytes(Path(__file__).read_bytes())
for n in files:
 q=stage/'initial-source'/n;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes((ROOT/n).read_bytes())
env=dict(os.environ,JAVA_HOME='/workspace/jdk21-complete',GRADLE_USER_HOME='/workspace/.gradle');env['PATH']='/workspace/jdk21-complete/bin:'+env.get('PATH','')
commands=[('unit',['./gradlew','test','--tests','com.terminaldetector.drmd.DroneSquadMailboxTest','--offline','--no-daemon']),('gametest',['./gradlew','runGametest','--offline','--no-daemon','-I','work/drone-squad/focus-fixed.init.gradle'])]
for label,command in commands:
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==SOURCE
 (stage/(label+'-start.json')).write_text(json.dumps({'source':SOURCE,'startTimeNs':time.time_ns(),'command':command},indent=2)+'\n')
 with (stage/(label+'.log')).open('wb') as output:
  child=subprocess.Popen(command,cwd=ROOT,env=env,stdout=output,stderr=subprocess.STDOUT);code=child.wait()
 (stage/(label+'.exit')).write_text(str(code)+'\n')
 (stage/(label+'-exit.json')).write_text(json.dumps({'source':SOURCE,'pid':child.pid,'exit':code,'closedTimeNs':time.time_ns()},indent=2)+'\n')
 print(label+' FIRST CLOSED exit='+str(code),flush=True)
 if code:raise SystemExit(code)
